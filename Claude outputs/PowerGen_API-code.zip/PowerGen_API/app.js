require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const path = require('path');
const fs = require('fs');
const { createServer } = require('http');
const { Server } = require('socket.io');
const cron = require('node-cron');


try {
  const logger = require('./utils/logger');
  const errorHandler = require('./middlewares/errorMiddleware');

  // ========== IMPORT ALL ROUTES ==========
  const authRoutes = require('./routes/authRoutes');
  const generatorRoutes = require('./routes/generatorRoutes');
  const towerRoutes = require('./routes/towerRoutes');
  const telemetryRoutes = require('./routes/telemetryRoutes');
  const maintenanceRoutes = require('./routes/maintenanceRoutes');
  const dashboardRoutes = require('./routes/dashboard');
  const partsRoutes = require('./routes/partRoutes');
  const clusterRoutes = require('./routes/clusterRoutes');
  const outageRoutes = require('./routes/outagesRoutes');
  const acUnitRoutes = require('./routes/acUnitsRoutes');
  const powerSystemRoutes = require('./routes/powerSystemsRoutes');
  const generatorUpdateRoutes = require('./routes/generatorUpdateRoutes');
  const sitesRoutes = require('./routes/siteRoutes');
  const supervisorRoutes = require('./routes/supervisor');
  const technicianRoutes = require('./routes/technicians');
  const validationRoutes = require('./routes/validationUploadRoutes');
  console.log('technicianRoutes type:', typeof technicianRoutes, 'isFunction:', typeof technicianRoutes === 'function');
  const protectedRoutes = require('./routes/protectedRoutes');
  // const technicianSiteAuditRoutes = require('./routes/technicianSiteAuditRoutes');

  // ========== NEW ROUTES ==========
  const fuelRoutes = require('./routes/fuelRoutes');
  console.log('fuelRoutes type:', typeof fuelRoutes, 'isFunction:', typeof fuelRoutes === 'function');
  const dieselManagerRoutes = require('./routes/dieselManagerRoutes');
  console.log('dieselManagerRoutes type:', typeof dieselManagerRoutes, 'isFunction:', typeof dieselManagerRoutes === 'function');
  const dataCollectorRoutes = require('./routes/dataCollectorRoutes');
  console.log('dataCollectorRoutes type:', typeof dataCollectorRoutes, 'isFunction:', typeof dataCollectorRoutes === 'function');
  const geminiRoutes = require('./routes/geminiRoutes');
  console.log('geminiRoutes type:', typeof geminiRoutes, 'isFunction:', typeof geminiRoutes === 'function');
  const adminRoutes = require('./routes/adminRoutes');
  console.log('adminRoutes type:', typeof adminRoutes, 'isFunction:', typeof adminRoutes === 'function');
  const aiAssistantRoutes = require('./routes/aiAssistantRoutes');
  console.log('aiAssistantRoutes type:', typeof aiAssistantRoutes, 'isFunction:', typeof aiAssistantRoutes === 'function');
  const uploadRoutes = require('./routes/uploadRoutes');
  console.log('uploadRoutes type:', typeof uploadRoutes, 'isFunction:', typeof uploadRoutes === 'function');
  const operationsRoutes = require('./routes/operationsRoutes');
  console.log('operationsRoutes type:', typeof operationsRoutes, 'isFunction:', typeof operationsRoutes === 'function');

  // ========== DIESEL RECONCILIATION SYSTEM ROUTES ==========
  const dieselCmsUploadRoutes = require('./routes/cmsUploadRoutes');
  console.log('dieselCmsUploadRoutes type:', typeof dieselCmsUploadRoutes, 'isFunction:', typeof dieselCmsUploadRoutes === 'function');
  const dieselTankLevelRoutes = require('./routes/tankLevelRoutes');
  console.log('dieselTankLevelRoutes type:', typeof dieselTankLevelRoutes, 'isFunction:', typeof dieselTankLevelRoutes === 'function');
  const dieselTomCardCycleBudgetRoutes = require('./routes/tomCardCycleBudgetRoutes');
  console.log('dieselTomCardCycleBudgetRoutes type:', typeof dieselTomCardCycleBudgetRoutes, 'isFunction:', typeof dieselTomCardCycleBudgetRoutes === 'function');
  const dieselSitesMapRoutes = require('./routes/sitesMapRoutes');
  console.log('dieselSitesMapRoutes type:', typeof dieselSitesMapRoutes, 'isFunction:', typeof dieselSitesMapRoutes === 'function');
  const technicianTrackingRoutes = require('./routes/technicianTrackingRoutes');
  console.log('technicianTrackingRoutes type:', typeof technicianTrackingRoutes, 'isFunction:', typeof technicianTrackingRoutes === 'function');
  const routeOptimizationRoutes = require('./routes/routeOptimizationRoutes');
  console.log('routeOptimizationRoutes type:', typeof routeOptimizationRoutes, 'isFunction:', typeof routeOptimizationRoutes === 'function');
  const theftInvestigationRoutes = require('./routes/theftInvestigationRoutes');
  console.log('theftInvestigationRoutes type:', typeof theftInvestigationRoutes, 'isFunction:', typeof theftInvestigationRoutes === 'function');
  const budgetPlanningRoutes = require('./routes/budgetPlanningRoutes');
  console.log('budgetPlanningRoutes type:', typeof budgetPlanningRoutes, 'isFunction:', typeof budgetPlanningRoutes === 'function');
  const aiInsightsRoutes = require('./routes/aiInsightsRoutes');
  console.log('aiInsightsRoutes type:', typeof aiInsightsRoutes, 'isFunction:', typeof aiInsightsRoutes === 'function');
  const historicalDataRoutes = require('./routes/historicalDataRoutes');
  console.log('historicalDataRoutes type:', typeof historicalDataRoutes, 'isFunction:', typeof historicalDataRoutes === 'function');
  const stockRoutes = require('./routes/stockRoutes');
  console.log('stockRoutes type:', typeof stockRoutes, 'isFunction:', typeof stockRoutes === 'function');
  const dataSourceComparisonRoutes = require('./routes/dataSourceComparisonRoutes');
  console.log('dataSourceComparisonRoutes type:', typeof dataSourceComparisonRoutes, 'isFunction:', typeof dataSourceComparisonRoutes === 'function');
  const dieselGratoUploadRoutes = require('./routes/gratoUploadRoutes');
  console.log('dieselGratoUploadRoutes type:', typeof dieselGratoUploadRoutes, 'isFunction:', typeof dieselGratoUploadRoutes === 'function');
  const dieselTomCardRoutes = require('./routes/tomCardRoutes');
  console.log('dieselTomCardRoutes type:', typeof dieselTomCardRoutes, 'isFunction:', typeof dieselTomCardRoutes === 'function');
  const dieselReconciliationRoutes = require('./routes/reconciliationRoutes');
  console.log('dieselReconciliationRoutes type:', typeof dieselReconciliationRoutes, 'isFunction:', typeof dieselReconciliationRoutes === 'function');
  const dieselAlertRoutes = require('./routes/alertRoutes');
  console.log('dieselAlertRoutes type:', typeof dieselAlertRoutes, 'isFunction:', typeof dieselAlertRoutes === 'function');
  const dieselDashboardRoutes = require('./routes/dashboardRoutes');
  console.log('dieselDashboardRoutes type:', typeof dieselDashboardRoutes, 'isFunction:', typeof dieselDashboardRoutes === 'function');
  const {
    reportRoutes: dieselReportRoutes,
    generatorLedgerRoutes: dieselGeneratorLedgerRoutes,
    siteBudgetRoutes: dieselSiteBudgetRoutes,
    fieldVisitRoutes: dieselFieldVisitRoutes,
    dieselCycleRoutes,
    notificationRoutes: dieselNotificationRoutes,
  } = require('./routes/otherRoutes');
  const siteBudgetUploadRoutes = require('./routes/siteBudgetUploadRoutes');
  console.log('dieselReportRoutes type:', typeof dieselReportRoutes, 'isFunction:', typeof dieselReportRoutes === 'function');
  console.log('dieselGeneratorLedgerRoutes type:', typeof dieselGeneratorLedgerRoutes, 'isFunction:', typeof dieselGeneratorLedgerRoutes === 'function');
  console.log('dieselSiteBudgetRoutes type:', typeof dieselSiteBudgetRoutes, 'isFunction:', typeof dieselSiteBudgetRoutes === 'function');
  console.log('dieselFieldVisitRoutes type:', typeof dieselFieldVisitRoutes, 'isFunction:', typeof dieselFieldVisitRoutes === 'function');
  console.log('dieselCycleRoutes type:', typeof dieselCycleRoutes, 'isFunction:', typeof dieselCycleRoutes === 'function');
  console.log('dieselNotificationRoutes type:', typeof dieselNotificationRoutes, 'isFunction:', typeof dieselNotificationRoutes === 'function');

  const { sendDailyDigest } = require('./services/emailNotificationService');

  // ========== SERVICES ==========
  require('./services/reminderService');

  const app = express();
  const server = createServer(app);

  // Socket.IO setup
  const io = new Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST'],
    }
  });

  // ========== UPLOADS PATH ==========
  // On Render: UPLOADS_PATH=/var/data/uploads (persistent disk)
  // Locally:   falls back to <project_root>/uploads
  const UPLOADS_PATH = process.env.UPLOADS_PATH || path.join(__dirname, 'uploads');

  // Ensure base upload dirs exist on startup (important on Render first boot)
  ['', 'temp', 'attachments', 'justifications', 'cms', 'grato', 'tomcard'].forEach((sub) => {
    fs.mkdirSync(path.join(UPLOADS_PATH, sub), { recursive: true });
  });

  console.log(`✓ Uploads path: ${UPLOADS_PATH}`);

  // ========== MIDDLEWARE ==========
  // 1. CORS (MUST BE FIRST)
  app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  }));

  app.use(cookieParser());
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: false, // Allow cross-origin resource loading
  }));

  app.use(compression());

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10000,
    message: {
      error: 'Too many requests from this IP, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
  });
  app.use(limiter);

  // Static files
  app.use('/public', express.static('public'));

  // ✅ Shared CORS middleware for all upload static routes
  const uploadCorsMiddleware = (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
  };

  // ✅ Serve uploads from the persistent disk path (absolute, not relative)
  //    /uploads/temp/* → UPLOADS_PATH/temp/
  //    /uploads/*      → UPLOADS_PATH/
  app.use('/uploads/temp', uploadCorsMiddleware, express.static(path.join(UPLOADS_PATH, 'temp')));
  app.use('/uploads', uploadCorsMiddleware, express.static(UPLOADS_PATH));

  // Health check
  app.get('/health', (req, res) => {
    res.status(200).json({
      status: 'OK',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      uploadsPath: UPLOADS_PATH,
      services: {
        database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
        socketio: 'active',
      }
    });
  });

  // Request logging
  app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
      console.log(`${req.method} ${req.path}`, {
        body: req.body && Object.keys(req.body).length > 0 ? Object.keys(req.body) : 'empty',
        hasAuth: !!req.headers.authorization,
        contentType: req.headers['content-type'],
        origin: req.headers.origin,
      });
    }
    next();
  });

  // ========== API ROUTES ==========
  // Core routes
  app.use('/api/auth', authRoutes);
  app.use('/api/upload', uploadRoutes);
  app.use('/api/dashboard', dashboardRoutes);
  app.use('/api/generators', generatorRoutes);
  app.use('/api/towers', towerRoutes);
  app.use('/api/telemetry', telemetryRoutes);
  app.use('/api/maintenance', maintenanceRoutes);
  app.use('/api/parts', partsRoutes);
  app.use('/api/clusters', clusterRoutes);
  app.use('/api/outages', outageRoutes);
  app.use('/api/ac-units', acUnitRoutes);
  app.use('/api/power-systems', powerSystemRoutes);
  app.use('/api/generator-updates', generatorUpdateRoutes);
  app.use('/api/protected', protectedRoutes);
  app.use('/api/sites', sitesRoutes);
  app.use('/api/supervisor', supervisorRoutes);

  app.use('/api/refuel-workflow', require('./routes/refuelWorkflowRoutes'));

  // Technician Site Audit API
  const technicianSiteAuditRoutes = require('./routes/technicianSiteAuditRoutes');
  app.use('/api/technician', technicianSiteAuditRoutes);
  // Tank Audit API — see SITE TANK AUDIT PLAN
  const tankAuditRoutes = require('./routes/tankAuditRoutes');
  app.use('/api/technician', tankAuditRoutes);
  app.use('/api/technician', technicianRoutes);
  app.use('/api/validation', validationRoutes);
  app.use('/api/technician/fuel-purchases', require('./routes/fuelPurchaseRoutes'));

  // ========== NEW ROLE-SPECIFIC ROUTES ==========
  app.use('/api/fuel', fuelRoutes);
  app.use('/api/diesel-manager', dieselManagerRoutes);
  app.use('/api/diesel', dieselManagerRoutes);
  app.use('/api/data-collector', dataCollectorRoutes);
  app.use('/api/intelligence', geminiRoutes);
  app.use('/api/admin', adminRoutes);
  app.use('/api/ai-assistant', aiAssistantRoutes);
  app.use('/api/operations', operationsRoutes);

  // (Refuel Workflow API already mounted above at '/api/refuel-workflow' —
  // removed a literal duplicate require+mount that was here; it was dead
  // code, never reachable, since Express resolves middleware in
  // registration order and the first mount always wins.)

  // ========== DIESEL RECONCILIATION SYSTEM ROUTES ==========
  // ── PRIMARY diesel reconciliation routes (/api/diesel-recon/*) ────────────
  // Kept separate from /api/diesel to avoid shadowing the existing
  // dieselManagerRoutes (fuel-request workflow). New frontend pages use
  // /api/diesel-recon/* via dieselApi.ts.
  const DIESEL_RECON_BASE = '/api/diesel-recon';
  app.use(`${DIESEL_RECON_BASE}/cms`,              dieselCmsUploadRoutes);
  app.use(`${DIESEL_RECON_BASE}/tank-level`,        dieselTankLevelRoutes);
  app.use(`${DIESEL_RECON_BASE}/tomcard-cycle-budget`, dieselTomCardCycleBudgetRoutes);
  app.use(`${DIESEL_RECON_BASE}/sites-map`, dieselSitesMapRoutes);
  app.use(`${DIESEL_RECON_BASE}/technician-tracking`, technicianTrackingRoutes);
  app.use(DIESEL_RECON_BASE, routeOptimizationRoutes);
  app.use(`${DIESEL_RECON_BASE}/theft-investigation`, theftInvestigationRoutes);
  app.use(`${DIESEL_RECON_BASE}/budget-plan`, budgetPlanningRoutes);
  app.use(`${DIESEL_RECON_BASE}/ai-insights`, aiInsightsRoutes);
  app.use(`${DIESEL_RECON_BASE}/historical`, historicalDataRoutes);
  app.use(`${DIESEL_RECON_BASE}/stock`, stockRoutes);
  app.use(`${DIESEL_RECON_BASE}/data-sources`, dataSourceComparisonRoutes);
  app.use(`${DIESEL_RECON_BASE}/grato`,            dieselGratoUploadRoutes);
  app.use(`${DIESEL_RECON_BASE}/tomcard`,          dieselTomCardRoutes);
  app.use(`${DIESEL_RECON_BASE}/reconciliation`,   dieselReconciliationRoutes);
  app.use(`${DIESEL_RECON_BASE}/alerts`,           dieselAlertRoutes);
  app.use(`${DIESEL_RECON_BASE}/dashboard`,        dieselDashboardRoutes);
  app.use(`${DIESEL_RECON_BASE}/reports`,          dieselReportRoutes);
  app.use(`${DIESEL_RECON_BASE}/generator-ledger`, dieselGeneratorLedgerRoutes);
  app.use(`${DIESEL_RECON_BASE}/site-budget`,      siteBudgetUploadRoutes);
  app.use(`${DIESEL_RECON_BASE}/field-visits`,     dieselFieldVisitRoutes);
  app.use(`${DIESEL_RECON_BASE}/cycles`,           dieselCycleRoutes);
  app.use(`${DIESEL_RECON_BASE}/notifications`,    dieselNotificationRoutes);

  // ── ALIAS mounts (short paths) ──────────────────────────────────────────
  // The existing frontend diesel pages (DashboardPage, LowFuelAlertsPage,
  // ScheduledPage, etc.) use an older API client that hits short paths like
  // /api/cycles, /api/cms, /api/grato. These aliases make those calls resolve
  // without requiring changes to every old page at once. They share the exact
  // same route handler instances — no duplicated logic.
  app.use('/api/cycles',           dieselCycleRoutes);
  app.use('/api/cms',              dieselCmsUploadRoutes);
  app.use('/api/tank-level',       dieselTankLevelRoutes);
  app.use('/api/tomcard-cycle-budget', dieselTomCardCycleBudgetRoutes);
  app.use('/api/sites-map', dieselSitesMapRoutes);
  app.use('/api/technician-tracking', technicianTrackingRoutes);
  app.use('/api', routeOptimizationRoutes);
  app.use('/api/theft-investigation', theftInvestigationRoutes);
  app.use('/api/budget-plan', budgetPlanningRoutes);
  app.use('/api/ai-insights', aiInsightsRoutes);
  app.use('/api/historical', historicalDataRoutes);
  app.use('/api/stock', stockRoutes);
  app.use('/api/data-sources', dataSourceComparisonRoutes);
  app.use('/api/grato',            dieselGratoUploadRoutes);
  app.use('/api/tomcard',          dieselTomCardRoutes);
  app.use('/api/reconciliation',   dieselReconciliationRoutes);
  app.use('/api/diesel-alerts',    dieselAlertRoutes);
  app.use('/api/alerts',           dieselAlertRoutes);          
  app.use('/api/recon-dashboard',  dieselDashboardRoutes);      
  app.use('/api/recon-reports',    dieselReportRoutes);
  app.use('/api/reports',          dieselReportRoutes);         
  app.use('/api/generator-ledger', dieselGeneratorLedgerRoutes);
  app.use('/api/site-budget',      siteBudgetUploadRoutes);
  app.use('/api/field-visits',     dieselFieldVisitRoutes);
  app.use('/api/diesel-notifications', dieselNotificationRoutes);

  // ── GRATO PowerGen Extensions ──────────────────────────────────────────────
  // These are new routes added on top of the existing system.
  // They use the individual route files already in /routes/ where possible.

  // Fuel planning prediction engine
  app.use('/api/fuel-planning',          require('./routes/fuelPlanningRoutes'));

  // Fuel request approval chain (6-level)
  app.use('/api/fuel-requests',          require('./routes/fuelRequestRoutes'));

  // Tom Card cluster transfers + deficit reconciliation
  app.use('/api/tomcard-transfers',      require('./routes/tomCardTransferRoutes'));

  // Site budget aggregate + utilisation (extends existing siteBudgetRoutes)
  //
  // ⚠️ FRAGILITY WARNING (found during audit, not fixed — currently NOT
  // causing wrong behavior, but is one careless edit away from silent
  // breakage): '/api/site-budget' is mounted TWICE with two DIFFERENT
  // router instances — this one, and siteBudgetUploadRoutes (mounted
  // above at line ~273: app.use('/api/site-budget', siteBudgetUploadRoutes)).
  // Express tries the FIRST mount's routes before falling through to the
  // second. Right now their route paths don't overlap:
  //   siteBudgetUploadRoutes.js: POST /, POST /preview, GET /status/:cycle_key
  //   routes/siteBudgetRoutes.js: GET /:cycle_key(/aggregate|/utilisation|/:site_id), PATCH /:cycle_key/:site_id
  // ...so both are currently reachable. But if anyone ever adds a
  // GET '/:cycle_key'-shaped route to siteBudgetUploadRoutes.js, it will
  // silently shadow this entire router for that path — no error, just
  // wrong/stale responses. Do not add such a route there; if these two
  // files' responsibilities keep growing, merge them into one router.
  app.use('/api/site-budget',            require('./routes/siteBudgetRoutes'));
  app.use('/api/site-budget-upload',     require('./routes/siteBudgetUploadRoutes'));

  // Audit log
  app.use('/api/audit',                  require('./routes/auditRoutes'));

  // Board PDF export
  app.use('/api/diesel/reports',         require('./routes/boardPdfRoutes'));

  // Set Socket.IO instance
  app.set('io', io);

  // 404 handler
  app.use('*path', (req, res) => {
    res.status(404).json({
      success: false,
      error: 'Not Found',
      message: `Route ${req.originalUrl} not found`,
      available_endpoints: {
        auth: '/api/auth/*',
        dashboard: '/api/dashboard/*',
        sites: '/api/sites/*',
        maintenance: '/api/maintenance/*',
        technician: '/api/technician/*',
        technician_site_audit: '/api/technician/site-audit',
        technician_site_audits: '/api/technician/site-audits',
        supervisor: '/api/supervisor/*',
        fuel: '/api/fuel/*',
        data_collector: '/api/data-collector/*',
        operations: '/api/operations/*',
        diesel_recon_cms: '/api/diesel-recon/cms/*  (alias: /api/cms/*)',
        diesel_recon_grato: '/api/diesel-recon/grato/*  (alias: /api/grato/*)',
        diesel_recon_tomcard: '/api/diesel-recon/tomcard/*  (alias: /api/tomcard/*)',
        diesel_recon_reconciliation: '/api/diesel-recon/reconciliation/*  (alias: /api/reconciliation/*)',
        diesel_recon_alerts: '/api/diesel-recon/alerts/*  (alias: /api/diesel-alerts/* or /api/alerts/*)',
        diesel_recon_dashboard: '/api/diesel-recon/dashboard/*  (alias: /api/recon-dashboard/*)',
        diesel_recon_reports: '/api/diesel-recon/reports/*  (alias: /api/recon-reports/* or /api/reports/*)',
        diesel_recon_generator_ledger: '/api/diesel-recon/generator-ledger/*  (alias: /api/generator-ledger/*)',
        diesel_recon_site_budget: '/api/diesel-recon/site-budget/*  (alias: /api/site-budget/*)',
        diesel_recon_field_visits: '/api/diesel-recon/field-visits/*  (alias: /api/field-visits/*)',
        diesel_recon_cycles: '/api/diesel-recon/cycles/*  (alias: /api/cycles/*)',
        diesel_recon_notifications: '/api/diesel-recon/notifications/*  (alias: /api/diesel-notifications/*)',
      }
    });
  });

  // Error handler
  app.use(errorHandler);

  // ========== DATABASE CONNECTION ==========
  const connectDB = async () => {
    try {
      const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/generator-management';

      await mongoose.connect(mongoURI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      });

      logger.info('MongoDB connected successfully');
      console.log('✓ MongoDB connected successfully');
    } catch (error) {
      logger.error('MongoDB connection error:', error);
      console.error('✗ MongoDB connection error:', error);
      process.exit(1);
    }
  };

  connectDB();

  // ========== CRON JOBS ==========
  // Daily diesel reconciliation digest email — 07:00 every day
  cron.schedule('0 7 * * *', async () => {
    logger.info('[Cron] Sending daily diesel digest');
    try {
      await sendDailyDigest();
    } catch (e) {
      logger.error('[Cron] Digest failed:', e);
    }
  });

  // ========== GRACEFUL SHUTDOWN ==========
  process.on('SIGTERM', () => {
    logger.info('SIGTERM received, shutting down gracefully');
    server.close(() => {
      logger.info('Process terminated');
      mongoose.connection.close(false, () => {
        logger.info('MongoDB connection closed');
        process.exit(0);
      });
    });
  });

  process.on('SIGINT', () => {
    logger.info('SIGINT received, shutting down gracefully');
    server.close(() => {
      logger.info('Process terminated');
      mongoose.connection.close(false, () => {
        logger.info('MongoDB connection closed');
        process.exit(0);
      });
    });
  });

  process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    logger.error('Uncaught Exception:', error);
    process.exit(1);
  });

  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    logger.error('Unhandled Rejection:', reason);
    process.exit(1);
  });

  // ========== SOCKET.IO HANDLERS ==========
  io.on('connection', (socket) => {
    console.log('Socket connected:', socket.id);

    socket.on('disconnect', () => {
      console.log('Socket disconnected:', socket.id);
    });

    socket.on('error', (error) => {
      console.error('Socket error:', error);
    });
  });

  // ========== START SERVER ==========
  const PORT = process.env.PORT || 5000;
  server.listen(PORT, '0.0.0.0', () => {
    logger.info(`Server running on port ${PORT}`);
    console.log('\n=================================');
    console.log('✓ Server running on port ' + PORT);
    console.log('✓ Environment: ' + (process.env.NODE_ENV || 'development'));
    console.log('✓ Listening on 0.0.0.0 (LAN enabled)');
    console.log('✓ Uploads path: ' + UPLOADS_PATH);
    console.log('✓ MongoDB: ' + (mongoose.connection.readyState === 1 ? 'Connected' : 'Connecting...'));
    console.log('✓ Socket.IO: Enabled');
    console.log('✓ Diesel reconciliation routes: /api/diesel-recon/* + short aliases (/api/cycles, /api/cms, etc.)');
    console.log('✓ Cron jobs: Daily diesel digest at 07:00');
    console.log('=================================\n');
  });

  module.exports = { app, server, io };

} catch (error) {
  console.error('Failed to start application:', error);
  console.error('Error stack:', error.stack);
  process.exit(1);
}

