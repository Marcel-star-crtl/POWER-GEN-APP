// utils/sendWhatsApp.js
//
// WhatsApp alerts via Twilio's WhatsApp API. Reuses the Cameroon
// phone-number formatting/validation already worked out in the
// (never-activated) utils/smsService.js, but fixes its worst flaw: that
// file threw at require-time if credentials were missing or malformed,
// which would crash the entire backend on startup just for an optional
// notification channel not being configured yet. This module instead
// disables itself gracefully — sendWhatsApp() becomes a safe no-op that
// logs why, so the rest of the app is completely unaffected by WhatsApp
// not being set up.
//
// Required env vars (all three, or the module stays disabled):
//   TWILIO_ACCOUNT_SID        — starts with "AC"
//   TWILIO_AUTH_TOKEN
//   TWILIO_WHATSAPP_FROM      — Twilio's WhatsApp-enabled sender number,
//                               e.g. "whatsapp:+14155238886" for the
//                               sandbox, or your own approved WhatsApp
//                               Business number once you have one.
//
// Setup: https://www.twilio.com/docs/whatsapp/quickstart/node — the
// sandbox number works for testing immediately; production requires
// WhatsApp Business approval through Twilio, which can take a few days.

const logger = require('./logger');

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const whatsappFrom = process.env.TWILIO_WHATSAPP_FROM;

function credentialsLookValid() {
  if (!accountSid || !accountSid.startsWith('AC')) return false;
  if (!authToken || authToken.length < 32) return false;
  if (!whatsappFrom || !whatsappFrom.startsWith('whatsapp:+')) return false;
  return true;
}

const ENABLED = credentialsLookValid();
let client = null;

if (ENABLED) {
  try {
    client = require('twilio')(accountSid, authToken);
    logger.info('[WhatsApp] Twilio client initialized — WhatsApp alerts are active.');
  } catch (err) {
    logger.error(`[WhatsApp] Twilio client failed to initialize (WhatsApp alerts disabled): ${err.message}`);
  }
} else {
  logger.info('[WhatsApp] TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN / TWILIO_WHATSAPP_FROM not fully configured — WhatsApp alerts are disabled. Set all three in .env to enable. See utils/sendWhatsApp.js for setup notes.');
}

/**
 * Formats a Cameroon phone number to E.164 (+237XXXXXXXXX), same
 * validation regex already established in utils/smsService.js.
 * @returns {string|null} formatted number, or null if genuinely invalid
 */
function formatCameroonNumber(phoneNumber) {
  if (!phoneNumber) return null;
  let formatted = phoneNumber.trim();
  if (!formatted.startsWith('+')) {
    formatted = formatted.startsWith('237') ? '+' + formatted : '+237' + formatted;
  }
  const phoneRegex = /^\+237[2368]\d{8}$/;
  return phoneRegex.test(formatted) ? formatted : null;
}

/**
 * Sends a WhatsApp message. Never throws — a failed or skipped send is
 * logged and returned as { success: false, reason }, since a
 * notification failing should never take down whatever business logic
 * triggered it (an alert not going out is bad; a fuel-request approval
 * or critical-alert flag failing to save because a WhatsApp send threw
 * would be much worse).
 *
 * @param {string} phoneNumber - Cameroon number, any reasonable format
 * @param {string} message
 * @returns {Promise<{success: boolean, messageId?: string, reason?: string}>}
 */
async function sendWhatsApp(phoneNumber, message) {
  if (!ENABLED || !client) {
    logger.info(`[WhatsApp] Skipped (not configured) — would have sent to ${phoneNumber}: "${message.slice(0, 60)}${message.length > 60 ? '…' : ''}"`);
    return { success: false, reason: 'whatsapp_not_configured' };
  }

  const formattedTo = formatCameroonNumber(phoneNumber);
  if (!formattedTo) {
    logger.warn(`[WhatsApp] Skipped — invalid phone number: ${phoneNumber}`);
    return { success: false, reason: 'invalid_phone_number' };
  }

  try {
    const result = await client.messages.create({
      from: whatsappFrom,
      to: `whatsapp:${formattedTo}`,
      body: message,
    });
    logger.info(`[WhatsApp] Sent to ${formattedTo}, SID: ${result.sid}`);
    return { success: true, messageId: result.sid };
  } catch (err) {
    logger.error(`[WhatsApp] Send failed to ${formattedTo}: ${err.message}`);
    return { success: false, reason: err.message };
  }
}

/**
 * Sends the same message to multiple recipients. Uses Promise.allSettled
 * so one bad number doesn't prevent the rest from sending.
 */
async function sendWhatsAppToMany(phoneNumbers, message) {
  const results = await Promise.allSettled(
    (phoneNumbers || []).filter(Boolean).map(p => sendWhatsApp(p, message))
  );
  return results.map(r => (r.status === 'fulfilled' ? r.value : { success: false, reason: r.reason?.message || 'unknown error' }));
}

module.exports = { sendWhatsApp, sendWhatsAppToMany, formatCameroonNumber, isEnabled: () => ENABLED };
