const mongoose = require('mongoose');

/**
 * SiteControllerLogSummary
 *
 * One row per raw site-controller log export the user supplied
 * ("GRATO-LOG-FILES.zip", uploaded 2026-09-17) — 48 files across 4
 * clusters (Bonaberi 1, Bonaberi 2, Kotto, Ndogbong), in three distinct
 * export formats from the sites' own power-system controllers/NMS, NOT
 * from this project's email-archive recovery effort. Deliberately a
 * separate collection from HistoricalMonthlyRecord: that collection is
 * GRATO's own signed-off Validation/Budget process, keyed by
 * `month_key`; this one is raw controller telemetry keyed by whatever
 * window each site's own export happened to retain (a fixed 200,000-row
 * cap for the "format A" sites means coverage ranges from under a day
 * to several months), cross-referenced against August 2026's Validation
 * data where the window overlaps, not replacing it.
 *
 * `archive_relpath` is the true unique key, not `site_id` — 3 of the 48
 * source files could not be matched to a real site (checked filename
 * and file content both; see `id_note`), so `site_id` is nullable and
 * NOT unique.
 *
 * Fuel consumption is deliberately NOT populated from these logs: every
 * "format A" site's fuel-flow signal is a flat, unmoving 0.0 across its
 * entire window (metering not wired/calibrated, not a real reading),
 * and "format B" sites only export a fuel-per-kWh efficiency ratio with
 * no matching daily energy figure to turn into a liters total — see
 * `dg_fuel_note` on every document for the specific reason. Only
 * generator runtime and mains/reliability figures are populated.
 *
 * `official_*` fields are a snapshot pulled from
 * scripts/historical_email_data/Aug2026_Validation.xlsx +
 * EstimatedBudget_Aug2026.xlsx at import time, for convenience — they
 * are NOT kept in sync if that source data changes later; re-run the
 * import to refresh them.
 */
const siteControllerLogSummarySchema = new mongoose.Schema({
  archive_relpath: { type: String, required: true, unique: true }, // e.g. "BONABERI1/Bodjongo_IHS_BNB_035.zip"

  site_id:             { type: String, index: true, default: null }, // IHS_XXX_NNN; null for the 3 unidentified files
  official_site_name:  String,
  official_cluster:    String, // from the official 164-site Validation list — use this, not archive_cluster_folder
  archive_cluster_folder: String, // the folder this file actually shipped in (BONABERI1/BONABERI2 are swapped vs. official_cluster — see cluster_label_mismatch)
  cluster_label_mismatch: { type: Boolean, default: false },

  id_resolution: { type: String, enum: ['from_filename', 'corrected', 'unidentified'], required: true },
  id_note: String, // reasoning, populated whenever id_resolution isn't a clean 'from_filename' match

  format: { type: String, enum: ['A', 'B', 'C'], required: true }, // A: raw ~7s signal dump; B: NMS perfmg/alarm bundle; C: 10-min snapshot

  window_start: Date,
  window_end: Date,
  coverage_days: Number,
  row_count: Number, // raw data volume in the source file, format-dependent meaning

  // ── Generator runtime — the one figure that DID cross-check reliably ──────
  dg_runtime_hours_window: Number, // total over the file's whole retained window
  aug2026_dg_runtime_hours: Number, // same, restricted to the Aug 2026 sub-window where the file covers it
  aug2026_days_covered: Number, // how many August days that sub-window actually spans
  official_genset_rh_per_day_aug: Number, // from Aug2026_Validation.xlsx, 'Genset RH/Day' column
  official_sbc_rh_per_day_aug: Number, // same sheet, 'SBC RH/Day' column

  // ── Fuel — deliberately not measurable from any file in this archive ──────
  dg_fuel_consumed_l_window: { type: Number, default: null },
  dg_fuel_note: String,

  // ── Cross-check snapshot from this project's own August 2026 records ──────
  official_approved_aug_cons_l: Number,
  official_sbc_submitted_cons_l: Number,
  official_aug_budget_l: Number,

  // ── Mains / reliability ─────────────────────────────────────────────────
  mains_hours_window: Number,
  mains_outage_hours_window: Number,
  mains_outage_count_window: Number,
  aug2026_mains_outage_hours: Number,
  aug2026_mains_outage_count: Number,
  llvd_hours_window: Number,
  aug2026_llvd_hours: Number,
  mains_note: String,

  alarm_counts: mongoose.Schema.Types.Mixed, // { by_severity, total, llvd_alarms, mains_related_alarms } - format B only; some severity tiers cap at exactly 12500 (export limit, not a real count - see Identity Issues sheet)
  dg_status_sample_distribution: mongoose.Schema.Types.Mixed, // format A only - event-sample counts, NOT time-weighted
  mains_status_sample_distribution: mongoose.Schema.Types.Mixed, // format A only - same caveat

  source_upload: { type: String, default: 'GRATO-LOG-FILES.zip (user-supplied, 2026-09-17)' },
}, { timestamps: true });

module.exports = mongoose.model('SiteControllerLogSummary', siteControllerLogSummarySchema);
