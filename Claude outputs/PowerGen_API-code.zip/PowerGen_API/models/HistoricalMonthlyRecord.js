const mongoose = require('mongoose');

/**
 * HistoricalMonthlyRecord
 *
 * Recovered from real operational email archives (December 2025 onward)
 * — the manual, spreadsheet-based validation/sign-off process this
 * organization was already running before this system existed, imported
 * as a genuine historical record rather than left buried in old email
 * threads.
 *
 * Deliberately a SEPARATE collection from CycleReconciliation, not
 * written into it directly: this data went through its own real-world
 * sign-off process (see `sign_off_status` and the source PDF filenames
 * this was cross-referenced against) and has its own provenance
 * (`source_file`, `source_version`) that's worth preserving distinctly
 * from what this system's own reconciliation engine computes going
 * forward. A site's history can show both a HistoricalMonthlyRecord
 * (validated, pre-system) and a CycleReconciliation (this system's own
 * computation) for the same month without either overwriting the other.
 *
 * One row per site per month. `budget_liters` is what was actually
 * requested/allocated (from the corresponding monthly Budget file, where
 * one was recovered); `final_consumption_l` is the validated,
 * signed-off actual consumption (from the Validation/Analysis sheet's
 * "Final Cons" column) — `reserve_liters = budget_liters -
 * final_consumption_l` is the answer to "was whatever was requested
 * actually exhausted, and if not, how much is left."
 */
const historicalMonthlyRecordSchema = new mongoose.Schema({
  site_id:    { type: String, required: true, index: true }, // IHS_ID_SITE
  site_name:  String,
  cluster:    String,
  region:     String,
  sbc:        String,
  topology:   String, // "Grid Gen" | "Gen Only" | "Hybrid Gen"

  month_key:  { type: String, required: true, index: true }, // "2025-12", "2026-01", etc.

  // ── Budget (requested) side — from the month's Budget file, where recovered ──
  budget_liters: Number,
  budget_xaf:    Number,
  budget_source_file: String, // which recovered file this came from, for audit

  // ── Reconciled (actual) side — from the Validation/Analysis sheet ──────────
  sbc_rh:                 Number, // field-submitted run-hours
  cms_rh:                 Number,
  final_rh:               Number, // the reconciled, signed-off run-hours actually used
  rh_variance:            Number, // CMS vs field
  final_dg_cph:           Number,
  sbc_consumption_l:      Number, // field-side consumption estimate
  final_consumption_l:    Number, // the reconciled, signed-off actual consumption — the "was it exhausted" figure
  consumption_variance_l: Number,
  fuel_qty_previously_l:  Number,
  fuel_qty_found_l:       Number,
  fuel_qty_added_l:       Number,
  fuel_qty_left_l:        Number,
  theft_liters:           Number, // explicit theft figure, where the source sheet flagged one
  gap_cph_variation:      String, // free-text comment from the source sheet, where present

  // ── Derived — the actual answer to the user's question ─────────────────────
  reserve_liters:  Number,  // budget_liters - final_consumption_l (null if either side is missing)
  fully_exhausted: Boolean, // final_consumption_l >= budget_liters (only computed when both sides exist)

  // ── Provenance — this data's real-world origin, not just a number ──────────
  source_file:       { type: String, required: true }, // e.g. "GRATO Validation TEMPLATE  Dec 2025 Vf.xlsx"
  source_version:    String, // "Vf" | "V2.0" | "V3.0" — which draft/final version this came from
  source_sheet:      String, // "Validation" | "Analysis"
  source_email_date: Date,
  sign_off_status:   { type: String, enum: ['signed_off', 'draft', 'pending_site_disputes', 'unknown'], default: 'unknown' },
  sign_off_verified: { type: Boolean, default: false }, // true only when an actual sign-off PDF was found and read — not inferred from the spreadsheet filename's version label alone
  sign_off_pdf_source: String, // the sign-off PDF's own filename, where one was found

  // ── From the "Analysis" sheet's comment columns (Phase 70) ──────────────────
  // Checked actual value distributions before adding these — not every
  // "100% filled" column turned out to be meaningful (e.g. "Site
  // Comment" is the literal number 0 for most sites, a placeholder, not
  // real text). These three genuinely vary and carry real information.
  needs_cms_investigation: Boolean, // "CMS Vs Field Comment" === "CMS Team to investigate" (vs "OK")
  dg_kva_source_used:      String,  // "DG Comment" — "OK" | "Use SBC DG KVA" | "Use IHS DG KVA"
  site_lifecycle_note:      String, // "Site Comment", only where it's real text (not the "0" placeholder) — e.g. "Site ID Changed", "New Site May-24"

  imported_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

historicalMonthlyRecordSchema.index({ site_id: 1, month_key: 1 }, { unique: true });
historicalMonthlyRecordSchema.index({ cluster: 1, month_key: 1 });

/** Chronological history for one site, oldest first — for trend charts. */
historicalMonthlyRecordSchema.statics.getSiteHistory = function (site_id) {
  return this.find({ site_id }).sort({ month_key: 1 }).lean();
};

module.exports = mongoose.model('HistoricalMonthlyRecord', historicalMonthlyRecordSchema);
