const mongoose = require('mongoose');

/**
 * MidCycleEstimateSnapshot
 *
 * A per-site "where do we stand" snapshot taken mid-cycle — found only
 * for March 2026 so far ("Grato Estimate to close 19 March cycle.xlsx").
 * Genuinely distinct from every other historical model: it combines
 * the site's initial budget, two rounds of emergency top-ups already
 * given, and what's actually been refueled so far, into one running
 * balance — a working document someone used to decide what else a site
 * needed before the cycle closed, not a formal reconciliation or
 * request/approval record.
 */
const midCycleEstimateSnapshotSchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  site_name: String,
  cluster:   String,
  region:    String,
  sbc:       String,
  topology:  String,

  month_key: { type: String, required: true, index: true },
  snapshot_date: Date, // this site's own "Date" value in the source — visit dates vary per site, not one fixed date for the whole file

  initial_budget_l: Number,
  first_extra_l:      Number,
  second_extra_l:       Number,
  combined_budget_l:      Number, // "Init + 1st Extra + 2nd Extra" — the source's own running total, not recomputed
  total_refuel_done_l:      Number,
  balance_l:                  Number, // combined_budget_l - total_refuel_done_l, per the source's own figure
  qty_left_l:                   Number,

  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('MidCycleEstimateSnapshot', midCycleEstimateSnapshotSchema);
