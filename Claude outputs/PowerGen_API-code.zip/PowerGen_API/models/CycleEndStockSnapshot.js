const mongoose = require('mongoose');

/**
 * CycleEndStockSnapshot
 *
 * Captures every site's fuel stock level at the exact moment a diesel
 * cycle is closed (see routes/otherRoutes.js's PATCH /:cycle_key/close,
 * the real, live cycle-closing endpoint). This is a genuinely new
 * capability — checked directly before building this: neither
 * CycleReconciliation nor DieselCycle store any stock figure at all,
 * so "what was left in the tank when this cycle ended" has never been
 * captured anywhere in the live system until now.
 *
 * Distinct from the historical-recovery HistoricalSiteStockSnapshot
 * model (Phase 70) — that one holds one-off stock audits recovered
 * from old emails, predating this system. This one is populated going
 * forward, automatically, by the live cycle-closing action itself.
 */
const cycleEndStockSnapshotSchema = new mongoose.Schema({
  cycle_key: { type: String, required: true, index: true }, // "2026-08"

  site: { type: mongoose.Schema.Types.ObjectId, ref: 'Site', required: true, index: true },
  site_id: String,   // IHS_ID_SITE, denormalized for fast lookups without a populate
  site_name: String,
  cluster: String,   // GRATO_Cluster, denormalized the same way every other diesel view already does
  region: String,

  stock_l: Number,           // Fuel_Quantity_Found at the moment of capture
  run_hours: Number,         // generator meter reading (RH) taken at the same moment as stock_l — becomes the NEXT cycle's "Opening Meter (hrs)"
  tank_capacity_l: Number,   // Tank_Capacity_1 at the moment of capture, for a fill-percentage view
  fuel_level_source: String, // 'field_visit' | 'tank_telemetry' | 'cms_telemetry' | null — same provenance meaning as on Site itself
  reading_age_hours: Number, // how old the underlying reading already was at the moment the cycle closed — a stale reading captured at cycle-end is still worth knowing about as stale

  captured_at: { type: Date, default: Date.now },
  captured_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

cycleEndStockSnapshotSchema.index({ cycle_key: 1, site: 1 }, { unique: true });
cycleEndStockSnapshotSchema.index({ cycle_key: 1, cluster: 1 });

module.exports = mongoose.model('CycleEndStockSnapshot', cycleEndStockSnapshotSchema);
