const mongoose = require('mongoose');

/**
 * AdHocFuelRequest
 *
 * Emergency/ad-hoc refueling requests recovered from real email
 * archives — outside the normal monthly budget cycle entirely (the
 * "Specil Refueling" threads for Edea/Pouma1/Pouma2, triggered by a
 * real fuel shortage in late July 2026). Distinct from
 * HistoricalMonthlyRecord (Phase 57), which tracks the regular monthly
 * budget/consumption cycle — this tracks the exceptions to it: specific
 * sites, specific dates, specific emergency quantities.
 */
const adHocFuelRequestSchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  site_name: String,
  cluster:   String,
  region:    String,
  topology:  String,
  priority:  String, // "P3", "P4", etc. — as recorded in the source sheet

  planned_date:    { type: Date, required: true, index: true },
  quantity_requested_l: { type: Number, required: true },
  approved_l: Number, // "SS approval" in the March tracker files — not present in the original July/August source
  delivered_l: Number, // "Extra Given" — actual delivered quantity, where tracked
  request_round: String, // e.g. "1st", "2nd", "3rd", "4th" — which numbered request this belongs to, for sources that track multiple rounds within one shortage event

  source_file:  { type: String, required: true },
  source_sheet: String, // which date-tab within the source file this came from
  imported_by:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  imported_at:  { type: Date, default: Date.now },
}, { timestamps: true });

// A site can genuinely appear more than once on the same planned date
// across different source snapshots as the plan evolved — not treated
// as unique per site+date, since these are point-in-time planning
// entries, not a single canonical record like the monthly reconciliation.
adHocFuelRequestSchema.index({ site_id: 1, planned_date: 1 });
adHocFuelRequestSchema.index({ cluster: 1, planned_date: 1 });

module.exports = mongoose.model('AdHocFuelRequest', adHocFuelRequestSchema);
