const mongoose = require('mongoose');

/**
 * FuelDeliveryEvent
 *
 * One document per real, individual delivery event — not an aggregate.
 * Phase 115 introduced `CycleReconciliation.mail_verified_delivered_l`
 * as a single summed total per site per cycle, which is enough to
 * drive the reconciliation math, but doesn't answer a real question a
 * user can reasonably have: how many times was a site actually
 * refueled this cycle, and how much on each specific date. This
 * collection is that detail, sourced from the same mail-tracker
 * per-delivery-event rows the aggregate was built from — not a
 * separate, re-derived source that could drift out of sync with it.
 */
const fuelDeliveryEventSchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  site_name: String,
  cluster:   String,
  cycle_key: { type: String, required: true, index: true },

  delivery_date: { type: Date, required: true },
  quantity_l:    { type: Number, required: true },

  // How this specific reading was taken, matching the tracker's own
  // three independent measurement methods — kept distinct rather than
  // collapsed into one number, since a real variance between them is
  // itself useful information, not noise to average away.
  dip_stick_qty_l:    Number,
  rms_qty_l:            Number,
  truck_flow_meter_qty_l: Number,

  gen_running_hour: Number, // the RH reading recorded at this same delivery event, where available
  truck_plate_number: String,
  raison:               String, // the tracker's own "Raison" / reason field — e.g. "ok", "Suspected incorrect refueling"

  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

// A site can genuinely have more than one delivery on the same date
// (a correction visit, a second truck) — not unique on
// (site_id, cycle_key, delivery_date) alone. Uniqueness instead on the
// combination that actually identifies a distinct source row, so a
// re-import of the same tracker file doesn't create duplicates but two
// genuinely different real deliveries on the same day both persist.
fuelDeliveryEventSchema.index(
  { site_id: 1, cycle_key: 1, delivery_date: 1, quantity_l: 1 },
  { unique: true }
);
fuelDeliveryEventSchema.index({ cycle_key: 1, cluster: 1 });

module.exports = mongoose.model('FuelDeliveryEvent', fuelDeliveryEventSchema);
