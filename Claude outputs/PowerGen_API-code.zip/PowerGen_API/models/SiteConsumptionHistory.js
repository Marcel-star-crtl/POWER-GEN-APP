const mongoose = require('mongoose');

/**
 * SiteConsumptionHistory
 *
 * One row per site per month of ACTUAL historical fuel consumption —
 * the real, ground-truth basis for "past site consumption" in automated
 * budget planning. Deliberately a separate, dedicated collection rather
 * than relying on CycleReconciliation for this: reconciliation may not
 * have been run (or run correctly) for every past cycle, while this data
 * comes directly from a verified source spreadsheet with known-good
 * figures (Grato Diesel Conso), so budget planning has a reliable
 * foundation regardless of reconciliation's own history.
 *
 * cycle_key follows the same "YYYY-MM" convention used everywhere else
 * in this system.
 */
const siteConsumptionHistorySchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  cycle_key: { type: String, required: true, index: true }, // "2026-07"

  actual_consumption_l:        { type: Number, required: true }, // "Grato Conso" — what was actually consumed
  submitted_contractual_l:     Number, // what the site/SBC submitted as contractual consumption
  approved_contractual_l:      Number, // what was finance-approved as contractual consumption

  source_file:  String,
  imported_by:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  imported_at:  { type: Date, default: Date.now },
}, { timestamps: true });

siteConsumptionHistorySchema.index({ site_id: 1, cycle_key: 1 }, { unique: true });

/**
 * Recent-month trend for one site, most-recent-first. Used directly by
 * the budget planning service — kept as a model static so the query
 * logic lives in one place rather than being re-written per caller.
 */
siteConsumptionHistorySchema.statics.getRecentHistory = function (site_id, monthsBack = 6) {
  return this.find({ site_id }).sort({ cycle_key: -1 }).limit(monthsBack).lean();
};

module.exports = mongoose.model('SiteConsumptionHistory', siteConsumptionHistorySchema);
