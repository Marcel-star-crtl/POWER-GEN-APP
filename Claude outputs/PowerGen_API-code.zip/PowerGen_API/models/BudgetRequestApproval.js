const mongoose = require('mongoose');

/**
 * BudgetRequestApproval
 *
 * The site-level request/approval exchange between Grato and IHS
 * Towers — genuinely distinct from every other historical model
 * recovered so far. HistoricalMonthlyRecord tracks the *reconciled,
 * after-the-fact* budget vs. actual consumption; TomCardAllocation
 * tracks the *cluster-level* funding of fuel cards. This tracks the
 * *site-level* negotiation itself: what Grato asked IHS Towers for
 * ("SBC Request"), and what IHS Towers actually approved — the real
 * request-and-approval step the user meant by "budget request," done
 * by email directly with IHS Towers, not through this system.
 *
 * Also carries the underlying engineering inputs (grid availability,
 * generator CPH, run-hours) the approved figure was actually built
 * from — useful for cross-checking this system's own Budget Planning
 * formula (services/budgetPlanningService.js) against a real, IHS
 * Towers-approved figure for the same site and month.
 */
const budgetRequestApprovalSchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  site_name: String,
  cluster:   String,
  region:    String,
  topology:  String, // "Grid Gen" | "Hybrid Gen" | "Gen Only", etc.

  cycle_key: { type: String, required: true, index: true }, // "2026-07"
  days_in_cycle: Number,

  // ── The actual request/approval exchange ────────────────────────────────
  sbc_requested_l: Number,  // what Grato asked for
  ihs_approved_l:  Number,  // what IHS Towers actually approved
  variance_l:      Number,  // ihs_approved_l - sbc_requested_l (negative = approved less than requested)

  // ── The engineering basis the approved figure was built from ────────────
  genset_cph:            Number,
  final_grid_availability: Number,
  run_hours:               Number,
  fueling_site:            Boolean, // "Fueling Sites (Yes/No)" — whether this site draws diesel budget at all this cycle

  comments: String,

  source_file: { type: String, required: true },
  imported_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

budgetRequestApprovalSchema.index({ site_id: 1, cycle_key: 1 }, { unique: true });

module.exports = mongoose.model('BudgetRequestApproval', budgetRequestApprovalSchema);
