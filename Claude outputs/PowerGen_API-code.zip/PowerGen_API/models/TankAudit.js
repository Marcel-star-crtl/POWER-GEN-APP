const mongoose = require('mongoose');

/**
 * TankAudit
 *
 * Matches the structure of the SITE TANK AUDIT PLAN document: site
 * information, seven on-site physical checks (each with a status, notes,
 * and — where the status is "issue" — a severity classification), the
 * fuel-level cross-check that's the plan's central objective (manual
 * dip vs. CMS vs. theoretical stock), and photos per check area.
 *
 * `logs_collected` is a direct addition beyond the source document,
 * per the user's explicit request — a yes/no per site on whether
 * generator run-hour/consumption logs were collected during the visit,
 * supporting the plan's "validate generator run-hour vs. fuel
 * consumption correlation" objective.
 */
const CHECK_STATUS = ['ok', 'issue', 'na'];
const SEVERITY = ['critical', 'major', 'minor'];

const checkItemSchema = new mongoose.Schema({
  status: { type: String, enum: CHECK_STATUS, default: null },
  notes: String,
  severity: { type: String, enum: SEVERITY, default: null }, // only meaningful when status === 'issue'
  // NOTE: the mime-type field is named "mime_type", not "type" — "type" is
  // a reserved word in Mongoose's schema syntax ({ type: String } is how a
  // field's type is normally declared), so a subdocument field literally
  // named "type" gets misread as a type declaration for the whole array
  // (silently becoming an array of strings, not objects) rather than a
  // subdocument field. Verified this directly: reproduced the exact
  // CastError with a minimal, unrelated schema before concluding this was
  // the actual cause, not an artifact of the real model's structure.
  photos: [{ uri: String, name: String, mime_type: String }],
}, { _id: false });

const tankAuditSchema = new mongoose.Schema({
  // ── Site information ──────────────────────────────────────────────────
  site_id_ihs:   { type: String, required: true, index: true },
  site_name:      String,
  region:          String,
  cluster:          String,
  site_priority:     String, // P1-P5 / TIS
  tank_capacity_l:    Number,
  tank_length_m:       Number,
  tank_width_m:          Number,
  tank_height_m:           Number,
  tank_base_type:           String,
  functional_topology:       String,
  audit_date:                  Date,
  auditor_name:                 String,

  // ── Fuel level cross-check — the plan's central objective ─────────────
  dip_reading_l:        Number,
  cms_reading_l:          Number,
  theoretical_stock_l:     Number,
  variance_pct:              Number, // computed server-side from the three figures above where possible
  // Run-hour meter reading taken during the same visit as the dip
  // reading — a real, valuable data point in its own right (matches
  // the source Tank Audit Plan's "validate generator run-hour vs. fuel
  // consumption correlation" objective), stored as the technician
  // entered it rather than diffed against a fragile baseline.
  audit_run_hours_reading: Number,
  audit_run_hours_reading_source: { type: String, enum: ['technician_entry', 'extraction_accepted', 'manual_correction', null], default: null },

  // Phase 119: when a generator's digital run-hour card is faulty, the
  // plan's own workaround is a mechanical counter meter, photographed
  // as evidence under check_gen_cards_faulty (see below). This lets
  // that photo's reading be extracted automatically via a vision
  // model, as a reviewable SUGGESTION — never silently written into
  // audit_run_hours_reading above. A misread meter feeding straight
  // into True CPH and Gain/Loss without a human ever seeing it would
  // be a real, consequential mistake; this is deliberately a two-step
  // process (extract, then someone accepts it) rather than one.
  run_hours_extraction: {
    status: { type: String, enum: ['not_attempted', 'pending', 'completed', 'failed', 'no_photo'], default: 'not_attempted' },
    extracted_value: Number,
    confidence: { type: String, enum: ['high', 'medium', 'low', null], default: null }, // the model's own stated confidence, not a computed score
    notes: String, // e.g. "digits partially obscured by glare — could be 28574 or 28974"
    source_photo_uri: String,
    extracted_at: Date,
    accepted: { type: Boolean, default: false }, // true once a person has copied extracted_value into audit_run_hours_reading via the normal review step
  },

  // ── On-site physical checks — matches the plan's seven check areas ────
  check_tank_capacity_verification: { type: checkItemSchema, default: () => ({}) },
  check_fuel_level:                  { type: checkItemSchema, default: () => ({}) },
  check_structural_condition:         { type: checkItemSchema, default: () => ({}) },
  check_leakage:                       { type: checkItemSchema, default: () => ({}) },
  check_caps_locking_security:          { type: checkItemSchema, default: () => ({}) },
  check_pipe_passage_earthing:           { type: checkItemSchema, default: () => ({}) },
  check_sensor_hardware:                  { type: checkItemSchema, default: () => ({}) },
  // Direct addition per the user's request — generators with faulty
  // gen cards need to be flagged for replacement with a mechanical
  // counter meter. Same status/severity/notes/photos shape as the
  // plan's own seven checks, for consistency.
  check_gen_cards_faulty:                   { type: checkItemSchema, default: () => ({}) },

  // ── Direct addition per the user's request ─────────────────────────────
  logs_collected: { type: Boolean, default: null }, // were generator run-hour/consumption logs collected on this visit
  // Direct addition per the user's follow-up request — a simple,
  // direct yes/no question ("is the gen card faulty?"), distinct from
  // check_gen_cards_faulty above (that's the full status/severity/notes/
  // photos check item, matching the plan's other seven checks). Kept
  // both rather than replace one with the other, since the user asked
  // for this as an additional field.
  gen_card_faulty: { type: Boolean, default: null },
  // Actual log file attachments from on-site equipment (power cabinet,
  // generator) — distinct from logs_collected (a yes/no flag) and from
  // photos (which capture check-area evidence, not raw equipment logs).
  log_files: [{ uri: String, name: String, mime_type: String, equipment: String }], // equipment: e.g. "power_cabinet" | "generator"

  // ── Overall findings ────────────────────────────────────────────────────
  overall_severity: { type: String, enum: SEVERITY, default: null }, // the worst severity among all flagged checks, computed server-side
  general_notes:      String,
  general_photos:       [{ uri: String, name: String, mime_type: String }],

  // ── Cycle reconciliation — determines this audit's profitability
  // (gain/loss) against what the cycle's system data expected. Phase
  // 106 originally assumed this system had no absolute meter-reading
  // baseline, only accumulated per-cycle RH — corrected in Phase 115:
  // "Opening Meter (hrs)" is the generator run-hour reading taken
  // alongside opening stock at the start of the cycle, and "Closing
  // Meter (hrs)" is the reading taken on the LAST DATE fuel was
  // delivered to the site before the audit — two distinct absolute
  // readings, not a single accumulated total. True CPH is find-
  // consumption divided by the gap between these two readings.
  cycle_key:            String, // e.g. "2026-08" — set from audit_date at save time
  opening_stock_l:       Number, // this cycle's opening stock = prior cycle's CycleEndStockSnapshot.stock_l; null if that snapshot doesn't exist
  opening_stock_source:   { type: String, enum: ['cycle_end_snapshot', 'missing'], default: null },
  opening_meter_hours:      Number, // prior cycle's CycleEndStockSnapshot.run_hours — taken at the same moment as opening_stock_l
  total_refueled_l:           Number, // this cycle's total delivered before the audit date
  total_refueled_source:        { type: String, enum: ['mail_verified', 'cycle_reconciliation', 'missing'], default: null }, // mail_verified = exact per-delivery-event figures from the refueling tracker (Phase 115); cycle_reconciliation = this system's own live aggregate, used only when mail data wasn't available for this site
  validated_cph:                  Number, // from this cycle's CCPH reference (CycleReconciliation.ccph) — the pre-existing benchmark rate, not computed from this audit
  closing_meter_hours:              Number, // RH reading taken on the last date fuel was delivered to this site before the audit
  closing_meter_date:                 Date, // that same last-delivery date
  system_consumption_l:                 Number, // from this cycle's CycleReconciliation.contractual_consumption (final_rh × ccph) — the system's OWN interim/mid-cycle expected-consumption figure, kept for reference only, NOT used for gain_loss_l (see below)
  stock_actualized_1_l:                   Number, // computed: opening_stock_l + total_refueled_l — the theoretical stock before this audit's physical count
  find_consumption_l:                       Number, // computed: stock_actualized_1_l - dip_reading_l
  true_cph:                                   Number, // computed: find_consumption_l / (closing_meter_hours - opening_meter_hours) — the rate this specific audit's own findings actually demonstrate, to compare against validated_cph
  // Gain/Loss can only be genuinely realized once the cycle this audit
  // belongs to has actually closed — before that, there's no real
  // "final run hours" to multiply validated_cph by, only a mid-cycle
  // interim figure that would understate or overstate the true
  // picture depending on how far through the cycle the audit happened.
  // final_run_hours comes from THIS cycle's own CycleEndStockSnapshot
  // (not the prior cycle's, which is what opening_stock_l/
  // opening_meter_hours use) — that snapshot only exists once the
  // cycle has closed, so its mere presence is the "has this cycle
  // closed yet" signal.
  final_run_hours:                              Number, // this cycle's own CycleEndStockSnapshot.run_hours — null until the cycle closes
  cycle_closed:                                   { type: Boolean, default: false },
  gain_loss_l:                                      Number, // computed: find_consumption_l - (final_run_hours × validated_cph) — null until cycle_closed is true
  reconciliation_flags: {
    missing_opening_stock: { type: Boolean, default: false }, // no CycleEndStockSnapshot found for the prior cycle
    missing_cycle_data:    { type: Boolean, default: false }, // no CycleReconciliation found for this site/cycle
    missing_closing_meter: { type: Boolean, default: false }, // no last-delivery meter reading found (neither mail-verified nor Excel-backfilled) — true_cph cannot be computed
  },
  // Whether this audit's dip reading / run-hours were actually written
  // back to the Site record (see the post-save hook below) — false
  // either because the audit isn't submitted yet, or because a newer
  // audit's data already reflects on Site and this one was correctly
  // skipped to avoid regressing it.
  site_state_updated: { type: Boolean, default: false },

  // ── Offline-sync + ownership (same pattern as TechnicianSiteAudit) ──────
  // unique + sparse: enforces true idempotency at the database level,
  // not just in application code — findOne-then-save isn't atomic, so
  // two near-simultaneous requests with the same client_id (a rapid
  // double-tap, or two offline-queued attempts syncing back to back)
  // could otherwise both pass the controller's own findOne check before
  // either finishes saving. Sparse because client_id is optional — not
  // every record has one (e.g. records from before this field existed),
  // and a plain unique index would treat multiple nulls as a conflict.
  client_id:  { type: String, index: { unique: true, sparse: true } },
  status:      { type: String, enum: ['draft', 'submitted'], default: 'draft' },
  created_by:   { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  updated_by:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

// Pure function — computes what pre-save applies, kept separate so it
// can be tested directly rather than only indirectly via a real save().
function computeDerivedFields(doc) {
  const derived = {};

  if (doc.dip_reading_l != null && doc.theoretical_stock_l) {
    derived.variance_pct = Math.round(((doc.dip_reading_l - doc.theoretical_stock_l) / doc.theoretical_stock_l) * 1000) / 10;
  } else {
    derived.variance_pct = null;
  }

  const checkFields = [
    'check_tank_capacity_verification', 'check_fuel_level', 'check_structural_condition',
    'check_leakage', 'check_caps_locking_security', 'check_pipe_passage_earthing', 'check_sensor_hardware',
    'check_gen_cards_faulty',
  ];
  const severities = checkFields
    .map(f => doc[f]?.status === 'issue' ? doc[f]?.severity : null)
    .filter(Boolean);
  if (severities.includes('critical')) derived.overall_severity = 'critical';
  else if (severities.includes('major')) derived.overall_severity = 'major';
  else if (severities.includes('minor')) derived.overall_severity = 'minor';
  else derived.overall_severity = null;

  // Cycle reconciliation chain. Guarded against non-numeric/missing
  // inputs explicitly (isNum, not just != null) — a bug caught the hard
  // way while building the equivalent Excel version of this: a "FAULTY"
  // meter-reading text value passed a `!= null` guard and silently
  // produced #VALUE! in 48 cells before the guard was tightened to
  // actually check for a number. Applying that same lesson here from
  // the start rather than repeating it.
  const isNum = v => typeof v === 'number' && Number.isFinite(v);

  derived.stock_actualized_1_l = (isNum(doc.opening_stock_l) && isNum(doc.total_refueled_l))
    ? doc.opening_stock_l + doc.total_refueled_l
    : null;

  derived.find_consumption_l = (isNum(derived.stock_actualized_1_l) && isNum(doc.dip_reading_l))
    ? derived.stock_actualized_1_l - doc.dip_reading_l
    : null;

  // True CPH — the rate THIS audit's own findings actually demonstrate,
  // over the real gap between the opening meter reading (start of
  // cycle) and the closing meter reading (last delivery date before
  // this audit). Distinct from validated_cph, which is a pre-existing
  // benchmark rate (from the CCPH reference), not computed from this
  // audit at all — set directly in the pre-save hook below, not here.
  const meterGap = (isNum(doc.closing_meter_hours) && isNum(doc.opening_meter_hours))
    ? doc.closing_meter_hours - doc.opening_meter_hours
    : null;
  derived.true_cph = (isNum(derived.find_consumption_l) && isNum(meterGap) && meterGap !== 0)
    ? Math.round((derived.find_consumption_l / meterGap) * 100) / 100
    : null;

  // Only realized once the cycle has actually closed — see the
  // field's own schema comment. Deliberately does NOT fall back to
  // system_consumption_l (the mid-cycle interim figure) as a
  // substitute; a null Gain/Loss with a clear "cycle still open" flag
  // is more honest than a number that looks final but isn't.
  derived.gain_loss_l = (doc.cycle_closed && isNum(derived.find_consumption_l) && isNum(doc.final_run_hours) && isNum(doc.validated_cph))
    ? Math.round((derived.find_consumption_l - (doc.final_run_hours * doc.validated_cph)) * 100) / 100
    : null;

  return derived;
}

// Server-side derivation, run on every save — keeps variance_pct and
// overall_severity consistent without relying on the mobile client to
// compute them correctly (and lets the dashboard trust these fields
// directly rather than recomputing on every read).
tankAuditSchema.pre('save', async function applyDerivedFields(next) {
  try {
    if (this.site_id_ihs && this.audit_date && !this.cycle_key) {
      const DieselCycle = require('./DieselCycle');
      const CycleEndStockSnapshot = require('./CycleEndStockSnapshot');
      const CycleReconciliation = require('./CycleReconciliation');
      const Site = require('./Site');

      const cycle = await DieselCycle.findOne({
        start_date: { $lte: this.audit_date },
        end_date: { $gte: this.audit_date },
      }).lean();
      this.cycle_key = cycle?.cycle_key ?? null;

      if (this.cycle_key) {
        const priorCycleKey = DieselCycle.getPreviousCycleKey(this.cycle_key);

        const siteDoc = await Site.findOne({ IHS_ID_SITE: this.site_id_ihs }).select('_id').lean();

        const [snapshot, reconciliation, ownCycleSnapshot] = await Promise.all([
          siteDoc ? CycleEndStockSnapshot.findOne({ cycle_key: priorCycleKey, site: siteDoc._id }).lean() : null,
          CycleReconciliation.findOne({ site_id: this.site_id_ihs, cycle_key: this.cycle_key }).lean(),
          // This cycle's OWN closing snapshot — only exists once the
          // cycle itself has closed. Its presence, not just a date
          // check, is the real signal: a cycle whose end_date has
          // passed but whose closing data hasn't been captured yet
          // still isn't ready for a genuine Gain/Loss figure.
          siteDoc ? CycleEndStockSnapshot.findOne({ cycle_key: this.cycle_key, site: siteDoc._id }).lean() : null,
        ]);

        if (ownCycleSnapshot?.run_hours != null) {
          this.final_run_hours = ownCycleSnapshot.run_hours;
          this.cycle_closed = true;
        } else {
          this.cycle_closed = false;
        }

        if (snapshot) {
          this.opening_stock_l = snapshot.stock_l;
          this.opening_stock_source = 'cycle_end_snapshot';
          this.opening_meter_hours = snapshot.run_hours ?? null;
        } else {
          this.opening_stock_source = 'missing';
          this.reconciliation_flags = { ...this.reconciliation_flags, missing_opening_stock: true };
        }

        if (reconciliation) {
          // Prefer the mail-verified, per-delivery-event total when
          // it exists — Phase 115 found the live system's own
          // field_fuel_added can lag behind what's actually been
          // delivered (confirmed directly against an August cross-
          // check, not assumed). Falls back to the live aggregate
          // when no mail-verified figure has been backfilled for this
          // site, rather than leave total_refueled_l blank.
          if (reconciliation.mail_verified_delivered_l != null) {
            this.total_refueled_l = reconciliation.mail_verified_delivered_l;
            this.total_refueled_source = 'mail_verified';
          } else if (reconciliation.field_fuel_added != null) {
            this.total_refueled_l = reconciliation.field_fuel_added;
            this.total_refueled_source = 'cycle_reconciliation';
          } else {
            this.total_refueled_source = 'missing';
          }

          this.validated_cph = reconciliation.ccph ?? null;
          this.system_consumption_l = reconciliation.contractual_consumption ?? null;

          if (reconciliation.closing_meter_hours != null) {
            this.closing_meter_hours = reconciliation.closing_meter_hours;
            this.closing_meter_date = reconciliation.closing_meter_date ?? null;
          } else {
            this.reconciliation_flags = { ...this.reconciliation_flags, missing_closing_meter: true };
          }
        } else {
          this.reconciliation_flags = { ...this.reconciliation_flags, missing_cycle_data: true, missing_closing_meter: true };
        }
      }
    }
  } catch (err) {
    this.reconciliation_flags = { ...this.reconciliation_flags, missing_cycle_data: true };
    console.error('TankAudit reconciliation lookup failed:', err.message);
  }

  Object.assign(this, computeDerivedFields(this));
  next();
});

tankAuditSchema.index({ status: 1, audit_date: -1 });
tankAuditSchema.index({ overall_severity: 1 });

// Post-save: feed a submitted audit's real, physical findings back into
// the Site record's own live state — the mechanism that lets the
// system's gaps actually close as real audits come in, rather than
// staying permanently dependent on a one-time Excel import. Runs after
// save (not part of applyDerivedFields above) because it writes to a
// different collection entirely and shouldn't block or complicate this
// document's own save.
tankAuditSchema.post('save', async function feedBackToSite(doc) {
  if (doc.status !== 'submitted' || doc.dip_reading_l == null) return;

  try {
    const Site = require('./Site');
    // .lean() — a plain object, not a full Mongoose document. Used only
    // to make decisions (freshness check, generator count) below; the
    // actual write uses a targeted updateOne, not this document's own
    // .save(), specifically to avoid triggering whole-document schema
    // validation on fields this hook never touches. A real, pre-
    // existing data issue surfaced this: some Site documents already
    // violate their own Current_Generators max-2 rule (confirmed
    // directly, unrelated to anything this hook writes), and calling
    // .save() on ANY such document fails immediately, blocking a
    // fuel-level update that has nothing to do with generators at all.
    const site = await Site.findOne({ IHS_ID_SITE: doc.site_id_ihs })
      .select('_id Fuel_Level_Updated_At Number_of_Generators Generators_Details')
      .lean();
    if (!site) return;

    // Never let an edit to an OLDER audit regress a site's live state
    // past what a NEWER audit already established — e.g. fixing a typo
    // in an old audit's notes must not silently overwrite today's
    // fresher reading with last month's.
    const siteIsFresherOrUnset = !site.Fuel_Level_Updated_At || doc.audit_date >= site.Fuel_Level_Updated_At;
    if (!siteIsFresherOrUnset) return;

    const setFields = {
      Fuel_Quantity_Found: doc.dip_reading_l,
      Fuel_Level_Source: 'field_visit',
      Fuel_Level_Updated_At: doc.audit_date,
    };

    // Run-hours: only auto-applied for single-generator sites. A
    // multi-generator site's Generators_Details array has no reliable
    // way from this audit alone to know which generator the technician
    // actually read — guessing wrong would be worse than leaving it
    // for manual entry, so it's deliberately skipped, not guessed.
    if (doc.audit_run_hours_reading != null && site.Number_of_Generators === 1 && Array.isArray(site.Generators_Details) && site.Generators_Details.length === 1) {
      setFields['Generators_Details.0.last_running_hours'] = doc.audit_run_hours_reading;
    }

    // updateOne with no runValidators option — deliberately does not
    // validate the whole document. Only the paths actually in $set
    // matter for this write; a pre-existing violation somewhere else
    // in the document (like Current_Generators above) is real and
    // worth fixing on its own, but is not this hook's job to be
    // blocked by.
    await Site.updateOne({ _id: site._id }, { $set: setFields });

    if (!doc.site_state_updated) {
      // Avoid an infinite save loop by updating directly rather than
      // calling doc.save() again from inside its own post-save hook.
      await mongoose.model('TankAudit').updateOne({ _id: doc._id }, { site_state_updated: true });
    }
  } catch (err) {
    console.error(`TankAudit feedBackToSite error (site ${doc.site_id_ihs}, audit ${doc._id}):`, err.message);
  }
});

module.exports = mongoose.model('TankAudit', tankAuditSchema);
module.exports.computeDerivedFields = computeDerivedFields;
