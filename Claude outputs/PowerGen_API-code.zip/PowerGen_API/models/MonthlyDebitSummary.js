const mongoose = require('mongoose');

/**
 * MonthlyDebitSummary
 *
 * The fleet-level (not per-site) monthly settlement between Grato and
 * IHS Towers — one row per month, found in each recovered validation
 * file's own "Debit" sheet. Genuinely distinct from
 * HistoricalMonthlyRecord (per-site) and BudgetRequestApproval
 * (per-site, upstream request/approval) — this is the downstream
 * financial reconciliation: what was submitted, what was approved,
 * what was actually purchased, and the resulting debit or credit
 * amount in both liters and XAF.
 *
 * Column set genuinely varies by month — April and May add extra
 * "BB Sites" (external-tank sites) stock-tracking fields that December
 * through February don't have. Only the core fields present in every
 * month are required; the BB-specific ones are optional and null where
 * not applicable.
 */
const monthlyDebitSummarySchema = new mongoose.Schema({
  cycle_key: { type: String, required: true, unique: true, index: true },
  sbc: String, // e.g. "GRATO - Littoral"

  submitted_consumption_l: Number,
  approved_consumption_l:  Number,
  purchases_l:              Number,
  stock_left_l:               Number, // "SBC Stock Left on Last Visit Date"
  management_fees_xaf:         Number,
  unit_price_xaf:                Number,
  debit_credit_l:                  Number, // negative = Grato owes IHS Towers (consumed/purchased more than approved)
  debit_credit_xaf:                  Number,
  debit_credit_amount_xaf:             Number, // the actual settlement figure

  // BB (external-tank) sites — only present in April/May's recovered files
  bb_sites_stock_l: Number,
  bb_purchase_to_consider_l: Number,

  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('MonthlyDebitSummary', monthlyDebitSummarySchema);
