const mongoose = require('mongoose');

/**
 * HistoricalSiteStockSnapshot
 *
 * One-off, site-level fuel stock snapshots — genuinely different
 * documents (HO Stock in December's file, BB Site Stock in April's),
 * but the same underlying concept: "how much fuel is actually at this
 * site, as of this date." Unlike HistoricalFieldVisit (Phase 68), these
 * aren't part of the recurring monthly visit cycle — they're one-off
 * audits/exercises that only appear in a single recovered month each.
 *
 * `snapshot_type` distinguishes the two real sources found:
 *   - "ho_stock": December 2025's Head Office stock check, 9 sites,
 *     dated from late-November visits (before the December cycle
 *     itself started) — includes a generator meter reading, which can
 *     be the literal string "FAULTY" instead of a number where the
 *     source data shows a broken meter.
 *   - "bb_site_stock": April 2026's tracking of "BB sites" specifically
 *     (external-tank sites), including how much was allocated,
 *     refuelled, and left as of month-end.
 *   - "small_tank_usage": May 2026's tracking of "Small Tank" sites —
 *     a different, smaller site subset than BB sites, tracking usage
 *     for a specific cycle rather than a full month's stock movement.
 */
const historicalSiteStockSnapshotSchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  site_name: String,
  sbc:       String,

  snapshot_type: { type: String, enum: ['ho_stock', 'bb_site_stock', 'small_tank_usage'], required: true },
  snapshot_date: { type: Date, required: true },
  month_key:     { type: String, required: true, index: true }, // the recovered month this snapshot's source file belongs to, not necessarily the snapshot_date's own month

  generator_capacity_kva: Number,
  generator_meter_reading: Number, // null where the source shows "FAULTY" instead of a number
  generator_meter_faulty:   Boolean, // true where the source literally says "FAULTY"

  stock_left_l:      Number,
  stock_allocated_l:  Number, // "bb_site_stock" only
  qty_refuelled_l:     Number, // "bb_site_stock" only
  usage_l:              Number, // "small_tank_usage" only — the "Qty Used" figure for that cycle

  source_file:  { type: String, required: true },
  source_sheet: String,
  imported_at:  { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('HistoricalSiteStockSnapshot', historicalSiteStockSnapshotSchema);
