const mongoose = require('mongoose');

/**
 * HistoricalFuelPurchase
 *
 * Individual fuel card purchase transactions recovered from each
 * validation file's own "Purchases" / "Purchases breakdown (Update)"
 * sheet. Genuinely distinct from HistoricalFieldVisit's "Fuel Qty
 * Added" (Phase 68): this is the *procurement* side — bulk fuel bought
 * with a card at a specific gas station — while the field-visit record
 * is the *distribution* side — fuel physically delivered to a site by a
 * technician. There's no site ID on a purchase transaction; it's linked
 * to an SBC/region/card, not an individual site.
 */
const historicalFuelPurchaseSchema = new mongoose.Schema({
  card_number: String,
  purchase_date: { type: Date, required: true, index: true },

  quantity_l:    Number,
  unit_price_xaf: Number,
  amount_xaf:      Number,

  place:  String, // the gas station, e.g. "TOTALENERGIES EDEA"
  vendor:  String, // "TOTAL", "TRADEX", etc.
  service:  String, // e.g. "GAZOLE"
  usage:     String, // e.g. "Generator"
  purchase_user: String,
  region:  String,
  sbc:      String,
  comments:  String,

  month_key: { type: String, required: true, index: true },
  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

historicalFuelPurchaseSchema.index({ month_key: 1, card_number: 1 });

module.exports = mongoose.model('HistoricalFuelPurchase', historicalFuelPurchaseSchema);
