const mongoose = require('mongoose');

/**
 * HistoricalFieldVisit
 *
 * Individual field-visit records recovered from each monthly validation
 * file's own "Main" sheet — the most granular data found in this entire
 * recovery effort. Genuinely distinct from HistoricalMonthlyRecord
 * (one row per site per MONTH): this is one row per VISIT, and a site
 * can have several visits within a single month.
 *
 * `fuel_added_l` is the actual "delivered to site" figure per visit —
 * confirmed well-populated (71% fill rate on the month checked
 * directly) — not every visit involves a refuel, so nulls here are
 * expected and real, not missing data.
 *
 * NOTABLE ABSENCE, not silently omitted: the source template also has
 * "Theft (L)", "Gap CPH Variation (Stock Issue Or Others)", "Qty
 * Consumed (L)", "Generator Comment", and "LOAD Comment" columns —
 * checked all six recovered months for actual values in any of them:
 * zero, everywhere. These columns were part of the manual process's
 * template but were never actually filled in during this period. Not
 * included as fields here — a schema field that is permanently null
 * across 100% of real records adds clutter, not information. If a
 * future recovered month turns out to have these populated, the import
 * script's structure (see importHistoricalFieldVisits.js) makes it
 * straightforward to add them then, with real data behind them.
 */
const historicalFieldVisitSchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  site_name: String,
  cluster:   String,
  sbc:       String,
  region:    String,
  topology:  String, // "Visit Topology"

  month_key: { type: String, required: true, index: true }, // which recovered month this visit falls in

  visit_date:          { type: Date, required: true },
  previous_visit_date: Date,
  days_since_last_visit: Number,

  generator_meter_reading: Number,
  generator_capacity_kva:   Number,
  generator_brand:           String,
  generator_status:           String,
  generator_visual_check:      String,
  tank_type:                    String,

  run_hours:          Number, // "RH"
  ccph:                 Number,
  fuel_consumption_l:    Number,

  fuel_previously_left_l: Number,
  fuel_found_l:             Number,
  fuel_added_l:              Number, // the actual delivered-to-site figure for this visit
  fuel_left_l:                 Number,

  edo_site: Boolean, // "EDO Site?" — only meaningfully populated for a subset of sites

  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

historicalFieldVisitSchema.index({ site_id: 1, visit_date: 1 });
historicalFieldVisitSchema.index({ month_key: 1, site_id: 1 });

module.exports = mongoose.model('HistoricalFieldVisit', historicalFieldVisitSchema);
