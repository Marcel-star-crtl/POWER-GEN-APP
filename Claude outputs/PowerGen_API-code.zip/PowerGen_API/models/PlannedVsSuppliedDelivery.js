const mongoose = require('mongoose');

/**
 * PlannedVsSuppliedDelivery
 *
 * Per-site, per-planned-delivery tracking of what was scheduled versus
 * what actually arrived, with an explicit gap and gap-type
 * classification. Found in a "GRATO_FUEL PLAN JUNE-26" workbook that
 * turned out to span 26 May through 29 June 2026 in a single sheet —
 * genuinely different from HistoricalFieldVisit (which only records
 * what a visit actually found/added, with no "planned" figure to
 * compare against) and from HistoricalFuelPurchase (procurement, not
 * delivery scheduling).
 */
const plannedVsSuppliedDeliverySchema = new mongoose.Schema({
  site_id:   { type: String, required: true, index: true },
  site_name: String,
  cluster:   String,
  region:    String,
  topology:  String,
  site_priority: String,

  month_key: { type: String, required: true, index: true }, // derived from date_done

  date_de_passage: Date, // "DATE DE PASSAGE" — the scheduled visit date
  date_done:        Date, // when it was actually completed
  date_submitted:     Date, // when the report was submitted

  planned_l:  Number,
  supplied_l:  Number,
  gap_l:        Number, // planned - supplied, per the source's own figure, not recomputed
  gap_type:      String, // e.g. "OK" (no gap) or a real classification for a discrepancy
  ref_type:       String, // e.g. "PLANNED REF"
  comment:         String,

  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('PlannedVsSuppliedDelivery', plannedVsSuppliedDeliverySchema);
