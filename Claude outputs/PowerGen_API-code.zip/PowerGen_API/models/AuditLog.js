/**
 * AuditLog.js
 * PowerGen_API/models/AuditLog.js
 *
 * Immutable append-only record of every significant action in the system.
 * Written via the auditLog() helper — NEVER updated after creation.
 *
 * Fields:
 *   action       — verb describing what happened (e.g. 'fuel_request.approved')
 *   entity_type  — model name (FuelRequest, SiteBudget, TomCardTransfer, ...)
 *   entity_id    — the document _id that was affected
 *   actor_id     — the User who performed the action
 *   actor_email  — denormalised for readability (user may be deleted later)
 *   actor_role   — role at time of action
 *   cycle_key    — diesel cycle the action belongs to (optional)
 *   before       — snapshot of relevant fields BEFORE the change (optional)
 *   after        — snapshot of relevant fields AFTER the change (optional)
 *   metadata     — any extra context (site name, cluster, XAF amounts, etc.)
 *   ip           — client IP address
 *   created_at   — immutable timestamp
 */
'use strict';
const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema({
  action:       { type: String, required: true, index: true },
  entity_type:  { type: String, required: true, index: true },
  entity_id:    { type: mongoose.Schema.Types.ObjectId, index: true },
  actor_id:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
  actor_email:  { type: String },
  actor_role:   { type: String },
  cycle_key:    { type: String, index: true },
  before:       { type: mongoose.Schema.Types.Mixed },
  after:        { type: mongoose.Schema.Types.Mixed },
  metadata:     { type: mongoose.Schema.Types.Mixed },
  ip:           { type: String },
  created_at:   { type: Date, default: Date.now, immutable: true },
}, {
  timestamps: false,  // we control created_at
  versionKey: false,
});

// Composite index for efficient audit queries per entity
auditLogSchema.index({ entity_type: 1, entity_id: 1, created_at: -1 });
// Per-actor audit trail
auditLogSchema.index({ actor_id: 1, created_at: -1 });
// Per-cycle audit
auditLogSchema.index({ cycle_key: 1, created_at: -1 });

const AuditLog = mongoose.model('AuditLog', auditLogSchema);

/**
 * auditLog(params) — write one audit event
 * Non-blocking: always resolves, never throws.
 */
async function auditLog({ action, entityType, entityId, actor, cycleKey, before, after, metadata, ip }) {
  try {
    await AuditLog.create({
      action,
      entity_type:  entityType,
      entity_id:    entityId,
      actor_id:     actor?.userId || actor?._id,
      actor_email:  actor?.email,
      actor_role:   actor?.role,
      cycle_key:    cycleKey,
      before,
      after,
      metadata,
      ip,
    });
  } catch (err) {
    // Audit failures must never break the main flow
    require('../utils/logger').error('[AuditLog] Write failed:', err.message);
  }
}

module.exports = AuditLog;
module.exports.auditLog = auditLog;
