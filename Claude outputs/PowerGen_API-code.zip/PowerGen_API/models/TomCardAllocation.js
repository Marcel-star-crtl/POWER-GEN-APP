const mongoose = require('mongoose');

/**
 * TomCardAllocation
 *
 * Cluster-level fuel card funding — the actual "budget request" step at
 * the top of the process, submitted ahead of a cycle to fund the fuel
 * cards clusters draw against all month. Distinct from
 * HistoricalMonthlyRecord's per-site budget (which is what a site is
 * *allowed* to spend) — this is the upstream funding event that makes
 * that spending possible in the first place: literally putting money
 * onto the cards.
 *
 * Recovered from a real "TOMCARD-REFILL" document (see
 * scripts/historical_email_data/README.md) — currently a single
 * recovered instance (funding December 2025 -> January 2026's cycle),
 * not a recurring monthly series like the other historical data.
 */
const tomCardAllocationSchema = new mongoose.Schema({
  cluster: { type: String, required: true },
  funded_cycle_key: { type: String, required: true, index: true }, // which cycle this allocation funds — "2026-01"

  quantity_l:  Number,
  unit_price_xaf: Number,
  amount_xaf:   Number,
  card_number:   String,
  new_card_number: String, // present only in August 2026's source — a card reissue, null for other months

  fuel_amount_xaf:     Number, // the TOTALENERGIES fuel funding line itself
  recharge_fee_xaf:    Number,
  totalenergies_total_xaf: Number,
  tradex_amount_xaf:   Number, // 0/null where the document shows no TRADEX charge this cycle
  grand_total_xaf:     Number,

  submitted_date: Date, // the date on the actual document, e.g. 26/12/2025
  submitted_by:   String,

  // From the "Card Limit" sheet variant (Phase 70) — a different
  // source document shape than the TOMCARD-REFILL PDF above, tracking
  // the cycle's own budget alongside the card's actual limit and any
  // mid-cycle limit reset, rather than just the initial funding.
  vendor:                   String, // "TOTAL" | "TRADEX"
  budget_l:                  Number, // the cycle's own diesel budget, in liters
  budget_xaf:                  Number,
  initial_recharge_pct:          Number, // e.g. 0.6 = 60%
  initial_recharge_amount_xaf:    Number,
  actual_card_limit_xaf:            Number,
  new_limit_xaf:                      Number, // a mid-cycle limit reset, where the document shows one
  new_limit_date:                       Date,

  // From a richer, later snapshot of June 2026's own Card Limit
  // tracker specifically (Phase 102) — the same running document,
  // extended further into the cycle to record each extra-fuel round's
  // cluster-level approval as it happened. Genuinely absent from every
  // other month's Card Limit source checked so far; left null
  // elsewhere rather than assumed to generalize. Captures the settled
  // limit after each round's processing (the source shows some
  // intermediate same-day corrections too, e.g. two different "new
  // limit" values both dated 08 June for round 1 — the later, settled
  // one is what's stored here, not every intermediate figure).
  extra_round1_approved_l:   Number,
  extra_round1_approved_xaf: Number,
  extra_round1_new_limit_xaf: Number,
  extra_round2_approved_l:   Number,
  extra_round2_approved_xaf: Number,
  extra_round2_new_limit_xaf: Number,
  extra_round3_approved_l:   Number,
  extra_round3_approved_xaf: Number,
  extra_round3_new_limit_xaf: Number,
  extra_rounds_comment:      String,

  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

tomCardAllocationSchema.index({ cluster: 1, funded_cycle_key: 1 }, { unique: true });

module.exports = mongoose.model('TomCardAllocation', tomCardAllocationSchema);
