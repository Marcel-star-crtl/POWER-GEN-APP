const mongoose = require('mongoose');

/**
 * MidCycleBudgetRelease
 *
 * A genuinely distinct concept from both HistoricalMonthlyRecord (the
 * regular monthly budget/consumption cycle) and AdHocFuelRequest
 * (specific emergency refueling events): an early, PARTIAL release of a
 * future cycle's budget — recovered from the real "August Refueling
 * Details Budget" thread, where August's budget was released in tiers
 * (50%, later 80%) ahead of the normal cycle start, in direct response
 * to the same fuel shortage that produced the ad-hoc requests.
 *
 * One row per site, representing the LATEST recovered progress snapshot
 * for that site's early release — not a time series (see
 * MidCycleReleaseDailyProgress for the daily, cluster-level trend).
 */
const midCycleBudgetReleaseSchema = new mongoose.Schema({
  site_id:   { type: String, required: true, unique: true, index: true },
  site_name: String,
  cluster:   String,
  region:    String,
  topology:  String,
  priority:  String,

  release_cycle_key: { type: String, required: true, index: true }, // "2026-08" — which cycle this early release is for

  delivered_l:      Number, // how much has actually been delivered so far, per the latest snapshot
  released_budget_l: Number, // the approved release amount this delivery is measured against
  variance_l:        Number, // released_budget_l - delivered_l (delivered ahead of or behind the release)
  to_be_added_l:      Number, // remaining amount still to deliver
  tier_50pct_l:        Number, // the 50%-of-full-budget release tier amount
  tier_80pct_l:         Number, // the 80%-of-full-budget release tier amount, where a later tier was recovered

  source_file:  { type: String, required: true },
  source_date:  Date, // which day's snapshot this came from (the file's own "updated" date)
  imported_by:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  imported_at:  { type: Date, default: Date.now },
}, { timestamps: true });

/**
 * MidCycleReleaseDailyProgress
 *
 * Cluster-level daily delivery trend for a mid-cycle release — from the
 * source file's own "Recap" sheet, which already aggregates this at the
 * cluster level day by day. Kept as its own lightweight collection
 * rather than embedded, since it's a genuinely different grain (cluster
 * + day) from the per-site snapshot above.
 */
const midCycleReleaseDailyProgressSchema = new mongoose.Schema({
  release_cycle_key: { type: String, required: true, index: true },
  cluster:  { type: String, required: true },
  date:     { type: Date, required: true },
  delivered_l: Number, // from the main "Recap" sheet — may be null if only the Service Desk team recorded this cluster/day
  // From the same file's separate "Service desk Recap" sheet — an
  // independently-tracked figure for the same cluster and day, from a
  // different team. Checked directly rather than assumed redundant:
  // the two sources genuinely disagree (e.g. Bonaberi 1 on 26 July:
  // 1,370L in the main Recap vs. 1,433L here) — preserved separately,
  // not merged or silently resolved, since there's no way to determine
  // from the data alone which team's figure is authoritative.
  service_desk_delivered_l: Number,

  source_file: { type: String, required: true },
  imported_at: { type: Date, default: Date.now },
});
midCycleReleaseDailyProgressSchema.index({ release_cycle_key: 1, cluster: 1, date: 1 }, { unique: true });

module.exports = {
  MidCycleBudgetRelease: mongoose.model('MidCycleBudgetRelease', midCycleBudgetReleaseSchema),
  MidCycleReleaseDailyProgress: mongoose.model('MidCycleReleaseDailyProgress', midCycleReleaseDailyProgressSchema),
};
