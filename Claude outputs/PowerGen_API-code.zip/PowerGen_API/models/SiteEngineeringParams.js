const mongoose = require('mongoose');

/**
 * SiteEngineeringParams
 *
 * The current engineering parameters per site that drive automated
 * budget calculation — imported from the organization's own engineering
 * model (verified against real data before building this: matches to
 * near-exact precision the formula already in use —
 *   run_hours = (1 - grid_availability) * 24 * days_in_cycle
 *   budget_liters = run_hours * genset_cph  (rounded up)
 * — see services/budgetPlanningService.js for where this is actually
 * applied).
 *
 * One row per site, updated whenever a new engineering snapshot is
 * imported (a generator swap, a grid-availability reassessment, etc.),
 * NOT one row per cycle — this represents "the current known parameters
 * for this site," which the planning service projects forward onto
 * whatever cycle is being planned.
 */
const siteEngineeringParamsSchema = new mongoose.Schema({
  site_id: { type: String, required: true, unique: true, index: true },
  site_name: String,
  cluster: String,
  region: String,
  topology: String, // "Grid Gen", "Hybrid Gen", "Gen Only", etc.

  actual_dg_kva: Number,
  genset_capacity_mapped_kva: Number,
  genset_cph: { type: Number, required: true }, // Genset CPH (L/h) — the core consumption-rate parameter

  final_grid_availability: { type: Number, min: 0, max: 1, required: true }, // 0.0–1.0
  hybrid_expectation_hrs: Number, // extra expected runtime for hybrid-gen sites, beyond pure grid-unavailability hours

  is_fueling_site: { type: Boolean, default: true },

  source_file: String,
  source_cycle_key: String, // which cycle's engineering snapshot this came from
  imported_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  imported_at: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('SiteEngineeringParams', siteEngineeringParamsSchema);
