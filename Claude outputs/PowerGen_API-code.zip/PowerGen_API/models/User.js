const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    index: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: [
      'admin', 'supervisor', 'technician', 'ac',
      'diesel_manager', 'data_collector', 'analyst',
      'operations', 'fuel',
      'finance',           // L4 — Ranibell Mambo (Finance Officer)
      'head_of_business',  // L5 — Kelvin E.T (Head of Business)
      'ceo',               // L6 — Tom (CEO, ≥100L only)
    ],
    required: true,
    index: true
  },
  phone: {
    type: String,
    required: true
  },
  isActive: {
    type: Boolean,
    default: true,
    index: true
  },

  // Technician-specific fields
  specializations: [{
    type: String,
    enum: [
      'preventive_maintenance',
      'emergency_repair',
      'electrical_systems',
      'fuel_systems',
      'generator_repair',
      'system_management',
      'user_management',
      'team_management',
      'approval_workflows',
      'fuel_management',
      'logistics',
      'data_analysis',
      'reporting',
      'data_analytics',
      'business_intelligence',
      'generator',
      'maintenance',
      'power_system',
      'electrical',
      'mechanical',
      'ac_unit'
    ]
  }],

  certifications: [{
    name: String,
    issued_by: String,
    issue_date: Date,
    expiry_date: Date,
    certificate_url: String
  }],

  // Assignment tracking
  assigned_sites: [{
    type: String,
    ref: 'Site'
  }],

  assignedClusters: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Cluster'
  }],

  assigned_cluster: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Cluster'
  },

  // Supervisor-specific
  supervised_clusters: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Cluster'
  }],

  assignedTechnicians: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],

  // Technician-specific fields
  supervisor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },

  // Performance tracking
  performance_metrics: {
    total_visits:          { type: Number, default: 0 },
    completed_tasks:       { type: Number, default: 0 },
    average_response_time: { type: Number, default: 0 },
    rating:                { type: Number, min: 0, max: 5, default: 0 }
  },

  // Availability
  availability_status: {
    type: String,
    enum: ['available', 'on_site', 'off_duty', 'on_leave'],
    default: 'available'
  },

  last_known_location: {
    latitude:   Number,
    longitude:  Number,
    updated_at: Date
  },

  // Session management
  refresh_tokens: [{
    token:      String,
    created_at: Date,
    expires_at: Date,
    device:     String
  }],

  // Audit fields
  created_by:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  last_login:  Date,
  login_count: { type: Number, default: 0 },

  // Profile
  profile_picture: String,
  department:      String,
  employee_id:     String,
  date_joined:     { type: Date, default: Date.now },

  // Push notifications (Expo)
  expoPushToken: {
    type: String,
    default: null
  }

}, {
  timestamps: true,
  toJSON: {
    virtuals: true,
    transform: function (doc, ret) {
      delete ret.password;
      delete ret.refresh_tokens;
      return ret;
    }
  },
  toObject: { virtuals: true }
});

// Indexes for performance
userSchema.index({ email: 1, isActive: 1 });
userSchema.index({ role: 1, isActive: 1 });
userSchema.index({ assigned_cluster: 1 });
userSchema.index({ 'performance_metrics.rating': -1 });

// Virtual for active assignments count
userSchema.virtual('active_assignments_count').get(function () {
  return this.assigned_sites?.length || 0;
});

// Virtual for full contact
userSchema.virtual('full_contact').get(function () {
  return { name: this.fullName, email: this.email, phone: this.phone };
});

// Instance method: Check if user has role
userSchema.methods.hasRole = function (role) {
  if (Array.isArray(role)) return role.includes(this.role);
  return this.role === role;
};

// Instance method: Check if user can access resource
userSchema.methods.canAccess = function (resourceType) {
  const permissions = {
    admin:            ['all'],
    supervisor:       ['sites', 'maintenance', 'technicians', 'clusters', 'reports'],
    technician:       ['sites', 'maintenance', 'own_profile'],
    ac:               ['sites', 'maintenance', 'own_profile'],
    diesel_manager:   ['fuel', 'sites', 'reports'],
    data_collector:   ['sites', 'maintenance', 'fuel', 'exports', 'reports'],
    analyst:          ['sites', 'maintenance', 'fuel', 'analytics', 'reports'],
    // ── New approval-chain roles ──────────────────────────────────────────────
    finance:          ['fuel', 'sites', 'reports', 'analytics', 'exports'],
    head_of_business: ['fuel', 'sites', 'reports', 'analytics', 'exports'],
    ceo:              ['all'],
  };
  const rolePermissions = permissions[this.role] || [];
  return rolePermissions.includes('all') || rolePermissions.includes(resourceType);
};

// Instance method: Update last login
userSchema.methods.updateLastLogin = async function () {
  this.last_login = new Date();
  this.login_count += 1;
  return this.save();
};

// Instance method: Update last activity
userSchema.methods.updateLastActivity = async function () {
  this.last_login = new Date();
  return this.save({ validateBeforeSave: false });
};

// Instance method: Add refresh token
userSchema.methods.addRefreshToken = function (token, device = 'unknown') {
  this.refresh_tokens.push({
    token,
    created_at: new Date(),
    expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    device
  });
  if (this.refresh_tokens.length > 5) {
    this.refresh_tokens = this.refresh_tokens.slice(-5);
  }
  return this.save();
};

// Instance method: Remove expired tokens
userSchema.methods.cleanExpiredTokens = function () {
  this.refresh_tokens = this.refresh_tokens.filter(t => t.expires_at > new Date());
  return this.save();
};

// Static method: Find by role
userSchema.statics.findByRole = function (role, activeOnly = true) {
  const query = { role };
  if (activeOnly) query.isActive = true;
  return this.find(query);
};

// Static method: Get available technicians
userSchema.statics.getAvailableTechnicians = function () {
  return this.find({
    role: 'technician',
    isActive: true,
    availability_status: 'available'
  }).select('fullName email phone specializations performance_metrics');
};

// Static method: Get role statistics
userSchema.statics.getRoleStats = async function () {
  return this.aggregate([
    {
      $group: {
        _id:        '$role',
        total:      { $sum: 1 },
        active:     { $sum: { $cond: ['$isActive', 1, 0] } },
        avg_rating: { $avg: '$performance_metrics.rating' }
      }
    }
  ]);
};

// Pre-save hook to hash password
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  try {
    const isAlreadyHashed = /^\$2[ayb]\$/.test(this.password);
    if (isAlreadyHashed) return next();
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password for login
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Method to check if password is hashed
userSchema.methods.isPasswordHashed = function () {
  return /^\$2[ayb]\$/.test(this.password);
};

module.exports = mongoose.model('User', userSchema);
