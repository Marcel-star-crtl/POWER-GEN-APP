const mongoose = require('mongoose');

/**
 * TechnicianLocationPing
 *
 * Privacy design (do not weaken these without deliberate reconsideration):
 *
 *   1. Every ping is tied to a specific RefuelWorkflow (workflowId,
 *      required). There is no "ambient" tracking endpoint that accepts a
 *      location without an active job — the technician is only ever
 *      located while genuinely on a checked-in work session.
 *
 *   2. `expiresAt` + the TTL index below make MongoDB delete each ping
 *      automatically a few hours after it's written. This is a HARD
 *      database-level guarantee, not just an application convention —
 *      even a future bug in application code can't accidentally turn
 *      this into a permanent location history.
 *
 *   3. Only the SAME document's `latitude`/`longitude`/`updatedAt` are
 *      ever read back for the live map — see routes/technicianTrackingRoutes.js.
 *      There is deliberately no "get ping history for technician X"
 *      endpoint. If that's ever needed, it should be a conscious,
 *      separate decision with its own retention and access-control
 *      review, not an accidental byproduct of this collection existing.
 */
const technicianLocationPingSchema = new mongoose.Schema({
  technicianId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  workflowId:   { type: mongoose.Schema.Types.ObjectId, ref: 'RefuelWorkflow', required: true },
  siteId:       { type: mongoose.Schema.Types.ObjectId, ref: 'Site' },
  latitude:     { type: Number, required: true },
  longitude:    { type: Number, required: true },
  accuracy:     { type: Number },
  // One row per technician — each new ping overwrites the previous one
  // (see the upsert in the route) rather than accumulating a series.
  // There is intentionally no way to reconstruct a technician's path.
  updatedAt:    { type: Date, default: Date.now },
  expiresAt:    { type: Date, required: true },
}, { timestamps: { createdAt: false, updatedAt: false } }); // updatedAt managed manually above, matches the "latest ping" upsert pattern

technicianLocationPingSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
technicianLocationPingSchema.index({ technicianId: 1 }, { unique: true });

module.exports = mongoose.model('TechnicianLocationPing', technicianLocationPingSchema);
