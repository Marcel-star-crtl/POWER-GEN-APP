'use strict';

/**
 * notesRunHoursScanner.js
 *
 * Phase 121/122/124. Before this system had a dedicated run-hours
 * field (Phase 118), some technicians recorded a generator's run-hour
 * reading directly in the Faulty Gen Card check area's own notes field
 * — a real, genuine workaround, confirmed directly by the user
 * (Phase 122 corrected this from an earlier, broader field scope).
 *
 * Phase 124: Phase 123's verification script was run against real
 * live data, and what it found changed this file directly, not just
 * confirmed it worked:
 *   - Every one of 8 real matches used a bare "NNNNhrs" pattern with
 *     no explicit "RH" label — zero used the label this file's
 *     original "high confidence" pattern was built around. Since this
 *     field is scanned ONLY because it's specifically about a run-
 *     hours reading (Phase 122's whole point), a bare number here
 *     genuinely isn't as ambiguous as the same bare number would be in
 *     some other, unrelated field — confidence is now context-aware,
 *     not a fixed property of the pattern alone.
 *   - One real value (91400hrs) is implausible for a diesel generator
 *     — over 10 years of continuous, nonstop operation. Flagged as a
 *     real, separate concern rather than presented with the same
 *     trust as an ordinary reading.
 *   - The same real value appeared 2-3 times within a single audit's
 *     notes text, producing redundant duplicate suggestions for the
 *     same audit. Deduplicated.
 *
 * This scans text using plain regex, not a vision/AI model — an
 * explicit or even implicit run-hours mention in a field that's
 * exclusively about run hours is something regex catches reliably,
 * and reaching for an AI call for a task regex already handles well
 * would just add an unnecessary dependency (and cost, and latency)
 * for no real accuracy gain.
 *
 * Deliberately conservative regardless of the above: every match is
 * still a SUGGESTION with a confidence level, the exact text it came
 * from, and now a plausibility flag — never a value this module
 * decides on its own to write anywhere. The caller is responsible for
 * requiring a real review/accept step, same as the photo-extraction
 * feature (Phase 119).
 */

// A diesel generator running genuinely continuously, 24 hours a day,
// for 10 years straight, would reach about 87,600 hours — and these
// generators supplement grid power, they don't run nonstop. A reading
// above this is almost certainly a typo or misread, not a real value.
// Deliberately a round, conservative number, not a precisely-tuned
// domain threshold this codebase doesn't have real data to justify
// more precisely — the point is catching an obviously-wrong value
// like the real 91400hrs found in Phase 123, not asserting a strict
// fleet-specific ceiling.
const IMPLAUSIBLE_RUN_HOURS_THRESHOLD = 90000;

/**
 * @param {string} text
 * @param {{ fieldIsRunHoursSpecific?: boolean }} [options] - when true,
 *   a bare "NNNNhrs" match (no explicit "RH"/"run hours" label) is
 *   treated as high confidence rather than medium — correct only when
 *   the text being scanned comes from a field that's ALREADY,
 *   specifically, about a run-hours reading (like
 *   check_gen_cards_faulty.notes), where the field context itself
 *   removes most of the ambiguity a bare number would otherwise carry
 *   in general-purpose text. Confirmed this reflects real technician
 *   behavior directly (Phase 123's live-data run: 8 of 8 real matches
 *   used exactly this bare pattern, zero used an explicit label).
 * @returns {Array<{ value: number, confidence: 'high'|'medium', matched_text: string, plausible: boolean }>}
 */
function extractRunHoursCandidates(text, options = {}) {
  if (!text || typeof text !== 'string') return [];
  const { fieldIsRunHoursSpecific = false } = options;
  const candidates = [];

  const withPlausibility = (value, confidence, matched_text) => ({
    value, confidence, matched_text,
    plausible: value <= IMPLAUSIBLE_RUN_HOURS_THRESHOLD,
  });

  // Explicit label — "RH", "R.H.", "run hours", "run-hours",
  // "runhours" — directly followed by a number. About as unambiguous
  // as free text gets on its own, regardless of which field it's in.
  const labelFirst = /\b(?:run[\s-]?hours?|r\.?h\.?)\s*[:=\-]?\s*([\d,]{1,9}(?:\.\d+)?)\b/gi;
  let m;
  while ((m = labelFirst.exec(text)) !== null) {
    const raw = m[1].replace(/,/g, '');
    const value = parseFloat(raw);
    if (Number.isFinite(value)) {
      candidates.push(withPlausibility(value, 'high', m[0].trim()));
    }
  }

  // A number followed by "hrs"/"hours" with no explicit label. Only
  // checked when no explicit-label match already exists. Confidence
  // depends on context: "high" when the field itself is exclusively
  // about run hours (fieldIsRunHoursSpecific) — real data confirms
  // this is how technicians actually write it there, every time.
  // "medium" otherwise, since a bare number+hrs in a general-purpose
  // field genuinely could mean something else (a visit duration, etc).
  // A minimum of 3 digits filters out short numbers like "spent 2
  // hours on site", which is a duration, not a plausible reading,
  // regardless of which field it's found in.
  if (candidates.length === 0) {
    const numberFirst = /\b([\d,]{3,9}(?:\.\d+)?)\s*(?:hrs?|hours?)\b/gi;
    while ((m = numberFirst.exec(text)) !== null) {
      const raw = m[1].replace(/,/g, '');
      const value = parseFloat(raw);
      if (Number.isFinite(value)) {
        candidates.push(withPlausibility(value, fieldIsRunHoursSpecific ? 'high' : 'medium', m[0].trim()));
      }
    }
  }

  // Pure-number-line pattern — Phase 131. Driven by a real user-
  // provided export showing 70 real cases where the ENTIRE Gen Card
  // notes field is just a bare number, no unit or label at all
  // ("6934", not "6934hrs" or "RH: 6934"), plus a couple more where
  // the number sits on its own line among other descriptive text
  // ("15532\nDisplay screen too blurred"). Neither the label pattern
  // nor the "hrs"-suffix pattern above catches these — there's simply
  // no anchor text for either to match against. Only applied when the
  // field is run-hours-specific: a bare, unlabeled number is only
  // unambiguous because the field itself has no other plausible
  // purpose, not because the number "looks like" a reading on its own.
  // No 3-digit floor here (unlike the "hrs" pattern above, which
  // exists specifically to reject a short duration like "2 hours") —
  // the real data includes legitimate short readings like "35" and
  // "65" for a newly-installed generator, and a bare number in this
  // field was never at risk of being mistaken for a visit duration in
  // the first place, so imposing that same floor would just discard
  // real values.
  if (candidates.length === 0 && fieldIsRunHoursSpecific) {
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    for (const line of lines) {
      if (/^\d+(\.\d+)?$/.test(line)) {
        const value = parseFloat(line);
        if (Number.isFinite(value)) {
          candidates.push(withPlausibility(value, 'high', line));
        }
      }
    }
  }

  // Deduplicate identical values from the same piece of text — a
  // technician who wrote the same reading twice in one note (e.g.
  // "digital card faulty, mechanical shows 91400hrs, confirmed
  // 91400hrs with supervisor") should produce one suggestion, not one
  // per repetition. Keeps the first occurrence's exact matched text.
  const seen = new Set();
  return candidates.filter(c => {
    if (seen.has(c.value)) return false;
    seen.add(c.value);
    return true;
  });
}

/**
 * Scans the Faulty Gen Card check area's own notes field —
 * check_gen_cards_faulty.notes. Confirmed directly by the user that
 * this is specifically where the workaround readings were recorded,
 * not the general "Additional Notes" field (general_notes was
 * originally scanned too, in an earlier version of this feature, and
 * removed after that correction — general_notes is a genuinely
 * general-purpose free-text field, and scanning it risked false-
 * positive matches on unrelated "hours" mentions that have nothing to
 * do with a generator meter reading).
 *
 * @param {object} audit - a TankAudit document or lean object
 * @returns {Array<{ value: number, confidence: 'high'|'medium', matched_text: string, plausible: boolean, source_field: string }>}
 */
function scanAuditForRunHours(audit) {
  const results = [];
  const fieldsToScan = [
    { field: 'check_gen_cards_faulty.notes', text: audit.check_gen_cards_faulty?.notes, fieldIsRunHoursSpecific: true },
  ];
  for (const { field, text, fieldIsRunHoursSpecific } of fieldsToScan) {
    for (const candidate of extractRunHoursCandidates(text, { fieldIsRunHoursSpecific })) {
      results.push({ ...candidate, source_field: field });
    }
  }
  return results;
}

module.exports = { extractRunHoursCandidates, scanAuditForRunHours, IMPLAUSIBLE_RUN_HOURS_THRESHOLD };
