'use strict';

const axios = require('axios');

// OSRM's public demo server — free, no API key, same "no paid/key-gated
// maps provider" principle this app already follows for its map tiles
// (see SitesMapPage.tsx). This is a shared demo instance, not a
// dedicated one: it has no uptime guarantee and is rate-limited for
// heavy use. Fine for a single technician planning a day's route
// (a handful of calls, occasionally); if this fleet's usage ever grows
// heavy enough to hit rate limits routinely, the fix is standing up a
// self-hosted OSRM instance (open source, same API, no code changes
// needed here beyond the base URL) — not switching to a paid API.
const OSRM_BASE_URL = process.env.OSRM_BASE_URL || 'https://router.project-osrm.org';
const REQUEST_TIMEOUT_MS = 8000;

/**
 * Real driving distance/duration between every pair of points, in one
 * request — OSRM's Table service. Point 0 is always `start`, followed
 * by `stops` in the order given.
 *
 * @param {{lat:number, lng:number}} start
 * @param {Array<{lat:number, lng:number}>} stops
 * @returns {Promise<{distances: number[][], durations: number[][]} | null>}
 *   null (not a thrown error) on any failure — callers fall back to
 *   straight-line distance rather than crash the whole route request
 *   over a flaky third-party demo server.
 */
async function getDrivingMatrix(start, stops) {
  try {
    const points = [start, ...stops];
    const coordString = points.map(p => `${p.lng},${p.lat}`).join(';');
    const url = `${OSRM_BASE_URL}/table/v1/driving/${coordString}`;
    const res = await axios.get(url, {
      params: { annotations: 'distance,duration' },
      timeout: REQUEST_TIMEOUT_MS,
    });
    if (res.data?.code !== 'Ok') return null;
    return { distances: res.data.distances, durations: res.data.durations };
  } catch (err) {
    console.error('OSRM table request failed, falling back to straight-line distance:', err.message);
    return null;
  }
}

/**
 * Real road-path geometry and total distance/duration for a specific,
 * already-decided visiting order — OSRM's Route service. Called AFTER
 * the order is decided (via getDrivingMatrix + the nearest-neighbor
 * heuristic), not used to decide the order itself — Route always
 * visits points in the exact sequence given, so it's the wrong tool
 * for "what order should I visit these in."
 *
 * @param {Array<{lat:number, lng:number}>} orderedPoints - start first, then stops in visit order
 * @returns {Promise<{distance_m: number, duration_s: number, geometry: Array<[number, number]>} | null>}
 *   geometry is [lat, lng] pairs (react-leaflet's Polyline convention),
 *   already converted from OSRM's [lng, lat] GeoJSON order — a common
 *   source of silently-backwards routes on a map if left unconverted.
 */
async function getDrivingRoute(orderedPoints) {
  try {
    const coordString = orderedPoints.map(p => `${p.lng},${p.lat}`).join(';');
    const url = `${OSRM_BASE_URL}/route/v1/driving/${coordString}`;
    const res = await axios.get(url, {
      params: { overview: 'full', geometries: 'geojson' },
      timeout: REQUEST_TIMEOUT_MS,
    });
    if (res.data?.code !== 'Ok' || !res.data.routes?.length) return null;
    const route = res.data.routes[0];
    return {
      distance_m: route.distance,
      duration_s: route.duration,
      geometry: route.geometry.coordinates.map(([lng, lat]) => [lat, lng]),
    };
  } catch (err) {
    console.error('OSRM route request failed, falling back to straight-line path:', err.message);
    return null;
  }
}

module.exports = { getDrivingMatrix, getDrivingRoute };
