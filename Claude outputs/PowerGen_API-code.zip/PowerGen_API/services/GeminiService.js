const { GoogleGenerativeAI } = require("@google/generative-ai");
const logger = require('../utils/logger');
const axios = require('axios');

class GeminiService {
  constructor() {
    this.apiKey = process.env.GEMINI_API_KEY;
    if (!this.apiKey) {
      logger.warn('GEMINI_API_KEY is not set in environment variables');
    }
    this.genAI = new GoogleGenerativeAI(this.apiKey);
    this.model = this.genAI.getGenerativeModel({ model: "gemini-flash-latest" });
  }

  /**
   * Generate maintenance advice based on task details
   * @param {Object} taskDetails - Details of the maintenance task
   * @returns {Promise<string>} - Advice text
   */
  async generateMaintenanceAdvice(taskDetails) {
    try {
      const prompt = `
        You are an expert industrial generator technician. 
        Provide specific, safe, and professional maintenance advice for the following task:
        
        Equipment: ${taskDetails.equipmentName || 'Generator'}
        Issue/Task: ${taskDetails.description || 'General Maintenance'}
        Error Codes (if any): ${taskDetails.errorCodes || 'None'}
        
        Please provide:
        1. Safety precautions first.
        2. Step-by-step troubleshooting or maintenance guide.
        3. Tools likely needed.
      `;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      logger.error('Gemini generateMaintenanceAdvice error:', error);
      throw new Error('Failed to generate maintenance advice');
    }
  }

  /**
   * Enhance technician notes into a professional report
   * @param {string} rawNotes - Rough notes from technician
   * @returns {Promise<string>} - Polished report text
   */
  async enhanceReport(rawNotes) {
    try {
      const prompt = `
        Transform the following rough technician notes into a clear, professional technical report paragraph.
        Fix grammar, expand abbreviations, and ensure a professional tone. Keep it factual.
        
        Technician Notes:
        "${rawNotes}"
      `;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      logger.error('Gemini enhanceReport error:', error);
      throw new Error('Failed to enhance report');
    }
  }

  /**
   * Analyze cluster performance and provide insights for Supervisor
   * @param {Object} clusterStats - Statistics about the cluster
   * @returns {Promise<string>} - Analysis text
   */
  async analyzeClusterPerformance(clusterStats) {
    try {
      // safe stringify
      const statsStr = JSON.stringify(clusterStats, null, 2);

      const prompt = `
        Analyze the following cluster performance data for a Grato supervisor.
        Highlight any anomalies, efficiency issues, or areas needing attention.
        
        Data:
        ${statsStr}
        
        Provide 3 key insights or action items.
      `;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      logger.error('Gemini analyzeClusterPerformance error:', error);
      throw new Error('Failed to analyze cluster performance');
    }
  }

  /**
   * General chat for assistance
   * @param {string} message - User query
   * @param {string} role - User role (technician/supervisor)
   * @returns {Promise<string>}
   */
  async chat(message, role) {
    try {
      const prompt = `
        You are an AI assistant for the Grato Monitoring System.
        The user is a ${role}.
        Answer their question regarding generator maintenance, system usage, or safety.
        
        User Question: "${message}"
      `;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      logger.error('Gemini chat error:', error);
      throw new Error('Failed to process chat message');
    }
  }

  /**
   * Extract a generator run-hour reading from a photo of a meter or
   * mechanical counter — used when a site's digital run-hour card is
   * faulty and a technician photographs the mechanical replacement
   * instead (the Tank Audit Plan's own documented workaround).
   *
   * Returns a SUGGESTION, not a fact — the caller is responsible for
   * keeping this separate from any technician-entered value and
   * requiring a real accept step before it feeds into anything, since
   * this reading ultimately feeds fuel-accounting calculations
   * (True CPH, Gain/Loss) where a wrong number has real consequences.
   *
   * @param {string} imageUrl - a real, fetchable HTTPS URL (Cloudinary, in this app's case)
   * @returns {Promise<{ value: number|null, confidence: 'high'|'medium'|'low'|null, notes: string|null }>}
   */
  async extractRunHoursFromImage(imageUrl) {
    try {
      const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 15000 });
      const base64Data = Buffer.from(imageResponse.data).toString('base64');
      const mimeType = imageResponse.headers['content-type'] || 'image/jpeg';

      const prompt = `You are looking at a photo taken by a field technician of a generator's run-hour meter or mechanical hour counter (this photo was taken specifically because the site's digital run-hour card is faulty, and this mechanical counter is the documented workaround).

Read the numeric run-hour value shown on the meter/counter in this photo.

Respond with ONLY a JSON object, no other text, no markdown code fences, in exactly this shape:
{"value": <number or null>, "confidence": "high" | "medium" | "low", "notes": "<short note, or empty string>"}

- "value": the run-hour number you read, as a plain number. Use null if the photo doesn't show a readable meter/counter at all.
- "confidence": "high" if the digits are clear and unambiguous, "medium" if mostly readable but with some uncertainty, "low" if you had to guess at one or more digits.
- "notes": explain anything relevant — glare, blur, a partially obscured digit, whether it looks like a real run-hour counter vs. something else, etc. Keep it to one short sentence. Empty string if there's nothing worth noting.`;

      const result = await this.model.generateContent([
        prompt,
        { inlineData: { mimeType, data: base64Data } },
      ]);
      const responseText = (await result.response).text().trim();

      // Strip markdown code fences if the model added them despite
      // being asked not to — a real, observed model behavior, not a
      // hypothetical worth guarding against.
      const cleaned = responseText.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();

      let parsed;
      try {
        parsed = JSON.parse(cleaned);
      } catch (parseErr) {
        logger.error('Gemini extractRunHoursFromImage: response was not valid JSON:', responseText);
        return { value: null, confidence: null, notes: 'The extraction response could not be parsed — try again or enter the reading manually.' };
      }

      const value = typeof parsed.value === 'number' && Number.isFinite(parsed.value) ? parsed.value : null;
      const confidence = ['high', 'medium', 'low'].includes(parsed.confidence) ? parsed.confidence : null;
      const notes = typeof parsed.notes === 'string' ? parsed.notes : null;

      return { value, confidence, notes };
    } catch (error) {
      logger.error('Gemini extractRunHoursFromImage error:', error);
      throw new Error('Failed to extract run-hours reading from image');
    }
  }
}

module.exports = new GeminiService();
