'use strict';
const logger = require('../utils/logger');
let _transporter = null;
function getTransporter() {
  if (_transporter) return _transporter;
  if (!process.env.EMAIL_HOST) { logger.warn('[emailService] EMAIL_HOST not set — emails logged only'); return null; }
  const nodemailer = require('nodemailer');
  _transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST, port: parseInt(process.env.EMAIL_PORT || '587'),
    secure: process.env.EMAIL_SECURE === 'true',
    auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
    tls: { rejectUnauthorized: false },
  });
  return _transporter;
}
async function sendEmail({ to, subject, html, text }) {
  const transporter = getTransporter();
  const recipients  = Array.isArray(to) ? to.join(', ') : to;
  const from        = process.env.EMAIL_FROM || 'GRATO PowerGen <noreply@gratoengineering.com>';
  if (!transporter) { logger.info(`[emailService] MOCK → ${recipients} | ${subject}`); return { mock: true }; }
  try {
    const info = await transporter.sendMail({ from, to: recipients, subject, html, text });
    logger.info(`[emailService] Sent → ${recipients} | ${subject}`);
    return info;
  } catch (err) {
    logger.error(`[emailService] Failed → ${recipients} | ${err.message}`);
    throw err;
  }
}
module.exports = { sendEmail };

