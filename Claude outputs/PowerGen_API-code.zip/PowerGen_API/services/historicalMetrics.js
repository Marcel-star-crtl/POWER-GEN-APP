/**
 * historicalMetrics.js
 * diesel-system/services/historicalMetrics.js
 *
 * Phase 169 — extracted, not rewritten. These four pure functions used to
 * live inline in routes/historicalDataRoutes.js (Phases 165-168); the Excel
 * export (services/historicalExcelExport.js) needed the exact same math for
 * its new Gain/Loss, Carried-Over Stock Burned, Run Hours/True CPH, and
 * Stability/Anomaly columns, and copy-pasting them into a second file would
 * have created exactly the kind of drift risk this whole feature set has
 * deliberately avoided since Phase 166 ("one shared function, not four
 * separate inline copies"). Pulled out here instead, required by both
 * files, so the live app and the Excel export can never quietly disagree
 * about what "Gain / Loss" or "Carried-Over Stock Burned" means.
 *
 * No database access, no Express, no req/res — every function here takes
 * plain arrays/numbers already fetched by the caller and returns plain
 * objects. That's what makes reusing them across a route handler and an
 * offline batch export safe.
 */
'use strict';

/**
 * carriedOverStockBurn(visits) — Phase 165, REDEFINED Phase 168.
 *
 * Originally (Phase 165) this isolated only the carried-over stock
 * consumed BEFORE a cycle's first delivery. The user has since asked
 * for something simpler and more literal, replacing that entirely:
 * the net change in physical stock across the WHOLE cycle —
 *
 *   net_change_l = last visit's own fuel_left_l reading
 *                  − first visit's own fuel_found_l reading
 *
 * — both actual tank-dip measurements this cycle, nothing modeled or
 * estimated. A NEGATIVE result means stock net DECREASED over the
 * cycle (burned); POSITIVE means it net INCREASED (e.g. deliveries
 * outpaced consumption). Deliveries and consumption both feed into
 * this number implicitly — unlike the old figure, it does not isolate
 * one from the other. For a figure that nets out deliveries and
 * validated consumption explicitly, see Gain/Loss (computeGainLoss
 * below) — a different, complementary question.
 *
 * `visits` must be one site's own visits for one cycle, sorted
 * ascending by visit_date (every call site already fetches/sorts this
 * way — same contract this function has always had). A site with only
 * one visit this cycle has first === last, so the figure reduces to
 * that single visit's own (fuel_left_l − fuel_found_l) — i.e. roughly
 * what was added/consumed at that one visit, which is correct, not a
 * degenerate case.
 */
function carriedOverStockBurn(visits) {
  if (!visits || !visits.length) {
    return {
      net_change_l: null,
      first_visit_date: null, first_visit_found_l: null,
      last_visit_date: null, last_visit_stock_l: null,
      note: 'No field visit recorded this cycle.',
    };
  }
  const first = visits[0];
  const last = visits[visits.length - 1];
  const first_visit_found_l = first.fuel_found_l ?? null;
  const last_visit_stock_l = last.fuel_left_l ?? null;
  const net_change_l = (first_visit_found_l != null && last_visit_stock_l != null)
    ? last_visit_stock_l - first_visit_found_l
    : null;
  return {
    net_change_l,
    first_visit_date: first.visit_date, first_visit_found_l,
    last_visit_date: last.visit_date, last_visit_stock_l,
    note: net_change_l != null ? null
      : (first_visit_found_l == null
        ? 'First visit this cycle did not record a fuel_found_l reading.'
        : 'Last visit this cycle did not record a fuel_left_l reading.'),
  };
}

/**
 * cycleEngineeringFigures(visits) — Phase 168.
 *
 * Shared re-derivation of the per-interval True CPH math the single-
 * site report has always done inline, pulled out so the bulk sortable
 * listings (site-cycle-summary, cluster-cycle-summary) can compute the
 * same figures per site without duplicating the logic. `visits` must
 * be one site's own visits for one cycle. Returns each interval's own
 * True CPH (liters consumed ÷ run_hours, self-contained per visit —
 * `fuel_previously_left_l - fuel_found_l` needs no cross-row lookup),
 * the cycle's run-hours total, and the weighted-average True CPH
 * across all qualifying intervals (weighted by hours, not a simple
 * average of per-interval rates).
 */
function cycleEngineeringFigures(visits) {
  const intervals = (visits || [])
    .filter(v => v.fuel_previously_left_l != null && v.fuel_found_l != null && !!v.run_hours)
    .map(v => {
      const consumed_l = v.fuel_previously_left_l - v.fuel_found_l;
      return { run_hours: v.run_hours, interval_consumed_l: consumed_l, interval_true_cph: Math.round((consumed_l / v.run_hours) * 100) / 100 };
    });
  const run_hours_total = (visits || []).reduce((s, v) => s + (v.run_hours || 0), 0);
  let avg_true_cph = null;
  if (intervals.length) {
    const totalHours = intervals.reduce((s, v) => s + v.run_hours, 0);
    const totalConsumed = intervals.reduce((s, v) => s + v.interval_consumed_l, 0);
    avg_true_cph = totalHours ? Math.round((totalConsumed / totalHours) * 100) / 100 : null;
  }
  return { run_hours_total, avg_true_cph, intervals };
}

/**
 * consumptionStability(intervals) — Phase 168.
 *
 * Answers "has this site's consumption been stable this cycle, or
 * does it show anomalies?" with ONE number driving both ends of a
 * sort, per the user's own preferred definition: the coefficient of
 * variation (stddev ÷ mean) of True CPH across this cycle's own
 * intervals. Low CoV = tightly clustered = stable. An `anomaly_flag`
 * is also set when at least one interval's True CPH is more than 2x
 * or less than 0.5x that SAME site's own average this cycle — a
 * relative, per-site threshold, not a fleet-wide one, since sites
 * legitimately run at very different baseline rates.
 *
 * Needs at least 2 qualifying intervals to say anything meaningful —
 * with 0 or 1, both figures come back null rather than a misleadingly
 * confident "stable."
 */
function consumptionStability(intervals) {
  const list = intervals || [];
  if (list.length < 2) {
    return {
      coefficient_of_variation: null, anomaly_flag: null, anomaly_interval_count: 0,
      interval_count: list.length,
      note: list.length === 1
        ? 'Only one qualifying interval this cycle — not enough data to judge stability.'
        : 'No qualifying intervals this cycle (needs fuel_previously_left_l, fuel_found_l, and run_hours on at least two visits).',
    };
  }
  const vals = list.map(v => v.interval_true_cph);
  const mean = vals.reduce((s, v) => s + v, 0) / vals.length;
  const variance = vals.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / vals.length;
  const stddev = Math.sqrt(variance);
  const coefficient_of_variation = mean !== 0 ? Math.round((stddev / Math.abs(mean)) * 1000) / 1000 : null;
  const anomalies = mean !== 0 ? vals.filter(v => v > mean * 2 || v < mean * 0.5) : [];
  return {
    coefficient_of_variation,
    anomaly_flag: anomalies.length > 0,
    anomaly_interval_count: anomalies.length,
    interval_count: vals.length,
    note: null,
  };
}

/**
 * computeGainLoss(visits, delivered_to_site_l, consumed_l) — Phase 167.
 *
 * Replaces the budget-based Reserve tile with a purely physical
 * reconciliation, per the user's own formula: what came in this cycle
 * (whatever was already on site at the first visit, plus whatever got
 * delivered) minus what was validated as consumed.
 *
 *   gain_loss_l = delivered_to_site_l + first_visit_fuel_found_l - consumed_l
 *
 * `first_visit_fuel_found_l` is `fuel_found_l` on the cycle's
 * chronologically FIRST visit (visits[0] — the array must already be
 * sorted ascending, same contract as carriedOverStockBurn) — i.e. the
 * opening physical stock for the cycle, as actually measured, not
 * assumed to equal the prior cycle's closing figure. `delivered_to_site_l`
 * is the same figure already shown on its own tile (sum of fuel_added_l
 * across the cycle's visits). `consumed_l` is the validated
 * final_consumption_l each call site already has in hand — this
 * function does not recompute it.
 *
 * Null (not 0) when either the opening stock or the validated
 * consumption is missing — a real gap should read as "unknown," not
 * silently understate or overstate a Gain/Loss that isn't really
 * knowable yet. Distinct from, and does NOT touch, the older
 * budget-based `reserve_liters` / `fully_exhausted` fields — those stay
 * as they are (used elsewhere, e.g. Chronically Exhausted Sites), this
 * is a separate, additional figure that now takes Reserve's place on
 * the KPI tiles specifically.
 */
function computeGainLoss(visits, delivered_to_site_l, consumed_l) {
  const firstVisit = visits && visits.length ? visits[0] : null;
  const first_visit_fuel_found_l = firstVisit?.fuel_found_l ?? null;
  const base = {
    delivered_to_site_l: delivered_to_site_l ?? 0,
    first_visit_fuel_found_l,
    first_visit_date: firstVisit?.visit_date ?? null,
    consumed_l: consumed_l ?? null,
  };
  if (first_visit_fuel_found_l == null || consumed_l == null) {
    return {
      ...base,
      gain_loss_l: null,
      note: first_visit_fuel_found_l == null
        ? 'No field visit this cycle recorded a fuel_found_l reading on its first visit.'
        : 'No validated consumption figure (final_consumption_l) recorded for this cycle.',
    };
  }
  return {
    ...base,
    gain_loss_l: (delivered_to_site_l || 0) + first_visit_fuel_found_l - consumed_l,
    note: null,
  };
}

module.exports = {
  carriedOverStockBurn,
  cycleEngineeringFigures,
  consumptionStability,
  computeGainLoss,
};
