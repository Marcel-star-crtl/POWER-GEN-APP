'use strict';

/**
 * aiFleetInsightsService.js
 *
 * "Studying the behavior of the entire diesel system" in practice means
 * synthesizing the REAL, ALREADY-COMPUTED signals this system produces
 * across its different features — not asking an LLM to invent an
 * assessment from nothing. Every number handed to Gemini here comes from
 * a real query against real collections; Gemini's job is narrative
 * synthesis and prioritization across sources a human would otherwise
 * have to check one page at a time (Alerts, Budget Planning, Reconciliation,
 * Fuel Requests), not fact invention. This keeps the output grounded and
 * auditable — every claim in the narrative can be traced back to the
 * `evidence` object returned alongside it.
 */

const DieselAlert = require('../models/DieselAlert');
const CycleReconciliation = require('../models/CycleReconciliation');
const FuelRequest = require('../models/FuelRequest');
const TechnicianLocationPing = require('../models/TechnicianLocationPing');
const { planAllSites } = require('./budgetPlanningService');
const logger = require('../utils/logger');

// Regenerating a briefing calls Gemini and re-runs the whole budget plan
// across every site — genuinely not cheap. Cached in memory per cycle,
// same reasoning as the technician-tracking in-progress lock: a single-
// server-instance cache is the right scope for this app's actual
// deployment shape.
const briefingCache = new Map(); // cycle_key -> { generatedAt, data }
const CACHE_TTL_MS = 60 * 60 * 1000; // 1 hour

async function gatherEvidence(cycle_key) {
  const [
    alertsBySeverity,
    alertsByType,
    reconStats,
    pendingRequests,
    activeTechnicians,
    plan,
  ] = await Promise.all([
    DieselAlert.aggregate([
      { $match: { cycle_key, status: { $in: ['open', 'acknowledged'] } } },
      { $group: { _id: '$severity', count: { $sum: 1 } } },
    ]),
    DieselAlert.aggregate([
      { $match: { cycle_key, status: { $in: ['open', 'acknowledged'] } } },
      { $group: { _id: '$alert_type', count: { $sum: 1 }, sites: { $push: '$site_id' } } },
      { $sort: { count: -1 } },
      { $limit: 8 },
    ]),
    CycleReconciliation.aggregate([
      { $match: { cycle_key } },
      { $group: {
        _id: null,
        total_sites: { $sum: 1 },
        missing_field_data: { $sum: { $cond: ['$grato_submission_missing', 1, 0] } },
        missing_cms: { $sum: { $cond: [{ $lt: ['$cms_days_covered', '$cms_days_expected'] }, 1, 0] } },
        theft_suspected: { $sum: { $cond: ['$alerts.theft_suspected', 1, 0] } },
        total_theft_liters: { $sum: { $ifNull: ['$theft_liters', 0] } },
        avg_cons_variance_pct: { $avg: { $ifNull: ['$cons_variance_pct', 0] } },
      }},
    ]),
    FuelRequest.aggregate([
      { $match: { cycle_key, status: { $regex: /^pending_/ } } },
      { $group: { _id: '$status', count: { $sum: 1 }, oldest: { $min: '$createdAt' } } },
    ]),
    TechnicianLocationPing.countDocuments({ expiresAt: { $gt: new Date() } }),
    planAllSites(30).catch(() => null), // 30-day default; this is an evidence signal, not a precise commit-ready plan
  ]);

  const flaggedBudgetSites = (plan?.sites || [])
    .filter(s => s.flag)
    .sort((a, b) => Math.abs(b.variance_pct || 0) - Math.abs(a.variance_pct || 0))
    .slice(0, 10)
    .map(s => ({ site_id: s.site_id, site_name: s.site_name, variance_pct: s.variance_pct, confidence: s.confidence }));

  return {
    cycle_key,
    alerts: {
      by_severity: alertsBySeverity,
      by_type: alertsByType,
      total_open: alertsBySeverity.reduce((s, a) => s + a.count, 0),
    },
    reconciliation: reconStats[0] || null,
    pending_approvals: pendingRequests,
    active_technicians_now: activeTechnicians,
    budget_planning: {
      total_flagged: flaggedBudgetSites.length,
      top_flagged_sites: flaggedBudgetSites,
      fleet_summary: plan?.summary || null,
    },
  };
}

function buildPrompt(evidence) {
  return `
You are a senior fleet operations analyst for a diesel generator network
powering telecom towers in Cameroon (GRATO PowerGen). You've been given
real, already-computed operational data pulled directly from the fleet
management system's live database for cycle ${evidence.cycle_key} —
not raw guesses, actual current figures.

ALERTS (open/acknowledged):
${JSON.stringify(evidence.alerts, null, 2)}

RECONCILIATION COMPLETENESS & THEFT SIGNALS:
${JSON.stringify(evidence.reconciliation, null, 2)}

PENDING FUEL REQUEST APPROVALS (by approval stage):
${JSON.stringify(evidence.pending_approvals, null, 2)}

TECHNICIANS CURRENTLY ON AN ACTIVE JOB: ${evidence.active_technicians_now}

BUDGET PLANNING — sites where the engineering formula and actual recent
consumption disagree significantly (each already computed, not an
estimate you need to make):
${JSON.stringify(evidence.budget_planning, null, 2)}

Write a briefing for a diesel operations manager starting their day.
Structure it in exactly these sections, using the section headers shown:

## Priority Actions Today
The 3-5 most urgent, specific things to act on right now, each tied to a
concrete number from the data above (not vague advice). Order by urgency.

## Patterns Worth Noting
Any correlations or repeated signals across the different data sources
above (e.g. a cluster showing up in both alerts and budget-planning
flags is a stronger signal than either alone). Only mention genuine
patterns actually visible in the data — do not invent one if there
isn't one.

## Watch List
Sites or signals that aren't urgent yet but are trending toward becoming
a problem, based on the variance and trend data provided — this is
where you flag something before it becomes an emergency, using only the
data given, not speculation beyond it.

Keep the whole thing under 300 words, professional, and direct — this
person has an actual fleet to run, not time for padding. If a section
genuinely has nothing to report, say so briefly rather than manufacturing
content.
`.trim();
}

/**
 * Generates (or returns a cached) fleet intelligence briefing for a cycle.
 * Returns { narrative, evidence, generatedAt, cached } — the evidence is
 * always returned alongside the narrative so the UI can show the real
 * numbers a claim is based on, not just trust the prose.
 */
async function generateBriefing(cycle_key, { forceRefresh = false } = {}) {
  const cached = briefingCache.get(cycle_key);
  if (!forceRefresh && cached && (Date.now() - cached.generatedAt) < CACHE_TTL_MS) {
    return { ...cached.data, cached: true };
  }

  const evidence = await gatherEvidence(cycle_key);

  let narrative = null;
  let ai_enabled = false;
  if (process.env.GEMINI_API_KEY) {
    ai_enabled = true;
    try {
      const gemini = require('./GeminiService');
      narrative = await gemini.chat(buildPrompt(evidence), 'diesel_manager');
    } catch (e) {
      logger.warn('[AIFleetInsights] Gemini briefing failed (non-fatal):', e.message);
      narrative = null;
    }
  }

  const result = { narrative, ai_enabled, evidence, generatedAt: new Date(), cached: false };
  briefingCache.set(cycle_key, { generatedAt: Date.now(), data: result });
  return result;
}

module.exports = { generateBriefing, gatherEvidence };
