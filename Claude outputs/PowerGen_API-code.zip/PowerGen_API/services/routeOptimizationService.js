'use strict';

const { calculateDistanceMeters } = require('../utils/geofence');

// Urgency acts as a "pull sites forward" weight, not a hard sort — a
// critical site 2km away should usually be visited before an ok site
// 500m away, but not always at the total expense of an efficient route
// (e.g. if the critical site is also basically on the way). This is a
// deliberately simple, explainable model rather than a black-box score:
// each urgency level subtracts a fixed "credit" (in meters) from a
// site's effective distance when it's being considered next, making
// urgent sites look closer than they really are by an amount
// proportional to how urgent they are.
const URGENCY_CREDIT_METERS = {
  critical: 8000,
  high:     4000,
  medium:   1500,
  ok:       0,
  unknown:  0,
};

/**
 * Orders a list of stops into an efficient visiting sequence using a
 * greedy nearest-neighbor heuristic, starting from `start`.
 *
 * Deliberately NOT a full TSP solver (branch-and-bound, simulated
 * annealing, etc.) — for the realistic size of a single technician's day
 * (2-10 stops), nearest-neighbor with an urgency credit produces a route
 * that's easy to explain ("closest urgent site next"), fast enough to
 * compute instantly, and close enough to optimal that the difference
 * doesn't matter at this scale. A real TSP solver would be worth
 * revisiting only if route planning ever needs to span dozens of stops
 * in one sequence, which isn't how this fleet's refuel days work.
 *
 * @param {{lat:number, lng:number}} start
 * @param {Array<{site_id:string, lat:number, lng:number, urgency?:string}>} stops
 * @param {{distances: number[][], durations: number[][]} | null} [drivingMatrix]
 *   Real road distances/durations from OSRM's Table service, indexed
 *   [start, ...stops] in that exact original order (index 0 = start,
 *   1..n = stops in the order passed in). When provided, both the
 *   nearest-neighbor decisions AND the reported leg distances use real
 *   road data instead of straight-line — a genuinely different route
 *   can result, not just a different number on the same route, since a
 *   straight-line-nearest site isn't always the road-nearest one.
 *   Pass null/omit to use straight-line distance only (the original
 *   behavior, unchanged for any caller not passing this).
 * @returns {{ order: Array, total_distance_m: number, total_duration_s: number|null, legs: Array, used_road_distance: boolean }}
 */
function optimizeRoute(start, stops, drivingMatrix = null) {
  // Stable original indices — `remaining` gets spliced down as stops
  // are visited, but the matrix's rows/columns are fixed to each
  // stop's ORIGINAL position (1..n, since index 0 is always `start`).
  // Losing track of this and using `remaining`'s shrinking array
  // position instead would silently look up the wrong pair's distance
  // after the first stop is removed.
  const remaining = stops.map((stop, i) => ({ stop, originalIndex: i + 1 }));
  const order = [];
  const legs = [];
  let currentIndex = 0; // 0 = start, in matrix terms
  let current = start;
  let totalDistance = 0;
  let totalDuration = drivingMatrix ? 0 : null;
  const usedRoadDistance = !!drivingMatrix;

  while (remaining.length > 0) {
    let bestPos = 0;
    let bestEffectiveDistance = Infinity;
    let bestRealDistance = 0;
    let bestDuration = null;

    for (let i = 0; i < remaining.length; i++) {
      const { stop, originalIndex } = remaining[i];
      let realDistance, duration;
      if (drivingMatrix) {
        realDistance = drivingMatrix.distances?.[currentIndex]?.[originalIndex];
        duration = drivingMatrix.durations?.[currentIndex]?.[originalIndex];
        // A specific pair OSRM couldn't route between (e.g. an island
        // with no bridge) shows up as null in its matrix — fall back
        // to straight-line for just that one comparison rather than
        // let one bad pair silently break distance-based ordering for
        // every other pair.
        if (realDistance == null) realDistance = calculateDistanceMeters(current.lat, current.lng, stop.lat, stop.lng);
      } else {
        realDistance = calculateDistanceMeters(current.lat, current.lng, stop.lat, stop.lng);
      }
      const credit = URGENCY_CREDIT_METERS[stop.urgency] || 0;
      const effectiveDistance = Math.max(0, realDistance - credit);
      if (effectiveDistance < bestEffectiveDistance) {
        bestEffectiveDistance = effectiveDistance;
        bestRealDistance = realDistance;
        bestDuration = duration ?? null;
        bestPos = i;
      }
    }

    const { stop: next, originalIndex: nextIndex } = remaining.splice(bestPos, 1)[0];
    order.push(next);
    legs.push({
      from: current.site_id || 'start',
      to: next.site_id,
      distance_m: Math.round(bestRealDistance),
      duration_s: bestDuration != null ? Math.round(bestDuration) : null,
    });
    totalDistance += bestRealDistance;
    if (totalDuration != null && bestDuration != null) totalDuration += bestDuration;
    current = next;
    currentIndex = nextIndex;
  }

  return {
    order,
    total_distance_m: Math.round(totalDistance),
    total_duration_s: totalDuration != null ? Math.round(totalDuration) : null,
    legs,
    used_road_distance: usedRoadDistance,
  };
}

module.exports = { optimizeRoute, URGENCY_CREDIT_METERS };
