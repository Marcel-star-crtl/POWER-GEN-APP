'use strict';

const SiteEngineeringParams = require('../models/SiteEngineeringParams');
const SiteConsumptionHistory = require('../models/SiteConsumptionHistory');
const Site = require('../models/Site');

const DEFAULT_XAF_PER_LITER = 828;

// How much weight recent months get in the trend calculation — most
// recent month counted heaviest, since the closer a month is to the
// cycle being planned, the more representative it likely is of current
// conditions (recent maintenance, recent grid changes, etc.).
const TREND_WEIGHTS = [0.5, 0.3, 0.2]; // most-recent, 2nd-most-recent, 3rd-most-recent
const TREND_MONTHS = TREND_WEIGHTS.length;

// Divergence thresholds between the engineering estimate and the real
// historical trend — deliberately not a single hard cutoff. A small gap
// is normal noise; a large one means the engineering assumption (grid
// availability, generator condition) probably no longer matches reality
// for that specific site, and the plan should lean toward what's
// actually been happening rather than a stale formula input.
const REVIEW_THRESHOLD_PCT = 15;   // beyond this: blend estimate and trend, flag for review
const URGENT_THRESHOLD_PCT = 40;   // beyond this: weight heavily toward the trend, flag urgently

function roundUpLiters(n) {
  return Math.ceil(n);
}

/**
 * Weighted average of a site's most recent months of actual consumption.
 * Returns null if there's no history at all (distinct from 0 — a site
 * with genuinely zero consumption history is different from one with no
 * data on file).
 */
function computeTrend(historyRows) {
  // historyRows expected sorted most-recent-first (see
  // SiteConsumptionHistory.getRecentHistory).
  const recent = historyRows.slice(0, TREND_MONTHS);
  if (recent.length === 0) return null;

  // If fewer months are available than TREND_WEIGHTS has entries,
  // re-normalize the weights we do have so they still sum to 1 rather
  // than silently under-weighting (e.g. a site with only 1 month of
  // history should have that month count for 100%, not 50%).
  const weights = TREND_WEIGHTS.slice(0, recent.length);
  const weightSum = weights.reduce((a, b) => a + b, 0);

  let weighted = 0;
  for (let i = 0; i < recent.length; i++) {
    weighted += recent[i].actual_consumption_l * (weights[i] / weightSum);
  }
  return weighted;
}

/**
 * Plans one site's budget for a target cycle.
 *
 * @param {string} site_id
 * @param {number} daysInCycle
 * @returns {Promise<object|null>} null if the site has no engineering
 *   params on file at all (can't compute anything without CPH/grid
 *   availability) — caller decides how to handle sites with no plan.
 */
async function planSiteBudget(site_id, daysInCycle) {
  const [params, historyRows] = await Promise.all([
    SiteEngineeringParams.findOne({ site_id }).lean(),
    // Fetches a generous window (covers the full imported history, not
    // just the months the trend calculation itself needs) so the full
    // series can be returned for charting on the frontend, not just the
    // narrow slice used in the variance math below.
    SiteConsumptionHistory.getRecentHistory(site_id, 12),
  ]);

  if (!params) {
    return {
      site_id, plannable: false,
      reason: 'No engineering parameters on file for this site — run scripts/importBudgetPlanningData.js, or this may be a new site not yet in the engineering model.',
    };
  }

  // ── Engineering estimate — the organization's own verified formula ──────────
  const runHours = (1 - params.final_grid_availability) * 24 * daysInCycle;
  const engineeringEstimate = runHours * params.genset_cph;

  // ── Historical trend — real, ground-truth recent consumption ────────────────
  const trend = computeTrend(historyRows);

  let finalLiters, confidence, flag, variancePct = null;

  if (trend === null) {
    // No history at all — nothing to cross-validate against, so the
    // engineering estimate is the only figure available. Flagged as
    // lower-confidence rather than presented with the same certainty as
    // a cross-validated figure.
    finalLiters = engineeringEstimate;
    confidence = 'low';
    flag = 'No historical consumption data for this site — using engineering estimate only, unvalidated.';
  } else {
    variancePct = engineeringEstimate > 0
      ? ((trend - engineeringEstimate) / engineeringEstimate) * 100
      : (trend > 0 ? 100 : 0);
    const absVariance = Math.abs(variancePct);

    if (absVariance <= REVIEW_THRESHOLD_PCT) {
      // Engineering estimate and real recent behavior agree closely —
      // trust the formula, it's validated by what's actually happening.
      finalLiters = engineeringEstimate;
      confidence = 'high';
      flag = null;
    } else if (absVariance <= URGENT_THRESHOLD_PCT) {
      // Meaningful but not extreme divergence — split the difference
      // rather than fully trusting either source alone, and surface it
      // for a human to look at.
      finalLiters = (engineeringEstimate * 0.5) + (trend * 0.5);
      confidence = 'medium';
      flag = `Engineering estimate diverges from recent actual consumption by ${variancePct.toFixed(1)}% — review grid availability / generator assumptions for this site.`;
    } else {
      // Large divergence — the engineering snapshot (grid availability,
      // generator condition) is very likely stale for this site. Weight
      // heavily toward real, recent, observed behavior instead.
      finalLiters = (engineeringEstimate * 0.2) + (trend * 0.8);
      confidence = 'low';
      flag = `URGENT — engineering estimate diverges from recent actual consumption by ${variancePct.toFixed(1)}%. This site's grid-availability/generator data is likely outdated; verify before relying on this figure.`;
    }
  }

  const budgetLiters = roundUpLiters(finalLiters);

  return {
    site_id,
    site_name: params.site_name,
    cluster: params.cluster,
    region: params.region,
    topology: params.topology,
    plannable: true,
    days_in_cycle: daysInCycle,
    genset_cph: params.genset_cph,
    final_grid_availability: params.final_grid_availability,
    budgeted_rh: Math.round(runHours * 100) / 100,
    engineering_estimate_l: Math.round(engineeringEstimate * 100) / 100,
    trend_l: trend !== null ? Math.round(trend * 100) / 100 : null,
    variance_pct: variancePct !== null ? Math.round(variancePct * 10) / 10 : null,
    months_of_history: historyRows.length,
    // Oldest-first for natural left-to-right chart reading — historyRows
    // itself is fetched most-recent-first (see getRecentHistory).
    history: [...historyRows].reverse().map(h => ({
      cycle_key: h.cycle_key,
      actual_consumption_l: h.actual_consumption_l,
    })),
    budget_liters: budgetLiters,
    budget_xaf: Math.round(budgetLiters * DEFAULT_XAF_PER_LITER),
    confidence,
    flag,
  };
}

/**
 * Plans budgets for every site with usable engineering parameters.
 * Sites with no engineering params on file are returned with
 * plannable:false rather than silently omitted, so gaps in the
 * engineering-parameter data are visible, not hidden.
 */
async function planAllSites(daysInCycle) {
  const [allParams, managedSiteIds] = await Promise.all([
    SiteEngineeringParams.find({}).select('site_id').lean(),
    Site.find({ Grato_Managed: { $ne: false } }).select('IHS_ID_SITE').lean()
      .then(sites => new Set(sites.map(s => s.IHS_ID_SITE))),
  ]);

  const activeParams = allParams.filter(p => managedSiteIds.has(p.site_id));
  const results = await Promise.all(
    activeParams.map(p => planSiteBudget(p.site_id, daysInCycle))
  );

  const plannable = results.filter(r => r.plannable);
  const unplannable = results.filter(r => !r.plannable);

  return {
    sites: plannable,
    unplannable_sites: unplannable,
    summary: {
      total_sites: results.length,
      plannable: plannable.length,
      unplannable: unplannable.length,
      high_confidence: plannable.filter(r => r.confidence === 'high').length,
      medium_confidence: plannable.filter(r => r.confidence === 'medium').length,
      low_confidence: plannable.filter(r => r.confidence === 'low').length,
      flagged_for_review: plannable.filter(r => r.flag).length,
      total_budget_liters: plannable.reduce((sum, r) => sum + r.budget_liters, 0),
      total_budget_xaf: plannable.reduce((sum, r) => sum + r.budget_xaf, 0),
    },
  };
}

module.exports = { planSiteBudget, planAllSites, computeTrend, DEFAULT_XAF_PER_LITER };
