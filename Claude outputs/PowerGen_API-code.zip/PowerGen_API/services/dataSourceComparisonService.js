'use strict';

/**
 * dataSourceComparisonService.js
 *
 * Per-site, per-cycle comparison of CMS/ERS telemetry against field-visit
 * data — CMS explicitly the fallback, field data the trusted source of
 * truth (same priority already established for run-hours in Phase 42,
 * and now for fuel level in Phase 53's CMS-import fix). This service
 * makes that priority visible and auditable, not just something that
 * happens silently inside reconciliation math.
 *
 * Deliberately batched, not per-site queries — an earlier feature this
 * session (the Live Site Map, Phase 27) and the core reconciliation
 * engine itself (Phase 37) both had real, confirmed timeout bugs from
 * exactly this per-site-sequential-query mistake at fleet scale. Every
 * query here is a single aggregation across all sites in the cycle.
 */

const CycleReconciliation = require('../models/CycleReconciliation');
const CmsDailyRecord = require('../models/CmsDailyRecord');
const FieldVisitRecord = require('../models/FieldVisitRecord');
const Site = require('../models/Site');
const DieselCycle = require('../models/DieselCycle');
const SiteBudget = require('../models/SiteBudget');
const User = require('../models/User');

function pct(a, b) {
  if (a == null || b == null || b === 0) return null;
  return Math.round(((a - b) / b) * 1000) / 10;
}

async function getComparison(cycle_key) {
  const cycle = await DieselCycle.findOne({ cycle_key }).select('start_date end_date').lean();

  const [reconRecords, latestCmsPerSite, latestFieldPerSite, budgets] = await Promise.all([
    CycleReconciliation.find({ cycle_key })
      .select('site_id site_name cluster region field_rh cms_rh final_rh rh_source rh_variance rh_variance_pct rh_from_mobile cms_consumption contractual_consumption has_grato_data has_mobile_field_data has_field_data has_cms_data')
      .lean(),

    // Latest CMS fuel-level reading per site this cycle — one aggregation,
    // not a per-site query.
    CmsDailyRecord.aggregate([
      { $match: { cycle_key } },
      { $sort: { record_date: -1 } },
      { $group: {
        _id: '$site_id',
        fuel_level_l: { $first: '$fuel_level_l' },
        record_date: { $first: '$record_date' },
      }},
    ]),

    // Latest field-visit fuel level per site this cycle — same pattern.
    cycle ? FieldVisitRecord.aggregate([
      { $match: { current_visit_date: { $gte: cycle.start_date, $lte: cycle.end_date } } },
      { $sort: { current_visit_date: -1 } },
      { $group: {
        _id: '$site_id',
        fuel_qty_left: { $first: '$fuel_qty_left' },
        visit_date: { $first: '$current_visit_date' },
        submitted_by: { $first: '$submitted_by' },
      }},
    ]) : [],

    SiteBudget.find({ cycle_key }).select('site_id budget_liters').lean(),
  ]);

  const cmsMap = new Map(latestCmsPerSite.map(c => [c._id, c]));
  const fieldMap = new Map(latestFieldPerSite.map(f => [f._id, f]));
  const budgetMap = new Map(budgets.map(b => [b.site_id, b.budget_liters]));

  const technicianIds = [...new Set(latestFieldPerSite.map(f => f.submitted_by).filter(Boolean).map(String))];
  const technicians = technicianIds.length
    ? await User.find({ _id: { $in: technicianIds } }).select('fullName').lean()
    : [];
  const technicianNameById = new Map(technicians.map(t => [String(t._id), t.fullName]));

  const siteIds = reconRecords.map(r => r.site_id);
  const sites = await Site.find({ IHS_ID_SITE: { $in: siteIds } })
    .select('IHS_ID_SITE Tank_Capacity_1 Fuel_Quantity_Found Fuel_Level_Source Fuel_Level_Updated_At')
    .lean();
  const siteMap = new Map(sites.map(s => [s.IHS_ID_SITE, s]));

  const rows = reconRecords.map(r => {
    const cms = cmsMap.get(r.site_id);
    const field = fieldMap.get(r.site_id);
    const site = siteMap.get(r.site_id);
    const tankCapacity = site?.Tank_Capacity_1 || null;

    const cmsFuelPct = cms?.fuel_level_l != null && tankCapacity ? Math.round((cms.fuel_level_l / tankCapacity) * 1000) / 10 : null;
    const fieldFuelPct = field?.fuel_qty_left != null && tankCapacity ? Math.round((field.fuel_qty_left / tankCapacity) * 1000) / 10 : null;

    return {
      site_id: r.site_id,
      site_name: r.site_name,
      cluster: r.cluster,
      region: r.region,
      tank_capacity_l: tankCapacity,

      cms: {
        fuel_level_l: cms?.fuel_level_l ?? null,
        fuel_level_pct: cmsFuelPct,
        fuel_level_date: cms?.record_date ?? null,
        rh: r.cms_rh ?? null,
        consumption_l: r.cms_consumption ?? null,
        has_data: !!r.has_cms_data,
      },

      field: {
        fuel_level_l: field?.fuel_qty_left ?? null,
        fuel_level_pct: fieldFuelPct,
        fuel_level_date: field?.visit_date ?? null,
        technician_name: field?.submitted_by ? (technicianNameById.get(String(field.submitted_by)) || null) : null,
        rh: r.field_rh ?? null,
        rh_from_mobile: r.rh_from_mobile ?? null,
        consumption_l: r.contractual_consumption ?? null, // contractual = final_rh (field-preferred) x CPH
        has_data: !!r.has_field_data,
      },

      variance: {
        fuel_level_l: (cms?.fuel_level_l != null && field?.fuel_qty_left != null) ? Math.round((cms.fuel_level_l - field.fuel_qty_left) * 10) / 10 : null,
        fuel_level_pct: (cmsFuelPct != null && fieldFuelPct != null) ? Math.round((cmsFuelPct - fieldFuelPct) * 10) / 10 : null,
        rh: r.rh_variance ?? null,
        rh_pct: r.rh_variance_pct != null ? Math.round(r.rh_variance_pct * 1000) / 10 : null,
        consumption_l: (r.cms_consumption != null && r.contractual_consumption != null) ? Math.round((r.cms_consumption - r.contractual_consumption) * 10) / 10 : null,
        consumption_pct: pct(r.cms_consumption, r.contractual_consumption),
      },

      combined: {
        fuel_level_l: site?.Fuel_Quantity_Found ?? null,
        fuel_level_source: site?.Fuel_Level_Source ?? null,
        fuel_level_updated_at: site?.Fuel_Level_Updated_At ?? null,
        rh: r.final_rh ?? null,
        rh_source: r.rh_source ?? null,
        consumption_l: r.contractual_consumption ?? null,
      },

      budget: {
        budget_liters: budgetMap.get(r.site_id) ?? null,
        variance_pct: pct(r.contractual_consumption, budgetMap.get(r.site_id)),
        over_budget: (() => {
          const budgetLiters = budgetMap.get(r.site_id);
          return budgetLiters != null && r.contractual_consumption != null && r.contractual_consumption > budgetLiters;
        })(),
      },
    };
  });

  const summary = {
    total_sites: rows.length,
    both_sources_available: rows.filter(r => r.cms.has_data && r.field.has_data).length,
    cms_only: rows.filter(r => r.cms.has_data && !r.field.has_data).length,
    field_only: rows.filter(r => !r.cms.has_data && r.field.has_data).length,
    neither: rows.filter(r => !r.cms.has_data && !r.field.has_data).length,
    // "Significant disagreement" mirrors the same 15% threshold already
    // established as meaningful in Budget Planning (Phase 39) — not an
    // arbitrary new number.
    significant_rh_disagreement: rows.filter(r => r.variance.rh_pct != null && Math.abs(r.variance.rh_pct) > 15).length,
    significant_fuel_disagreement: rows.filter(r => r.variance.fuel_level_pct != null && Math.abs(r.variance.fuel_level_pct) > 15).length,
    over_budget_count: rows.filter(r => r.budget.over_budget).length,
  };

  return { cycle_key, rows, summary };
}

module.exports = { getComparison };
