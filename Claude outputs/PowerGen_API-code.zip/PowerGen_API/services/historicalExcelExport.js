/**
 * historicalExcelExport.js
 * diesel-system/services/historicalExcelExport.js
 *
 * Phase 152 — "Now I need these reports in an excel file with charts and
 * graphs." Builds one workbook covering all four report types the user
 * picked: Global Summary, Site Cycle Analysis, Cluster Cycle Analysis, and
 * the Historical Data page's Complete Monthly Summary — each on its own
 * sheet, each with at least one embedded chart, all sourced live from the
 * database at request time (not a static snapshot).
 *
 * WHY A SEPARATE FILE, NOT MORE ENDPOINTS IN historicalDataRoutes.js:
 * This reuses the exact same query/aggregation logic those existing
 * endpoints already use (so the numbers in the spreadsheet match the app
 * exactly), but restructured as a handful of broad, batched queries
 * instead of looping the existing single-cycle/single-cluster endpoints
 * 9–72 times each — the same "one query per collection, not one per
 * cycle" principle `/site-cycle-summary` and `/cluster-cycle-summary`
 * already established, applied here across the whole export at once so
 * this stays fast even though it covers every cycle and every cluster in
 * one request.
 *
 * WHY CHARTS ARE IMAGES, NOT NATIVE EXCEL CHART OBJECTS:
 * exceljs 4.4.0 (this project's installed version) has no chart-writing
 * API at all (`worksheet.addChart` does not exist — checked directly
 * before assuming) — an open, unimplemented feature request upstream, not
 * a version we're behind on. Charts are rendered server-side to PNG with
 * chartjs-node-canvas (chart.js + node-canvas, no network dependency, no
 * external chart-image service) and embedded as pictures via
 * `workbook.addImage`/`worksheet.addImage`. This means a chart image is
 * not natively editable inside Excel the way a real chart object would
 * be, but it renders identically everywhere and needs nothing at
 * open-time — the tradeoff was made deliberately, not a fallback of last
 * resort.
 *
 * CLUSTER ATTRIBUTION: reuses the fix behind Phase 148's revert — cluster
 * rollups are built only against the 8 real, known cluster names
 * (REAL_CLUSTERS below), the same clean set the Cluster Cycle Analysis
 * tab's own cycle-scoped dropdown uses (sourced from
 * HistoricalMonthlyRecord.cluster, not AdHocFuelRequest.cluster's
 * contaminated free-text column — see the Phase 148 changelog entry for
 * the full diagnosis). Any AdHocFuelRequest/TomCardAllocation row whose
 * own `cluster` field isn't one of these 8 is simply not attributed to
 * any cluster here, the same as it already isn't anywhere else in the app.
 */
'use strict';

const ExcelJS = require('exceljs');
const { ChartJSNodeCanvas } = require('chartjs-node-canvas');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');
const AdHocFuelRequest = require('../models/AdHocFuelRequest');
const TomCardAllocation = require('../models/TomCardAllocation');
const BudgetRequestApproval = require('../models/BudgetRequestApproval');
const MonthlyDebitSummary = require('../models/MonthlyDebitSummary');
const HistoricalFieldVisit = require('../models/HistoricalFieldVisit');
const HistoricalFuelPurchase = require('../models/HistoricalFuelPurchase');
const SiteEngineeringParams = require('../models/SiteEngineeringParams');
// Phase 169 — the exact same Gain/Loss, Carried-Over Stock Burned (net
// change), Run Hours/True CPH, and Stability/Anomaly math the live app
// uses (routes/historicalDataRoutes.js), shared via services/
// historicalMetrics.js so this export can never drift from what the
// Site/Cluster Cycle Analysis and Global Summary tabs actually show.
const { carriedOverStockBurn, cycleEngineeringFigures, consumptionStability, computeGainLoss } = require('./historicalMetrics');

// ─── Shared scope constants — mirrors HistoricalAnalysisPage.tsx exactly ──
const CYCLES = ['2025-12', '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08'];
const GLOBAL_MIN_MONTH_KEY = '2025-12';
const REAL_CLUSTERS = ['Bonaberi 1', 'Bonaberi 2', 'Edea', 'Kotto', 'Ndogbong', 'Pouma 1', 'Pouma 2', 'Yassa'];

// ─── Fixed color roles — same meaning, same color, as the live app's own
// COLOR/urgency tokens (HistoricalAnalysisPage.tsx / dieselTokens.ts) ──────
const COLOR = {
  requested: '#64748b', // slate
  approved: '#16a34a',  // green
  extra: '#d97706',     // amber
  delivered: '#2563eb', // blue
  consumed: '#7c3aed',  // violet
  reserve: '#16a34a',   // green
  gainLoss: '#16a34a',  // green — same role Reserve used to play (see Phase 167/169)
  cob: '#d97706',       // amber — matches the app's own Carried-Over Stock Burned chart color
  critical: '#dc2626',  // red
  ok: '#16a34a',         // green
};

function monthLabel(key) {
  if (!key) return key;
  const [y, m] = key.split('-');
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${names[Number(m) - 1]} '${y.slice(2)}`;
}

function toNum(v) { return v == null ? null : Number(v); }
function sumOrNull(...vals) {
  const present = vals.filter(v => v != null);
  if (!present.length) return null;
  return present.reduce((s, v) => s + v, 0);
}

/**
 * fetchVisitsBySiteCycle(monthKeyFilter) — Phase 169.
 *
 * One raw HistoricalFieldVisit query, grouped by `${site_id}|${month_key}`,
 * sorted ascending by visit_date within each group — the exact shape
 * carriedOverStockBurn/cycleEngineeringFigures/computeGainLoss all expect
 * (see historicalMetrics.js). Reused by every sheet below that needs any
 * of the new Phase 165-168 figures, instead of a separate visits query per
 * sheet.
 */
async function fetchVisitsBySiteCycle(monthKeyFilter) {
  const visits = await HistoricalFieldVisit.find(monthKeyFilter)
    .select('site_id cluster month_key visit_date fuel_previously_left_l fuel_found_l fuel_added_l fuel_left_l run_hours')
    .sort({ site_id: 1, month_key: 1, visit_date: 1 })
    .lean();
  const bySiteCycle = new Map(); // "site_id|month_key" -> visits[]
  for (const v of visits) {
    const key = `${v.site_id}|${v.month_key}`;
    if (!bySiteCycle.has(key)) bySiteCycle.set(key, []);
    bySiteCycle.get(key).push(v);
  }
  return { visits, bySiteCycle };
}

/**
 * siteCycleMetrics(visits, consumed_l) — Phase 169.
 *
 * One site's own visits for one cycle, plus that cycle's validated
 * consumption figure -> every one of the new per-site figures in one
 * call: end-of-cycle stock (last visit's own fuel_left_l — the same
 * "Stock on Site (Last Visit)" figure from Phase 164, not previously
 * shared as its own function since it's a one-line lookup, included here
 * for convenience), carried-over stock burn (net change, Phase 165/168),
 * Gain/Loss (Phase 167), and the engineering/stability figures (Phase
 * 168). `visits` must already be sorted ascending by visit_date.
 */
function siteCycleMetrics(visits, consumed_l) {
  const cob = carriedOverStockBurn(visits);
  const eng = cycleEngineeringFigures(visits);
  const delivered_to_site_l = (visits || []).reduce((s, v) => s + (v.fuel_added_l || 0), 0);
  const gainLoss = computeGainLoss(visits, delivered_to_site_l, consumed_l ?? null);
  const stability = consumptionStability(eng.intervals);
  const lastVisit = visits && visits.length ? visits[visits.length - 1] : null;
  return {
    stock_on_site_l: lastVisit?.fuel_left_l ?? null,
    cob, gainLoss, eng, stability,
    has_stock: cob.last_visit_stock_l != null ? cob.last_visit_stock_l > 0 : null,
  };
}

const chartRenderer = new ChartJSNodeCanvas({ width: 920, height: 420, backgroundColour: '#ffffff' });
async function renderChart(config) {
  return chartRenderer.renderToBuffer({
    ...config,
    options: {
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } }, title: { display: false } },
      scales: config.options?.scales,
      ...config.options,
    },
  });
}

// ─── Sheet-writing helpers ─────────────────────────────────────────────────
const HEADER_FILL = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } };
const HEADER_FONT = { color: { argb: 'FFFFFFFF' }, bold: true, size: 11 };

function writeTitle(ws, row, text, sub) {
  ws.getCell(`A${row}`).value = text;
  ws.getCell(`A${row}`).font = { bold: true, size: 16, color: { argb: 'FF1E293B' } };
  let next = row + 1;
  if (sub) {
    ws.getCell(`A${next}`).value = sub;
    ws.getCell(`A${next}`).font = { italic: true, size: 10, color: { argb: 'FF64748B' } };
    next += 1;
  }
  return next + 1;
}

function writeTable(ws, startRow, headers, rows, { widths, numberCols = [], autoFilter = false } = {}) {
  const headerRow = ws.getRow(startRow);
  headers.forEach((h, i) => {
    const cell = headerRow.getCell(i + 1);
    cell.value = h;
    cell.fill = HEADER_FILL;
    cell.font = HEADER_FONT;
    cell.alignment = { vertical: 'middle' };
  });
  headerRow.height = 20;

  rows.forEach((r, ri) => {
    const row = ws.getRow(startRow + 1 + ri);
    r.forEach((v, ci) => {
      const cell = row.getCell(ci + 1);
      cell.value = v == null ? '—' : v;
      if (numberCols.includes(ci) && typeof v === 'number') cell.numFmt = '#,##0';
      if (ri % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } };
    });
  });

  if (widths) headers.forEach((_, i) => { ws.getColumn(i + 1).width = widths[i] || 14; });
  ws.views = [{ state: 'frozen', ySplit: startRow, xSplit: 0 }];
  // Phase 169 — "I need to be able to personally sort and filter through
  // all this" (the same ask that made the Site Cycle Summary table
  // sortable in-app) applies here too: native Excel AutoFilter drop-downs
  // on the header row give the same sort-by-any-column / filter-by-value
  // capability once the file is open, no macro or pivot table needed.
  if (autoFilter && rows.length) {
    ws.autoFilter = {
      from: { row: startRow, column: 1 },
      to: { row: startRow + rows.length, column: headers.length },
    };
  }
  return startRow + 1 + rows.length;
}

async function embedImage(workbook, ws, buffer, rangeStart, rowsSpan = 20, colsSpan = 8) {
  const imgId = workbook.addImage({ buffer, extension: 'png' });
  const startCol = rangeStart.col;
  const endCol = String.fromCharCode(startCol.charCodeAt(0) + colsSpan);
  ws.addImage(imgId, `${startCol}${rangeStart.row}:${endCol}${rangeStart.row + rowsSpan}`);
  return rangeStart.row + rowsSpan + 2;
}

// ─── Data builders ──────────────────────────────────────────────────────────

async function fetchGlobalSummaryData(since) {
  const monthMatch = since ? [{ $match: { month_key: { $gte: since } } }] : [];
  const byMonth = await HistoricalMonthlyRecord.aggregate([
    ...monthMatch,
    { $group: {
      _id: '$month_key',
      site_count: { $sum: 1 },
      sites_with_budget: { $sum: { $cond: [{ $ne: ['$budget_liters', null] }, 1, 0] } },
      total_budget_l: { $sum: { $ifNull: ['$budget_liters', 0] } },
      total_consumption_l: { $sum: { $ifNull: ['$final_consumption_l', 0] } },
      total_reserve_l: { $sum: { $ifNull: ['$reserve_liters', 0] } },
      exhausted_count: { $sum: { $cond: [{ $eq: ['$fully_exhausted', true] }, 1, 0] } },
      theft_flagged_count: { $sum: { $cond: [{ $gt: [{ $ifNull: ['$theft_liters', 0] }, 0] }, 1, 0] } },
    } },
    { $sort: { _id: 1 } },
  ]);

  const perSite = await HistoricalMonthlyRecord.aggregate([
    { $match: { budget_liters: { $ne: null }, ...(since ? { month_key: { $gte: since } } : {}) } },
    { $group: {
      _id: '$site_id',
      site_name: { $first: '$site_name' },
      cluster: { $first: '$cluster' },
      months_with_budget: { $sum: 1 },
      months_exhausted: { $sum: { $cond: [{ $eq: ['$fully_exhausted', true] }, 1, 0] } },
      avg_reserve_l: { $avg: '$reserve_liters' },
    } },
    { $match: { $expr: { $eq: ['$months_with_budget', '$months_exhausted'] } } },
    { $sort: { avg_reserve_l: 1 } },
    { $limit: 20 },
  ]);

  const debitMonthsRaw = await MonthlyDebitSummary.find({}).sort({ cycle_key: 1 }).lean();
  const debitMonths = debitMonthsRaw.filter(m => !since || m.cycle_key >= since);

  const adhocByMonthRaw = await AdHocFuelRequest.aggregate([
    { $addFields: { month_key: { $dateToString: { format: '%Y-%m', date: '$planned_date' } } } },
    { $group: {
      _id: '$month_key',
      total_l: { $sum: '$quantity_requested_l' },
      total_approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
      total_delivered_l: { $sum: { $ifNull: ['$delivered_l', 0] } },
    } },
    { $sort: { _id: 1 } },
  ]);
  const adhocByMonth = adhocByMonthRaw.filter(m => !since || m._id >= since).map(m => ({ month_key: m._id, ...m }));

  const tomCardRaw = await TomCardAllocation.find({}).lean();
  const tomCardByCycleMap = new Map();
  for (const a of tomCardRaw) {
    if (since && a.funded_cycle_key < since) continue;
    if (!tomCardByCycleMap.has(a.funded_cycle_key)) tomCardByCycleMap.set(a.funded_cycle_key, 0);
    tomCardByCycleMap.set(a.funded_cycle_key, tomCardByCycleMap.get(a.funded_cycle_key) + (a.quantity_l || a.budget_l || 0));
  }
  const tomCardByCycle = [...tomCardByCycleMap.entries()].sort((a, b) => a[0].localeCompare(b[0]));

  // ── Phase 169 — Gain/Loss, Carried-Over Stock Burned (net change), and
  // Has Stock/No Stock, fleet-wide per month, mirroring `/summary`'s
  // by_month exactly (see historicalDataRoutes.js). Needs each site-
  // month's own visits (for cob/gain_loss/has_stock) plus its own
  // final_consumption_l (for gain_loss — the byMonth aggregate above only
  // has this as a fleet SUM, not per site-month).
  const { bySiteCycle } = await fetchVisitsBySiteCycle(since ? { month_key: { $gte: since } } : {});
  const consumptionRows = await HistoricalMonthlyRecord.find(since ? { month_key: { $gte: since } } : {})
    .select('site_id month_key final_consumption_l').lean();
  const consumedBySiteMonth = new Map(consumptionRows.map(r => [`${r.site_id}|${r.month_key}`, r.final_consumption_l ?? null]));

  const newMetricsByMonth = new Map(); // month_key -> { gain_loss_l, cob_l, has_stock, no_stock, sites_reporting_gl, sites_reporting_cob }
  for (const [key, visits] of bySiteCycle) {
    const month_key = key.split('|')[1];
    if (!newMetricsByMonth.has(month_key)) {
      newMetricsByMonth.set(month_key, { gain_loss_l: 0, gl_reporting: 0, cob_l: 0, cob_reporting: 0, has_stock: 0, no_stock: 0 });
    }
    const agg = newMetricsByMonth.get(month_key);
    const m = siteCycleMetrics(visits, consumedBySiteMonth.get(key) ?? null);
    if (m.gainLoss.gain_loss_l != null) { agg.gain_loss_l += m.gainLoss.gain_loss_l; agg.gl_reporting += 1; }
    if (m.cob.net_change_l != null) { agg.cob_l += m.cob.net_change_l; agg.cob_reporting += 1; }
    if (m.has_stock === true) agg.has_stock += 1;
    else if (m.has_stock === false) agg.no_stock += 1;
  }
  for (const m of byMonth) {
    const agg = newMetricsByMonth.get(m._id);
    m.gain_loss_l = agg && agg.gl_reporting ? agg.gain_loss_l : null;
    m.gain_loss_sites_reporting = agg?.gl_reporting ?? 0;
    m.carried_over_stock_burn_l = agg && agg.cob_reporting ? agg.cob_l : null;
    m.carried_over_stock_burn_sites_reporting = agg?.cob_reporting ?? 0;
    m.has_stock_count = agg?.has_stock ?? 0;
    m.no_stock_count = agg?.no_stock ?? 0;
  }

  return { byMonth, chronicallyExhausted: perSite, debitMonths, adhocByMonth, tomCardByCycle };
}

async function fetchSiteCycleData(cycles) {
  const [monthlyRecords, approvals, adhocRaw, visitsRaw, { bySiteCycle }, engParamsRaw] = await Promise.all([
    HistoricalMonthlyRecord.find({ month_key: { $in: cycles } }).lean(),
    BudgetRequestApproval.find({ cycle_key: { $in: cycles } }).lean(),
    AdHocFuelRequest.aggregate([
      { $addFields: { month_key: { $dateToString: { format: '%Y-%m', date: '$planned_date' } } } },
      { $match: { month_key: { $in: cycles } } },
      { $group: {
        _id: { month_key: '$month_key', site_id: '$site_id' },
        requested_l: { $sum: '$quantity_requested_l' },
        approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
        any_approval: { $max: { $ne: [{ $ifNull: ['$approved_l', null] }, null] } },
      } },
    ]),
    HistoricalFieldVisit.aggregate([
      { $match: { month_key: { $in: cycles } } },
      { $group: { _id: { month_key: '$month_key', site_id: '$site_id' }, delivered_l: { $sum: { $ifNull: ['$fuel_added_l', 0] } }, visit_count: { $sum: 1 } } },
    ]),
    // Phase 169 — raw per-visit rows (not just aggregated totals), needed to
    // compute Stock on Site, Carried-Over Stock Burned, Gain/Loss, Run
    // Hours, Avg True CPH and Stability the same way the live app does.
    fetchVisitsBySiteCycle({ month_key: { $in: cycles } }),
    SiteEngineeringParams.find({}).select('site_id genset_cph').lean(),
  ]);

  const byKey = (arr) => new Map(arr.map(r => [`${r._id.month_key}|${r._id.site_id}`, r]));
  const adhocByKey = byKey(adhocRaw);
  const visitsByKey = byKey(visitsRaw);
  const monthlyByKey = new Map(monthlyRecords.map(r => [`${r.month_key}|${r.site_id}`, r]));
  const approvalByKey = new Map(approvals.map(r => [`${r.cycle_key}|${r.site_id}`, r]));
  const engParamsBySite = new Map(engParamsRaw.map(p => [p.site_id, p]));

  const rows = [];
  for (const cycle of cycles) {
    const siteIds = new Set([
      ...monthlyRecords.filter(r => r.month_key === cycle).map(r => r.site_id),
      ...approvals.filter(r => r.cycle_key === cycle).map(r => r.site_id),
      ...adhocRaw.filter(r => r._id.month_key === cycle).map(r => r._id.site_id),
      ...visitsRaw.filter(r => r._id.month_key === cycle).map(r => r._id.site_id),
    ]);
    for (const site_id of siteIds) {
      const key = `${cycle}|${site_id}`;
      const monthly = monthlyByKey.get(key);
      const approval = approvalByKey.get(key);
      const adhoc = adhocByKey.get(key);
      const visit = visitsByKey.get(key);

      const initial_requested_l = approval?.sbc_requested_l ?? null;
      const initial_approved_l = approval?.ihs_approved_l ?? monthly?.budget_liters ?? null;
      const extra_requested_l = adhoc?.requested_l ?? null;
      const extra_approved_l = adhoc?.any_approval ? adhoc.approved_l : null;
      const total_requested_l = sumOrNull(initial_requested_l, extra_requested_l);
      const total_approved_l = sumOrNull(initial_approved_l, extra_approved_l);
      const consumed_l = monthly?.final_consumption_l ?? null;
      const reserve_l = monthly?.reserve_liters ?? null;

      // Phase 169 — same per-cycle field-visit metrics the live app's
      // /site-cycle-summary route computes, reused here via the shared
      // services/historicalMetrics.js functions so the Excel export can
      // never drift from the app's own numbers.
      const cycleVisits = bySiteCycle.get(`${site_id}|${cycle}`) || [];
      const m = siteCycleMetrics(cycleVisits, consumed_l);
      const contractual_cph = approval?.genset_cph ?? engParamsBySite.get(site_id)?.genset_cph ?? null;
      const true_cph_vs_contractual = (m.eng.avg_true_cph != null && contractual_cph != null)
        ? m.eng.avg_true_cph - contractual_cph : null;

      rows.push({
        cycle, site_id,
        site_name: monthly?.site_name || approval?.site_name || null,
        cluster: monthly?.cluster || approval?.cluster || null,
        initial_requested_l, extra_requested_l, total_requested_l,
        requested_partial: (initial_requested_l == null) !== (extra_requested_l == null),
        initial_approved_l, extra_approved_l, total_approved_l,
        approved_partial: (initial_approved_l == null) !== (extra_approved_l == null),
        delivered_to_site_l: visit?.delivered_l ?? null,
        visit_count: visit?.visit_count ?? 0,
        consumed_l, reserve_l,
        status: reserve_l == null ? null : (monthly?.fully_exhausted ? 'Exhausted' : 'Has Reserve'),
        // Phase 168/169 additions
        gain_loss_l: m.gainLoss.gain_loss_l,
        stock_on_site_l: m.stock_on_site_l,
        carried_over_stock_burn_l: m.cob.net_change_l,
        run_hours_total: m.eng.run_hours_total,
        avg_true_cph: m.eng.avg_true_cph,
        contractual_cph,
        true_cph_vs_contractual,
        stability_cov: m.stability.coefficient_of_variation,
        anomaly_interval_count: m.stability.anomaly_interval_count,
        has_stock: m.has_stock,
      });
    }
  }
  rows.sort((a, b) => a.cycle.localeCompare(b.cycle) || (a.site_name || a.site_id).localeCompare(b.site_name || b.site_id));
  return rows;
}

async function fetchClusterCycleData(cycles, clusters, fleetDebitByCycle = new Map()) {
  const [approvals, adhocRaw, tomCardRows, purchasesRaw, monthlyRaw, { visits: visitsRaw }] = await Promise.all([
    BudgetRequestApproval.find({ cycle_key: { $in: cycles }, cluster: { $in: clusters } }).lean(),
    AdHocFuelRequest.aggregate([
      { $addFields: { month_key: { $dateToString: { format: '%Y-%m', date: '$planned_date' } } } },
      { $match: { month_key: { $in: cycles }, cluster: { $in: clusters } } },
      { $group: {
        _id: { month_key: '$month_key', cluster: '$cluster' },
        requested_l: { $sum: '$quantity_requested_l' },
        approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
      } },
    ]),
    TomCardAllocation.find({ funded_cycle_key: { $in: cycles }, cluster: { $in: clusters } }).lean(),
    HistoricalFuelPurchase.find({ month_key: { $in: cycles } }).lean(),
    // Phase 149's real per-cluster Consumed/Reserve, and the basis for this
    // cluster's estimated share of the fleet-wide debit/credit — the same
    // "only when every site in the cluster has a recovered figure" gate the
    // frontend's own clusterDebitEstimate uses, so an incomplete cluster
    // never gets a misleadingly precise number.
    HistoricalMonthlyRecord.find({ month_key: { $in: cycles }, cluster: { $in: clusters } }).lean(),
    // Phase 169 — raw per-visit rows for the cluster's own sites, so the
    // export can mirror the live app's /cluster-cycle-summary rollups
    // (Gain/Loss, Carried-Over Stock Burned, Run Hours, Avg True CPH, Has
    // Stock) rather than being limited to the older budget-only fields.
    fetchVisitsBySiteCycle({ month_key: { $in: cycles } }),
  ]);

  // `${cycle}|${card_number}` -> cluster. Keyed by cycle AND card number,
  // not card number alone — a physical Tom Card is re-funded every cycle,
  // so the same card_number legitimately appears in TomCardAllocation
  // across many cycles. An earlier version of this map was keyed by
  // card_number only, so each card's entry got silently overwritten by
  // whichever cycle's row happened to be processed last (in practice, the
  // most recent cycle) — every older purchase made on that card then
  // looked up that same latest-cycle owner and failed the `owner.cycle
  // === cycle` check for its own (earlier) cycle, so it was attributed to
  // NO cluster/cycle at all. That's why the cluster sheet in earlier runs
  // showed Purchases only for the most recent cycle and blanks everywhere
  // else. The single-cycle `/cluster-cycle-report` route never had this
  // bug — it only ever loads one cycle's TomCardAllocation rows at a
  // time, so there was nothing for a card number to collide with.
  const cardOwner = new Map();
  for (const t of tomCardRows) {
    for (const cn of [t.card_number, t.new_card_number].filter(Boolean)) {
      cardOwner.set(`${t.funded_cycle_key}|${cn}`, t.cluster);
    }
  }

  // Phase 169 — group the raw visits into cycle|cluster -> site_id -> visits[],
  // mirroring the live /cluster-cycle-summary route's grouping so this export's
  // Gain/Loss, Carried-Over Stock Burned, Run Hours, Avg True CPH and Has
  // Stock rollups can never drift from what the app shows.
  const visitsByCycleClusterSite = new Map(); // "cycle|cluster" -> Map(site_id -> visits[])
  for (const v of visitsRaw) {
    if (!v.cluster || !clusters.includes(v.cluster) || !cycles.includes(v.month_key)) continue;
    const groupKey = `${v.month_key}|${v.cluster}`;
    if (!visitsByCycleClusterSite.has(groupKey)) visitsByCycleClusterSite.set(groupKey, new Map());
    const bySite = visitsByCycleClusterSite.get(groupKey);
    if (!bySite.has(v.site_id)) bySite.set(v.site_id, []);
    bySite.get(v.site_id).push(v);
  }
  const consumedBySiteCycle = new Map(monthlyRaw.map(m => [`${m.month_key}|${m.site_id}`, m.final_consumption_l ?? null]));

  const rows = [];
  for (const cycle of cycles) {
    for (const cluster of clusters) {
      const key = `${cycle}|${cluster}`;
      const clusterApprovals = approvals.filter(a => a.cycle_key === cycle && a.cluster === cluster);
      const adhoc = adhocRaw.find(a => a._id.month_key === cycle && a._id.cluster === cluster);
      const cardRows = tomCardRows.filter(t => t.funded_cycle_key === cycle && t.cluster === cluster);
      const purchases = purchasesRaw.filter(p => p.month_key === cycle && cardOwner.get(`${cycle}|${p.card_number}`) === cluster);
      const monthlyRecords = monthlyRaw.filter(m => m.month_key === cycle && m.cluster === cluster);
      const clusterVisitsBySite = visitsByCycleClusterSite.get(key) || new Map();

      if (!clusterApprovals.length && !adhoc && !cardRows.length && !purchases.length && !monthlyRecords.length && !clusterVisitsBySite.size) continue;

      const requested_l = clusterApprovals.length ? clusterApprovals.reduce((s, a) => s + (a.sbc_requested_l || 0), 0) : null;
      const approved_l = clusterApprovals.length ? clusterApprovals.reduce((s, a) => s + (a.ihs_approved_l || 0), 0) : null;
      const extra_requested_l = adhoc?.requested_l ?? null;
      const extra_approved_l = adhoc?.approved_l ?? null;
      const purchases_l = purchases.length ? purchases.reduce((s, p) => s + (p.quantity_l || 0), 0) : null;
      const purchases_xaf = purchases.length ? purchases.reduce((s, p) => s + (p.amount_xaf || 0), 0) : null;
      const cardFundingL = cardRows.length
        ? cardRows.reduce((s, t) => s + (t.quantity_l || t.budget_l || 0) + (t.extra_round1_approved_l || 0) + (t.extra_round2_approved_l || 0) + (t.extra_round3_approved_l || 0), 0)
        : null;
      const cardFundingXaf = cardRows.length
        ? cardRows.reduce((s, t) => s + (t.amount_xaf || t.budget_xaf || 0) + (t.extra_round1_approved_xaf || 0) + (t.extra_round2_approved_xaf || 0) + (t.extra_round3_approved_xaf || 0), 0)
        : null;

      const consumedCount = monthlyRecords.filter(m => m.final_consumption_l != null).length;
      const total_consumed_l = consumedCount ? monthlyRecords.reduce((s, m) => s + (m.final_consumption_l || 0), 0) : null;
      const total_reserve_l = consumedCount ? monthlyRecords.reduce((s, m) => s + (m.reserve_liters || 0), 0) : null;
      const site_coverage = monthlyRecords.length ? `${consumedCount}/${monthlyRecords.length}` : null;

      const fleetDebit = fleetDebitByCycle.get(cycle) || null;
      let estimated_share_xaf = null;
      if (monthlyRecords.length && consumedCount === monthlyRecords.length && fleetDebit?.approved_consumption_l && fleetDebit?.debit_credit_amount_xaf != null) {
        const share = total_consumed_l / fleetDebit.approved_consumption_l;
        estimated_share_xaf = Math.round(share * fleetDebit.debit_credit_amount_xaf);
      }

      // Phase 169 — per-site metrics for every site with a visit this
      // cycle/cluster, then rolled up to the cluster level (sums for
      // Gain/Loss, Carried-Over Stock Burned and Run Hours; count-weighted
      // average for True CPH; site counts for Has Stock).
      let glSum = null, glCount = 0;
      let cobSum = null, cobCount = 0;
      let runHoursSum = 0, cphWeightedSum = 0, cphWeight = 0;
      let hasStockCount = 0, noStockCount = 0;
      for (const [site_id, siteVisits] of clusterVisitsBySite) {
        const consumed_l = consumedBySiteCycle.get(`${cycle}|${site_id}`) ?? null;
        const m = siteCycleMetrics(siteVisits, consumed_l);
        if (m.gainLoss.gain_loss_l != null) { glSum = (glSum ?? 0) + m.gainLoss.gain_loss_l; glCount += 1; }
        if (m.cob.net_change_l != null) { cobSum = (cobSum ?? 0) + m.cob.net_change_l; cobCount += 1; }
        if (m.eng.run_hours_total != null) runHoursSum += m.eng.run_hours_total;
        if (m.eng.avg_true_cph != null && m.eng.run_hours_total) { cphWeightedSum += m.eng.avg_true_cph * m.eng.run_hours_total; cphWeight += m.eng.run_hours_total; }
        if (m.has_stock === true) hasStockCount += 1;
        else if (m.has_stock === false) noStockCount += 1;
      }

      rows.push({
        cycle, cluster, requested_l, approved_l, extra_requested_l, extra_approved_l,
        purchases_l, purchases_xaf, card_funding_l: cardFundingL, card_funding_xaf: cardFundingXaf,
        total_consumed_l, total_reserve_l, site_coverage,
        fleet_debit_credit_xaf: fleetDebit?.debit_credit_amount_xaf ?? null,
        estimated_share_xaf,
        // Phase 168/169 additions
        gain_loss_l: glCount ? glSum : null,
        gain_loss_sites_reporting: glCount,
        carried_over_stock_burn_l: cobCount ? cobSum : null,
        carried_over_stock_burn_sites_reporting: cobCount,
        run_hours_total: clusterVisitsBySite.size ? runHoursSum : null,
        avg_true_cph_this_cycle: cphWeight ? cphWeightedSum / cphWeight : null,
        has_stock_count: hasStockCount,
        no_stock_count: noStockCount,
      });
    }
  }
  return rows;
}

async function fetchCompleteMonthlyData() {
  const allMonths = (await HistoricalMonthlyRecord.distinct('month_key')).sort();

  const [monthlyRecords, approvals, adhocRaw, { bySiteCycle }, engParamsRaw] = await Promise.all([
    HistoricalMonthlyRecord.find({}).lean(),
    BudgetRequestApproval.find({}).lean(),
    AdHocFuelRequest.aggregate([
      { $addFields: { month_key: { $dateToString: { format: '%Y-%m', date: '$planned_date' } } } },
      { $group: { _id: { month_key: '$month_key', site_id: '$site_id' }, requested_l: { $sum: '$quantity_requested_l' } } },
    ]),
    // Phase 169 — raw visits across ALL recovered months (not just the 9
    // CYCLES), so this "full history" sheet also carries the new
    // per-visit-derived metrics wherever field-visit data exists. Months
    // before field-visit recovery began naturally have no visits and fall
    // back to '—' via the same writeTable convention used elsewhere.
    fetchVisitsBySiteCycle({}),
    SiteEngineeringParams.find({}).select('site_id genset_cph').lean(),
  ]);

  const monthlyByKey = new Map(monthlyRecords.map(r => [`${r.month_key}|${r.site_id}`, r]));
  const approvalByKey = new Map(approvals.map(r => [`${r.cycle_key}|${r.site_id}`, r]));
  const adhocByKey = new Map(adhocRaw.map(r => [`${r._id.month_key}|${r._id.site_id}`, r]));
  const engParamsBySite = new Map(engParamsRaw.map(p => [p.site_id, p]));

  const rows = [];
  for (const month of allMonths) {
    const siteIds = new Set([
      ...monthlyRecords.filter(r => r.month_key === month).map(r => r.site_id),
      ...approvals.filter(r => r.cycle_key === month).map(r => r.site_id),
      ...adhocRaw.filter(r => r._id.month_key === month).map(r => r._id.site_id),
    ]);
    for (const site_id of siteIds) {
      const key = `${month}|${site_id}`;
      const monthly = monthlyByKey.get(key);
      const approval = approvalByKey.get(key);
      const adhoc = adhocByKey.get(key);
      const reserve_l = monthly?.reserve_liters ?? null;
      const consumed_l = monthly?.final_consumption_l ?? null;

      const cycleVisits = bySiteCycle.get(`${site_id}|${month}`) || [];
      const m = siteCycleMetrics(cycleVisits, consumed_l);
      const contractual_cph = approval?.genset_cph ?? engParamsBySite.get(site_id)?.genset_cph ?? null;

      rows.push({
        month, site_id,
        site_name: monthly?.site_name || approval?.site_name || null,
        cluster: monthly?.cluster || approval?.cluster || null,
        requested_l: approval?.sbc_requested_l ?? null,
        approved_l: approval?.ihs_approved_l ?? monthly?.budget_liters ?? null,
        extra_fuel_l: adhoc?.requested_l ?? null,
        consumed_l, reserve_l,
        status: reserve_l == null ? null : (monthly?.fully_exhausted ? 'Exhausted' : 'Has Reserve'),
        // Phase 168/169 additions — blank ('—' at render time) for months
        // with no recovered field visits
        gain_loss_l: cycleVisits.length ? m.gainLoss.gain_loss_l : null,
        stock_on_site_l: cycleVisits.length ? m.stock_on_site_l : null,
        carried_over_stock_burn_l: cycleVisits.length ? m.cob.net_change_l : null,
        run_hours_total: cycleVisits.length ? m.eng.run_hours_total : null,
        avg_true_cph: cycleVisits.length ? m.eng.avg_true_cph : null,
        contractual_cph: cycleVisits.length ? contractual_cph : null,
        has_stock: cycleVisits.length ? m.has_stock : null,
      });
    }
  }
  rows.sort((a, b) => a.month.localeCompare(b.month) || (a.site_name || a.site_id).localeCompare(b.site_name || b.site_id));

  const fleetReserveByMonth = allMonths.map(month => {
    const monthRows = rows.filter(r => r.month === month);
    return {
      month,
      total_consumed_l: sumOrNull(...monthRows.map(r => r.consumed_l)) ?? 0,
      total_reserve_l: sumOrNull(...monthRows.map(r => r.reserve_l)) ?? 0,
      total_gain_loss_l: sumOrNull(...monthRows.map(r => r.gain_loss_l)) ?? 0,
    };
  });

  return { allMonths, rows, fleetReserveByMonth };
}

// ─── Sheet builders ─────────────────────────────────────────────────────────

async function addGlobalSummarySheet(workbook, data) {
  const ws = workbook.addWorksheet('Global Summary');
  let row = writeTitle(ws, 1, 'Global Summary — Fleet-Wide', `December 2025 onward · generated ${new Date().toISOString().slice(0, 10)}`);

  const totals = {
    months: data.byMonth.length,
    budget: data.byMonth.reduce((s, m) => s + m.total_budget_l, 0),
    consumed: data.byMonth.reduce((s, m) => s + m.total_consumption_l, 0),
    // Phase 169 — Total Reserve replaced with Total Gain/Loss, mirroring
    // the app's own Phase 167 KPI-tile swap. Months with no reporting
    // sites contribute 0 to the sum (same as the app's globalTotals).
    gainLoss: data.byMonth.reduce((s, m) => s + (m.gain_loss_l || 0), 0),
    extraRequested: data.adhocByMonth.reduce((s, m) => s + (m.total_l || 0), 0),
    chronicSites: data.chronicallyExhausted.length,
  };
  row = writeTable(ws, row, ['Months Covered', 'Total Budget (L)', 'Total Consumed (L)', 'Total Gain / Loss (L)', 'Extra Fuel Requested (L)', 'Chronically Exhausted Sites'],
    [[totals.months, Math.round(totals.budget), Math.round(totals.consumed), Math.round(totals.gainLoss), Math.round(totals.extraRequested), totals.chronicSites]],
    { widths: [16, 18, 18, 20, 22, 22], numberCols: [0, 1, 2, 3, 4, 5] });
  row += 1;

  // Chart 1 — Budget vs Consumption vs Gain/Loss (Phase 169 — was Reserve)
  const budgetChart = await renderChart({
    type: 'line',
    data: {
      labels: data.byMonth.map(m => monthLabel(m._id)),
      datasets: [
        { label: 'Budget', data: data.byMonth.map(m => m.total_budget_l), borderColor: COLOR.requested, backgroundColor: COLOR.requested, fill: false, tension: 0.2 },
        { label: 'Consumed', data: data.byMonth.map(m => m.total_consumption_l), borderColor: COLOR.consumed, backgroundColor: COLOR.consumed, fill: false, tension: 0.2 },
        { label: 'Gain / Loss', data: data.byMonth.map(m => m.gain_loss_l), borderColor: COLOR.gainLoss, backgroundColor: COLOR.gainLoss, fill: false, tension: 0.2 },
      ],
    },
    options: { plugins: { title: { display: true, text: 'Budget vs Consumption vs Gain/Loss, Every Month' } } },
  });
  row = await embedImage(workbook, ws, budgetChart, { col: 'A', row });

  // Chart 2 — Extra Fuel Requested/Approved/Delivered
  const extraFuelChart = await renderChart({
    type: 'bar',
    data: {
      labels: data.adhocByMonth.map(m => monthLabel(m.month_key)),
      datasets: [
        { label: 'Requested', data: data.adhocByMonth.map(m => m.total_l), backgroundColor: COLOR.requested },
        { label: 'Approved', data: data.adhocByMonth.map(m => m.total_approved_l), backgroundColor: COLOR.approved },
        { label: 'Delivered', data: data.adhocByMonth.map(m => m.total_delivered_l), backgroundColor: COLOR.delivered },
      ],
    },
    options: { plugins: { title: { display: true, text: 'Extra Fuel: Requested vs Approved vs Delivered' } } },
  });
  row = await embedImage(workbook, ws, extraFuelChart, { col: 'A', row });

  // Chart 3 — Monthly Debit/Credit Settlement
  const debitChart = await renderChart({
    type: 'bar',
    data: {
      labels: data.debitMonths.map(m => monthLabel(m.cycle_key)),
      datasets: [{
        label: 'Debit/Credit (XAF)',
        data: data.debitMonths.map(m => m.debit_credit_amount_xaf ?? 0),
        backgroundColor: data.debitMonths.map(m => (m.debit_credit_amount_xaf ?? 0) < 0 ? COLOR.critical : COLOR.ok),
      }],
    },
    options: { plugins: { title: { display: true, text: 'Monthly Debit/Credit Settlement (green = credit, red = debit)' }, legend: { display: false } } },
  });
  row = await embedImage(workbook, ws, debitChart, { col: 'A', row });

  // Chart 4 — Sites w/ Stock vs No Stock (Phase 168/169 — was Exhausted vs Has Reserve,
  // which stayed budget-based; this is the new field-visit-based "has stock on site" cut)
  const stockChart = await renderChart({
    type: 'bar',
    data: {
      labels: data.byMonth.map(m => monthLabel(m._id)),
      datasets: [
        { label: 'Has Stock', data: data.byMonth.map(m => m.has_stock_count || 0), backgroundColor: COLOR.ok, stack: 's' },
        { label: 'No Stock', data: data.byMonth.map(m => m.no_stock_count || 0), backgroundColor: COLOR.critical, stack: 's' },
      ],
    },
    options: { plugins: { title: { display: true, text: 'Sites w/ Stock vs No Stock, per Month (field visits)' } }, scales: { x: { stacked: true }, y: { stacked: true } } },
  });
  row = await embedImage(workbook, ws, stockChart, { col: 'A', row });

  // Chart 4b — Sites Exhausted vs Has Reserve (kept — budget-based, distinct from the
  // field-visit-based Has Stock/No Stock chart above; per Phase 168 decision not to
  // remove the budget-tracking view)
  const exhaustChart = await renderChart({
    type: 'bar',
    data: {
      labels: data.byMonth.map(m => monthLabel(m._id)),
      datasets: [
        { label: 'Exhausted', data: data.byMonth.map(m => m.exhausted_count), backgroundColor: COLOR.critical, stack: 's' },
        { label: 'Has Reserve', data: data.byMonth.map(m => Math.max((m.sites_with_budget || 0) - (m.exhausted_count || 0), 0)), backgroundColor: COLOR.ok, stack: 's' },
      ],
    },
    options: { plugins: { title: { display: true, text: 'Sites Exhausted vs Has Reserve, per Month (budget)' } }, scales: { x: { stacked: true }, y: { stacked: true } } },
  });
  row = await embedImage(workbook, ws, exhaustChart, { col: 'A', row });

  // Chart 4c — Carried-Over Stock Burned, by Cycle (Phase 169 — new; previously absent
  // from the Excel export entirely)
  const cobChart = await renderChart({
    type: 'bar',
    data: {
      labels: data.byMonth.map(m => monthLabel(m._id)),
      datasets: [{
        label: 'Carried-Over Stock Burned (L)',
        data: data.byMonth.map(m => m.carried_over_stock_burn_l ?? 0),
        backgroundColor: data.byMonth.map(m => (m.carried_over_stock_burn_l ?? 0) < 0 ? COLOR.critical : COLOR.ok),
      }],
    },
    options: { plugins: { title: { display: true, text: 'Carried-Over Stock Burned, by Cycle (negative = net burned)' }, legend: { display: false } } },
  });
  row = await embedImage(workbook, ws, cobChart, { col: 'A', row });

  // Chart 5 — Tom Card Funding by Cycle
  const tomCardChart = await renderChart({
    type: 'bar',
    data: {
      labels: data.tomCardByCycle.map(([cycle]) => monthLabel(cycle)),
      datasets: [{ label: 'Funded (L)', data: data.tomCardByCycle.map(([, l]) => l), backgroundColor: COLOR.delivered }],
    },
    options: { plugins: { title: { display: true, text: 'Tom Card Funding, by Cycle' }, legend: { display: false } } },
  });
  row = await embedImage(workbook, ws, tomCardChart, { col: 'A', row });

  // Data tables
  ws.getCell(`A${row}`).value = 'Monthly Detail';
  ws.getCell(`A${row}`).font = { bold: true, size: 13 };
  row += 1;
  row = writeTable(ws, row,
    ['Month', 'Sites', 'Sites w/ Budget', 'Total Budget (L)', 'Total Consumed (L)', 'Total Reserve (L)', 'Total Gain / Loss (L)', 'Carried-Over Stock Burned (L)', 'Has Stock', 'No Stock', 'Exhausted', 'Theft Flagged'],
    data.byMonth.map(m => [
      monthLabel(m._id), m.site_count, m.sites_with_budget, Math.round(m.total_budget_l), Math.round(m.total_consumption_l), Math.round(m.total_reserve_l),
      m.gain_loss_l == null ? '—' : Math.round(m.gain_loss_l),
      m.carried_over_stock_burn_l == null ? '—' : Math.round(m.carried_over_stock_burn_l),
      m.has_stock_count ?? 0, m.no_stock_count ?? 0,
      m.exhausted_count, m.theft_flagged_count,
    ]),
    { widths: [12, 10, 14, 16, 18, 16, 18, 24, 10, 10, 12, 14], numberCols: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], autoFilter: true });
  row += 2;

  ws.getCell(`A${row}`).value = 'Chronically Exhausted Sites (exhausted every month they had a budget figure)';
  ws.getCell(`A${row}`).font = { bold: true, size: 13 };
  row += 1;
  writeTable(ws, row, ['Site', 'Cluster', 'Months Exhausted / With Budget', 'Avg Reserve (L)'],
    data.chronicallyExhausted.map(s => [s.site_name || s._id, s.cluster || '—', `${s.months_exhausted}/${s.months_with_budget}`, Math.round(s.avg_reserve_l)]),
    { widths: [22, 16, 28, 16], numberCols: [3] });
}

async function addSiteCycleSheet(workbook, rows) {
  const ws = workbook.addWorksheet('Site Cycle Analysis');
  let row = writeTitle(ws, 1, 'Site Cycle Analysis', `Every recovered cycle, every site · ${rows.length} rows`);

  const byCycle = CYCLES.map(cycle => {
    const cRows = rows.filter(r => r.cycle === cycle);
    return {
      cycle,
      consumed: sumOrNull(...cRows.map(r => r.consumed_l)) ?? 0,
      gainLoss: sumOrNull(...cRows.map(r => r.gain_loss_l)) ?? 0,
    };
  });
  const chart = await renderChart({
    type: 'bar',
    data: {
      labels: byCycle.map(c => monthLabel(c.cycle)),
      datasets: [
        { label: 'Consumed (L)', data: byCycle.map(c => c.consumed), backgroundColor: COLOR.consumed },
        { label: 'Gain / Loss (L)', data: byCycle.map(c => c.gainLoss), backgroundColor: COLOR.gainLoss },
      ],
    },
    options: { plugins: { title: { display: true, text: 'Total Consumed vs Gain/Loss, per Cycle (all sites)' } } },
  });
  row = await embedImage(workbook, ws, chart, { col: 'A', row });
  row += 1;

  writeTable(ws, row,
    ['Cycle', 'Site', 'Site ID', 'Cluster',
      'Requested — Initial (L)', 'Requested — Extra (L)', 'Total Requested (L)', 'Requested Partial?',
      'Approved — Initial (L)', 'Approved — Extra (L)', 'Total Approved (L)', 'Approved Partial?',
      'Delivered to Site (L)', 'Visits This Cycle', 'Consumed (L)', 'Gain / Loss (L)', 'Status',
      'Stock on Site — Last Visit (L)', 'Carried-Over Stock Burned (L)',
      'Run Hours', 'Avg True CPH (L/h)', 'Contractual CPH (L/h)', 'CPH Gap vs Contractual (L/h)',
      'Stability (CoV)', 'Anomaly Intervals', 'Has Stock'],
    rows.map(r => [monthLabel(r.cycle), r.site_name || '—', r.site_id, r.cluster || '—',
      r.initial_requested_l != null ? Math.round(r.initial_requested_l) : null,
      r.extra_requested_l != null ? Math.round(r.extra_requested_l) : null,
      r.total_requested_l != null ? Math.round(r.total_requested_l) : null,
      r.requested_partial ? 'Yes' : 'No',
      r.initial_approved_l != null ? Math.round(r.initial_approved_l) : null,
      r.extra_approved_l != null ? Math.round(r.extra_approved_l) : null,
      r.total_approved_l != null ? Math.round(r.total_approved_l) : null,
      r.approved_partial ? 'Yes' : 'No',
      r.delivered_to_site_l != null ? Math.round(r.delivered_to_site_l) : null,
      r.visit_count ?? 0,
      r.consumed_l != null ? Math.round(r.consumed_l) : null,
      r.gain_loss_l != null ? Math.round(r.gain_loss_l) : '—',
      r.status || '—',
      r.stock_on_site_l != null ? Math.round(r.stock_on_site_l) : '—',
      r.carried_over_stock_burn_l != null ? Math.round(r.carried_over_stock_burn_l) : '—',
      r.run_hours_total != null ? Math.round(r.run_hours_total * 10) / 10 : '—',
      r.avg_true_cph != null ? Math.round(r.avg_true_cph * 100) / 100 : '—',
      r.contractual_cph != null ? Math.round(r.contractual_cph * 100) / 100 : '—',
      r.true_cph_vs_contractual != null ? Math.round(r.true_cph_vs_contractual * 100) / 100 : '—',
      r.stability_cov != null ? Math.round(r.stability_cov * 1000) / 1000 : '—',
      r.anomaly_interval_count ?? '—',
      r.has_stock == null ? '—' : (r.has_stock ? 'Yes' : 'No'),
    ]),
    { widths: [10, 22, 14, 14, 15, 14, 15, 12, 15, 14, 15, 12, 16, 12, 14, 12, 12, 22, 22, 10, 16, 16, 18, 12, 14, 10],
      numberCols: [4, 5, 6, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 24],
      autoFilter: true });
}

async function addClusterCycleSheet(workbook, rows) {
  const ws = workbook.addWorksheet('Cluster Cycle Analysis');
  let row = writeTitle(ws, 1, 'Cluster Cycle Analysis', `Every recovered cycle, the 8 real clusters · ${rows.length} rows`);

  const byCluster = REAL_CLUSTERS.map(cluster => {
    const cRows = rows.filter(r => r.cluster === cluster);
    return {
      cluster,
      purchases: sumOrNull(...cRows.map(r => r.purchases_l)) ?? 0,
      gainLoss: sumOrNull(...cRows.map(r => r.gain_loss_l)) ?? 0,
    };
  });
  const chart = await renderChart({
    type: 'bar',
    data: {
      labels: byCluster.map(c => c.cluster),
      datasets: [{ label: 'Purchases (L), all cycles', data: byCluster.map(c => c.purchases), backgroundColor: COLOR.delivered }],
    },
    options: { plugins: { title: { display: true, text: 'Total Purchases by Cluster (all recovered cycles)' }, legend: { display: false } } },
  });
  row = await embedImage(workbook, ws, chart, { col: 'A', row });

  // Chart 2 — Total Gain/Loss by Cluster (Phase 169 — new, for parity with
  // the app's own Compare Clusters view)
  const glChart = await renderChart({
    type: 'bar',
    data: {
      labels: byCluster.map(c => c.cluster),
      datasets: [{
        label: 'Gain / Loss (L), all cycles',
        data: byCluster.map(c => c.gainLoss),
        backgroundColor: byCluster.map(c => c.gainLoss < 0 ? COLOR.critical : COLOR.ok),
      }],
    },
    options: { plugins: { title: { display: true, text: 'Total Gain/Loss by Cluster (all recovered cycles)' }, legend: { display: false } } },
  });
  row = await embedImage(workbook, ws, glChart, { col: 'A', row });
  row += 1;

  writeTable(ws, row,
    ['Cycle', 'Cluster', 'Requested (L)', 'Approved (L)', 'Extra Fuel Requested (L)', 'Extra Fuel Approved (L)',
      'Purchases (L)', 'Purchases (XAF)', 'Card Funding incl. Extra (L)', 'Card Funding incl. Extra (XAF)',
      'Consumed — Actual (L)', 'Reserve (L)', 'Consumed Coverage (sites)',
      'Fleet-Wide Debit/Credit for Cycle (XAF, NOT per-cluster)',
      'Estimated Cluster Share of Settlement (XAF) — COMPUTED, not recorded',
      'Gain / Loss (L)', 'Carried-Over Stock Burned (L)', 'Run Hours', 'Avg True CPH (L/h)', 'Has Stock (sites)', 'No Stock (sites)'],
    rows.map(r => [monthLabel(r.cycle), r.cluster,
      r.requested_l != null ? Math.round(r.requested_l) : null,
      r.approved_l != null ? Math.round(r.approved_l) : null,
      r.extra_requested_l != null ? Math.round(r.extra_requested_l) : null,
      r.extra_approved_l != null ? Math.round(r.extra_approved_l) : null,
      r.purchases_l != null ? Math.round(r.purchases_l) : null,
      r.purchases_xaf != null ? Math.round(r.purchases_xaf) : null,
      r.card_funding_l != null ? Math.round(r.card_funding_l) : null,
      r.card_funding_xaf != null ? Math.round(r.card_funding_xaf) : null,
      r.total_consumed_l != null ? Math.round(r.total_consumed_l) : null,
      r.total_reserve_l != null ? Math.round(r.total_reserve_l) : null,
      r.site_coverage || '—',
      r.fleet_debit_credit_xaf != null ? Math.round(r.fleet_debit_credit_xaf) : null,
      r.estimated_share_xaf != null ? Math.round(r.estimated_share_xaf) : null,
      r.gain_loss_l != null ? Math.round(r.gain_loss_l) : '—',
      r.carried_over_stock_burn_l != null ? Math.round(r.carried_over_stock_burn_l) : '—',
      r.run_hours_total != null ? Math.round(r.run_hours_total * 10) / 10 : '—',
      r.avg_true_cph_this_cycle != null ? Math.round(r.avg_true_cph_this_cycle * 100) / 100 : '—',
      r.has_stock_count ?? '—',
      r.no_stock_count ?? '—',
    ]),
    { widths: [10, 14, 14, 14, 18, 18, 14, 16, 20, 22, 16, 12, 18, 26, 30, 16, 24, 10, 16, 14, 14],
      numberCols: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20],
      autoFilter: true });
}

async function addCompleteMonthlySheet(workbook, data) {
  const ws = workbook.addWorksheet('Complete Monthly Summary');
  let row = writeTitle(ws, 1, 'Complete Monthly Summary', `Every recovered month (Dec 2025 onward, plus 2025 pre-history where recovered) · ${data.rows.length} rows`);

  const chart = await renderChart({
    type: 'line',
    data: {
      labels: data.fleetReserveByMonth.map(m => monthLabel(m.month)),
      datasets: [
        { label: 'Consumed (L)', data: data.fleetReserveByMonth.map(m => m.total_consumed_l), borderColor: COLOR.consumed, backgroundColor: COLOR.consumed, fill: false, tension: 0.2 },
        { label: 'Gain / Loss (L)', data: data.fleetReserveByMonth.map(m => m.total_gain_loss_l), borderColor: COLOR.gainLoss, backgroundColor: COLOR.gainLoss, fill: false, tension: 0.2 },
      ],
    },
    options: { plugins: { title: { display: true, text: 'Fleet-Wide Consumed vs Gain/Loss — Full Recovered History' } } },
  });
  row = await embedImage(workbook, ws, chart, { col: 'A', row });
  row += 1;

  writeTable(ws, row,
    ['Month', 'Site', 'Site ID', 'Cluster', 'Requested (L)', 'Approved (L)', 'Extra Fuel (L)', 'Consumed (L)', 'Gain / Loss (L)', 'Status',
      'Stock on Site — Last Visit (L)', 'Carried-Over Stock Burned (L)', 'Run Hours', 'Avg True CPH (L/h)', 'Contractual CPH (L/h)', 'Has Stock'],
    data.rows.map(r => [monthLabel(r.month), r.site_name || '—', r.site_id, r.cluster || '—',
      r.requested_l != null ? Math.round(r.requested_l) : null,
      r.approved_l != null ? Math.round(r.approved_l) : null,
      r.extra_fuel_l != null ? Math.round(r.extra_fuel_l) : null,
      r.consumed_l != null ? Math.round(r.consumed_l) : null,
      r.gain_loss_l != null ? Math.round(r.gain_loss_l) : '—',
      r.status || '—',
      r.stock_on_site_l != null ? Math.round(r.stock_on_site_l) : '—',
      r.carried_over_stock_burn_l != null ? Math.round(r.carried_over_stock_burn_l) : '—',
      r.run_hours_total != null ? Math.round(r.run_hours_total * 10) / 10 : '—',
      r.avg_true_cph != null ? Math.round(r.avg_true_cph * 100) / 100 : '—',
      r.contractual_cph != null ? Math.round(r.contractual_cph * 100) / 100 : '—',
      r.has_stock == null ? '—' : (r.has_stock ? 'Yes' : 'No'),
    ]),
    { widths: [10, 22, 14, 14, 14, 14, 14, 14, 14, 12, 22, 22, 10, 16, 16, 10],
      numberCols: [4, 5, 6, 7, 8, 10, 11, 12, 13, 14],
      autoFilter: true });
}

// ─── Entry point ────────────────────────────────────────────────────────────

async function buildHistoricalExcelWorkbook() {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'PowerGen API — Historical Data (Recovered)';
  workbook.created = new Date();

  // Fetched up front (cheap — one collection, $in filter) so the cluster
  // sheet's estimated settlement share can reference each cycle's real
  // fleet-wide debit/credit figure without re-running the global summary's
  // full aggregation pipeline just for this one field.
  const debitRaw = await MonthlyDebitSummary.find({ cycle_key: { $in: CYCLES } }).lean();
  const fleetDebitByCycle = new Map(debitRaw.map(d => [d.cycle_key, d]));

  const [globalData, siteRows, clusterRows, completeData] = await Promise.all([
    fetchGlobalSummaryData(GLOBAL_MIN_MONTH_KEY),
    fetchSiteCycleData(CYCLES),
    fetchClusterCycleData(CYCLES, REAL_CLUSTERS, fleetDebitByCycle),
    fetchCompleteMonthlyData(),
  ]);

  await addGlobalSummarySheet(workbook, globalData);
  await addSiteCycleSheet(workbook, siteRows);
  await addClusterCycleSheet(workbook, clusterRows);
  await addCompleteMonthlySheet(workbook, completeData);

  return workbook.xlsx.writeBuffer();
}

module.exports = {
  buildHistoricalExcelWorkbook,
  CYCLES, REAL_CLUSTERS, GLOBAL_MIN_MONTH_KEY,
  // Exported so other read-only tools (e.g.
  // scripts/printHistoricalAnalysisSummary.js) can reuse the exact same
  // batched-query data-gathering logic instead of re-deriving it and
  // risking drift from what the workbook (and the app's own endpoints)
  // actually show.
  fetchGlobalSummaryData, fetchSiteCycleData, fetchClusterCycleData, fetchCompleteMonthlyData,
  monthLabel,
};
