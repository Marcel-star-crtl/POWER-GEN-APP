const Maintenance = require('../models/Maintenance');
const Generator = require('../models/Generator');
const User = require('../models/User');
const Notification = require('../models/Notifications');
const pushNotificationService = require('../services/pushNotificationService');
const ExcelJS = require('exceljs');
const fs = require('fs');

// @desc    Get all maintenance records
// @route   GET /api/maintenance
// @access  Public
exports.getAllMaintenance = async (req, res) => {
  try {
    const { generator, tower, completed } = req.query;
    const filter = {};
    
    if (generator) filter.generator_id = generator;
    if (tower) filter.tower_id = tower;
    if (completed) filter.completed = completed === 'true';

    const maintenance = await Maintenance.find(filter)
      .populate('generator_id', 'model')
      .populate('tower_id', 'name')
      .sort({ date: -1 })
      .lean();

    res.json(maintenance);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// @desc    Get generator maintenance history
// @route   GET /api/maintenance/generator/:id
// @access  Public
exports.getGeneratorMaintenance = async (req, res) => {
  try {
    const maintenance = await Maintenance.find({ generator_id: req.params.id })
      .sort({ date: -1 })
      .lean();

    res.json(maintenance);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// @desc    Create maintenance record
// @route   POST /api/maintenance
// @access  Private/Admin
exports.createMaintenance = async (req, res) => {
  try {
    // Verify generator exists
    const generator = await Generator.findById(req.body.generator_id);
    if (!generator) {
      return res.status(400).json({ error: 'Generator not found' });
    }

    const maintenance = new Maintenance({
      ...req.body,
      date: req.body.date || new Date()
    });

    await maintenance.save();

    // Update generator's last maintenance if completed
    if (maintenance.completed) {
      generator.last_maintenance = maintenance.date;
      generator.maintenance_history.push(maintenance._id);
      await generator.save();
    }

    res.status(201).json(maintenance);
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(val => val.message);
      return res.status(400).json({ error: messages });
    }
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// @desc    Update maintenance record
// @route   PUT /api/maintenance/:id
// @access  Private/Admin
exports.updateMaintenance = async (req, res) => {
  try {
    const maintenance = await Maintenance.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!maintenance) {
      return res.status(404).json({ error: 'Maintenance record not found' });
    }

    // Update generator's last maintenance if completed
    if (maintenance.completed) {
      await Generator.findByIdAndUpdate(
        maintenance.generator_id,
        { 
          last_maintenance: maintenance.date,
          $addToSet: { maintenance_history: maintenance._id }
        }
      );
    }

    res.json(maintenance);
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(val => val.message);
      return res.status(400).json({ error: messages });
    }
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// @desc    Upload maintenance schedule from Excel
// @route   POST /api/maintenance/upload-schedule
// @access  Private/Supervisor/Admin
exports.uploadMaintenanceSchedule = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel file' });
    }

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(req.file.path);
    const worksheet = workbook.getWorksheet(1);
    
    if (!worksheet) {
      throw new Error('No worksheet found in Excel file');
    }

    const headers = {};
    const firstRow = worksheet.getRow(1);
    firstRow.eachCell((cell, colNumber) => {
      const value = cell.value;
      let headerName = '';
      
      if (typeof value === 'string') {
        headerName = value.trim();
      } else if (value && typeof value === 'object' && value.richText) {
        headerName = value.richText.map(rt => rt.text).join('').trim();
      } else if (value && typeof value === 'object' && value.text) {
        headerName = value.text.trim();
      } else if (value) {
        headerName = String(value).trim();
      }
      
      if (headerName) {
        headers[headerName] = colNumber;
      }
    });

    console.log('Detected headers:', Object.keys(headers));

    // Validation for required columns (case-insensitive check)
    const requiredMapping = {
        'IHS SITE ID': ['ihs site id', 'site id'],
        'Site Name': ['site name'],
        '1st service Planned Date': ['1st service planned date', 'planned date']
    };

    const validatedHeaders = {};
    const headerKeys = Object.keys(headers);

    for (const [standardName, variations] of Object.entries(requiredMapping)) {
        const foundKey = headerKeys.find(h => 
            standardName.toLowerCase() === h.toLowerCase() || 
            variations.some(v => h.toLowerCase().includes(v))
        );
        if (foundKey) {
            validatedHeaders[standardName] = headers[foundKey];
        }
    }
    
    // Check for technician column with some flexibility
    const techColName = headerKeys.find(h => 
        h.toLowerCase().includes('technician name') || 
        h.toLowerCase() === 'technician'
    );
    
    if (techColName) {
        validatedHeaders['Technician Name'] = headers[techColName];
    }
    
    const emailColName = headerKeys.find(h => h.toLowerCase().includes('email'));
    if (emailColName) {
        validatedHeaders['Technician Email'] = headers[emailColName];
    }

    const missingCols = ['IHS SITE ID', 'Site Name', '1st service Planned Date', 'Technician Name']
        .filter(col => !validatedHeaders[col]);
    
    if (missingCols.length > 0) {
        throw new Error(`Missing required columns: ${missingCols.join(', ')}. Found: ${headerKeys.join('|')}`);
    }
    
    const technicianCol = validatedHeaders['Technician Name'];
    const emailCol = validatedHeaders['Technician Email'];
    
    // Overwrite headers with validated ones for consistency in access
    Object.assign(headers, validatedHeaders);

    // Fetch all technicians for lookup
    const technicians = await User.find({ role: 'technician' }).select('fullName email _id');
    
    const findTechnician = (name, email) => {
        if (email) {
            const tech = technicians.find(t => t.email && t.email.toLowerCase() === email.toLowerCase().trim());
            if (tech) return tech;
        }
        if (name) {
             const normalizedName = name.toLowerCase().trim();
             return technicians.find(t => t.fullName.toLowerCase().includes(normalizedName));
        }
        return null;
    };

    let processedCount = 0;
    const errors = [];

    const rowCount = worksheet.rowCount;
    if (rowCount > 1) {
       for (let i = 2; i <= rowCount; i++) {
           const row = worksheet.getRow(i);
           if (!row.hasValues) continue;
           
           try {
              const getValue = (colIdx) => {
                  if (!colIdx) return null;
                  const cell = row.getCell(colIdx);
                  const val = cell.value;
                  if (val && typeof val === 'object') {
                      if (val.richText) return val.richText.map(rt => rt.text).join('').trim();
                      if (val.text) return val.text.trim();
                      if (val.result !== undefined) return val.result;
                  }
                  return val;
              };

              const siteId = getValue(headers['IHS SITE ID']);
              if (!siteId) continue;
              
              const siteName = getValue(headers['Site Name']);
              
              // Date parsing
              let visitDateRaw = getValue(headers['1st service Planned Date']);
              if (!visitDateRaw) continue;

              const visitDate = new Date(visitDateRaw);
              if (isNaN(visitDate.getTime())) {
                  errors.push(`Row ${i}: Invalid date format '${visitDateRaw}'`);
                  continue;
              }
              
              const techName = getValue(technicianCol);
              const techEmail = getValue(emailCol);
              
              let tech = findTechnician(techName, techEmail);
              if (!tech) {
                  errors.push(`Row ${i}: Technician '${techName}' not found`);
                  continue;
              }
             
              const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
              const maintenanceId = `MAINT-${dateStr}-${Date.now().toString().slice(-4)}-${i}`;

              const maintenance = new Maintenance({
                   maintenance_id: maintenanceId,
                   site_id: String(siteId),
                   site_name: String(siteName || ''),
                   technician: tech._id,
                   technician_name: tech.fullName,
                   supervisor: req.user._id,
                   visit_type: 'PM',
                   visit_date: visitDate,
                   status: 'scheduled',                   created_by: req.user._id,                   site_metadata: {
                       cluster: headers['Cluster'] ? String(getValue(headers['Cluster']) || '') : '',
                       site_priority: headers['Priority'] ? String(getValue(headers['Priority']) || '') : '',
                       power_topology: headers['Actual topology'] ? String(getValue(headers['Actual topology']) || '') : ''
                   }
               });
               
               await maintenance.save();

               // Send notification to technician
               try {
                   const notificationData = {
                       recipient: tech._id,
                       type: 'maintenance_scheduled',
                       title: 'New Maintenance Scheduled',
                       message: `You have a new PM scheduled for site ${siteId} (${siteName}) on ${visitDate.toLocaleDateString()}`,
                       data: {
                           maintenanceId: maintenance._id,
                           siteId: String(siteId),
                           siteName: String(siteName),
                           visitType: 'preventive'
                       },
                       priority: 'normal'
                   };

                   await Notification.create(notificationData);
                   
                   // Push notification
                   await pushNotificationService.sendToUser(tech._id, {
                       title: notificationData.title,
                       body: notificationData.message,
                       data: {
                           type: 'maintenance_scheduled',
                           maintenanceId: String(maintenance._id),
                           siteId: String(siteId)
                       }
                   }).catch(err => console.error(`Push notification failed for ${tech._id}:`, err.message));

               } catch (notiErr) {
                   console.error('Failed to create notification record:', notiErr);
               }

               processedCount++;
           } catch (e) {
               errors.push(`Row ${i}: ${e.message}`);
           }
       }
    }

    // Cleanup
    fs.unlinkSync(req.file.path);

    res.json({ 
        message: 'Schedule processed', 
        processed: processedCount,
        errors: errors
    });

  } catch (err) {
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    console.error(err);
    res.status(500).json({ error: err.message || 'Server error' });
  }
};

// @desc    Bulk create maintenance schedules from mapped data
// @route   POST /api/maintenance/batch-schedule
// @access  Private/Supervisor/Admin
exports.batchScheduleMaintenance = async (req, res) => {
    try {
        const { schedules } = req.body;
        const finalSchedules = Array.isArray(schedules) ? schedules : (Array.isArray(req.body) ? req.body : null);
        
        if (!finalSchedules) {
            return res.status(400).json({ error: 'Schedules array is required' });
        }

        const technicians = await User.find({ role: 'technician' }).select('fullName email _id');
        
        const findTechnician = (name, email, providedId) => {
            if (providedId) {
                const tech = technicians.find(t => String(t._id) === String(providedId));
                if (tech) return tech;
            }
            if (email) {
                const tech = technicians.find(t => t.email && t.email.toLowerCase() === email.toLowerCase().trim());
                if (tech) return tech;
            }
            if (name) {
                const normalizedName = name.toLowerCase().trim();
                return technicians.find(t => t.fullName.toLowerCase().includes(normalizedName));
            }
            return null;
        };

        const results = {
            successCount: 0,
            errors: []
        };

        const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
        
        for (let i = 0; i < finalSchedules.length; i++) {
            const item = finalSchedules[i];
            try {
                const tech = findTechnician(item.technicianName, item.technicianEmail, item.technician);
                if (!tech) {
                    results.errors.push(`Row ${i + 1}: Technician not found`);
                    continue;
                }

                // Check for valid date
                const visitDate = new Date(item.visitDate);
                if (isNaN(visitDate.getTime())) {
                    results.errors.push(`Row ${i + 1}: Invalid date '${item.visitDate}'`);
                    continue;
                }

                const maintenanceId = `MAINT-${dateStr}-${String(Date.now()).slice(-4)}-${i}`;

                const maintenance = new Maintenance({
                    maintenance_id: maintenanceId,
                    site_id: String(item.siteId),
                    site_name: String(item.siteName || ''),
                    technician: tech._id,
                    technician_name: tech.fullName,
                    supervisor: req.user.userId || req.user._id,
                    visit_type: item.visitType || 'PM',
                    visit_date: visitDate,
                    status: 'scheduled',
                    created_by: req.user.userId || req.user._id,
                    site_metadata: {
                        cluster: String(item.cluster || ''),
                        site_priority: String(item.priority || ''),
                        power_topology: String(item.topology || '')
                    }
                });

                await maintenance.save();

                // Send notification
                try {
                    const notificationData = {
                        recipient: tech._id,
                        type: 'maintenance_scheduled',
                        title: 'New Maintenance Scheduled',
                        message: `You have a new ${item.visitType || 'PM'} scheduled for site ${item.siteId} (${item.siteName}) on ${visitDate.toLocaleDateString()}`,
                        data: {
                            maintenanceId: maintenance._id,
                            siteId: String(item.siteId),
                            siteName: String(item.siteName),
                            visitType: (item.visitType || 'PM').includes('PM') ? 'preventive' : ((item.visitType || '').includes('RF') ? 'refueling' : 'corrective')
                        },
                        priority: 'normal'
                    };
                    await Notification.create(notificationData);
                    await pushNotificationService.sendToUser(tech._id, {
                        title: notificationData.title,
                        body: notificationData.message,
                        data: {
                            type: 'maintenance_scheduled',
                            maintenanceId: String(maintenance._id),
                            siteId: String(item.siteId)
                        }
                    }).catch(err => console.error(`Push notification failed for ${tech._id}:`, err.message));
                } catch (e) {
                    console.error('Notification failed:', e.message);
                }

                results.successCount++;
            } catch (err) {
                results.errors.push(`Row ${i + 1}: ${err.message}`);
            }
        }

        res.json({
            success: true,
            message: 'Batch processing complete',
            processed: results.successCount,
            total: finalSchedules.length,
            errors: results.errors
        });
    } catch (err) {
        console.error('Batch schedule error:', err);
        res.status(500).json({ error: 'Server error during batch processing' });
    }
};