const TankAudit = require('../models/TankAudit');

// Phase 139: the Tank Audit page's data views (Analytics, Reconciliation,
// the main audit list, and the summary) exclude Yassa, Kribi 1, and
// Kribi 2 — a live query-level filter, not a deletion. This is the
// opposite direction of Phase 129's removeNonKeptClusters.js (which
// deleted everything NOT in a 7-cluster keep-list): here, the data
// still exists in the database (restored in Phase 133), it's just
// filtered out of what this specific page shows. Kept as one shared
// constant, reused by every endpoint below that needs it, rather than
// hand-typed separately in each — the same principle Phase 133's
// restore script used when it reused Phase 129's own model mapping
// instead of re-deriving it.
const EXCLUDED_CLUSTERS = ['Yassa', 'Kribi 1', 'Kribi 2'];
const normalizeCluster = s => (s || '').toString().trim().toUpperCase();
const EXCLUDED_CLUSTERS_NORM = new Set(EXCLUDED_CLUSTERS.map(normalizeCluster));
const isExcludedCluster = cluster => EXCLUDED_CLUSTERS_NORM.has(normalizeCluster(cluster));
// For endpoints that must filter at the MongoDB query level (pagination
// happens in Mongo, not after fetching — filtering in JS afterward would
// silently break the page counts) — same exclusion list, case-insensitive
// regex per name so it matches regardless of how the cluster was typed.
const EXCLUDED_CLUSTER_QUERY = { cluster: { $nin: EXCLUDED_CLUSTERS.map(c => new RegExp(`^\\s*${c}\\s*$`, 'i')) } };

const buildPagination = (page = 1, limit = 20) => {
  const currentPage = Math.max(parseInt(page, 10) || 1, 1);
  const pageSize = Math.max(parseInt(limit, 10) || 20, 1);
  return { currentPage, pageSize, skip: (currentPage - 1) * pageSize };
};

/**
 * GET /api/tank-audits/reconciliation?cycle_key=2026-08
 *
 * The live, in-app equivalent of manually building the
 * AUGUST_2026_CYCLE_ANALYSIS workbook's Audit sheet by hand: every
 * site for the given cycle, its system baseline (opening stock,
 * refuel total, contractual CPH — from CycleReconciliation and
 * CycleEndStockSnapshot), and its actual audit findings where a
 * submitted TankAudit exists for that site this cycle. Sites with no
 * submitted audit yet still appear, with audit-specific fields null —
 * matching the same principle the Excel version followed: show what's
 * real, never fabricate what's still missing.
 */
/**
 * GET /api/tank-audits/delivery-events/:site_id?cycle_key=2026-08
 *
 * Every individual delivery event for a site in a cycle — how many
 * times it was refueled, and the exact quantity on each date. The
 * detail behind CycleReconciliation.mail_verified_delivered_l, which
 * is only ever the sum of these.
 */
/**
 * GET /api/tank-audits/delivery-events?cycle_key=2026-08
 *
 * Every delivery event across every site in a cycle, in one call —
 * built for the reconciliation export, where fetching per-site would
 * mean one API call per site.
 */
exports.getAllDeliveryEventsForCycle = async (req, res) => {
  try {
    const { cycle_key } = req.query;
    if (!cycle_key) {
      return res.status(400).json({ success: false, error: 'cycle_key query parameter is required (e.g. "2026-08")' });
    }

    const FuelDeliveryEvent = require('../models/FuelDeliveryEvent');
    const events = await FuelDeliveryEvent.find({ cycle_key })
      .sort({ site_id: 1, delivery_date: 1 })
      .lean();

    return res.json({ success: true, cycle_key, event_count: events.length, events });
  } catch (error) {
    console.error('TankAudit getAllDeliveryEventsForCycle error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load delivery events' });
  }
};

exports.getSiteDeliveryEvents = async (req, res) => {
  try {
    const { site_id } = req.params;
    const { cycle_key } = req.query;
    if (!cycle_key) {
      return res.status(400).json({ success: false, error: 'cycle_key query parameter is required (e.g. "2026-08")' });
    }

    const FuelDeliveryEvent = require('../models/FuelDeliveryEvent');
    const events = await FuelDeliveryEvent.find({ site_id, cycle_key })
      .sort({ delivery_date: 1 })
      .lean();

    const total_delivered_l = events.reduce((sum, e) => sum + (e.quantity_l || 0), 0);

    return res.json({
      success: true,
      site_id,
      cycle_key,
      event_count: events.length,
      total_delivered_l: Math.round(total_delivered_l * 100) / 100,
      events,
    });
  } catch (error) {
    console.error('TankAudit getSiteDeliveryEvents error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load delivery events' });
  }
};

/**
 * POST /api/tank-audits/:id/extract-run-hours
 *
 * Extracts a run-hours reading from the Gen Cards Faulty check area's
 * photo (a mechanical counter meter, photographed as the documented
 * workaround when a site's digital run-hour card is faulty) using a
 * vision model. Stores the result as a suggestion under
 * run_hours_extraction — never writes audit_run_hours_reading itself.
 * A separate accept step (see acceptExtractedRunHours below) is
 * required before the extracted value becomes the audit's real,
 * used reading — this feeds fuel-accounting math, so an automated
 * read needs a person to actually look at it first.
 */
exports.extractRunHours = async (req, res) => {
  try {
    const audit = await TankAudit.findById(req.params.id);
    if (!audit) return res.status(404).json({ success: false, error: 'Tank audit not found' });

    const photos = audit.check_gen_cards_faulty?.photos || [];
    if (!photos.length) {
      audit.set('run_hours_extraction.status', 'no_photo');
      await audit.save();
      return res.status(400).json({ success: false, error: 'No photo attached to the Gen Cards Faulty check area for this audit.' });
    }

    // The most recently added photo — a technician correcting a bad
    // photo by re-uploading would expect the newer one to be used, not
    // silently ignored in favor of the first.
    const photo = photos[photos.length - 1];

    audit.set('run_hours_extraction.status', 'pending');
    audit.set('run_hours_extraction.source_photo_uri', photo.uri);
    await audit.save();

    const GeminiService = require('../services/GeminiService');
    let result;
    try {
      result = await GeminiService.extractRunHoursFromImage(photo.uri);
    } catch (extractionErr) {
      audit.set('run_hours_extraction.status', 'failed');
      audit.set('run_hours_extraction.notes', extractionErr.message);
      await audit.save();
      return res.status(502).json({ success: false, error: 'Run-hours extraction failed', data: audit.run_hours_extraction });
    }

    audit.run_hours_extraction = {
      status: 'completed',
      extracted_value: result.value,
      confidence: result.confidence,
      notes: result.notes,
      source_photo_uri: photo.uri,
      extracted_at: new Date(),
      accepted: false,
    };
    await audit.save();

    return res.json({ success: true, data: audit.run_hours_extraction });
  } catch (error) {
    console.error('TankAudit extractRunHours error:', error);
    return res.status(500).json({ success: false, error: 'Failed to extract run hours' });
  }
};

/**
 * POST /api/tank-audits/:id/accept-extracted-run-hours
 *
 * The real "accept" step — copies run_hours_extraction.extracted_value
 * into audit_run_hours_reading, the field that actually feeds
 * True CPH and Gain/Loss. Requires a completed extraction with a real
 * value; refuses to accept a null/failed extraction rather than write
 * nothing and call it success.
 */
exports.acceptExtractedRunHours = async (req, res) => {
  try {
    const audit = await TankAudit.findById(req.params.id);
    if (!audit) return res.status(404).json({ success: false, error: 'Tank audit not found' });

    if (audit.run_hours_extraction?.status !== 'completed' || audit.run_hours_extraction?.extracted_value == null) {
      return res.status(400).json({ success: false, error: 'No completed extraction with a real value to accept for this audit.' });
    }

    audit.audit_run_hours_reading = audit.run_hours_extraction.extracted_value;
    audit.audit_run_hours_reading_source = 'extraction_accepted';
    audit.run_hours_extraction.accepted = true;
    await audit.save();

    return res.json({ success: true, data: { audit_run_hours_reading: audit.audit_run_hours_reading, run_hours_extraction: audit.run_hours_extraction } });
  } catch (error) {
    console.error('TankAudit acceptExtractedRunHours error:', error);
    return res.status(500).json({ success: false, error: 'Failed to accept extracted run hours' });
  }
};

/**
 * PATCH /api/tank-audits/:id/manual-run-hours
 *
 * A narrowly-scoped correction path for exactly one field —
 * audit_run_hours_reading — available to the same DASHBOARD_ROLES that
 * can already view and extract/accept for this audit. Built because
 * updateAudit (the general edit endpoint) is deliberately restricted
 * to technician/admin only, and a diesel_manager or other reviewer
 * needs a real way to enter a value directly when extraction fails or
 * a value was only ever recorded in a notes field during an earlier
 * period before this system collected run hours at all — without
 * broadening full-record edit access to every dashboard role just to
 * fix this one number.
 */
/**
 * GET /api/tank-audits/notes-run-hours-candidates
 *
 * Phase 121, corrected after Phase 121's initial version: scans every
 * submitted audit that's missing audit_run_hours_reading for a
 * run-hours value that might have been recorded in the Faulty Gen
 * Card check area's own notes field instead — confirmed directly by
 * the user that this specific field, not general_notes, is where the
 * workaround readings were actually recorded before this system had a
 * dedicated field for it (Phase 118). Every result is a suggestion for
 * review, not something this endpoint applies on its own — use
 * setManualRunHours (the existing manual-run-hours endpoint) to
 * actually accept one.
 */
exports.getNotesRunHoursCandidates = async (req, res) => {
  try {
    const { scanAuditForRunHours } = require('../services/notesRunHoursScanner');

    const audits = await TankAudit.find({
      status: 'submitted',
      audit_run_hours_reading: null, // MongoDB's null-equality matches both an explicitly-null field and a missing one — no need for a separate $exists check
      'check_gen_cards_faulty.notes': { $exists: true, $ne: '' },
    })
      .select('site_id_ihs auditor_name audit_date check_gen_cards_faulty.notes')
      .lean();

    const results = [];
    for (const audit of audits) {
      const candidates = scanAuditForRunHours(audit);
      if (candidates.length) {
        results.push({
          audit_id: audit._id,
          site_id: audit.site_id_ihs,
          auditor_name: audit.auditor_name,
          audit_date: audit.audit_date,
          candidates,
        });
      }
    }

    return res.json({
      success: true,
      audits_scanned: audits.length,
      audits_with_candidates: results.length,
      data: results,
    });
  } catch (error) {
    console.error('TankAudit getNotesRunHoursCandidates error:', error);
    return res.status(500).json({ success: false, error: 'Failed to scan notes for run-hours candidates' });
  }
};

exports.setManualRunHours = async (req, res) => {
  try {
    const { value } = req.body;
    if (value === undefined || value === null || typeof value !== 'number' || !Number.isFinite(value)) {
      return res.status(400).json({ success: false, error: 'A real numeric "value" is required.' });
    }

    const audit = await TankAudit.findById(req.params.id);
    if (!audit) return res.status(404).json({ success: false, error: 'Tank audit not found' });

    audit.audit_run_hours_reading = value;
    audit.audit_run_hours_reading_source = 'manual_correction';
    audit.updated_by = (req.user.userId || req.user.id || '').toString();
    await audit.save();

    return res.json({ success: true, data: { audit_run_hours_reading: audit.audit_run_hours_reading, true_cph: audit.true_cph } });
  } catch (error) {
    console.error('TankAudit setManualRunHours error:', error);
    return res.status(500).json({ success: false, error: 'Failed to save manual run hours' });
  }
};

/**
 * GET /api/tank-audits/analytics?cycle_key=2026-08
 *
 * Live equivalent of the earlier one-off docx analysis — same
 * categories of findings (data completeness by cluster, consumption
 * distribution, CPH vs validated CPH, faulty meters, negative-
 * consumption outliers, top/bottom sites), computed from the real,
 * current TankAudit/Site collections rather than a static file
 * snapshot from one specific email.
 */
exports.getAuditAnalytics = async (req, res) => {
  try {
    const { cycle_key } = req.query;
    const Site = require('../models/Site');

    const sites = (await Site.find({}).select('IHS_ID_SITE Site_Name GRATO_Cluster').lean())
      .filter(s => !isExcludedCluster(s.GRATO_Cluster));
    const siteByIhsId = new Map(sites.map(s => [s.IHS_ID_SITE, s]));
    const includedSiteIds = new Set(sites.map(s => s.IHS_ID_SITE));

    const auditMatch = { status: 'submitted' };
    if (cycle_key) auditMatch.cycle_key = cycle_key;
    const audits = (await TankAudit.find(auditMatch)
      .select('site_id_ihs dip_reading_l find_consumption_l true_cph validated_cph gain_loss_l check_gen_cards_faulty.status opening_stock_l total_refueled_l stock_actualized_1_l')
      .lean())
      .filter(a => includedSiteIds.has(a.site_id_ihs));

    // ── 1. Data completeness by cluster — a site "has data" if it has
    // at least one submitted audit with a real dip reading, mirroring
    // the earlier report's "raw data present" concept. ──────────────
    const sitesWithAudit = new Set(audits.filter(a => a.dip_reading_l != null).map(a => a.site_id_ihs));
    const completenessByCluster = new Map();
    for (const s of sites) {
      const cluster = s.GRATO_Cluster || '(no cluster)';
      if (!completenessByCluster.has(cluster)) completenessByCluster.set(cluster, { has: 0, missing: 0 });
      const entry = completenessByCluster.get(cluster);
      if (sitesWithAudit.has(s.IHS_ID_SITE)) entry.has++; else entry.missing++;
    }
    const completeness_by_cluster = [...completenessByCluster.entries()]
      .map(([cluster, v]) => ({ cluster, has_data: v.has, missing: v.missing, total: v.has + v.missing, pct_complete: Math.round((v.has / (v.has + v.missing)) * 1000) / 10 }))
      .sort((a, b) => b.has_data - a.has_data);

    // ── 2. Consumption distribution + by-cluster averages ───────────
    const validConsumption = audits.filter(a => typeof a.find_consumption_l === 'number');
    const byClusterConsumption = new Map();
    for (const a of validConsumption) {
      const cluster = siteByIhsId.get(a.site_id_ihs)?.GRATO_Cluster || '(unknown)';
      if (!byClusterConsumption.has(cluster)) byClusterConsumption.set(cluster, []);
      byClusterConsumption.get(cluster).push(a.find_consumption_l);
    }
    const consumption_by_cluster = [...byClusterConsumption.entries()]
      .map(([cluster, values]) => ({
        cluster,
        avg_consumption_l: Math.round((values.reduce((s, v) => s + v, 0) / values.length) * 10) / 10,
        site_count: values.length,
      }))
      .sort((a, b) => b.avg_consumption_l - a.avg_consumption_l);

    // ── 3. True CPH vs Validated CPH ─────────────────────────────────
    const cphPairs = audits
      .filter(a => typeof a.true_cph === 'number' && typeof a.validated_cph === 'number')
      .map(a => ({ site_id: a.site_id_ihs, true_cph: a.true_cph, validated_cph: a.validated_cph, above_validated: a.true_cph > a.validated_cph }));
    const sitesAboveValidatedRate = cphPairs.filter(p => p.above_validated).length;

    // ── 4. Faulty gen card meters ─────────────────────────────────────
    const faultyAudits = audits.filter(a => a.check_gen_cards_faulty?.status === 'issue');
    const faultyByCluster = new Map();
    for (const a of faultyAudits) {
      const cluster = siteByIhsId.get(a.site_id_ihs)?.GRATO_Cluster || '(unknown)';
      faultyByCluster.set(cluster, (faultyByCluster.get(cluster) || 0) + 1);
    }
    const faulty_meters_by_cluster = [...faultyByCluster.entries()]
      .map(([cluster, count]) => ({ cluster, count }))
      .sort((a, b) => b.count - a.count);

    // ── 5. Negative-consumption outliers — physically impossible, worth a direct follow-up ──
    const negative_consumption_sites = validConsumption
      .filter(a => a.find_consumption_l < 0)
      .map(a => ({
        site_id: a.site_id_ihs,
        site_name: siteByIhsId.get(a.site_id_ihs)?.Site_Name || null,
        cluster: siteByIhsId.get(a.site_id_ihs)?.GRATO_Cluster || null,
        opening_stock_l: a.opening_stock_l,
        total_refueled_l: a.total_refueled_l,
        stock_actualized_1_l: a.stock_actualized_1_l,
        dip_reading_l: a.dip_reading_l,
        find_consumption_l: a.find_consumption_l,
      }))
      .sort((a, b) => a.find_consumption_l - b.find_consumption_l);

    // ── 6. Top/bottom consumption sites ──────────────────────────────
    const sortedByConsumption = [...validConsumption].sort((a, b) => b.find_consumption_l - a.find_consumption_l);
    const top_consumption_sites = sortedByConsumption.slice(0, 10).map(a => ({ site_id: a.site_id_ihs, find_consumption_l: a.find_consumption_l }));
    const bottom_consumption_sites = sortedByConsumption.slice(-5).reverse().map(a => ({ site_id: a.site_id_ihs, find_consumption_l: a.find_consumption_l }));

    return res.json({
      success: true,
      cycle_key: cycle_key || null,
      summary: {
        total_sites: sites.length,
        sites_with_audit_data: sitesWithAudit.size,
        sites_missing_audit_data: sites.length - sitesWithAudit.size,
        total_submitted_audits: audits.length,
        faulty_meter_count: faultyAudits.length,
        negative_consumption_count: negative_consumption_sites.length,
        sites_above_validated_rate: sitesAboveValidatedRate,
        cph_pairs_available: cphPairs.length,
      },
      completeness_by_cluster,
      consumption_by_cluster,
      cph_comparison: cphPairs,
      faulty_meters_by_cluster,
      negative_consumption_sites,
      top_consumption_sites,
      bottom_consumption_sites,
    });
  } catch (error) {
    console.error('TankAudit getAuditAnalytics error:', error);
    return res.status(500).json({ success: false, error: 'Failed to compute audit analytics' });
  }
};

exports.getReconciliationDashboard = async (req, res) => {
  try {
    const { cycle_key } = req.query;
    if (!cycle_key) {
      return res.status(400).json({ success: false, error: 'cycle_key query parameter is required (e.g. "2026-08")' });
    }

    const Site = require('../models/Site');
    const CycleReconciliation = require('../models/CycleReconciliation');
    const CycleEndStockSnapshot = require('../models/CycleEndStockSnapshot');
    const DieselCycle = require('../models/DieselCycle');

    const priorCycleKey = DieselCycle.getPreviousCycleKey(cycle_key);
    const thisCycle = await DieselCycle.findOne({ cycle_key }).lean();

    // Match by cycle_key where it's been resolved, but fall back to the
    // cycle's own date range for audits that predate this feature (their
    // cycle_key field was never populated — the pre-save hook that
    // computes it only runs on save, not retroactively on documents that
    // already existed). Without this fallback, every audit submitted
    // before this feature shipped would silently vanish from this view.
    const auditMatch = { status: 'submitted' };
    if (thisCycle) {
      auditMatch.$or = [
        { cycle_key },
        { cycle_key: { $exists: false }, audit_date: { $gte: thisCycle.start_date, $lte: thisCycle.end_date } },
        { cycle_key: null, audit_date: { $gte: thisCycle.start_date, $lte: thisCycle.end_date } },
      ];
    } else {
      // No DieselCycle document for this key at all — can't build a date
      // range fallback, so fall back to matching cycle_key alone. Real,
      // but narrower coverage; flagged in the response below.
      auditMatch.cycle_key = cycle_key;
    }

    const [sitesRaw, reconciliations, snapshots, audits] = await Promise.all([
      Site.find({}).select('IHS_ID_SITE Site_Name Region GRATO_Cluster').lean(),
      CycleReconciliation.find({ cycle_key }).lean(),
      CycleEndStockSnapshot.find({ cycle_key: priorCycleKey }).lean(),
      TankAudit.find(auditMatch)
        .select('site_id_ihs audit_date auditor_name dip_reading_l audit_run_hours_reading stock_actualized_1_l find_consumption_l true_cph validated_cph gain_loss_l overall_severity site_state_updated cycle_key opening_meter_hours closing_meter_hours closing_meter_date total_refueled_source cycle_closed final_run_hours')
        .lean(),
    ]);
    const sites = sitesRaw.filter(s => !isExcludedCluster(s.GRATO_Cluster));

    const reconBysite = new Map(reconciliations.map(r => [r.site_id, r]));
    const snapshotBySite = new Map(snapshots.map(s => [String(s.site), s]));
    const auditBySite = new Map(audits.map(a => [a.site_id_ihs, a]));

    const rows = sites.map(site => {
      const recon = reconBysite.get(site.IHS_ID_SITE);
      const snapshot = snapshotBySite.get(String(site._id));
      const audit = auditBySite.get(site.IHS_ID_SITE);

      // Same source-preference logic as the pre-save hook (mail-
      // verified over the live aggregate) — kept consistent here so a
      // site's PRE-audit numbers on this dashboard don't silently
      // differ from what its audit would compute once submitted.
      let totalRefueled = null, totalRefueledSource = 'missing';
      if (recon?.mail_verified_delivered_l != null) {
        totalRefueled = recon.mail_verified_delivered_l;
        totalRefueledSource = 'mail_verified';
      } else if (recon?.field_fuel_added != null) {
        totalRefueled = recon.field_fuel_added;
        totalRefueledSource = 'cycle_reconciliation';
      }

      return {
        site_id: site.IHS_ID_SITE,
        site_name: site.Site_Name,
        region: site.Region,
        cluster: site.GRATO_Cluster,
        opening_stock_l: snapshot?.stock_l ?? null,
        opening_stock_source: snapshot ? 'cycle_end_snapshot' : 'missing',
        opening_meter_hours: snapshot?.run_hours ?? null,
        total_refueled_l: totalRefueled,
        total_refueled_source: totalRefueledSource,
        validated_cph: recon?.ccph ?? null,
        closing_meter_hours: recon?.closing_meter_hours ?? null,
        closing_meter_date: recon?.closing_meter_date ?? null,
        system_consumption_l: recon?.contractual_consumption ?? null,
        stock_actualized_1_l: (typeof snapshot?.stock_l === 'number' && typeof totalRefueled === 'number')
          ? snapshot.stock_l + totalRefueled
          : null,
        has_recent_audit: !!audit,
        audit_date: audit?.audit_date ?? null,
        auditor_name: audit?.auditor_name ?? null,
        dip_reading_l: audit?.dip_reading_l ?? null,
        audit_run_hours_reading: audit?.audit_run_hours_reading ?? null,
        site_state_updated: audit?.site_state_updated ?? false,
        find_consumption_l: audit?.find_consumption_l ?? null,
        true_cph: audit?.true_cph ?? null,
        gain_loss_l: audit?.gain_loss_l ?? null,
        cycle_closed: audit?.cycle_closed ?? false,
        final_run_hours: audit?.final_run_hours ?? null,
        overall_severity: audit?.overall_severity ?? null,
        data_quality_flags: {
          missing_opening_stock: !snapshot,
          missing_cycle_data: !recon,
          missing_closing_meter: !(recon?.closing_meter_hours != null),
        },
      };
    });

    const summary = {
      total_sites: rows.length,
      sites_audited: rows.filter(r => r.has_recent_audit).length,
      sites_missing_opening_stock: rows.filter(r => r.data_quality_flags.missing_opening_stock).length,
      sites_missing_cycle_data: rows.filter(r => r.data_quality_flags.missing_cycle_data).length,
      sites_missing_closing_meter: rows.filter(r => r.data_quality_flags.missing_closing_meter).length,
      sites_with_loss: rows.filter(r => typeof r.gain_loss_l === 'number' && r.gain_loss_l < 0).length,
    };

    return res.json({
      success: true,
      cycle_key,
      prior_cycle_key: priorCycleKey,
      cycle_found: !!thisCycle,
      audits_matched_by_date_fallback: audits.filter(a => !a.cycle_key).length,
      summary,
      data: rows,
    });
  } catch (error) {
    console.error('TankAudit getReconciliationDashboard error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load reconciliation dashboard' });
  }
};

exports.listAudits = async (req, res) => {
  try {
    const { status, siteId, severity, logsCollected, createdBy, dateFrom, dateTo, sortBy, sortOrder, page = 1, limit = 20 } = req.query;
    const filter = { ...EXCLUDED_CLUSTER_QUERY };
    if (status) filter.status = status;
    if (siteId) filter.site_id_ihs = siteId;
    if (severity) filter.overall_severity = severity;
    if (logsCollected === 'true') filter.logs_collected = true;
    if (logsCollected === 'false') filter.logs_collected = false;
    if (createdBy) filter.created_by = createdBy;

    // Date range filters on audit_date — the day the audit actually
    // happened on-site, not createdAt (when the record was saved,
    // which can differ from the visit date for an offline-queued
    // submission that synced later).
    if (dateFrom || dateTo) {
      filter.audit_date = {};
      if (dateFrom) {
        const from = new Date(dateFrom);
        from.setHours(0, 0, 0, 0);
        filter.audit_date.$gte = from;
      }
      if (dateTo) {
        // Inclusive of the whole end day, not just its midnight instant —
        // a technician picking "audits on the 14th" expects everything
        // from that day, not nothing because 00:00:00 already passed.
        const to = new Date(dateTo);
        to.setHours(23, 59, 59, 999);
        filter.audit_date.$lte = to;
      }
    }

    const sortField = sortBy === 'audit_date' ? 'audit_date' : 'createdAt';
    const sortDirection = sortOrder === 'asc' ? 1 : -1;

    const { currentPage, pageSize, skip } = buildPagination(page, limit);
    const [items, total] = await Promise.all([
      TankAudit.find(filter).sort({ [sortField]: sortDirection }).skip(skip).limit(pageSize).lean(),
      TankAudit.countDocuments(filter),
    ]);
    return res.json({
      success: true,
      data: items,
      pagination: { current: currentPage, pageSize, total, pages: Math.ceil(total / pageSize) },
    });
  } catch (error) {
    console.error('TankAudit listAudits error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load tank audits' });
  }
};

exports.getAuditById = async (req, res) => {
  try {
    const audit = await TankAudit.findById(req.params.id).lean();
    if (!audit) return res.status(404).json({ success: false, error: 'Tank audit not found' });
    return res.json({ success: true, data: audit });
  } catch (error) {
    console.error('TankAudit getAuditById error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load tank audit' });
  }
};

exports.createAudit = async (req, res) => {
  try {
    const { site_id_ihs, client_id } = req.body;
    if (!site_id_ihs) {
      return res.status(400).json({ success: false, error: 'Site ID (IHS) is required' });
    }

    // Same offline-sync idempotency guard as TechnicianSiteAudit — the
    // mobile app generates a stable client_id before its first submit
    // attempt and resends the same one on every retry from the offline
    // queue. If a record with this client_id already exists, an earlier
    // attempt already succeeded — return it instead of creating a
    // duplicate audit for the same site visit.
    if (client_id) {
      const existing = await TankAudit.findOne({ client_id });
      if (existing) {
        return res.status(200).json({ success: true, data: existing });
      }
    }

    const audit = new TankAudit({
      ...req.body,
      client_id,
      created_by: req.user.userId,
      updated_by: req.user.userId,
    });
    await audit.save();
    return res.status(201).json({ success: true, data: audit });
  } catch (error) {
    // A genuine race — two near-simultaneous requests with the same
    // client_id both passed the findOne check above before either
    // finished saving, and the database's own unique index caught the
    // second one. Not a real failure: the first request's record is
    // exactly what the caller wanted, so look it up and return it
    // rather than surface a confusing 500 for something that actually
    // succeeded (just not via this particular request).
    if (error.code === 11000 && error.keyPattern?.client_id) {
      const winner = await TankAudit.findOne({ client_id: req.body.client_id });
      if (winner) {
        return res.status(200).json({ success: true, data: winner });
      }
    }
    console.error('TankAudit createAudit error:', error);
    return res.status(500).json({ success: false, error: 'Failed to create tank audit' });
  }
};

exports.updateAudit = async (req, res) => {
  try {
    const audit = await TankAudit.findById(req.params.id);
    if (!audit) {
      return res.status(404).json({ success: false, error: 'Tank audit not found' });
    }

    const requesterId = (req.user.userId || req.user.id || '').toString();
    const ownerId = (audit.created_by || '').toString();
    const isOwner = ownerId === requesterId;
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, error: 'Not authorized to update this tank audit' });
    }

    Object.assign(audit, req.body, { updated_by: requesterId });
    await audit.save();
    return res.json({ success: true, data: audit });
  } catch (error) {
    console.error('TankAudit updateAudit error:', error);
    return res.status(500).json({ success: false, error: 'Failed to update tank audit' });
  }
};

exports.updateAuditStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const audit = await TankAudit.findById(req.params.id);
    if (!audit) {
      return res.status(404).json({ success: false, error: 'Tank audit not found' });
    }
    const requesterId = (req.user.userId || req.user.id || '').toString();
    const ownerId = (audit.created_by || '').toString();
    const isOwner = ownerId === requesterId;
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, error: 'Not authorized to update this tank audit' });
    }
    audit.status = status;
    audit.updated_by = requesterId;
    await audit.save();
    return res.json({ success: true, data: audit });
  } catch (error) {
    console.error('TankAudit updateAuditStatus error:', error);
    return res.status(500).json({ success: false, error: 'Failed to update tank audit status' });
  }
};

/**
 * GET /api/technician/tank-audits/summary
 *
 * Dashboard-facing rollup. Severity counts are scoped to SUBMITTED
 * audits only — a draft's findings aren't final, so counting them
 * toward "critical findings" would overstate real, confirmed problems.
 * draft_count is returned as its own distinct figure instead, so a
 * dashboard admin can see how much work is in progress without it
 * being conflated with confirmed findings.
 */
exports.getSummary = async (req, res) => {
  try {
    const submittedFilter = { status: 'submitted', ...EXCLUDED_CLUSTER_QUERY };
    const [total, draftCount, bySeverity, logsStats, recentCritical] = await Promise.all([
      TankAudit.countDocuments(submittedFilter),
      TankAudit.countDocuments({ status: 'draft', ...EXCLUDED_CLUSTER_QUERY }),
      TankAudit.aggregate([
        { $match: submittedFilter },
        { $group: { _id: '$overall_severity', count: { $sum: 1 } } },
      ]),
      TankAudit.aggregate([
        { $match: submittedFilter },
        { $group: {
          _id: null,
          collected: { $sum: { $cond: [{ $eq: ['$logs_collected', true] }, 1, 0] } },
          notCollected: { $sum: { $cond: [{ $eq: ['$logs_collected', false] }, 1, 0] } },
          unspecified: { $sum: { $cond: [{ $eq: ['$logs_collected', null] }, 1, 0] } },
        } },
      ]),
      TankAudit.find({ ...submittedFilter, overall_severity: { $in: ['critical', 'major'] } })
        .sort({ audit_date: -1 })
        .limit(10)
        .select('site_id_ihs site_name overall_severity audit_date auditor_name variance_pct logs_collected')
        .lean(),
    ]);

    const severityCounts = { critical: 0, major: 0, minor: 0, none: 0 };
    for (const row of bySeverity) {
      if (row._id === 'critical') severityCounts.critical = row.count;
      else if (row._id === 'major') severityCounts.major = row.count;
      else if (row._id === 'minor') severityCounts.minor = row.count;
      else severityCounts.none += row.count; // null overall_severity — no flagged issues
    }

    return res.json({
      success: true,
      data: {
        total_audits: total,
        draft_count: draftCount,
        by_severity: severityCounts,
        logs_collected: logsStats[0] || { collected: 0, notCollected: 0, unspecified: 0 },
        recent_flagged_sites: recentCritical,
      },
    });
  } catch (error) {
    console.error('TankAudit getSummary error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load tank audit summary' });
  }
};

/**
 * GET /api/technician/tank-audit-sites
 *
 * All sites, for tank audit site selection specifically — unlike
 * /technician/sites (which correctly scopes to a technician's own
 * assigned sites for routine maintenance), a tank audit is a one-off
 * inspection task any technician may need to pick up for any site, so
 * this deliberately returns the full site list rather than reuse the
 * assignment-scoped endpoint.
 */
exports.getAllSitesForAudit = async (req, res) => {
  try {
    const Site = require('../models/Site');
    const sites = await Site.find({})
      .select('IHS_ID_SITE Site_Name Region GRATO_Cluster')
      .sort({ Site_Name: 1 })
      .lean();
    return res.json({ success: true, data: sites });
  } catch (error) {
    console.error('TankAudit getAllSitesForAudit error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load sites' });
  }
};
