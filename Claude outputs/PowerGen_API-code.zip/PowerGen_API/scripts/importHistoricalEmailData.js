/**
 * importHistoricalEmailData.js
 * diesel-system/scripts/importHistoricalEmailData.js
 *
 * Imports real, validated historical diesel data recovered from email
 * archives (December 2025 onward) — the manual spreadsheet-based
 * validation/sign-off process this organization was running before this
 * system existed. See models/HistoricalMonthlyRecord.js for the full
 * reasoning on why this is a separate collection, not written into
 * CycleReconciliation directly.
 *
 * WHY NAME-BASED COLUMN LOOKUP, NOT FIXED POSITIONS:
 * Verified directly against all five recovered months' "Validation"
 * sheets before writing this — the same set of named columns exists in
 * every month, but at genuinely different positions (December's sheet
 * is 40 columns wide with "Final RH" at position 19; February's is 44
 * columns wide with the same "Final RH" at position 23). A parser
 * assuming fixed positions would have silently produced wrong numbers
 * for most months. This one builds a header-name-to-index map fresh for
 * each file instead.
 *
 * Handles two further real inconsistencies found during verification:
 *   - The sheet is named "Validation" in most months but "Validations"
 *     (plural) in January — tries both.
 *   - "State" is actually the site's region (confirmed against real
 *     values like "Littoral"), not a status field — named accordingly
 *     in the output regardless of the source column's own label.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed — same convention
 * as every other script in this folder.
 *
 * Usage:
 *   node scripts/importHistoricalEmailData.js
 *   node scripts/importHistoricalEmailData.js --confirm
 *   node scripts/importHistoricalEmailData.js --month=2026-01 --confirm   (single month only)
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const monthArg = process.argv.find(a => a.startsWith('--month='));
const ONLY_MONTH = monthArg ? monthArg.split('=')[1] : null;

const DATA_DIR = path.join(__dirname, 'historical_email_data');

// Each recovered month: its validation file, which sheet name it uses
// (verified individually — not assumed to be the same across months),
// its source version/sign-off status, and its budget file if one was
// recovered for that month specifically.
const MONTHS = [
  // 2025 months — found Phase 88, an entire previously-untouched year
  // predating this recovery effort's earlier earliest month (December
  // 2025). All eight have real sign-off PDFs, opened and read directly
  // (not inferred from filename) before marking signed_off. All use
  // standard row 1 header / row 2 data alignment, verified individually
  // rather than assumed to match the 2026 months' pattern.
  { month_key: '2025-04', file: 'Apr2025_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_Apr2025.pdf' },
  { month_key: '2025-05', file: 'May2025_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_May2025.pdf' },
  { month_key: '2025-06', file: 'Jun2025_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_Jun2025.pdf' },
  { month_key: '2025-07', file: 'Jul2025_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_Jul2025.pdf' },
  { month_key: '2025-08', file: 'Aug2025_Validation.xlsx', sheet: 'Validation', version: 'V3.0', signOff: 'signed_off', signOffPdf: 'SignOff_Aug2025.pdf' },
  { month_key: '2025-09', file: 'Sep2025_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_Sep2025.pdf' },
  { month_key: '2025-10', file: 'Oct2025_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_Oct2025.pdf' },
  { month_key: '2025-11', file: 'Nov2025_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_Nov2025.pdf' },
  // Sign-off status verified against real sign-off PDFs actually opened
  // and read (not inferred from filename alone) for Dec/Jan/Feb/Apr —
  // see /scripts/historical_email_data/README.md for which email each
  // PDF came from.
  { month_key: '2025-12', file: 'Dec2025_Validation.xlsx', sheet: 'Validation',  version: 'Vf',   signOff: 'signed_off', signOffPdf: 'GRATO Dec-25 Validation sign off.pdf' },
  { month_key: '2026-01', file: 'Jan2026_Validation.xlsx', sheet: 'Validations', version: 'Vf',   signOff: 'signed_off', signOffPdf: 'GRATO Jan-26 Validation sign off.pdf' },
  { month_key: '2026-02', file: 'Feb2026_Validation.xlsx', sheet: 'Validation',  version: 'V3.0', signOff: 'signed_off', signOffPdf: 'GRATO Feb-26 Validation Sign Off.pdf' },
  { month_key: '2026-04', file: 'Apr2026_Validation.xlsx', sheet: 'Validation',  version: 'V3.0', signOff: 'signed_off', signOffPdf: 'GRATO Apr-26 Validation Sign Off.pdf' },
  // June — found via a sixth email batch (Phase 82), closing what had
  // been the largest remaining monthly-reconciliation gap. Real
  // sign-off PDF opened and read directly (not inferred from
  // filename): dated 25 June 2026, genuine attestation for this month.
  { month_key: '2026-06', file: 'Jun2026_Validation.xlsx', sheet: 'Validation',  version: 'V3.0', signOff: 'signed_off', signOffPdf: 'SignOff_Jun2026.pdf' },
  // March — found via a seventh email batch (Phase 83), the last
  // remaining month with no monthly-reconciliation source at all.
  // Real sign-off PDF opened and read directly: dated 25 March 2026,
  // genuine attestation, same format as every other confirmed month.
  // Replaces the earlier budget-only placeholder (Phase 76) — March
  // now has real consumption/reserve data, not just a budget figure.
  { month_key: '2026-03', file: 'Mar2026_Validation.xlsx', sheet: 'Validation', version: 'Vf', signOff: 'signed_off', signOffPdf: 'SignOff_Mar2026.pdf' },
  // Corrected: previously marked 'signed_off' based only on the "Vf"
  // filename. Direct evidence contradicts that — a screenshot attached
  // to the real email thread ("Grato pending SBC comment.png"), dated
  // 20 July 2026 (nearly two months after May ended), shows multiple
  // sites with blank/unresolved SBC comments on topology and counter
  // disputes. The fleet-wide numbers may be final; specific sites are
  // not. "Vf" in a filename is not reliable evidence of sign-off on its
  // own — this correction is why. sign_off_verified is deliberately
  // false here: this screenshot is evidence of a dispute, not a
  // completed attestation, so it doesn't count as verified sign-off.
  { month_key: '2026-05', file: 'May2026_Validation.xlsx', sheet: 'Validation',  version: 'Vf',   signOff: 'pending_site_disputes', signOffPdf: null, signOffEvidence: 'Grato pending SBC comment.png (shows open disputes, not attestation)' },
  // July — corrected Phase 87: a real sign-off PDF was found (dated
  // 25 July 2026, verified by reading it directly, same attestation
  // format as every other confirmed month), attached to a V2.0
  // revision of the Validation file that also has real Debit and
  // Analysis sheets — neither existed in the V1.0 file this system had
  // been using. Cross-checked the two files' Validation sheets before
  // switching: all 164 sites' Final Cons figures match exactly between
  // versions — this is the same underlying data, just completed with
  // sheets that hadn't been sent yet when V1.0 went out.
  { month_key: '2026-07', file: 'Jul2026_Validation.xlsx', sheet: 'Validation',  version: 'V2.0', signOff: 'signed_off', signOffPdf: 'SignOff_Jul2026.pdf' },
  // August — received Phase 171 as "GRATO Validation TEMPLATE August
  // 2026 V3.0.xlsx", mislabeled by the sender as June; corrected via
  // AskUserQuestion after direct evidence (column names, "Month: Aug-26"
  // on the sign-off PDF, stock-as-of-31-August wording). Initially held
  // back — the sheet's header sits one row lower than every other month
  // (headerRowIndex: 2) and is missing Final DG CPH / CMS Vs Field / all
  // four fuel-quantity columns entirely (see OPTIONAL_FIELDS above).
  // Phase 172 — messagesources_86 (the original Sept 15 2026 email
  // thread this file came from, Charles Gnouve/IHS to Dominique
  // Assako+Minka Kevin/GRATO, "RE: GRATO validation file August 2026")
  // resolved why: IHS management (Dominique Assako) explicitly directed
  // switching from CPH-based to load-based consumption for Aug/Sep/Oct
  // — "There is nothing like gen CPH... consumption now depends on
  // load, topology, grid availability, and generator capacity" — so the
  // structural gap is a deliberate methodology change, not a broken
  // file. Cross-validated the new 'Approved August-26 Cons' column
  // (used here for final_consumption_l) against two independent
  // sources: it sums to exactly 99,800L across all 164 rows, matching
  // BOTH the same file's own Debit sheet total AND the sign-off PDF's
  // printed "Approved Consumption (L)" figure. 'SBC Submited Cons'
  // (sbc_consumption_l) cross-checks the same way at 110,280L. All 164
  // rows already carry SBC === 'GRATO' directly — no Analysis DB /
  // multi-SBC filter needed after all.
  // Sign-off: still genuinely unsigned as of the Sept 15 2026 email
  // ("kindly sign the attached document and return it to us") — visually
  // confirmed via the rendered PDF page, not just blank-looking text
  // extraction, that no signature is present. signOffPdf is deliberately
  // null and sign_off_status is 'draft' (closest fit in the fixed model
  // enum) rather than 'signed_off', mirroring how May 2026's disputed
  // sign-off was handled — data imported, attestation status left
  // honestly unverified rather than assumed.
  {
    month_key: '2026-08',
    file: 'Aug2026_Validation.xlsx',
    sheet: 'Validation',
    version: 'V3.0',
    headerRowIndex: 2,
    signOff: 'draft',
    signOffPdf: null,
    signOffEvidence: 'Aug2026_ValidationSignOff_UNSIGNED.pdf — rendered and visually inspected directly: all attestation lines blank, no signature. Per the messagesources_86 email thread (Charles Gnouve/IHS to Dominique Assako+Minka Kevin/GRATO, 15 Sept 2026), GRATO had not yet countersigned as of the most recent message: "kindly sign the attached document and return it to us."',
  },
];

// Multi-month budget rollup ("Grato Analysis.xlsx" — from the "Diesel
// Analysis from January to July" email thread) — the primary budget
// source for every month, Jan through July, replacing the earlier
// per-month dedicated files. Verified before switching to this: cross-
// checked its January column against the original standalone January
// budget file across all 164 common sites — 36% differed, and in every
// single mismatch this file's figure was higher, never lower. That's
// consistent with mid-cycle budget revisions (the "CARD LIMIT UPDATE"
// pattern seen repeatedly in the source emails) being reflected in this
// later rollup but not the original, as-issued file — making this the
// more complete, final figure to use, not just a redundant duplicate.
const MULTI_MONTH_BUDGET_FILE = 'MultiMonth_Budget_JanJul.xlsx';
const BUDGET_MONTH_LABELS = {
  '2025-12': null, // not covered by the multi-month file — genuinely missing
  '2026-01': 'Jan-26', '2026-02': 'Feb-26', '2026-03': 'March-26',
  '2026-04': 'April-26', '2026-05': 'May-26',
  // June deliberately excluded from THIS file — checked directly before
  // using it. The multi-month rollup's "Total June-26 Budget given to
  // the SBCs (L)" column sums to 147,014L, which matches neither the
  // verified approved budget already stored in BudgetRequestApproval
  // (61,410L, Phase 81's correction) nor June's own Debit sheet's
  // "Approved Consumption (L)" figure (113,121L, a genuinely different
  // concept — post-cycle reconciled consumption, not the pre-cycle
  // budget allocation). Using this third, unexplained number for
  // budget_liters risked repeating the exact mislabeling mistake
  // already caught and fixed once.
  //
  // Phase 150 — this doesn't mean June's budget is unrecoverable, only
  // that the multi-month rollup specifically isn't a safe source for
  // it. `RequestApproval_Jun2026.xlsx`'s own "Matrix Budget June-26"
  // sheet carries the real, per-site "Final June-26 Budget given to the
  // SBCs (L)" figure — the exact same one `importBudgetRequestApproval.js`
  // already trusts for `BudgetRequestApproval.ihs_approved_l` (that
  // 61,410L cited above IS this figure, summed). Verified directly
  // against the real file before wiring it in: 164 of 164 sites in
  // June's own Validation sheet have a matching row here, summing to
  // 61,410.04L — not a new number, the same one already treated as
  // authoritative elsewhere in this system. See `parseJuneBudget()`
  // below rather than the generic multi-month path this map otherwise
  // drives.
  '2026-06': null,
  '2026-07': 'July-26',
};

// June's real budget source (Phase 150) — see the long comment on
// BUDGET_MONTH_LABELS['2026-06'] above for why this exists as its own
// function instead of a `budgetLabel` entry: it's a structurally
// different file (its own per-site sheet, not a column in the
// multi-month rollup), reusing the exact column
// `importBudgetRequestApproval.js`'s `parseJuneRequestApproval()`
// already reads for `ihs_approved_l`.
const JUNE_BUDGET_FILE = 'RequestApproval_Jun2026.xlsx';
function parseJuneBudget() {
  const wb = XLSX.readFile(path.join(DATA_DIR, JUNE_BUDGET_FILE));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Matrix Budget June-26'], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idIdx = header.indexOf('NEW IHS ID');
  const budgetIdx = header.indexOf('Final June-26 Budget given to the SBCs (L)');
  if (idIdx === -1 || budgetIdx === -1) {
    throw new Error(`${JUNE_BUDGET_FILE} "Matrix Budget June-26" is missing an expected column. Header: ${JSON.stringify(header)}`);
  }
  const budgetBySite = new Map();
  for (const row of rows.slice(2)) {
    if (!row || !row[idIdx]) continue;
    budgetBySite.set(String(row[idIdx]).trim(), { budget_liters: toNum(row[budgetIdx]), budget_xaf: null });
  }
  return budgetBySite;
}

// Canonical field -> candidate header text(s) to search for, in order,
// in each file's own header row. Originally a single fixed name per
// field, worked for every month from December 2025 onward — but the
// earlier 2025 templates (found Phase 88) genuinely use different names
// for several of these same concepts, verified directly across all 8
// months before building this list as arrays rather than assuming one
// name fits every recovered month:
//   - site_id: June 2025 uses "IHS ID" (no periods), every other month
//     uses "I.H.S SITE ID".
//   - fuel_qty_previously_l / fuel_qty_added_l: May–August 2025 use
//     "QTY OF FUEL PREVIOUSLY Left" / "Fuel Qty Added (L)" — genuinely
//     different header text, not just whitespace.
//   - fuel_qty_previously_l / fuel_qty_found_l (April 2025 only): no
//     "QTY OF FUEL PREVIOUSLY"-style column at all — uses "PREVIOUS
//     DIESEL LEVEL Found" / "ACTUAL DIESEL LEVEL Found" instead.
// August 2026 (Phase 172) added a further wrinkle, verified directly
// against the real file (see MONTHS['2026-08'] below and the
// messagesources_86 email thread it's sourced from): IHS management
// directed a switch from CPH-based to load-based consumption
// calculation for August/September/October, which (a) renamed several
// columns ('NEW IHS ID', 'Approved August-26 Cons', 'SBC Submited
// Cons', 'SBC Vs Approved', 'Aug-26 Update Topology' — added as
// candidates below) and (b) genuinely dropped Final DG CPH, CMS Vs
// Field, and all four per-visit fuel-quantity columns from the sheet
// entirely — not a parsing gap, so those fields are declared OPTIONAL
// below rather than forced into COLUMN_MAP's required-or-fallback model.
const COLUMN_MAP = {
  site_id:                ['I.H.S SITE ID', 'IHS ID', 'NEW IHS ID'],
  site_name:              ['Site Name'],
  region:                 ['State'], // confirmed to actually hold region values like "Littoral", not a status
  cluster:                ['Cluster'],
  sbc:                    ['SBC'], // April/September 2025 have no standalone SBC column at all — handled with a verified hardcoded fallback below, not treated as missing
  topology:                ['DR Topology', 'Aug-26 Update Topology'],
  sbc_rh:                  ['SBC RH'],
  final_rh:                ['Final RH'],
  cms_rh:                  ['CMS RH'],
  rh_variance:             ['CMS Vs Field'],
  final_dg_cph:            ['Final DG CPH'],
  sbc_consumption_l:       ['SBC Cons', 'SBC Submited Cons'],
  final_consumption_l:     ['Final Cons', 'Approved August-26 Cons'],
  consumption_variance_l:  ['Cons Var', 'SBC Vs Approved'],
  fuel_qty_previously_l:   ['QTY OF FUEL PREVIOUSLY', 'QTY OF FUEL PREVIOUSLY Left', 'PREVIOUS DIESEL LEVEL Found'],
  fuel_qty_found_l:        ['QTY OF FUEL FOUND', 'ACTUAL DIESEL LEVEL Found'],
  fuel_qty_added_l:        ['QTY OF FUEL ADDED', 'Fuel Qty Added (L)'],
  fuel_qty_left_l:         ['QTY OF FUEL LEFT'],
};

// Fields where no column exists in some months, but the real value is
// a verified constant across the entire recovered dataset — every
// month's own SBC column (where one exists) has held "GRATO" for every
// row, since this whole reconciliation process belongs to Grato.
// Applied only when no candidate column matched, not as an override.
const FIELD_FALLBACKS = { sbc: 'GRATO' };

// Fields genuinely absent from some months' source files, where there is
// no fallback value to apply — resolve to null for that month rather
// than throwing a "missing expected column" error. First (and so far
// only) use: August 2026's real methodology change (see the COLUMN_MAP
// comment above and MONTHS['2026-08']) dropped these six columns from
// the sheet entirely, verified directly by searching the full workbook
// for every candidate name before concluding they're absent, not just
// renamed. Every other month still has all of these and is unaffected —
// this only suppresses the error when a candidate genuinely can't be
// found AND the field is listed here.
const OPTIONAL_FIELDS = new Set([
  'final_dg_cph', 'rh_variance',
  'fuel_qty_previously_l', 'fuel_qty_found_l', 'fuel_qty_added_l', 'fuel_qty_left_l',
]);

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function buildHeaderIndex(headerRow) {
  const index = {};
  headerRow.forEach((cell, i) => {
    if (typeof cell === 'string') index[cell.trim()] = i;
  });
  return index;
}

function resolveColumnIndex(headerIndex, candidates) {
  for (const name of candidates) {
    if (name in headerIndex) return headerIndex[name];
  }
  return null;
}

function parseValidationSheet(filePath, sheetName, headerRowIndex = 1) {
  const wb = XLSX.readFile(filePath);
  const actualSheetName = wb.SheetNames.includes(sheetName)
    ? sheetName
    : wb.SheetNames.find(n => n.toLowerCase().startsWith('validation'));
  if (!actualSheetName) {
    throw new Error(`No "${sheetName}" (or similar) sheet found. Sheets present: ${wb.SheetNames.join(', ')}`);
  }

  const ws = wb.Sheets[actualSheetName];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  // Verified directly against every recovered month: header is row index
  // 1, data starts at row index 2, consistently — for every month EXCEPT
  // August 2026, whose real header sits one row lower (row index 2, data
  // from row index 3), verified directly with the real XLSX package
  // against the real file rather than assumed. headerRowIndex defaults
  // to 1 and is only overridden by a month's own MONTHS entry.
  const headerRow = rows[headerRowIndex];
  const dataRows = rows.slice(headerRowIndex + 1).filter(r => r && r[0]);

  const headerIndex = buildHeaderIndex(headerRow);
  const resolvedIndex = {};
  const missingColumns = [];
  for (const [field, candidates] of Object.entries(COLUMN_MAP)) {
    const idx = resolveColumnIndex(headerIndex, candidates);
    if (idx !== null) { resolvedIndex[field] = idx; continue; }
    if (field in FIELD_FALLBACKS) continue; // handled via fallback at read time, not a missing-column error
    if (OPTIONAL_FIELDS.has(field)) continue; // genuinely absent this month (verified) — resolves to null, not an error
    missingColumns.push(candidates[0]);
  }
  if (missingColumns.length) {
    throw new Error(`Sheet "${actualSheetName}" is missing expected column(s): ${missingColumns.join(', ')}`);
  }

  const records = dataRows.map(row => {
    const get = (field) => (field in resolvedIndex) ? row[resolvedIndex[field]] : FIELD_FALLBACKS[field];
    const record = { site_id: String(get('site_id')).trim() };
    for (const field of Object.keys(COLUMN_MAP)) {
      if (field === 'site_id') continue;
      const raw = get(field);
      record[field] = ['site_name', 'region', 'cluster', 'sbc', 'topology'].includes(field)
        ? (raw != null ? String(raw).trim() : null)
        : toNum(raw);
    }
    return record;
  });

  return { records, actualSheetName, totalRows: dataRows.length };
}

function parseMultiMonthBudgetFile(filePath, monthLabel) {
  const wb = XLSX.readFile(filePath);
  const ws = wb.Sheets['Grato Diesel Budgets'];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  // Header is row index 3, data starts row index 4 — verified directly
  // with the real xlsx package against the real file (an earlier check
  // with a different library suggested row 4/5; this is the corrected,
  // verified value, same class of discrepancy caught in Phase 38).
  const headerRow = rows[3];
  const idIdx = 0; // 'NEW IHS ID' — confirmed first column
  const budgetIdx = headerRow.findIndex(h =>
    typeof h === 'string' && h.includes(monthLabel) && h.toLowerCase().includes('budget')
  );
  if (budgetIdx === -1) {
    throw new Error(`No budget column found for "${monthLabel}" in the multi-month file. Header: ${JSON.stringify(headerRow)}`);
  }

  const dataRows = rows.slice(4).filter(r => r && r[idIdx]);
  const budgetBySite = new Map();
  for (const row of dataRows) {
    budgetBySite.set(String(row[idIdx]).trim(), { budget_liters: toNum(row[budgetIdx]), budget_xaf: null });
  }
  return budgetBySite;
}

async function main() {
  const monthsToProcess = ONLY_MONTH ? MONTHS.filter(m => m.month_key === ONLY_MONTH) : MONTHS;
  if (monthsToProcess.length === 0) {
    throw new Error(`No matching month found for --month=${ONLY_MONTH}. Available: ${MONTHS.map(m => m.month_key).join(', ')}`);
  }

  const allRecords = [];
  for (const m of monthsToProcess) {
    const filePath = path.join(DATA_DIR, m.file);
    console.log(`\n── ${m.month_key} (${m.file}) ──────────────────────────────`);

    const { records, actualSheetName, totalRows } = parseValidationSheet(filePath, m.sheet, m.headerRowIndex || 1);
    console.log(`  Sheet "${actualSheetName}": ${totalRows} site row(s) parsed.`);

    let budgetBySite = new Map();
    const budgetLabel = BUDGET_MONTH_LABELS[m.month_key];
    let budgetSourceFile = null;
    if (budgetLabel) {
      budgetBySite = parseMultiMonthBudgetFile(path.join(DATA_DIR, MULTI_MONTH_BUDGET_FILE), budgetLabel);
      budgetSourceFile = MULTI_MONTH_BUDGET_FILE;
      console.log(`  Budget (from multi-month rollup, "${budgetLabel}" column): ${budgetBySite.size} site(s) with a budget figure.`);
    } else if (m.month_key === '2026-06') {
      // Phase 150 — June's own per-site source, not the multi-month
      // rollup (see the BUDGET_MONTH_LABELS['2026-06'] comment above).
      budgetBySite = parseJuneBudget();
      budgetSourceFile = JUNE_BUDGET_FILE;
      console.log(`  Budget (from ${JUNE_BUDGET_FILE}, "Final June-26 Budget given to the SBCs (L)" column): ${budgetBySite.size} site(s) with a budget figure.`);
    } else {
      console.log(`  No budget source available for this month — reserve/exhausted figures will be null for these sites.`);
    }

    for (const rec of records) {
      const budget = budgetBySite.get(rec.site_id);
      const budget_liters = budget?.budget_liters ?? null;
      const budget_xaf = budget?.budget_xaf ?? null;
      const reserve_liters = (budget_liters != null && rec.final_consumption_l != null)
        ? Math.round((budget_liters - rec.final_consumption_l) * 10) / 10
        : null;

      allRecords.push({
        ...rec,
        month_key: m.month_key,
        budget_liters,
        budget_xaf,
        budget_source_file: budgetSourceFile,
        reserve_liters,
        fully_exhausted: reserve_liters != null ? reserve_liters <= 0 : null,
        source_file: m.file,
        source_version: m.version,
        source_sheet: actualSheetName,
        sign_off_status: m.signOff,
        sign_off_verified: !!m.signOffPdf, // true only when an actual attestation PDF was found — the May "evidence" is a dispute screenshot, not an attestation, so it's deliberately excluded
        sign_off_pdf_source: m.signOffPdf || m.signOffEvidence || null,
      });
    }
  }

  console.log(`\n── Total: ${allRecords.length} site-month record(s) across ${monthsToProcess.length} month(s). ──`);

  const withBudget = allRecords.filter(r => r.budget_liters != null).length;
  const exhausted = allRecords.filter(r => r.fully_exhausted === true).length;
  console.log(`  ${withBudget} record(s) have a budget figure to compare against.`);
  console.log(`  ${exhausted} of those show the full budget exhausted (reserve <= 0).`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = allRecords.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id, month_key: r.month_key },
      update: { $set: r },
      upsert: true,
    },
  }));
  const result = await HistoricalMonthlyRecord.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
