/**
 * computeGainLossOnCycleClose.js
 * diesel-system/scripts/computeGainLossOnCycleClose.js
 *
 * Gain/Loss cannot be computed at the moment a technician submits an
 * audit — the cycle it belongs to is usually still open, and there's
 * no real "final run hours" yet, only a mid-cycle interim figure that
 * would misrepresent the true picture. It only becomes computable
 * once the cycle itself closes.
 *
 * The TankAudit pre-save hook resolves this correctly at the moment an
 * audit is first saved — but an audit's cycle_key, once set, tells the
 * hook "already resolved," so it won't re-run just because time passed
 * and the cycle closed AFTER the audit was submitted. This script is
 * the missing piece: run it once a cycle actually closes (i.e., once
 * that cycle's own CycleEndStockSnapshot records exist), and it
 * updates every submitted audit belonging to that cycle with the real
 * final_run_hours and a genuine gain_loss_l.
 *
 * Usage:
 *   node scripts/computeGainLossOnCycleClose.js <cycle_key>            (dry run)
 *   node scripts/computeGainLossOnCycleClose.js <cycle_key> --confirm  (writes)
 *
 * Example:
 *   node scripts/computeGainLossOnCycleClose.js 2026-08 --confirm
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const CONFIRM = process.argv.includes('--confirm');
const cycleKey = process.argv[2];

async function main() {
  if (!cycleKey || cycleKey === '--confirm') {
    console.error('Usage: node scripts/computeGainLossOnCycleClose.js <cycle_key> [--confirm]');
    console.error('Example: node scripts/computeGainLossOnCycleClose.js 2026-08 --confirm');
    process.exit(1);
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const TankAudit = require('../models/TankAudit');
  const CycleEndStockSnapshot = require('../models/CycleEndStockSnapshot');

  const closingSnapshotCount = await CycleEndStockSnapshot.countDocuments({ cycle_key: cycleKey });
  console.log(`CycleEndStockSnapshot records found for ${cycleKey}: ${closingSnapshotCount}`);
  if (closingSnapshotCount === 0) {
    console.log(`\n⚠ No closing snapshots exist yet for ${cycleKey} — this cycle doesn't appear to have closed.`);
    console.log('Nothing to compute. Re-run this once the cycle actually closes and its snapshots exist.');
    await mongoose.disconnect();
    return;
  }

  const audits = await TankAudit.find({ cycle_key: cycleKey, status: 'submitted' });
  console.log(`Submitted audits found for ${cycleKey}: ${audits.length}`);

  if (!audits.length) {
    console.log('Nothing to do.');
    await mongoose.disconnect();
    return;
  }

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to compute Gain/Loss for these ${audits.length} audit(s).`);
    await mongoose.disconnect();
    return;
  }

  console.log('\n── Recomputing each audit (re-saves, triggering the same pre-save hook) ──');
  let closed = 0, stillOpen = 0, gainLossComputed = 0, errored = 0;

  for (const audit of audits) {
    try {
      // Force the hook to treat this as unresolved so it re-checks
      // for the (now-existing) closing snapshot — same mechanism the
      // Phase 116 backfill script uses.
      audit.cycle_key = undefined;
      await audit.save();
      if (audit.cycle_closed) closed++; else stillOpen++;
      if (audit.gain_loss_l != null) gainLossComputed++;
    } catch (err) {
      errored++;
      console.error(`  ✗ ${audit._id} (${audit.site_id_ihs}): ${err.message}`);
    }
  }

  console.log(`\n── Done. ──`);
  console.log(`  Marked cycle_closed: ${closed}`);
  console.log(`  Still show cycle_closed=false (no per-site closing snapshot found even though the cycle overall closed — a real per-site gap, not a bug): ${stillOpen}`);
  console.log(`  Gain/Loss actually computed: ${gainLossComputed}`);
  console.log(`  Errored: ${errored}`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
