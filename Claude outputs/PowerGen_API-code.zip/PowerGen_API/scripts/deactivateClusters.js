/**
 * deactivateClusters.js
 * diesel-system/scripts/deactivateClusters.js
 *
 * Marks every site in the given cluster(s) as Grato_Managed: false — for
 * clusters that have been handed off or decommissioned from GRATO's
 * management (immediate case: Kribi 1, Kribi 2, Yassa). Sites marked
 * this way stop appearing on the Live Site Map, Site Directory (by
 * default), and Budget Planning, without deleting any underlying data —
 * their history stays intact for audit/reference.
 *
 * Reusable for any future cluster handoff, not a one-time hardcoded fix
 * — pass whichever cluster name(s) need deactivating.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed — same convention
 * as every other script in this folder.
 *
 * Usage:
 *   node scripts/deactivateClusters.js "Kribi 1" "Kribi 2" "Yassa"
 *   node scripts/deactivateClusters.js "Kribi 1" "Kribi 2" "Yassa" --confirm
 *
 *   node scripts/deactivateClusters.js --reactivate "Kribi 1"   # undo, if a cluster comes back under GRATO
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const Site = require('../models/Site');

const CONFIRM = process.argv.includes('--confirm');
const REACTIVATE = process.argv.includes('--reactivate');
const clusters = process.argv.slice(2).filter(a => !a.startsWith('--'));

async function main() {
  if (clusters.length === 0) {
    throw new Error('Usage: node scripts/deactivateClusters.js "Cluster Name" ["Another Cluster"] [--confirm] [--reactivate]');
  }

  console.log(`${REACTIVATE ? 'Reactivating' : 'Deactivating'} cluster(s): ${clusters.join(', ')}\n`);

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const matching = await Site.find({ GRATO_Cluster: { $in: clusters } })
    .select('IHS_ID_SITE Site_Name GRATO_Cluster Grato_Managed')
    .lean();

  console.log(`Found ${matching.length} site(s) across the given cluster(s):`);
  const byCluster = {};
  for (const s of matching) {
    byCluster[s.GRATO_Cluster] = (byCluster[s.GRATO_Cluster] || 0) + 1;
  }
  for (const [cluster, count] of Object.entries(byCluster)) {
    console.log(`  ${cluster}: ${count} site(s)`);
  }
  for (const c of clusters) {
    if (!byCluster[c]) console.log(`  ⚠ "${c}" — no sites found with this exact cluster name. Check spelling/capitalization.`);
  }

  const alreadyCorrect = matching.filter(s => (s.Grato_Managed !== false) === REACTIVATE).length;
  const toChange = matching.length - alreadyCorrect;
  console.log(`\n${toChange} site(s) will change; ${alreadyCorrect} already ${REACTIVATE ? 'active' : 'inactive'}.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to ${REACTIVATE ? 'reactivate' : 'deactivate'} ${toChange} site(s).`);
    await mongoose.disconnect();
    return;
  }

  const result = await Site.updateMany(
    { GRATO_Cluster: { $in: clusters } },
    { $set: { Grato_Managed: REACTIVATE } }
  );
  console.log(`\n✓ Done. Matched: ${result.matchedCount}, modified: ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
