/**
 * importMonthlyDebitSummary.js
 * diesel-system/scripts/importMonthlyDebitSummary.js
 *
 * Imports the fleet-level monthly debit/credit settlement — the
 * "submitted vs approved consumption, purchases, debits" the user
 * specifically asked to have investigated, found in each recovered
 * validation file's own "Debit" sheet (never opened before this pass —
 * every earlier import only read the "Validation" sheet from these
 * same files).
 *
 * WHY NAME-BASED LOOKUP, PER MONTH, NOT A FIXED COLUMN LIST:
 * Checked directly before writing this — the column set genuinely
 * differs by month. December through February have 10 core columns;
 * April adds two more ("BB Sites Stock", "Apr-26 Purchase to
 * consider"); May adds even more (splitting BB stock into "left at
 * April" vs "left at May" vs "used in May") and renames "Submitted" to
 * "Submited" (a real typo in the source file, not a transcription
 * error here). July has no Debit sheet at all — consistent with it
 * being the least mature recovered month (only Main + Validation exist
 * for July). Handles all of this by matching columns by fuzzy name
 * (e.g. "starts with 'Submi'" catches both spellings) rather than an
 * exact list, and simply leaving BB-specific fields null where a month
 * doesn't have them.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importMonthlyDebitSummary.js
 *   node scripts/importMonthlyDebitSummary.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const MonthlyDebitSummary = require('../models/MonthlyDebitSummary');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

// July has no Debit sheet at all — not attempted, not silently skipped
// without explanation.
const MONTHS = [
  // 2025 months (Phase 90) — all standard row 1 alignment except April,
  // which genuinely has its header at row 2 (a summary row is inserted
  // at row 1 instead of row 0 like every other month) — verified
  // directly against the raw file, not assumed to match the others.
  { cycle_key: '2025-04', file: 'Apr2025_Validation.xlsx', headerRow: 2 },
  { cycle_key: '2025-05', file: 'May2025_Validation.xlsx' },
  { cycle_key: '2025-06', file: 'Jun2025_Validation.xlsx' },
  { cycle_key: '2025-07', file: 'Jul2025_Validation.xlsx' },
  { cycle_key: '2025-08', file: 'Aug2025_Validation.xlsx' },
  { cycle_key: '2025-09', file: 'Sep2025_Validation.xlsx' },
  { cycle_key: '2025-10', file: 'Oct2025_Validation.xlsx' },
  { cycle_key: '2025-11', file: 'Nov2025_Validation.xlsx' },
  { cycle_key: '2025-12', file: 'Dec2025_Validation.xlsx' },
  { cycle_key: '2026-01', file: 'Jan2026_Validation.xlsx' },
  { cycle_key: '2026-02', file: 'Feb2026_Validation.xlsx' },
  { cycle_key: '2026-04', file: 'Apr2026_Validation.xlsx' },
  { cycle_key: '2026-05', file: 'May2026_Validation.xlsx' },
  // June's Debit sheet genuinely differs from every other month —
  // verified directly with the real xlsx package: header is at row 3,
  // not row 1 (extra BB-sites-related columns push the summary row
  // down further than usual).
  { cycle_key: '2026-06', file: 'Jun2026_Validation.xlsx', headerRow: 3 },
  { cycle_key: '2026-03', file: 'Mar2026_Validation.xlsx' }, // found in Phase 83 — standard row 1 alignment, verified directly
  // July — found Phase 87 (a more complete V2.0 revision replaced the
  // earlier Debit-less V1.0 file). Same row-3 header quirk as June,
  // verified directly rather than assumed to match June's pattern.
  { cycle_key: '2026-07', file: 'Jul2026_Validation.xlsx', headerRow: 3 },
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function findCol(header, matcher) {
  const i = header.findIndex(h => typeof h === 'string' && matcher(h.trim()));
  return i === -1 ? null : i;
}

function parseDebitSheet(wb, cycle_key, headerRowIdx) {
  if (!wb.SheetNames.includes('Debit')) {
    console.log(`  No "Debit" sheet found for ${cycle_key} — skipped, not fabricated.`);
    return null;
  }
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Debit'], { header: 1, defval: null, raw: true });
  const header = rows[headerRowIdx];
  const dataRow = rows[headerRowIdx + 1];
  if (!header || !dataRow) {
    console.log(`  "Debit" sheet for ${cycle_key} is empty — skipped.`);
    return null;
  }

  const idx = {
    sbc: findCol(header, h => h === 'SBC'),
    submitted: findCol(header, h => h.startsWith('Submi')), // catches both "Submitted" and the May typo "Submited"
    approved: findCol(header, h => h.startsWith('Approved Consumption')),
    purchases: findCol(header, h => h.toLowerCase().includes('purchase') && !h.toLowerCase().includes('consider') && !h.includes('BB')),
    stock_left: findCol(header, h => h.includes('SBC Stock Left')), // genuinely absent in June's file — null there, not a bug
    mgmt_fees: findCol(header, h => h.toLowerCase().startsWith('management fee')), // June's file capitalizes "Fees" differently ("Management Fees" vs "Management fees") — matched case-insensitively
    unit_price: findCol(header, h => h.startsWith('Unit Price')),
    debit_l: findCol(header, h => h.includes('Debit Vs Credit') && h.includes('(L)')),
    debit_xaf_var: findCol(header, h => h.includes('Debit Vs Credit') && h.includes('(XAF)')),
    debit_amount: findCol(header, h => h.startsWith('Debit/Credit Amount')),
    // June has BOTH a prior-month opening figure ("...left at May-26")
    // and this month's own closing figure ("...left at June-26") —
    // matched specifically to "left at {this cycle's own month}" where
    // that distinction exists, so this doesn't silently grab the wrong
    // month's stock figure.
    bb_stock: findCol(header, h => h === 'BB Sites Stock' || (h.includes('BB Sites Stock left') && (cycle_key === '2026-06' ? h.includes('June-26') : true))),
    bb_purchase: findCol(header, h => h.includes('Purchase to consider')),
  };

  return {
    cycle_key,
    sbc: idx.sbc !== null ? dataRow[idx.sbc] : null,
    submitted_consumption_l: idx.submitted !== null ? toNum(dataRow[idx.submitted]) : null,
    approved_consumption_l: idx.approved !== null ? toNum(dataRow[idx.approved]) : null,
    purchases_l: idx.purchases !== null ? toNum(dataRow[idx.purchases]) : null,
    stock_left_l: idx.stock_left !== null ? toNum(dataRow[idx.stock_left]) : null,
    management_fees_xaf: idx.mgmt_fees !== null ? toNum(dataRow[idx.mgmt_fees]) : null,
    unit_price_xaf: idx.unit_price !== null ? toNum(dataRow[idx.unit_price]) : null,
    debit_credit_l: idx.debit_l !== null ? toNum(dataRow[idx.debit_l]) : null,
    debit_credit_xaf: idx.debit_xaf_var !== null ? toNum(dataRow[idx.debit_xaf_var]) : null,
    debit_credit_amount_xaf: idx.debit_amount !== null ? toNum(dataRow[idx.debit_amount]) : null,
    bb_sites_stock_l: idx.bb_stock !== null ? toNum(dataRow[idx.bb_stock]) : null,
    bb_purchase_to_consider_l: idx.bb_purchase !== null ? toNum(dataRow[idx.bb_purchase]) : null,
  };
}

async function main() {
  const records = [];
  for (const m of MONTHS) {
    console.log(`── ${m.cycle_key} (${m.file}) ──`);
    const wb = XLSX.readFile(path.join(DATA_DIR, m.file));
    const record = parseDebitSheet(wb, m.cycle_key, m.headerRow ?? 1);
    if (record) {
      records.push({ ...record, source_file: m.file });
      console.log(`  Submitted: ${record.submitted_consumption_l?.toLocaleString()} L | Approved: ${record.approved_consumption_l?.toLocaleString()} L | Debit/Credit: ${record.debit_credit_amount_xaf?.toLocaleString()} XAF`);
    }
  }

  console.log(`\n── Total: ${records.length} month(s) with a real Debit sheet found. ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${records.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = records.map(r => ({
    updateOne: { filter: { cycle_key: r.cycle_key }, update: { $set: r }, upsert: true },
  }));
  const result = await MonthlyDebitSummary.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
