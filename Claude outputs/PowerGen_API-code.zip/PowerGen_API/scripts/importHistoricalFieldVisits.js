/**
 * importHistoricalFieldVisits.js
 * diesel-system/scripts/importHistoricalFieldVisits.js
 *
 * Imports individual field-visit records from each recovered validation
 * file's own "Main" sheet — one row per visit, not per month. See
 * models/HistoricalFieldVisit.js for the full reasoning, including why
 * several template columns (Theft, Gap CPH Variation, Qty Consumed,
 * both comment fields) are deliberately NOT included: checked all six
 * recovered months directly, found zero populated values in any of
 * them, anywhere. Real absence, not an oversight.
 *
 * WHY THE SAME NAME-BASED APPROACH AS EVERY OTHER PARSER HERE:
 * Checked directly before writing this — this sheet's 45-column header
 * is genuinely identical across all six recovered months (the most
 * consistent sheet found in this whole recovery effort), so a fixed
 * column-index list would technically work here. Used name-based lookup
 * anyway, for the same reason as every other script in this folder:
 * consistency observed across six files doesn't guarantee a seventh
 * recovered month won't differ, and the cost of name-based lookup is
 * negligible.
 *
 * WHY EXCEL SERIAL DATES ARE CONVERTED MANUALLY:
 * Verified directly against this real file with the xlsx package before
 * writing this — visit dates come through as raw numeric serials
 * (e.g. 45982.688...), not JS Date objects, same as every other date
 * column encountered in this recovery effort. Reuses the same
 * conversion already proven in importAdHocFuelRequests.js (Phase 60).
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importHistoricalFieldVisits.js
 *   node scripts/importHistoricalFieldVisits.js --confirm
 *   node scripts/importHistoricalFieldVisits.js --month=2025-12 --confirm   (single month only)
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalFieldVisit = require('../models/HistoricalFieldVisit');

const CONFIRM = process.argv.includes('--confirm');
const monthArg = process.argv.find(a => a.startsWith('--month='));
const ONLY_MONTH = monthArg ? monthArg.split('=')[1] : null;

const DATA_DIR = path.join(__dirname, 'historical_email_data');

const MONTHS = [
  // 2025 months (Phase 89/90) — verified all 23 required columns are
  // present under their existing names in every one of these 8 months,
  // so no changes to the column-matching logic were needed here.
  { month_key: '2025-04', file: 'Apr2025_Validation.xlsx' },
  { month_key: '2025-05', file: 'May2025_Validation.xlsx' },
  { month_key: '2025-06', file: 'Jun2025_Validation.xlsx' },
  { month_key: '2025-07', file: 'Jul2025_Validation.xlsx' },
  { month_key: '2025-08', file: 'Aug2025_Validation.xlsx' },
  { month_key: '2025-09', file: 'Sep2025_Validation.xlsx' },
  { month_key: '2025-10', file: 'Oct2025_Validation.xlsx' },
  { month_key: '2025-11', file: 'Nov2025_Validation.xlsx' },
  { month_key: '2025-12', file: 'Dec2025_Validation.xlsx' },
  { month_key: '2026-01', file: 'Jan2026_Validation.xlsx' },
  { month_key: '2026-02', file: 'Feb2026_Validation.xlsx' },
  { month_key: '2026-04', file: 'Apr2026_Validation.xlsx' },
  { month_key: '2026-05', file: 'May2026_Validation.xlsx' },
  { month_key: '2026-06', file: 'Jun2026_Validation.xlsx' },
  { month_key: '2026-07', file: 'Jul2026_Validation.xlsx' },
  { month_key: '2026-03', file: 'Mar2026_Validation.xlsx' }, // found Phase 83 — standard row 1 alignment
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelSerialToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400 * 1000));
  if (typeof v === 'string') {
    const d = new Date(v);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}

function findCol(header, name) {
  const i = header.findIndex(h => typeof h === 'string' && h.trim() === name);
  return i === -1 ? null : i;
}

function parseMainSheet(filePath, month_key) {
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Main'], { header: 1, defval: null, raw: true });
  const header = rows[1]; // verified directly: header row index 1, data starts row index 2

  const idx = {
    site_id: findCol(header, 'I.H.S Site ID'),
    sbc: findCol(header, 'SBC'),
    site_name: findCol(header, 'Site Name'),
    cluster: findCol(header, 'Cluster'),
    topology: findCol(header, 'Visit Topology'),
    region: findCol(header, 'Region'),
    prev_visit: findCol(header, 'Date of Last Visit'),
    cur_visit: findCol(header, 'Date of Current Visit'),
    meter: findCol(header, 'Generetor Current Meter'),
    rh: findCol(header, 'RH'),
    capacity: findCol(header, 'Generator Capacity'),
    ccph: findCol(header, 'CCPH'),
    consumption: findCol(header, 'Fuel Consumption'),
    fuel_prev: findCol(header, 'QTY OF FUEL PREVIOUSLY Left'),
    fuel_found: findCol(header, 'QTY OF FUEL FOUND'),
    fuel_added: findCol(header, 'Fuel Qty Added (L)'),
    fuel_left: findCol(header, 'QTY OF FUEL LEFT'),
    nbr_days: findCol(header, 'Nbr Days'),
    gen_status: findCol(header, 'Generator Status'),
    gen_visual: findCol(header, 'Generator Visual Auto-Check'),
    gen_brand: findCol(header, 'Generator Brand'),
    tank_type: findCol(header, 'Tank Type'),
    edo: findCol(header, 'EDO Site?'),
  };

  const required = ['site_id', 'cur_visit', 'fuel_added'];
  const missing = required.filter(k => idx[k] === null);
  if (missing.length) {
    throw new Error(`"Main" sheet for ${month_key} is missing expected column(s): ${missing.join(', ')}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const visitDate = excelSerialToJs(row[idx.cur_visit]);
    if (!visitDate) continue; // no real visit date — skip rather than guess

    records.push({
      site_id: String(row[idx.site_id]).trim(),
      sbc: row[idx.sbc] ?? null,
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      topology: row[idx.topology] ?? null,
      region: row[idx.region] ?? null,
      month_key,
      visit_date: visitDate,
      previous_visit_date: excelSerialToJs(row[idx.prev_visit]),
      days_since_last_visit: toNum(row[idx.nbr_days]),
      generator_meter_reading: toNum(row[idx.meter]),
      generator_capacity_kva: toNum(row[idx.capacity]),
      generator_brand: row[idx.gen_brand] ?? null,
      generator_status: row[idx.gen_status] ?? null,
      generator_visual_check: row[idx.gen_visual] ?? null,
      tank_type: row[idx.tank_type] ?? null,
      run_hours: toNum(row[idx.rh]),
      ccph: toNum(row[idx.ccph]),
      fuel_consumption_l: toNum(row[idx.consumption]),
      fuel_previously_left_l: toNum(row[idx.fuel_prev]),
      fuel_found_l: toNum(row[idx.fuel_found]),
      fuel_added_l: toNum(row[idx.fuel_added]),
      fuel_left_l: toNum(row[idx.fuel_left]),
      edo_site: row[idx.edo] === 'Yes' ? true : row[idx.edo] === 'No' ? false : null,
    });
  }
  return records;
}

async function main() {
  const monthsToProcess = ONLY_MONTH ? MONTHS.filter(m => m.month_key === ONLY_MONTH) : MONTHS;
  if (monthsToProcess.length === 0) {
    throw new Error(`No matching month for --month=${ONLY_MONTH}. Available: ${MONTHS.map(m => m.month_key).join(', ')}`);
  }

  const allRecords = [];
  for (const m of monthsToProcess) {
    const filePath = path.join(DATA_DIR, m.file);
    const records = parseMainSheet(filePath, m.month_key).map(r => ({ ...r, source_file: m.file }));
    const withFuelAdded = records.filter(r => r.fuel_added_l != null && r.fuel_added_l > 0);
    const totalAdded = withFuelAdded.reduce((s, r) => s + r.fuel_added_l, 0);
    console.log(`── ${m.month_key} (${m.file}): ${records.length} visit(s), ${withFuelAdded.length} with real fuel added, ${Math.round(totalAdded).toLocaleString()} L total.`);
    allRecords.push(...records);
  }

  console.log(`\n── Total: ${allRecords.length} visit record(s) across ${monthsToProcess.length} month(s). ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  // No natural unique key at visit granularity (see the model's own
  // reasoning) — cleared per processed month and re-inserted, so
  // re-running this script for a month doesn't create duplicates.
  for (const m of monthsToProcess) {
    await HistoricalFieldVisit.deleteMany({ month_key: m.month_key, source_file: m.file });
  }
  const result = await HistoricalFieldVisit.insertMany(allRecords);
  console.log(`✓ Inserted ${result.length} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
