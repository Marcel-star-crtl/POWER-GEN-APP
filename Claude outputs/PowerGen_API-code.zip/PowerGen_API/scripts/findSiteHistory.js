/**
 * findSiteHistory.js
 * diesel-system/scripts/findSiteHistory.js
 *
 * Read-only. Searches every collection in this backend that could
 * reference a site for records matching the given IHS Site ID —
 * built by scanning all 62 models in this project directly and
 * verifying the exact field name and type each one actually uses
 * (most are a plain string IHS ID; two are an ObjectId reference to
 * Site, resolved via a lookup first; a couple use non-standard,
 * space-containing field names from a raw historical import), rather
 * than assuming a single consistent field name across the whole
 * codebase and silently missing whichever collections don't match it.
 *
 * Makes no changes to any data — every query is a find/countDocuments.
 *
 * Usage:
 *   node scripts/findSiteHistory.js <IHS_SITE_ID>
 *
 * Example:
 *   node scripts/findSiteHistory.js IHS_DLA_147
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');

const siteId = process.argv[2];

async function main() {
  if (!siteId) {
    console.error('Usage: node scripts/findSiteHistory.js <IHS_SITE_ID>');
    console.error('Example: node scripts/findSiteHistory.js IHS_DLA_147');
    process.exit(1);
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log(`✓ Connected to MongoDB\n`);
  console.log('══════════════════════════════════════════════════════════');
  console.log(` SITE HISTORY — ${siteId}`);
  console.log('══════════════════════════════════════════════════════════\n');

  let totalRecords = 0;
  const foundIn = [];
  const emptyIn = [];
  const erroredIn = [];

  // ── 1. The site record itself ────────────────────────────────────
  const Site = require('../models/Site');
  const site = await Site.findOne({ IHS_ID_SITE: siteId }).lean();
  if (site) {
    console.log('── SITE RECORD ──');
    console.log(`  Name: ${site.Site_Name || '(none)'}`);
    console.log(`  Cluster: ${site.GRATO_Cluster || '(none)'} | Region: ${site.Region || '(none)'}`);
    console.log(`  Current fuel level: ${site.Fuel_Quantity_Found ?? '(none)'} L (source: ${site.Fuel_Level_Source || 'unknown'}, updated ${site.Fuel_Level_Updated_At ? new Date(site.Fuel_Level_Updated_At).toLocaleString() : 'never'})`);
    console.log(`  Tank capacity: ${site.Tank_Capacity_1 ?? '(none)'} L`);
    console.log(`  MongoDB _id: ${site._id}`);
    console.log('');
    foundIn.push('Site (1 record)');
    totalRecords += 1;
  } else {
    console.log(`⚠ No Site record found for "${siteId}" — every other search below still runs (a site can have historical records even if the live Site record was removed or renamed), but this ID may not exist, or may be misspelled.\n`);
    emptyIn.push('Site');
  }

  // ── 2. Simple, direct string-field collections ───────────────────
  const directStringCollections = [
    { model: '../models/AdHocFuelRequest', name: 'AdHocFuelRequest', field: 'site_id', dateField: 'planned_date' },
    { model: '../models/BudgetRequestApproval', name: 'BudgetRequestApproval', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/CmsDailyRecord', name: 'CmsDailyRecord', field: 'site_id', dateField: 'record_date' },
    { model: '../models/CycleEndStockSnapshot', name: 'CycleEndStockSnapshot', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/CycleReconciliation', name: 'CycleReconciliation', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/DieselAlert', name: 'DieselAlert', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/FieldVisitRecord', name: 'FieldVisitRecord', field: 'site_id', dateField: 'current_visit_date' },
    { model: '../models/FuelConsumption', name: 'FuelConsumption', field: 'site_id', dateField: 'record_date' },
    { model: '../models/FuelDeliveryEvent', name: 'FuelDeliveryEvent', field: 'site_id', dateField: 'delivery_date' },
    { model: '../models/FuelPurchase', name: 'FuelPurchase', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/FuelRequest', name: 'FuelRequest', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/GeneratorAssignmentLedger', name: 'GeneratorAssignmentLedger', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/GeneratorUpdate', name: 'GeneratorUpdate', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/HistoricalFieldVisit', name: 'HistoricalFieldVisit', field: 'site_id', dateField: 'visit_date' },
    { model: '../models/HistoricalMonthlyRecord', name: 'HistoricalMonthlyRecord', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/HistoricalSiteStockSnapshot', name: 'HistoricalSiteStockSnapshot', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/Maintenance', name: 'Maintenance', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/MidCycleBudgetRelease', name: 'MidCycleBudgetRelease', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/MidCycleEstimateSnapshot', name: 'MidCycleEstimateSnapshot', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/Notifications', name: 'Notifications', field: 'siteId', dateField: 'createdAt' },
    { model: '../models/PlannedVsSuppliedDelivery', name: 'PlannedVsSuppliedDelivery', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/SiteBudget', name: 'SiteBudget', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/SiteConsumptionHistory', name: 'SiteConsumptionHistory', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/SiteEngineeringParams', name: 'SiteEngineeringParams', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/SiteVisit', name: 'SiteVisit', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/TankAudit', name: 'TankAudit', field: 'site_id_ihs', dateField: 'audit_date' },
    { model: '../models/TankLevelReading', name: 'TankLevelReading', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/TechnicianSiteAudit', name: 'TechnicianSiteAudit', field: 'site_id_ihs', dateField: 'createdAt' },
    { model: '../models/TomCardTransaction', name: 'TomCardTransaction', field: 'site_id', dateField: 'createdAt' },
    { model: '../models/ValidationRecord', name: 'ValidationRecord', field: 'site_id', dateField: 'createdAt' },
  ];

  for (const { model, name, field, dateField } of directStringCollections) {
    try {
      const Model = require(model);
      const count = await Model.countDocuments({ [field]: siteId });
      if (count > 0) {
        const records = await Model.find({ [field]: siteId }).sort({ [dateField]: -1 }).limit(5).lean();
        console.log(`── ${name} — ${count} record(s) ──`);
        for (const r of records) {
          const dateVal = r[dateField];
          console.log(`  ${dateVal ? new Date(dateVal).toLocaleDateString() : '(no date)'}  [${String(r._id).slice(-6)}]`);
        }
        if (count > 5) console.log(`  ...and ${count - 5} more (showing 5 most recent).`);
        console.log('');
        foundIn.push(`${name} (${count} record${count === 1 ? '' : 's'})`);
        totalRecords += count;
      } else {
        emptyIn.push(name);
      }
    } catch (err) {
      erroredIn.push(`${name}: ${err.message}`);
    }
  }

  // ── 3. Non-standard field names (raw historical import) ──────────
  try {
    const Outage = require('../models/Outage');
    const count = await Outage.countDocuments({ $or: [{ 'Tenant Site ID': siteId }, { 'Site ID': siteId }] });
    if (count > 0) {
      console.log(`── Outage — ${count} record(s) (matched on 'Tenant Site ID' or 'Site ID') ──\n`);
      foundIn.push(`Outage (${count} record${count === 1 ? '' : 's'})`);
      totalRecords += count;
    } else {
      emptyIn.push('Outage');
    }
  } catch (err) {
    erroredIn.push(`Outage: ${err.message}`);
  }

  // ── 4. ObjectId-referenced collections — resolve via Site first ──
  if (site) {
    const objectIdRefCollections = [
      { model: '../models/RefuelWorkflow', name: 'RefuelWorkflow', field: 'siteId' },
      { model: '../models/TechnicianLocationPing', name: 'TechnicianLocationPing', field: 'siteId' },
    ];
    for (const { model, name, field } of objectIdRefCollections) {
      try {
        const Model = require(model);
        const count = await Model.countDocuments({ [field]: site._id });
        if (count > 0) {
          console.log(`── ${name} — ${count} record(s) (matched via Site._id, this collection references sites by ObjectId, not the IHS string ID) ──\n`);
          foundIn.push(`${name} (${count} record${count === 1 ? '' : 's'})`);
          totalRecords += count;
        } else {
          emptyIn.push(name);
        }
      } catch (err) {
        erroredIn.push(`${name}: ${err.message}`);
      }
    }
  } else {
    emptyIn.push('RefuelWorkflow (skipped — no Site record to resolve the ObjectId reference through)');
    emptyIn.push('TechnicianLocationPing (skipped — same reason)');
  }

  // ── 5. Free-text / uncertain-format field — flagged, not silently included as a confirmed match ──
  try {
    const PartRequest = require('../models/PartRequest');
    const count = await PartRequest.countDocuments({ site: siteId });
    if (count > 0) {
      console.log(`── PartRequest — ${count} record(s) (this field is free text, not a strict IHS-ID field per its own schema comment — confirm these are genuinely about this site) ──\n`);
      foundIn.push(`PartRequest (${count} record${count === 1 ? '' : 's'}, free-text field)`);
      totalRecords += count;
    } else {
      emptyIn.push('PartRequest');
    }
  } catch (err) {
    erroredIn.push(`PartRequest: ${err.message}`);
  }

  // ── Summary ────────────────────────────────────────────────────
  console.log('══════════════════════════════════════════════════════════');
  console.log(` SUMMARY — ${siteId}`);
  console.log('══════════════════════════════════════════════════════════');
  console.log(`Total records found across all collections: ${totalRecords}\n`);
  if (foundIn.length) {
    console.log('Found in:');
    for (const f of foundIn) console.log(`  ✓ ${f}`);
  }
  console.log(`\nNo records in ${emptyIn.length} other collection(s) checked.`);
  if (erroredIn.length) {
    console.log(`\n⚠ ${erroredIn.length} collection(s) could not be checked:`);
    for (const e of erroredIn) console.log(`  ✗ ${e}`);
  }
  console.log('══════════════════════════════════════════════════════════');

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
