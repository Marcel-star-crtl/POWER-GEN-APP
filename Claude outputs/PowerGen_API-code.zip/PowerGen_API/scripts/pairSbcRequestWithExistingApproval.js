/**
 * pairSbcRequestWithExistingApproval.js
 * diesel-system/scripts/pairSbcRequestWithExistingApproval.js
 *
 * Pairs January, February, April, March, and May's "SBC Diesel Budget"
 * requested figure (same file family as importSbcBudgetFiles.js) with
 * the approved figure already imported for those months from the
 * multi-month rollup (MultiMonth_Budget_JanJul.xlsx, "Total
 * [Month]-26 Budget given to the SBCs"). Writes to
 * BudgetRequestApproval, NOT HistoricalMonthlyRecord — the existing
 * budget_liters figure for these months (already the approved side,
 * sourced from the same rollup) is untouched by this script.
 *
 * WHY MARCH MOVED HERE FROM importMarch2026Budget.js (Phase 83):
 * March was originally treated as a single-figure budget month (Phase
 * 76) because no separate approved figure was known at the time. Phase
 * 83 found two things: (1) a real monthly-reconciliation file for
 * March, which surfaced that the multi-month rollup's own "Total
 * March-26 Budget given to the SBCs" column had been present all
 * along but never actually used for March (BUDGET_MONTH_LABELS already
 * had the mapping — an oversight in Phase 76, not new data); (2)
 * cross-checking that rollup figure against the standalone "Requested
 * Quantity" file site-by-site found only 27 of 164 sites agree — a
 * real, substantial gap, not rounding noise, consistent with these
 * being genuinely different concepts (a request vs. what was actually
 * given), the same relationship already confirmed for February and
 * April. March's old single-figure import is superseded by this
 * pairing — its budget_liters in HistoricalMonthlyRecord is now
 * correctly sourced from the rollup via importHistoricalEmailData.js,
 * consistent with every other month, instead of the "Requested
 * Quantity" figure that was being used there before.
 *
 * WHY DECEMBER IS STILL HANDLED SEPARATELY:
 * December has no other approved-figure source at all — its "SBC
 * Diesel Budget" file remains its only figure, imported as a single
 * budget_liters value (see importSbcBudgetFiles.js).
 *
 * Cross-checked before trusting either source: neither figure is
 * assumed correct over the other — both are real, both are kept, and
 * the gap between them (April: 107,996L requested vs 137,746L
 * approved; February: 127,274L vs 134,081L; March: see this script's
 * own printed totals) is presented as a real finding, the same way
 * July's and June's request/approval gaps are.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/pairSbcRequestWithExistingApproval.js
 *   node scripts/pairSbcRequestWithExistingApproval.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const BudgetRequestApproval = require('../models/BudgetRequestApproval');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

const SOURCES = [
  { cycle_key: '2026-02', requestFile: 'SbcBudget_Feb2026.xlsx', requestSheet: 'Feuil1', approvedColumn: 'Total Feb-26 Budget given to the SBCs (L)' },
  { cycle_key: '2026-04', requestFile: 'SbcBudget_Apr2026.xlsx', requestSheet: 'April', approvedColumn: 'Total April-26 Budget given to the SBCs (L)' },
  { cycle_key: '2026-03', requestFile: 'SbcBudget_Mar2026.xlsx', requestSheet: 'Feuil1', approvedColumn: 'Total March-26 Budget given to the SBCs (L)' },
  { cycle_key: '2026-05', requestFile: 'SbcBudget_May2026.xlsx', requestSheet: 'May', approvedColumn: 'Total May-26 Budget given to the SBCs (L)' },
  // January — Phase 151. Same file family, user-supplied directly
  // (GRATO SBC DIESEL BUDGET January.xlsx, saved here as
  // SbcBudget_Jan2026.xlsx), same "Feuil1"/row-1-header layout as
  // February/March. This cycle simply had no pairing entry before —
  // the same kind of oversight already documented above for March
  // (Phase 76/83), not new or missing data: January's own approved
  // figure has been sitting in the multi-month rollup
  // ("Total Jan-26 Budget given to the SBCs (L)") the whole time,
  // already feeding HistoricalMonthlyRecord.budget_liters/reserve for
  // January — it was just never paired with a requested figure into
  // BudgetRequestApproval. Verified directly before wiring in: 164 of
  // 165 sites in the request file have a matching rollup row (one
  // site — IHS_DLA_448 / Bberi-Q-Princes-II — appears in the request
  // file only, so is left with a null approved figure rather than
  // guessed); 164 with both figures sum to 108,310L requested vs.
  // 111,582L approved.
  { cycle_key: '2026-01', requestFile: 'SbcBudget_Jan2026.xlsx', requestSheet: 'Feuil1', approvedColumn: 'Total Jan-26 Budget given to the SBCs (L)' },
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function findCol(header, name) {
  const target = String(name).replace(/\s+/g, ' ').trim();
  const i = header.findIndex(h => typeof h === 'string' && h.replace(/\s+/g, ' ').trim() === target);
  return i === -1 ? null : i;
}

function loadApprovedFigures(approvedColumn) {
  const wb = XLSX.readFile(path.join(DATA_DIR, 'MultiMonth_Budget_JanJul.xlsx'));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Grato Diesel Budgets'], { header: 1, defval: null, raw: true });
  const header = rows[3]; // verified directly with the real xlsx package (Phase 59/78)
  const idIdx = findCol(header, 'NEW IHS ID');
  const budIdx = findCol(header, approvedColumn);
  const map = new Map();
  for (const row of rows.slice(4)) {
    if (!row || !row[idIdx]) continue;
    map.set(String(row[idIdx]).trim(), toNum(row[budIdx]));
  }
  return map;
}

function parseRequestFile(src) {
  const wb = XLSX.readFile(path.join(DATA_DIR, src.requestFile));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[src.requestSheet], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idx = {
    site_id: findCol(header, 'IHS Site ID'),
    site_name: findCol(header, 'Site Name'),
    cluster: findCol(header, 'Cluster'),
    region: findCol(header, 'State'),
    topology: findCol(header, 'Site Topology'),
    requested_l: findCol(header, 'Requested Quantity (L)'),
  };
  const missing = Object.entries(idx).filter(([, v]) => v === null);
  if (missing.length) {
    throw new Error(`${src.requestFile} missing expected column(s): ${missing.map(([k]) => k).join(', ')}`);
  }

  const approvedMap = loadApprovedFigures(src.approvedColumn);
  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const site_id = String(row[idx.site_id]).trim();
    const sbc_requested_l = toNum(row[idx.requested_l]);
    const ihs_approved_l = approvedMap.get(site_id) ?? null;
    records.push({
      site_id,
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      cycle_key: src.cycle_key,
      sbc_requested_l,
      ihs_approved_l,
      variance_l: (sbc_requested_l != null && ihs_approved_l != null)
        ? Math.round((ihs_approved_l - sbc_requested_l) * 10) / 10 : null,
      source_file: `${src.requestFile} + MultiMonth_Budget_JanJul.xlsx`,
    });
  }
  return records;
}

async function main() {
  const allRecords = [];
  for (const src of SOURCES) {
    const records = parseRequestFile(src);
    const withBoth = records.filter(r => r.sbc_requested_l != null && r.ihs_approved_l != null);
    const totalReq = withBoth.reduce((s, r) => s + r.sbc_requested_l, 0);
    const totalApp = withBoth.reduce((s, r) => s + r.ihs_approved_l, 0);
    console.log(`── ${src.cycle_key}: ${records.length} site(s), ${withBoth.length} with both figures. Requested: ${Math.round(totalReq).toLocaleString()} L, approved: ${Math.round(totalApp).toLocaleString()} L.`);
    allRecords.push(...records);
  }

  console.log(`\n── Total: ${allRecords.length} record(s) across ${SOURCES.length} cycle(s). ──`);
  console.log('Note: this writes to BudgetRequestApproval only — HistoricalMonthlyRecord.budget_liters for Feb/Apr/Mar is untouched here (Feb/Apr already correct from the rollup; March gets its correct rollup-sourced figure via importHistoricalEmailData.js, run separately).');

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = allRecords.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id, cycle_key: r.cycle_key },
      update: { $set: r },
      upsert: true,
    },
  }));
  const result = await BudgetRequestApproval.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
