/**
 * verifyNotesRunHoursScan.js
 * diesel-system/scripts/verifyNotesRunHoursScan.js
 *
 * Verifies Phase 121/122's notes-scanning run-hours feature in two
 * parts:
 *
 *   1. A self-contained regression test of scanAuditForRunHours itself
 *      — no database needed. Confirms the exact behavior the two
 *      phases were built around: a high-confidence "RH: <number>"
 *      style match, a lower-confidence bare-number-plus-unit match,
 *      correct rejection of unrelated text, and — the actual thing
 *      Phase 122 fixed — that a run-hours-shaped value sitting in
 *      general_notes is genuinely ignored while the identical pattern
 *      in check_gen_cards_faulty.notes is not. This part alone would
 *      have caught Phase 121's original field-scope mistake before it
 *      ever reached a live database.
 *
 *   2. A live-database check (only if MONGODB_URI is set and reachable)
 *      confirming the real getNotesRunHoursCandidates query and field
 *      selection behave as expected against whatever data actually
 *      exists — reports real counts, not assumed ones, and prints a
 *      sample of real matches (site, matched text, confidence) so a
 *      person can eyeball whether the real data behaves as expected,
 *      not just trust a pass/fail count.
 *
 * Exits with a non-zero status if any regression-test assertion fails.
 * The live-data part reports what it finds but does not fail the
 * script on its own — a live deployment with zero current candidates
 * is a legitimate, correct outcome, not a bug.
 *
 * Usage:
 *   node scripts/verifyNotesRunHoursScan.js
 */
'use strict';

require('dotenv').config();

const { extractRunHoursCandidates, scanAuditForRunHours } = require('../services/notesRunHoursScanner');

let failures = 0;

function assert(label, condition, detail) {
  if (condition) {
    console.log(`  ✓ ${label}`);
  } else {
    failures++;
    console.log(`  ✗ ${label}${detail ? ` — ${detail}` : ''}`);
  }
}

// ── Part 1: regression test of the scanning logic itself ────────────
console.log('══════════════════════════════════════════════════════════');
console.log(' PART 1 — Scanning logic regression test (no database)');
console.log('══════════════════════════════════════════════════════════\n');

console.log('extractRunHoursCandidates — pattern matching:');
{
  const highConfidence = extractRunHoursCandidates('RH: 28574, tank was fine');
  assert('explicit "RH:" label matches with high confidence',
    highConfidence.length === 1 && highConfidence[0].value === 28574 && highConfidence[0].confidence === 'high',
    JSON.stringify(highConfidence));

  const commaFormatted = extractRunHoursCandidates('run hours: 28,574.5');
  assert('comma-formatted number is parsed correctly',
    commaFormatted.length === 1 && commaFormatted[0].value === 28574.5,
    JSON.stringify(commaFormatted));

  const mediumConfidence = extractRunHoursCandidates('meter reading 28574 hrs');
  assert('bare number + unit, generic context (no field flag), matches with medium confidence',
    mediumConfidence.length === 1 && mediumConfidence[0].value === 28574 && mediumConfidence[0].confidence === 'medium',
    JSON.stringify(mediumConfidence));

  const shortNumber = extractRunHoursCandidates('spent 2 hours on site');
  assert('a short number (visit duration, not a plausible reading) is correctly rejected',
    shortNumber.length === 0,
    JSON.stringify(shortNumber));

  const noMatch = extractRunHoursCandidates('No issues found');
  assert('text with no numbers at all produces no candidates',
    noMatch.length === 0,
    JSON.stringify(noMatch));

  const periods = extractRunHoursCandidates('R.H. 28574');
  assert('"R.H." with periods still matches',
    periods.length === 1 && periods[0].value === 28574,
    JSON.stringify(periods));
}

console.log('\nextractRunHoursCandidates — Phase 124 additions (driven by real Phase 123 live-data findings):');
{
  const fieldSpecificHigh = extractRunHoursCandidates('mechanical shows 2145hrs', { fieldIsRunHoursSpecific: true });
  assert('a bare "NNNNhrs" match is HIGH confidence when the field is run-hours-specific (real data: 8 of 8 live matches used exactly this bare pattern)',
    fieldSpecificHigh.length === 1 && fieldSpecificHigh[0].confidence === 'high' && fieldSpecificHigh[0].value === 2145,
    JSON.stringify(fieldSpecificHigh));

  const genericStillMedium = extractRunHoursCandidates('mechanical shows 2145hrs', { fieldIsRunHoursSpecific: false });
  assert('the identical bare match stays MEDIUM confidence when the field is not run-hours-specific',
    genericStillMedium.length === 1 && genericStillMedium[0].confidence === 'medium',
    JSON.stringify(genericStillMedium));

  const plausibleValue = extractRunHoursCandidates('RH: 28574');
  assert('an ordinary value is flagged plausible: true',
    plausibleValue.length === 1 && plausibleValue[0].plausible === true,
    JSON.stringify(plausibleValue));

  const implausibleValue = extractRunHoursCandidates('RH: 91400');
  assert('a value above the threshold (real data: an actual 91400hrs was found live) is flagged plausible: false, not silently trusted',
    implausibleValue.length === 1 && implausibleValue[0].value === 91400 && implausibleValue[0].plausible === false,
    JSON.stringify(implausibleValue));

  const repeatedValue = extractRunHoursCandidates('Card faulty, mechanical shows 91400hrs. Confirmed 91400hrs with supervisor, logged 91400hrs.', { fieldIsRunHoursSpecific: true });
  assert('the same real value repeated 3 times in one note (an actual live case) produces exactly ONE candidate, not three',
    repeatedValue.length === 1 && repeatedValue[0].value === 91400,
    JSON.stringify(repeatedValue));
}

console.log('\nextractRunHoursCandidates — Phase 131 additions (driven by a real user-provided export showing 70+ real cases neither prior pattern caught):');
{
  const pureBareNumber = extractRunHoursCandidates('6934', { fieldIsRunHoursSpecific: true });
  assert('a pure bare number with NO unit or label at all is matched (real data: this exact pattern accounted for 70 of 83 real cases)',
    pureBareNumber.length === 1 && pureBareNumber[0].value === 6934 && pureBareNumber[0].confidence === 'high',
    JSON.stringify(pureBareNumber));

  const shortBareNumber = extractRunHoursCandidates('35', { fieldIsRunHoursSpecific: true });
  assert('a short (2-digit) bare number is still matched — real data included legitimate short readings like this for newly-installed generators',
    shortBareNumber.length === 1 && shortBareNumber[0].value === 35,
    JSON.stringify(shortBareNumber));

  const numberOnOwnLine = extractRunHoursCandidates('15532 \nDisplay screen too blurred', { fieldIsRunHoursSpecific: true });
  assert('a number on its own line among other descriptive text is matched (real case, verbatim from the user\'s export)',
    numberOnOwnLine.length === 1 && numberOnOwnLine[0].value === 15532,
    JSON.stringify(numberOnOwnLine));

  const numberOnLaterLine = extractRunHoursCandidates('Display is blurry\n\n12556', { fieldIsRunHoursSpecific: true });
  assert('a number on a LATER line (description first, number after) is also matched (real case, verbatim from the user\'s export)',
    numberOnLaterLine.length === 1 && numberOnLaterLine[0].value === 12556,
    JSON.stringify(numberOnLaterLine));

  const bareNumberGenericField = extractRunHoursCandidates('6934', { fieldIsRunHoursSpecific: false });
  assert('a pure bare number is NOT matched when the field is not run-hours-specific — a bare number with zero anchor text is only unambiguous because of the field\'s own exclusive purpose',
    bareNumberGenericField.length === 0,
    JSON.stringify(bareNumberGenericField));

  const noNumberAtAll = extractRunHoursCandidates('Faulty gen card with blurred display', { fieldIsRunHoursSpecific: true });
  assert('descriptive text with no number anywhere in it still correctly produces zero candidates (real case, verbatim)',
    noNumberAtAll.length === 0,
    JSON.stringify(noNumberAtAll));

  const justOK = extractRunHoursCandidates('OK', { fieldIsRunHoursSpecific: true });
  assert('non-numeric short text ("OK") does not false-positive match anything',
    justOK.length === 0,
    JSON.stringify(justOK));
}

console.log('\nscanAuditForRunHours — field scope (the actual Phase 122 fix):');
{
  const onlyInGeneralNotes = scanAuditForRunHours({
    general_notes: 'RH 28574 — this should NOT be picked up',
    check_gen_cards_faulty: { notes: 'no run hours mentioned here' },
  });
  assert('a match sitting ONLY in general_notes produces zero candidates',
    onlyInGeneralNotes.length === 0,
    JSON.stringify(onlyInGeneralNotes));

  const onlyInGenCardNotes = scanAuditForRunHours({
    general_notes: 'nothing relevant here',
    check_gen_cards_faulty: { notes: 'RH: 30120' },
  });
  assert('the identical pattern in check_gen_cards_faulty.notes IS picked up',
    onlyInGenCardNotes.length === 1 && onlyInGenCardNotes[0].value === 30120 && onlyInGenCardNotes[0].source_field === 'check_gen_cards_faulty.notes',
    JSON.stringify(onlyInGenCardNotes));

  const bothFieldsHaveMatches = scanAuditForRunHours({
    general_notes: 'RH 11111 — a decoy that should be ignored',
    check_gen_cards_faulty: { notes: 'RH: 22222' },
  });
  assert('when both fields have a run-hours-shaped value, only the Gen Card one is returned',
    bothFieldsHaveMatches.length === 1 && bothFieldsHaveMatches[0].value === 22222,
    JSON.stringify(bothFieldsHaveMatches));

  const missingField = scanAuditForRunHours({ general_notes: 'RH 28574' });
  assert('an audit with no check_gen_cards_faulty at all does not throw, just returns nothing',
    missingField.length === 0,
    JSON.stringify(missingField));
}

console.log(`\n${failures === 0 ? '✓ Part 1 passed — all regression assertions correct.' : `✗ Part 1 FAILED — ${failures} assertion(s) did not hold.`}`);

// ── Part 2: live-database check (optional — only if reachable) ──────
async function runLiveCheck() {
  console.log('\n══════════════════════════════════════════════════════════');
  console.log(' PART 2 — Live database check');
  console.log('══════════════════════════════════════════════════════════\n');

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) {
    console.log('No MONGODB_URI (or MONGO_URI) set — skipping the live check.');
    console.log('Part 1\'s regression test above is still a real, independent verification of the scan logic itself.');
    return;
  }

  const mongoose = require('mongoose');
  try {
    await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  } catch (err) {
    console.log(`Could not connect to MongoDB (${err.message}) — skipping the live check.`);
    return;
  }
  console.log('✓ Connected to MongoDB\n');

  const TankAudit = require('../models/TankAudit');

  const missingRunHours = await TankAudit.countDocuments({ status: 'submitted', audit_run_hours_reading: null });
  const missingWithGenCardNotes = await TankAudit.countDocuments({
    status: 'submitted',
    audit_run_hours_reading: null,
    'check_gen_cards_faulty.notes': { $exists: true, $ne: '' },
  });
  console.log(`Submitted audits missing audit_run_hours_reading: ${missingRunHours}`);
  console.log(`...of those, with real text in check_gen_cards_faulty.notes: ${missingWithGenCardNotes}`);

  const audits = await TankAudit.find({
    status: 'submitted',
    audit_run_hours_reading: null,
    'check_gen_cards_faulty.notes': { $exists: true, $ne: '' },
  })
    .select('site_id_ihs auditor_name audit_date check_gen_cards_faulty.notes')
    .lean();

  const allCandidates = [];
  for (const audit of audits) {
    for (const c of scanAuditForRunHours(audit)) {
      allCandidates.push({ audit_id: audit._id, site_id: audit.site_id_ihs, auditor_name: audit.auditor_name, audit_date: audit.audit_date, ...c });
    }
  }

  console.log(`Real run-hours mentions found in check_gen_cards_faulty.notes: ${allCandidates.length}`);
  if (allCandidates.length) {
    console.log('\nSample (up to 10) — review these against the real notes text if anything looks off:');
    console.log('(Multiple rows for the same site are genuinely separate audit submissions — different visit dates, each its own record still missing a run-hours value — not the same audit shown twice. The date is shown specifically so this is never ambiguous.)\n');
    for (const c of allCandidates.slice(0, 10)) {
      const dateStr = c.audit_date ? new Date(c.audit_date).toISOString().slice(0, 10) : 'no date';
      console.log(`  ${c.site_id} — ${dateStr} (${c.auditor_name || 'unknown auditor'}) [audit ${String(c.audit_id).slice(-6)}] — "${c.matched_text}" → ${c.value} [${c.confidence}]${c.plausible === false ? '  ⚠ IMPLAUSIBLE — review before accepting' : ''}`);
    }
    if (allCandidates.length > 10) console.log(`  ...and ${allCandidates.length - 10} more.`);
  } else {
    console.log('No matches found in the live data right now — a legitimate outcome if no technician happened to use this specific workaround, not necessarily a problem with the scanner.');
  }

  // A direct, real-data confirmation that the Phase 122 fix matters in
  // practice, not just in the synthetic Part 1 test above — checks
  // whether any currently-missing-run-hours audit has a run-hours-
  // shaped value sitting in general_notes that the scanner correctly
  // does NOT surface.
  const generalNotesCheck = await TankAudit.find({
    status: 'submitted',
    audit_run_hours_reading: null,
    general_notes: { $regex: /run[\s-]?hours?|r\.?h\.?\s*[:=\-]?\s*\d/i },
  }).select('site_id_ihs general_notes').lean();
  if (generalNotesCheck.length) {
    console.log(`\nℹ ${generalNotesCheck.length} audit(s) have a run-hours-shaped mention in general_notes specifically — confirmed these are correctly excluded from the results above (Phase 122's fix), not silently missed:`);
    for (const a of generalNotesCheck.slice(0, 5)) {
      console.log(`  ${a.site_id_ihs}: "${a.general_notes.slice(0, 80)}${a.general_notes.length > 80 ? '…' : ''}"`);
    }
    console.log('  If any of these actually belong in the real workflow, that\'s a real, separate finding worth a human decision — not something this script should silently pull in.');
  }

  await mongoose.disconnect();
}

runLiveCheck()
  .then(() => {
    console.log('\n══════════════════════════════════════════════════════════');
    if (failures === 0) {
      console.log(' ✓ VERIFICATION PASSED');
    } else {
      console.log(` ✗ VERIFICATION FAILED — ${failures} regression assertion(s) did not hold.`);
    }
    console.log('══════════════════════════════════════════════════════════');
    process.exit(failures === 0 ? 0 : 1);
  })
  .catch(err => {
    console.error('✗ Fatal error during live check:', err.message);
    process.exit(failures === 0 ? 1 : 1);
  });
