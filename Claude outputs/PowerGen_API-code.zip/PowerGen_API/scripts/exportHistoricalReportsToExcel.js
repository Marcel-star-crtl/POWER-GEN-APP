/**
 * exportHistoricalReportsToExcel.js
 * diesel-system/scripts/exportHistoricalReportsToExcel.js
 *
 * Phase 152 — a multi-sheet Excel export of the four reports on the
 * Historical Data / History Analysis pages, built by re-running the
 * SAME queries and arithmetic those pages' own backend endpoints use
 * (`/full-summary/:month_key`, `/site-cycle-summary/:cycle_key`,
 * `/cluster-cycle-report/:cluster/:cycle_key`, `/summary`,
 * `/debit-summary`, `/adhoc-requests`, `/tomcard-allocations` — see
 * routes/historicalDataRoutes.js), so every number in this workbook is
 * exactly what the app itself would show, not a re-derivation from raw
 * source files that could drift from it. Read-only — this script never
 * writes to the database, so there's no --confirm gate and no dry run;
 * it just connects, reads, and writes the .xlsx file.
 *
 * Sheets:
 *   1. Monthly Summary       — one row per site per recovered month
 *      (Requested/Approved/Extra Fuel/Consumed/Reserve), same shape as
 *      the Historical Data page's "Complete Monthly Summary" table,
 *      across every month HistoricalMonthlyRecord has (2025-04 onward
 *      — this sheet is intentionally NOT scoped to Dec 2025+, since the
 *      page itself lets you pick any recovered month via its dropdown).
 *   2. Site Cycle Analysis   — one row per site per cycle (Total
 *      Requested/Approved split into initial+extra, Delivered to Site,
 *      Consumed, Reserve), same shape as History Analysis's Site Cycle
 *      Analysis tab. Scoped to the same nine cycles that tab's own
 *      dropdown offers (Dec 2025 – Aug 2026) — the earlier 2025 months
 *      were never exposed there either.
 *   3. Cluster Cycle Analysis — one row per real cluster (the 8 named
 *      by the user in Phase 148 — Bonaberi 1/2, Edea, Kotto, Ndogbong,
 *      Pouma 1/2, Yassa) per cycle, same shape as History Analysis's
 *      Cluster Cycle Analysis tab, including Phase 149's real
 *      Consumed/Reserve totals and its explicitly-labeled ESTIMATED
 *      share of the fleet-wide settlement (never presented as a
 *      recorded figure — see the Estimated Debit/Credit column's own
 *      note).
 *   4. Global – * (five sheets) — the Global Summary tab's own data,
 *      scoped to December 2025 onward (Phase 151's fix): fleet-wide
 *      monthly trend, extra fuel by month, debit/credit settlement by
 *      month, Tom Card funding by cycle, and chronically exhausted
 *      sites.
 *
 * Usage:
 *   node scripts/exportHistoricalReportsToExcel.js
 *   node scripts/exportHistoricalReportsToExcel.js --out=/path/to/file.xlsx
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const ExcelJS = require('exceljs');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');
const AdHocFuelRequest = require('../models/AdHocFuelRequest');
const TomCardAllocation = require('../models/TomCardAllocation');
const BudgetRequestApproval = require('../models/BudgetRequestApproval');
const MonthlyDebitSummary = require('../models/MonthlyDebitSummary');
const HistoricalFieldVisit = require('../models/HistoricalFieldVisit');

const outArg = process.argv.find(a => a.startsWith('--out='));
const OUT_PATH = outArg ? outArg.split('=')[1] : path.join(__dirname, `Historical_Reports_${new Date().toISOString().slice(0, 10)}.xlsx`);

// Same 8 real clusters the user identified directly (Phase 148) — NOT
// derived from AdHocFuelRequest.cluster's free-text column, which has
// ~74 site-name-as-cluster data-entry errors (see Phase 148's own
// diagnosis in the changelog).
const REAL_CLUSTERS = ['Bonaberi 1', 'Bonaberi 2', 'Edea', 'Kotto', 'Ndogbong', 'Pouma 1', 'Pouma 2', 'Yassa'];
// Same nine cycles History Analysis's own Site/Cluster tab dropdowns offer.
const CYCLES = ['2025-12', '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08'];
const GLOBAL_MIN_MONTH_KEY = '2025-12'; // Phase 151

function cycleDateRange(cycle_key) {
  const [year, month] = cycle_key.split('-').map(Number);
  return { monthStart: new Date(Date.UTC(year, month - 1, 1)), monthEnd: new Date(Date.UTC(year, month, 1)) };
}
function monthLabel(key) {
  if (!key) return key;
  const [y, m] = key.split('-');
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${names[Number(m) - 1]} '${y.slice(2)}`;
}

function addHeaderRow(sheet, headers) {
  const row = sheet.addRow(headers);
  row.font = { bold: true };
  row.eachCell(c => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE5E7EB' } }; });
  sheet.autoFilter = { from: { row: row.number, column: 1 }, to: { row: row.number, column: headers.length } };
  sheet.views = [{ state: 'frozen', ySplit: row.number }];
}

// ─── Sheet 1: Monthly Summary — mirrors /full-summary/:month_key ──────────
async function buildMonthlySummarySheet(wb) {
  const sheet = wb.addWorksheet('Monthly Summary');
  addHeaderRow(sheet, [
    'Month', 'Site ID', 'Site Name', 'Cluster',
    'Requested (L)', 'Approved (L)',
    'Extra Fuel Requested (L)', 'Extra Fuel Requests', 'Extra Fuel Approved (L)', 'Extra Fuel Delivered (L)',
    'Extra Fuel Approved Count', 'Extra Fuel Rejected Count', 'Extra Fuel Pending Count', 'Extra Fuel Delivered Count',
    'Consumed (L)', 'Reserve (L)', 'Fully Exhausted',
  ]);

  const monthKeys = (await HistoricalMonthlyRecord.distinct('month_key')).sort();
  console.log(`Monthly Summary: ${monthKeys.length} recovered month(s) — ${monthKeys.join(', ')}`);

  for (const month_key of monthKeys) {
    const [year, month] = month_key.split('-').map(Number);
    const monthStart = new Date(Date.UTC(year, month - 1, 1));
    const monthEnd = new Date(Date.UTC(year, month, 1));

    const [monthlyRecords, requestApprovals, adhocByMonth] = await Promise.all([
      HistoricalMonthlyRecord.find({ month_key }).lean(),
      BudgetRequestApproval.find({ cycle_key: month_key }).lean(),
      AdHocFuelRequest.aggregate([
        { $match: { planned_date: { $gte: monthStart, $lt: monthEnd } } },
        { $addFields: {
          decision_status: {
            $switch: {
              branches: [
                { case: { $ne: [{ $ifNull: ['$delivered_l', null] }, null] }, then: 'delivered' },
                { case: { $eq: ['$approved_l', 0] }, then: 'rejected' },
                { case: { $gt: ['$approved_l', 0] }, then: 'approved' },
              ],
              default: 'pending',
            },
          },
        }},
        { $group: {
          _id: '$site_id',
          extra_fuel_l: { $sum: '$quantity_requested_l' },
          extra_fuel_requests: { $sum: 1 },
          extra_fuel_approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
          extra_fuel_delivered_l: { $sum: { $ifNull: ['$delivered_l', 0] } },
          extra_fuel_approved_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'approved'] }, 1, 0] } },
          extra_fuel_rejected_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'rejected'] }, 1, 0] } },
          extra_fuel_pending_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'pending'] }, 1, 0] } },
          extra_fuel_delivered_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'delivered'] }, 1, 0] } },
        }},
      ]),
    ]);

    const approvalBySite = new Map(requestApprovals.map(r => [r.site_id, r]));
    const adhocBySite = new Map(adhocByMonth.map(a => [a._id, a]));
    const allSiteIds = new Set([
      ...monthlyRecords.map(r => r.site_id),
      ...requestApprovals.map(r => r.site_id),
      ...adhocByMonth.map(a => a._id),
    ]);

    const rows = [...allSiteIds].map(site_id => {
      const monthly = monthlyRecords.find(r => r.site_id === site_id);
      const approval = approvalBySite.get(site_id);
      const adhoc = adhocBySite.get(site_id);
      return {
        site_name: monthly?.site_name || approval?.site_name || null,
        cluster: monthly?.cluster || approval?.cluster || null,
        site_id,
        requested_l: approval?.sbc_requested_l ?? null,
        approved_l: approval?.ihs_approved_l ?? monthly?.budget_liters ?? null,
        extra_fuel_l: adhoc?.extra_fuel_l ?? null,
        extra_fuel_requests: adhoc?.extra_fuel_requests ?? null,
        extra_fuel_approved_l: adhoc?.extra_fuel_approved_l ?? null,
        extra_fuel_delivered_l: adhoc?.extra_fuel_delivered_l ?? null,
        extra_fuel_approved_count: adhoc?.extra_fuel_approved_count ?? null,
        extra_fuel_rejected_count: adhoc?.extra_fuel_rejected_count ?? null,
        extra_fuel_pending_count: adhoc?.extra_fuel_pending_count ?? null,
        extra_fuel_delivered_count: adhoc?.extra_fuel_delivered_count ?? null,
        consumed_l: monthly?.final_consumption_l ?? null,
        reserve_l: monthly?.reserve_liters ?? null,
        fully_exhausted: monthly?.fully_exhausted ?? null,
      };
    }).sort((a, b) => (a.site_name || a.site_id).localeCompare(b.site_name || b.site_id));

    for (const r of rows) {
      sheet.addRow([
        monthLabel(month_key), r.site_id, r.site_name, r.cluster,
        r.requested_l, r.approved_l,
        r.extra_fuel_l, r.extra_fuel_requests, r.extra_fuel_approved_l, r.extra_fuel_delivered_l,
        r.extra_fuel_approved_count, r.extra_fuel_rejected_count, r.extra_fuel_pending_count, r.extra_fuel_delivered_count,
        r.consumed_l, r.reserve_l, r.fully_exhausted == null ? null : (r.fully_exhausted ? 'Exhausted' : 'Has Reserve'),
      ]);
    }
  }
  sheet.columns.forEach(c => { c.width = 16; });
  sheet.getColumn(3).width = 24;
}

// ─── Sheet 2: Site Cycle Analysis — mirrors /site-cycle-summary/:cycle_key ─
async function buildSiteCycleSheet(wb) {
  const sheet = wb.addWorksheet('Site Cycle Analysis');
  addHeaderRow(sheet, [
    'Cycle', 'Site ID', 'Site Name', 'Cluster',
    'Total Requested — Initial (L)', 'Total Requested — Extra (L)', 'Total Requested (L)', 'Requested Partial?',
    'Total Approved — Initial (L)', 'Total Approved — Extra (L)', 'Total Approved (L)', 'Approved Partial?',
    'Delivered to Site (L)', 'Visits This Cycle',
    'Consumed (L)', 'Reserve (L)', 'Fully Exhausted',
  ]);

  for (const cycle_key of CYCLES) {
    const { monthStart, monthEnd } = cycleDateRange(cycle_key);
    const [monthlyRecords, approvals, adhocByS, deliveredByS] = await Promise.all([
      HistoricalMonthlyRecord.find({ month_key: cycle_key }).lean(),
      BudgetRequestApproval.find({ cycle_key }).lean(),
      AdHocFuelRequest.aggregate([
        { $match: { planned_date: { $gte: monthStart, $lt: monthEnd } } },
        { $group: {
          _id: '$site_id',
          requested_l: { $sum: '$quantity_requested_l' },
          approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
        }},
      ]),
      HistoricalFieldVisit.aggregate([
        { $match: { month_key: cycle_key } },
        { $group: { _id: '$site_id', delivered_to_site_l: { $sum: { $ifNull: ['$fuel_added_l', 0] } }, visit_count: { $sum: 1 } } },
      ]),
    ]);

    const approvalBySite = new Map(approvals.map(r => [r.site_id, r]));
    const adhocBySite = new Map(adhocByS.map(a => [a._id, a]));
    const deliveredBySite = new Map(deliveredByS.map(d => [d._id, d]));
    const allSiteIds = new Set([
      ...monthlyRecords.map(r => r.site_id),
      ...approvals.map(r => r.site_id),
      ...adhocByS.map(a => a._id),
      ...deliveredByS.map(d => d._id),
    ]);

    console.log(`Site Cycle Analysis ${cycle_key}: ${allSiteIds.size} site(s).`);

    for (const site_id of allSiteIds) {
      const monthly = monthlyRecords.find(r => r.site_id === site_id);
      const approval = approvalBySite.get(site_id);
      const adhoc = adhocBySite.get(site_id);
      const delivered = deliveredBySite.get(site_id);

      const initial_requested_l = approval?.sbc_requested_l ?? null;
      const initial_approved_l = approval?.ihs_approved_l ?? monthly?.budget_liters ?? null;
      const extra_fuel_requested_l = adhoc ? adhoc.requested_l : null;
      const extra_fuel_approved_l = adhoc ? adhoc.approved_l : null;
      const total_requested_l = (initial_requested_l == null && extra_fuel_requested_l == null) ? null : (initial_requested_l || 0) + (extra_fuel_requested_l || 0);
      const total_approved_l = (initial_approved_l == null && extra_fuel_approved_l == null) ? null : (initial_approved_l || 0) + (extra_fuel_approved_l || 0);

      sheet.addRow([
        monthLabel(cycle_key), site_id,
        monthly?.site_name || approval?.site_name || adhoc?.site_name || null,
        monthly?.cluster || approval?.cluster || adhoc?.cluster || null,
        initial_requested_l, extra_fuel_requested_l, total_requested_l, (initial_requested_l == null) !== (extra_fuel_requested_l == null) ? 'Yes' : 'No',
        initial_approved_l, extra_fuel_approved_l, total_approved_l, (initial_approved_l == null) !== (extra_fuel_approved_l == null) ? 'Yes' : 'No',
        delivered?.delivered_to_site_l ?? null, delivered?.visit_count ?? 0,
        monthly?.final_consumption_l ?? null, monthly?.reserve_liters ?? null,
        monthly?.fully_exhausted == null ? null : (monthly.fully_exhausted ? 'Exhausted' : 'Has Reserve'),
      ]);
    }
  }
  sheet.columns.forEach(c => { c.width = 15; });
  sheet.getColumn(3).width = 24;
}

// ─── Sheet 3: Cluster Cycle Analysis — mirrors /cluster-cycle-report ──────
async function buildClusterCycleSheet(wb, fleetDebitByCycle) {
  const sheet = wb.addWorksheet('Cluster Cycle Analysis');
  addHeaderRow(sheet, [
    'Cycle', 'Cluster', 'Site Count',
    'Requested — Regular (L)', 'Approved — Regular (L)',
    'Extra Fuel Requested (L)', 'Extra Fuel Approved (L)',
    'Purchases (L)', 'Purchases (XAF)',
    'Card Funding incl. Extra Rounds (L)', 'Card Funding incl. Extra Rounds (XAF)',
    'Consumed — Actual (L)', 'Reserve (L)', 'Consumed Coverage (sites)',
    'Fleet-Wide Debit/Credit for Cycle (XAF, NOT per-cluster)',
    'Estimated Cluster Share of Settlement (XAF) — COMPUTED, not recorded',
  ]);

  for (const cycle_key of CYCLES) {
    const { monthStart, monthEnd } = cycleDateRange(cycle_key);
    const fleetDebit = fleetDebitByCycle.get(cycle_key) || null;

    for (const cluster of REAL_CLUSTERS) {
      const [approvals, monthlyRecords, adhocRaw, tomCardRows] = await Promise.all([
        BudgetRequestApproval.find({ cluster, cycle_key }).lean(),
        HistoricalMonthlyRecord.find({ cluster, month_key: cycle_key }).lean(),
        AdHocFuelRequest.find({ cluster, planned_date: { $gte: monthStart, $lt: monthEnd } }).lean(),
        TomCardAllocation.find({ cluster, funded_cycle_key: cycle_key }).lean(),
      ]);

      if (!approvals.length && !monthlyRecords.length && !adhocRaw.length && !tomCardRows.length) continue; // matches the endpoint's own 404 case — nothing recovered for this cluster/cycle

      const totalRequested = approvals.reduce((s, a) => s + (a.sbc_requested_l ?? 0), 0);
      const totalApproved = approvals.reduce((s, a) => s + (a.ihs_approved_l ?? 0), 0);
      const extraRequested = adhocRaw.reduce((s, r) => s + (r.quantity_requested_l || 0), 0);
      const extraApproved = adhocRaw.reduce((s, r) => s + (r.approved_l || 0), 0);

      const clusterCardNumbers = new Set(tomCardRows.flatMap(t => [t.card_number, t.new_card_number].filter(Boolean)));
      let purchaseTotals = { total_l: 0, total_xaf: 0 };
      if (clusterCardNumbers.size) {
        const HistoricalFuelPurchase = require('../models/HistoricalFuelPurchase');
        const purchases = await HistoricalFuelPurchase.find({ month_key: cycle_key, card_number: { $in: [...clusterCardNumbers] } }).lean();
        purchaseTotals = purchases.reduce((acc, p) => { acc.total_l += p.quantity_l || 0; acc.total_xaf += p.amount_xaf || 0; return acc; }, { total_l: 0, total_xaf: 0 });
      }

      const tomCardTotals = tomCardRows.reduce((acc, t) => {
        const base_l = t.quantity_l ?? t.budget_l ?? 0;
        const base_xaf = t.amount_xaf ?? t.budget_xaf ?? 0;
        const extra_l = (t.extra_round1_approved_l || 0) + (t.extra_round2_approved_l || 0) + (t.extra_round3_approved_l || 0);
        const extra_xaf = (t.extra_round1_approved_xaf || 0) + (t.extra_round2_approved_xaf || 0) + (t.extra_round3_approved_xaf || 0);
        acc.total_incl_extra_l += base_l + extra_l;
        acc.total_incl_extra_xaf += base_xaf + extra_xaf;
        return acc;
      }, { total_incl_extra_l: 0, total_incl_extra_xaf: 0 });

      // Phase 149's real per-cluster Consumed/Reserve
      const monthlyTotals = monthlyRecords.reduce((acc, m) => {
        if (m.final_consumption_l != null) { acc.total_consumed_l += m.final_consumption_l; acc.consumed_count += 1; }
        if (m.reserve_liters != null) acc.total_reserve_l += m.reserve_liters;
        return acc;
      }, { total_consumed_l: 0, total_reserve_l: 0, consumed_count: 0 });

      // Phase 149's estimate — only when every site in the cluster has a
      // recovered consumption figure, exactly matching the frontend's own
      // clusterDebitEstimate logic.
      let estimatedShareXaf = null;
      if (monthlyRecords.length && monthlyTotals.consumed_count === monthlyRecords.length && fleetDebit?.approved_consumption_l && fleetDebit?.debit_credit_amount_xaf != null) {
        const share = monthlyTotals.total_consumed_l / fleetDebit.approved_consumption_l;
        estimatedShareXaf = Math.round(share * fleetDebit.debit_credit_amount_xaf);
      }

      const siteCount = new Set([...approvals.map(a => a.site_id), ...monthlyRecords.map(m => m.site_id), ...adhocRaw.map(a => a.site_id)]).size;

      sheet.addRow([
        monthLabel(cycle_key), cluster, siteCount,
        totalRequested || null, totalApproved || null,
        extraRequested || null, extraApproved || null,
        purchaseTotals.total_l || null, purchaseTotals.total_xaf || null,
        tomCardTotals.total_incl_extra_l || null, tomCardTotals.total_incl_extra_xaf || null,
        monthlyTotals.consumed_count ? monthlyTotals.total_consumed_l : null,
        monthlyTotals.consumed_count ? monthlyTotals.total_reserve_l : null,
        monthlyRecords.length ? `${monthlyTotals.consumed_count}/${monthlyRecords.length}` : null,
        fleetDebit?.debit_credit_amount_xaf ?? null,
        estimatedShareXaf,
      ]);
    }
  }
  sheet.columns.forEach(c => { c.width = 17; });
  sheet.getColumn(16).width = 30;
}

// ─── Sheet 4 (five sheets): Global Summary ─────────────────────────────────
async function buildGlobalSheets(wb) {
  // Fleet-wide monthly trend — mirrors /summary?since=2025-12
  const trendSheet = wb.addWorksheet('Global - Monthly Trend');
  addHeaderRow(trendSheet, ['Month', 'Site Count', 'Sites With Budget', 'Total Budget (L)', 'Total Consumed (L)', 'Total Reserve (L)', 'Exhausted Count', 'Theft Flagged Count', 'Avg RH Variance']);
  const byMonth = await HistoricalMonthlyRecord.aggregate([
    { $match: { month_key: { $gte: GLOBAL_MIN_MONTH_KEY } } },
    { $group: {
      _id: '$month_key', site_count: { $sum: 1 },
      sites_with_budget: { $sum: { $cond: [{ $ne: ['$budget_liters', null] }, 1, 0] } },
      total_budget_l: { $sum: { $ifNull: ['$budget_liters', 0] } },
      total_consumption_l: { $sum: { $ifNull: ['$final_consumption_l', 0] } },
      total_reserve_l: { $sum: { $ifNull: ['$reserve_liters', 0] } },
      exhausted_count: { $sum: { $cond: [{ $eq: ['$fully_exhausted', true] }, 1, 0] } },
      theft_flagged_count: { $sum: { $cond: [{ $gt: [{ $ifNull: ['$theft_liters', 0] }, 0] }, 1, 0] } },
      avg_rh_variance: { $avg: '$rh_variance' },
    }},
    { $sort: { _id: 1 } },
  ]);
  for (const m of byMonth) {
    trendSheet.addRow([monthLabel(m._id), m.site_count, m.sites_with_budget, Math.round(m.total_budget_l), Math.round(m.total_consumption_l), Math.round(m.total_reserve_l), m.exhausted_count, m.theft_flagged_count, m.avg_rh_variance != null ? Math.round(m.avg_rh_variance * 10) / 10 : null]);
  }
  trendSheet.columns.forEach(c => { c.width = 16; });

  // Extra fuel by month — mirrors /adhoc-requests's by_month (already Dec'25+ by nature)
  const extraSheet = wb.addWorksheet('Global - Extra Fuel');
  addHeaderRow(extraSheet, ['Month', 'Requested (L)', 'Approved (L)', 'Delivered (L)', 'Request Count', 'Unique Sites', 'Pending Count', 'Rejected Count']);
  const adhocByMonth = await AdHocFuelRequest.aggregate([
    { $addFields: { month_key: { $dateToString: { format: '%Y-%m', date: '$planned_date' } } } },
    { $addFields: {
      decision_status: {
        $switch: {
          branches: [
            { case: { $ne: [{ $ifNull: ['$delivered_l', null] }, null] }, then: 'delivered' },
            { case: { $eq: ['$approved_l', 0] }, then: 'rejected' },
            { case: { $gt: ['$approved_l', 0] }, then: 'approved' },
          ],
          default: 'pending',
        },
      },
    }},
    { $group: {
      _id: { month_key: '$month_key', site_id: '$site_id' },
      total_l: { $sum: '$quantity_requested_l' },
      approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
      delivered_l: { $sum: { $ifNull: ['$delivered_l', 0] } },
      request_count: { $sum: 1 },
      pending_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'pending'] }, 1, 0] } },
      rejected_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'rejected'] }, 1, 0] } },
    }},
    { $group: {
      _id: '$_id.month_key',
      total_l: { $sum: '$total_l' }, total_approved_l: { $sum: '$approved_l' }, total_delivered_l: { $sum: '$delivered_l' },
      request_count: { $sum: '$request_count' }, unique_sites: { $sum: 1 },
      pending_count: { $sum: '$pending_count' }, rejected_count: { $sum: '$rejected_count' },
    }},
    { $sort: { _id: 1 } },
  ]);
  for (const m of adhocByMonth) {
    extraSheet.addRow([monthLabel(m._id), Math.round(m.total_l), Math.round(m.total_approved_l), Math.round(m.total_delivered_l), m.request_count, m.unique_sites, m.pending_count, m.rejected_count]);
  }
  extraSheet.columns.forEach(c => { c.width = 16; });

  // Debit/Credit settlement by month — mirrors /debit-summary, filtered to Global tab's scope
  const debitSheet = wb.addWorksheet('Global - Debit Credit');
  addHeaderRow(debitSheet, ['Month', 'Submitted Consumption (L)', 'Approved Consumption (L)', 'Purchases (L)', 'Debit/Credit (XAF)']);
  const debitMonths = await MonthlyDebitSummary.find({ cycle_key: { $gte: GLOBAL_MIN_MONTH_KEY } }).sort({ cycle_key: 1 }).lean();
  for (const m of debitMonths) {
    debitSheet.addRow([monthLabel(m.cycle_key), m.submitted_consumption_l, m.approved_consumption_l, m.purchases_l, m.debit_credit_amount_xaf]);
  }
  debitSheet.columns.forEach(c => { c.width = 20; });

  // Tom Card funding by cycle — mirrors /tomcard-allocations, all cycles (not month-scoped in the app either)
  const tomCardSheet = wb.addWorksheet('Global - TomCard Funding');
  addHeaderRow(tomCardSheet, ['Funded Cycle', 'Total Quantity (L)', 'Total Amount (XAF)', 'Grand Total (XAF)', 'Allocation Count']);
  const tomCardRows = await TomCardAllocation.find({}).lean();
  const byCycle = new Map();
  for (const a of tomCardRows) {
    const key = a.funded_cycle_key;
    if (!byCycle.has(key)) byCycle.set(key, { total_l: 0, total_xaf: 0, grand_total_xaf: a.grand_total_xaf ?? null, count: 0 });
    const g = byCycle.get(key);
    g.total_l += (a.quantity_l || a.budget_l || 0);
    g.total_xaf += (a.amount_xaf || a.budget_xaf || 0);
    g.count += 1;
  }
  for (const [key, g] of [...byCycle.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    tomCardSheet.addRow([monthLabel(key), Math.round(g.total_l), Math.round(g.total_xaf), g.grand_total_xaf, g.count]);
  }
  tomCardSheet.columns.forEach(c => { c.width = 18; });

  // Chronically exhausted sites — mirrors /summary?since=2025-12's chronically_exhausted_sites
  const chronicSheet = wb.addWorksheet('Global - Chronic Sites');
  addHeaderRow(chronicSheet, ['Site ID', 'Site Name', 'Cluster', 'Months With Budget', 'Months Exhausted', 'Avg Reserve (L)']);
  const chronic = await HistoricalMonthlyRecord.aggregate([
    { $match: { budget_liters: { $ne: null }, month_key: { $gte: GLOBAL_MIN_MONTH_KEY } } },
    { $group: {
      _id: '$site_id', site_name: { $first: '$site_name' }, cluster: { $first: '$cluster' },
      months_with_budget: { $sum: 1 }, months_exhausted: { $sum: { $cond: [{ $eq: ['$fully_exhausted', true] }, 1, 0] } },
      avg_reserve_l: { $avg: '$reserve_liters' },
    }},
    { $match: { $expr: { $eq: ['$months_with_budget', '$months_exhausted'] } } },
    { $sort: { avg_reserve_l: 1 } },
    { $limit: 20 },
  ]);
  for (const s of chronic) {
    chronicSheet.addRow([s._id, s.site_name, s.cluster, s.months_with_budget, s.months_exhausted, s.avg_reserve_l != null ? Math.round(s.avg_reserve_l * 10) / 10 : null]);
  }
  chronicSheet.columns.forEach(c => { c.width = 20; });

  return debitMonths;
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB (read-only — this script never writes)');

  const wb = new ExcelJS.Workbook();
  wb.creator = 'PowerGen_API — Historical Data export';
  wb.created = new Date();

  console.log('\nBuilding Monthly Summary…');
  await buildMonthlySummarySheet(wb);

  console.log('\nBuilding Site Cycle Analysis…');
  await buildSiteCycleSheet(wb);

  console.log('\nBuilding Global Summary sheets (needed first — Cluster sheet reuses its Debit/Credit-by-cycle data)…');
  const debitMonths = await buildGlobalSheets(wb);
  const fleetDebitByCycle = new Map(debitMonths.map(m => [m.cycle_key, m]));
  // Cluster sheet also needs cycles before Dec 2025 is irrelevant here —
  // CYCLES only goes Dec'25 onward — but fleetDebitByCycle above was built
  // from the Dec'25+-filtered debitMonths, which already covers every
  // cycle CYCLES will look up. Re-fetch unfiltered only if a cycle is
  // missing (it won't be, but this keeps the lookup honest rather than
  // silently reusing a filtered map for a different purpose).
  for (const cycle_key of CYCLES) {
    if (!fleetDebitByCycle.has(cycle_key)) {
      const m = await MonthlyDebitSummary.findOne({ cycle_key }).lean();
      if (m) fleetDebitByCycle.set(cycle_key, m);
    }
  }

  console.log('\nBuilding Cluster Cycle Analysis…');
  await buildClusterCycleSheet(wb, fleetDebitByCycle);

  await wb.xlsx.writeFile(OUT_PATH);
  console.log(`\n✓ Wrote ${OUT_PATH}`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
