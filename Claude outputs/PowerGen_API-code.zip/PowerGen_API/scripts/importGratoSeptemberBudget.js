/**
 * importGratoSeptemberBudget.js
 * diesel-system/scripts/importGratoSeptemberBudget.js
 *
 * Imports "Grato_Sept_Approved_Budget.xlsx" — the September 2026 approved
 * per-site diesel budget for the GRATO SBC, the base per-cluster Tom Card
 * budget for the same cycle, and the two mid-month "extra fuel" approvals
 * that followed it (16-Sep and 18-Sep) — all from the same workbook.
 *
 * PHASE 180 ADDITION: the "Card Limit" sheet is now imported too. A first
 * dry run of this script against the real database (Phase 179) showed
 * ALL 10 extra-fuel top-ups skipping, because no "2026-09"
 * TomCardCycleBudget doc existed yet for any of the 7 GRATO cards — the
 * base card budget for the cycle had never been loaded into that
 * collection. Confirmed with the user before adding this rather than
 * assuming; see the CHANGELOG's Phase 180 entry. Import order in main()
 * now matters: Card Limit runs BEFORE Extra Fuel, in the same process, so
 * a single `--confirm` run creates the base card records and immediately
 * has something for the extra-fuel top-ups to land on.
 *
 * WHY THIS ISN'T importSiteBudgetFile() / services/siteBudgetImportService.js:
 *   That importer expects the full "Book11" file (~32 columns: generator
 *   KVA, CPH, run-hours, grid availability, tank data, etc.). This file
 *   is a much simpler approved-figure summary — just IHS ID / Operator
 *   Site ID / Cluster / New SBC / SBC-Region / Site Name / Diesel Budget
 *   (L) / Diesel Budget Amount (XAF) — so it needs its own parser, and it
 *   deliberately WRITES DIFFERENT FIELDS depending on whether a September
 *   SiteBudget doc already exists for a site (see "Budget sheet" below).
 *
 * TWO DIFFERENT TARGET COLLECTIONS, because the rows in this workbook are
 * at two different grains:
 *
 *   1. "Budget" sheet — ONE ROW PER SITE (166 GRATO sites). Goes to
 *      SiteBudget (site_id + cycle_key). This is the collection every
 *      other part of the system already reads for the current cycle's
 *      per-site budget (Diesel Manager's Budget Planning page, the
 *      fuel-request budget check, etc.).
 *
 *   2. "Card Limit" sheet (base) and "Extra Fuel of 16-09-2026" /
 *      "2nd Extra of 18-09-2026" sheets (top-ups) — ONE ROW PER CLUSTER /
 *      SHARED TOM CARD (7 GRATO clusters), matching the emails the extras
 *      came from ("RE: Grato September 1st/2nd Extrafuel request" —
 *      Charles Gnouve approving a cluster-level unlock, not a single
 *      site's allocation). These do NOT belong on SiteBudget — there is
 *      no clean way to attribute a shared card's budget/top-up to one
 *      specific site among several sharing it. They go to
 *      TomCardCycleBudget (cycle_key + card_number) instead, which is
 *      already exactly this grain (see models/TomCardCycleBudget.js and
 *      services/tomCardCycleBudgetImportService.js, which imports the
 *      fuller 12-column version of this same "Card Limit" concept for
 *      other cycles — this workbook's version only has 6 of those
 *      columns, hence a dedicated lightweight parser here rather than
 *      reusing that service).
 *
 * ── Budget sheet — CREATE vs UPDATE behave differently ──────────────────
 *   SiteBudget requires dg_kva and ccph (generator hardware specs) on
 *   every doc, and this file has neither — it only has the approved
 *   budget figure. So:
 *
 *     - If a "2026-09" SiteBudget doc ALREADY exists for a site (e.g. a
 *       full Book11 upload already happened this cycle): this script
 *       ONLY overwrites the budget figures on it (budget_liters,
 *       budget_xaf, and the *_approved_ihs pair — this file's own name is
 *       "...Approved Budget", so it's treated as the IHS-approved figure,
 *       same convention as services/siteBudgetImportService.js). Every
 *       other field (dg_kva, ccph, budgeted_rh, tank data, ...) is left
 *       untouched.
 *
 *     - If no "2026-09" doc exists yet for a site: this script looks up
 *       that site's MOST RECENT PRIOR SiteBudget doc (any earlier cycle)
 *       and carries forward only the fields that are genuinely
 *       month-independent hardware/reference data (dg_kva, ccph,
 *       topology, region, card_number, fuel_vendor, xaf_per_liter,
 *       is_fueling_site, site_priority, tank_bottom_l, dc_load_amps,
 *       site_load_kw, hybrid_expectation_hrs). It deliberately does NOT
 *       carry forward month-specific figures that this file doesn't
 *       provide (budgeted_rh, rh_per_day, final_grid_availability,
 *       last_visit_date/stock) — reusing e.g. August's run-hours target
 *       for September would be a fabricated number, not a real one.
 *       days_in_cycle IS recomputed correctly for September (30), since
 *       that's a calendar fact, not something to blindly carry over.
 *
 *     - If NO prior SiteBudget doc exists for a site at all (brand new
 *       site with no budget history in the system yet): the row is
 *       SKIPPED and reported — there is no source for required dg_kva/
 *       ccph, and inventing one would be worse than leaving it out.
 *
 * ── Card Limit sheet — base per-cluster card budget for the cycle ────────
 *   7 GRATO clusters, 6 columns only (New SBC, Cluster, Vendor, Card
 *   Number, Diesel Budget L, Diesel Budget Amount XAF) — a subset of the
 *   12-column layout tomCardCycleBudgetImportService.js expects (no
 *   recharge/limit columns in this particular file), so this uses its own
 *   narrow parser rather than that service. Upserts one TomCardCycleBudget
 *   doc per (cycle_key, card_number), setting only the fields this sheet
 *   actually has (sbc, cluster, vendor, budget_liters, budget_xaf,
 *   implied_xaf_per_liter) — never touching recharge_pct/card_limit_xaf/
 *   card_number_old, so a fuller import (before or after this one) isn't
 *   clobbered on those fields.
 *
 * ── Extra Fuel sheets — additive, existing cards only ────────────────────
 *   Each qualifying row $inc's that cluster's EXISTING "2026-09"
 *   TomCardCycleBudget doc's budget_liters/budget_xaf by the extra
 *   amount (not $set — two extra-fuel events in the same cycle must
 *   stack, not overwrite each other). Rows with no quantity (a cluster
 *   not covered by that particular extra) are skipped.
 *
 *   Only EXISTING cards are updated (upsert: false) — if no "2026-09"
 *   TomCardCycleBudget doc exists for a card by the time this phase runs,
 *   creating a partial doc from just the extra amount would produce a
 *   card budget missing its SBC/vendor/base-figure — worse than skipping
 *   and reporting it. In practice this now only matters if a cluster is
 *   missing from the Card Limit sheet itself (all 7 that appear in the
 *   extras also appear there, so this shouldn't currently trigger — kept
 *   as a safety net, not dead code).
 *
 *   No dedicated audit-trail record is written for each top-up event —
 *   TomCardCycleBudget has no history sub-array, unlike SiteBudget's
 *   transfers_in/transfers_out (see models/TomCardCycleBudget.js). The
 *   dry-run/--confirm console report below is the paper trail for this
 *   run. If a permanent per-event ledger turns out to matter (e.g. to
 *   show "16-Sep: +1,000 L, 18-Sep: +500 L" separately later, not just
 *   the blended total), that's a follow-up model change, not something
 *   this script invents unprompted.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed. Read-only until
 * then; a database connection is still required even for the dry run,
 * since the "carry forward" and "existing card" lookups need to read
 * what's already there.
 *
 * Usage:
 *   node scripts/importGratoSeptemberBudget.js
 *   node scripts/importGratoSeptemberBudget.js --confirm
 *
 * This sandbox has no network path to the production database (same
 * situation noted in scripts/importSbcBudgetFiles.js) — run this from
 * wherever MONGODB_URI actually points at the real one.
 */
'use strict';

require('dotenv').config();
const path = require('path');
const fs = require('fs');
const XLSX = require('xlsx');
const mongoose = require('mongoose');

const SiteBudget = require('../models/SiteBudget');
const { TomCardCycleBudget } = require('../models/TomCardCycleBudget');

const CONFIRM = process.argv.includes('--confirm');
const CYCLE_KEY = '2026-09';
const FILE_PATH = path.join(__dirname, 'historical_email_data', 'Grato_Sept_Approved_Budget.xlsx');
const EXPECTED_SBC = 'GRATO';

// ── Shared cell helpers (same contract as the other import services) ──────
function toStr(v) {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s === '' || s.toLowerCase() === 'nan' ? null : s;
}
function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
// Card numbers arrive as floats from Excel (e.g. 13408.0) — normalize the
// same way tomCardCycleBudgetImportService.js does, so they match however
// TomCardCycleBudget already stores them.
function toCardNumber(v) {
  const s = toStr(v);
  if (!s) return null;
  const n = Number(s);
  return !isNaN(n) && Number.isFinite(n) ? String(Math.trunc(n)) : s;
}
function daysInCycle(cycleKey) {
  const [y, m] = cycleKey.split('-').map(Number);
  return new Date(y, m, 0).getDate(); // day 0 of next month = last day of this one
}

// ── "Budget" sheet — header at row 2 (array index 1); a totals row sits
//    above it at row 1; data from row 3 (array index 2). Verified against
//    the actual uploaded file: 166 GRATO site rows, no nulls in either
//    budget column. ──────────────────────────────────────────────────────
const BUDGET_COLS = {
  ihs_id: 0, operator_site_id: 1, cluster: 2, new_sbc: 3, sbc_region: 4,
  site_name: 5, budget_liters: 6, budget_xaf: 7,
};

function parseBudgetSheet(wb) {
  const ws = wb.Sheets['Budget'];
  if (!ws) throw new Error(`"Budget" sheet not found. Sheets present: ${wb.SheetNames.join(', ')}`);
  const rawRows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });

  const header = rawRows[1] || [];
  const headerCheck = toStr(header[BUDGET_COLS.budget_liters]) || '';
  if (!/September 2026/i.test(headerCheck)) {
    throw new Error(`Unexpected "Budget" sheet header — expected a September 2026 budget column, got: "${headerCheck}". Aborting rather than importing the wrong month.`);
  }

  const rows = [];
  for (let i = 2; i < rawRows.length; i++) {
    const row = rawRows[i];
    if (!row || row.every(c => c == null)) continue;
    const site_id = toStr(row[BUDGET_COLS.ihs_id]);
    if (!site_id) continue;
    const sbc = toStr(row[BUDGET_COLS.new_sbc]);
    if (sbc !== EXPECTED_SBC) {
      throw new Error(`Row for site ${site_id} has New SBC "${sbc}", expected "${EXPECTED_SBC}" — this script is GRATO-only; aborting rather than silently writing another SBC's sites.`);
    }
    rows.push({
      site_id,
      cluster: toStr(row[BUDGET_COLS.cluster]),
      site_name: toStr(row[BUDGET_COLS.site_name]),
      budget_liters: toNum(row[BUDGET_COLS.budget_liters]),
      budget_xaf: toNum(row[BUDGET_COLS.budget_xaf]),
    });
  }
  return rows;
}

// ── "Card Limit" sheet — header at row 1 (array index 0), data from row 2
//    (array index 1) — same layout as the extra-fuel sheets, no totals row
//    above the header. Verified against the actual file: 7 GRATO cluster
//    rows (Bonaberi 1, Bonaberi 2, Edea, Kotto, Ndogbong, Pouma 1, Pouma 2),
//    no nulls. ────────────────────────────────────────────────────────────
const CARD_LIMIT_COLS = {
  new_sbc: 0, cluster: 1, vendor: 2, card_number: 3, budget_liters: 4, budget_xaf: 5,
};

function parseCardLimitSheet(wb) {
  const ws = wb.Sheets['Card Limit'];
  if (!ws) throw new Error(`"Card Limit" sheet not found. Sheets present: ${wb.SheetNames.join(', ')}`);
  const rawRows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });

  const rows = [];
  for (let i = 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    if (!row || row.every(c => c == null)) continue;
    const cluster = toStr(row[CARD_LIMIT_COLS.cluster]);
    const card_number = toCardNumber(row[CARD_LIMIT_COLS.card_number]);
    if (!cluster || !card_number) continue;
    const sbc = toStr(row[CARD_LIMIT_COLS.new_sbc]);
    if (sbc !== EXPECTED_SBC) {
      throw new Error(`"Card Limit" row for cluster ${cluster} has New SBC "${sbc}", expected "${EXPECTED_SBC}" — aborting.`);
    }
    rows.push({
      cluster,
      card_number,
      vendor: toStr(row[CARD_LIMIT_COLS.vendor]),
      budget_liters: toNum(row[CARD_LIMIT_COLS.budget_liters]),
      budget_xaf: toNum(row[CARD_LIMIT_COLS.budget_xaf]),
    });
  }
  return rows;
}

// ── Extra-fuel sheets — header at row 1 (array index 0), data from row 2
//    (array index 1). Different layout from the Budget sheet (no totals
//    row above the header here) — verified against the actual file. ─────
const EXTRA_COLS = {
  new_sbc: 0, cluster: 1, vendor: 2, card_number: 3, qty_l: 4, unit_price: 5, amount_xaf: 6,
};

function parseExtraFuelSheet(wb, sheetName, eventDate) {
  const ws = wb.Sheets[sheetName];
  if (!ws) throw new Error(`"${sheetName}" sheet not found.`);
  const rawRows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });

  const rows = [];
  for (let i = 1; i < rawRows.length; i++) {
    const row = rawRows[i];
    if (!row || row.every(c => c == null)) continue;
    const cluster = toStr(row[EXTRA_COLS.cluster]);
    const card_number = toCardNumber(row[EXTRA_COLS.card_number]);
    const qty_l = toNum(row[EXTRA_COLS.qty_l]);
    if (!cluster || !card_number) continue;
    if (qty_l == null || qty_l <= 0) continue; // cluster not covered by this particular extra
    const sbc = toStr(row[EXTRA_COLS.new_sbc]);
    if (sbc !== EXPECTED_SBC) {
      throw new Error(`"${sheetName}" row for cluster ${cluster} has New SBC "${sbc}", expected "${EXPECTED_SBC}" — aborting.`);
    }
    const unit_price = toNum(row[EXTRA_COLS.unit_price]);
    const amount_xaf = toNum(row[EXTRA_COLS.amount_xaf]) ?? (unit_price != null ? Math.round(qty_l * unit_price) : null);
    rows.push({ sheetName, event_date: eventDate, cluster, card_number, vendor: toStr(row[EXTRA_COLS.vendor]), qty_l, amount_xaf });
  }
  return rows;
}

// ── Fields carried forward from a site's most recent PRIOR SiteBudget doc
//    when creating its first "2026-09" record. Deliberately excludes
//    month-specific figures — see the module docblock. ───────────────────
const CARRY_FORWARD_FIELDS = [
  'dg_kva', 'ccph', 'dg_kva_actual', 'topology', 'region', 'is_fueling_site',
  'card_number', 'fuel_vendor', 'xaf_per_liter', 'site_priority',
  'tank_bottom_l', 'dc_load_amps', 'site_load_kw', 'hybrid_expectation_hrs',
];

async function main() {
  if (!fs.existsSync(FILE_PATH)) {
    throw new Error(`Source file not found at ${FILE_PATH}`);
  }
  const wb = XLSX.readFile(FILE_PATH);

  const budgetRows = parseBudgetSheet(wb);
  const cardLimitRows = parseCardLimitSheet(wb);
  const extraRows = [
    ...parseExtraFuelSheet(wb, 'Extra Fuel of 16-09-2026', '2026-09-16'),
    ...parseExtraFuelSheet(wb, '2nd Extra of 18-09-2026', '2026-09-18'),
  ];

  const totalBudgetL = budgetRows.reduce((s, r) => s + (r.budget_liters || 0), 0);
  const totalCardLimitL = cardLimitRows.reduce((s, r) => s + (r.budget_liters || 0), 0);
  const totalExtraL = extraRows.reduce((s, r) => s + (r.qty_l || 0), 0);
  console.log(`── Parsed "Budget" sheet: ${budgetRows.length} GRATO site(s), ${Math.round(totalBudgetL).toLocaleString()} L total. ──`);
  console.log(`── Parsed "Card Limit" sheet: ${cardLimitRows.length} GRATO cluster(s), ${Math.round(totalCardLimitL).toLocaleString()} L total. ──`);
  console.log(`── Parsed extra-fuel sheets: ${extraRows.length} cluster-event row(s), ${Math.round(totalExtraL).toLocaleString()} L total. ──\n`);

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log(`✓ Connected to MongoDB (${CONFIRM ? 'WILL WRITE' : 'read-only dry run'})\n`);

  try {
    await importBudgetSheet(budgetRows);
    console.log('');
    // Card Limit MUST run before Extra Fuel — the extras top up cards this
    // phase creates/confirms. Sequential await, same process: the extras
    // phase's own lookup below will see whatever this phase just wrote
    // (--confirm), and cardLimitPostState covers the dry-run preview case.
    const cardLimitPostState = await importCardLimitSheet(cardLimitRows);
    console.log('');
    await importExtraFuel(extraRows, cardLimitPostState);
  } finally {
    await mongoose.disconnect();
  }
}

async function importBudgetSheet(rows) {
  console.log(`── Budget sheet → SiteBudget (cycle_key="${CYCLE_KEY}") ──────────────────`);

  const siteIds = rows.map(r => r.site_id);
  const existingSept = await SiteBudget.find({ site_id: { $in: siteIds }, cycle_key: CYCLE_KEY }).lean();
  const existingSeptBySite = new Map(existingSept.map(d => [d.site_id, d]));

  // Latest prior record per site (any cycle before September), for the
  // carry-forward path. cycle_key is "YYYY-MM", which sorts lexically the
  // same as chronologically, so a simple string-descending sort works.
  const priorDocs = await SiteBudget.find({ site_id: { $in: siteIds }, cycle_key: { $lt: CYCLE_KEY } })
    .sort({ cycle_key: -1 })
    .lean();
  const latestPriorBySite = new Map();
  for (const d of priorDocs) {
    if (!latestPriorBySite.has(d.site_id)) latestPriorBySite.set(d.site_id, d);
  }

  const toUpdate = [];   // September doc already exists — budget figures only
  const toCreate = [];   // no September doc — carry forward + budget figures
  const skipped = [];    // no prior record at all — no dg_kva/ccph source

  for (const r of rows) {
    if (existingSeptBySite.has(r.site_id)) {
      toUpdate.push(r);
    } else if (latestPriorBySite.has(r.site_id)) {
      toCreate.push({ r, prior: latestPriorBySite.get(r.site_id) });
    } else {
      skipped.push(r);
    }
  }

  console.log(`  ${toUpdate.length} site(s) already have a "${CYCLE_KEY}" record — will update budget figures only.`);
  console.log(`  ${toCreate.length} site(s) need a new "${CYCLE_KEY}" record — will carry forward dg_kva/ccph/etc. from their latest prior cycle.`);
  console.log(`  ${skipped.length} site(s) skipped — no SiteBudget record in ANY prior cycle to source dg_kva/ccph from.`);
  if (skipped.length) {
    console.log(`    Skipped sites: ${skipped.map(r => `${r.site_id} (${r.site_name})`).join(', ')}`);
  }

  const ops = [];

  for (const r of toUpdate) {
    ops.push({
      updateOne: {
        filter: { site_id: r.site_id, cycle_key: CYCLE_KEY },
        update: {
          $set: {
            budget_liters: r.budget_liters,
            budget_xaf: r.budget_xaf,
            budget_liters_approved_ihs: r.budget_liters,
            budget_xaf_approved_ihs: r.budget_xaf,
            site_name: r.site_name,
            cluster: r.cluster,
            source_file: 'Grato_Sept_Approved_Budget.xlsx',
            imported_at: new Date(),
          },
        },
      },
    });
  }

  for (const { r, prior } of toCreate) {
    const setDoc = {
      site_name: r.site_name,
      cluster: r.cluster,
      budget_liters: r.budget_liters,
      budget_xaf: r.budget_xaf,
      budget_liters_approved_ihs: r.budget_liters,
      budget_xaf_approved_ihs: r.budget_xaf,
      days_in_cycle: daysInCycle(CYCLE_KEY), // recomputed for real, not carried
      source_file: 'Grato_Sept_Approved_Budget.xlsx',
      imported_at: new Date(),
    };
    for (const f of CARRY_FORWARD_FIELDS) {
      if (prior[f] != null) setDoc[f] = prior[f];
    }
    ops.push({
      updateOne: {
        filter: { site_id: r.site_id, cycle_key: CYCLE_KEY },
        update: { $set: setDoc, $setOnInsert: { site_id: r.site_id, cycle_key: CYCLE_KEY } },
        upsert: true,
      },
    });
  }

  if (!CONFIRM) {
    console.log(`\n  DRY RUN — ${ops.length} SiteBudget write(s) would be made. Re-run with --confirm to apply.`);
    return;
  }
  if (ops.length) {
    const result = await SiteBudget.bulkWrite(ops, { ordered: false, runValidators: true });
    console.log(`\n  ✓ SiteBudget: upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);
  } else {
    console.log('\n  Nothing to write.');
  }
}

/**
 * Card Limit sheet → TomCardCycleBudget, base per-cluster card budget.
 *
 * Returns a Map<card_number, {cluster, budget_liters, budget_xaf}>
 * representing the state each card WILL be in once this phase's writes
 * land — used by importExtraFuel() below so its own dry-run preview shows
 * the full chain (Card Limit creates the card -> Extra Fuel tops it up),
 * not just what's already in the database before this script ran. In a
 * --confirm run this is redundant with the real DB (this phase already
 * wrote for real, sequentially, before importExtraFuel's own query runs)
 * but harmless to overlay either way — same numbers either path.
 */
async function importCardLimitSheet(rows) {
  console.log(`── Card Limit sheet → TomCardCycleBudget (cycle_key="${CYCLE_KEY}") ────────`);

  const cardNumbers = rows.map(r => r.card_number);
  const existingCards = await TomCardCycleBudget.find({ cycle_key: CYCLE_KEY, card_number: { $in: cardNumbers } })
    .select('card_number')
    .lean();
  const existingCardSet = new Set(existingCards.map(d => d.card_number));

  const toCreate = rows.filter(r => !existingCardSet.has(r.card_number));
  const toUpdate = rows.filter(r => existingCardSet.has(r.card_number));
  console.log(`  ${toCreate.length} new card record(s) will be created for "${CYCLE_KEY}".`);
  console.log(`  ${toUpdate.length} card record(s) already exist for "${CYCLE_KEY}" — will refresh budget_liters/budget_xaf only.`);

  const postState = new Map();
  const ops = [];
  for (const r of rows) {
    const impliedRate = (r.budget_liters && r.budget_xaf) ? +(r.budget_xaf / r.budget_liters).toFixed(2) : null;
    postState.set(r.card_number, { cluster: r.cluster, budget_liters: r.budget_liters, budget_xaf: r.budget_xaf });
    ops.push({
      updateOne: {
        filter: { cycle_key: CYCLE_KEY, card_number: r.card_number },
        update: {
          $set: {
            sbc: EXPECTED_SBC,
            cluster: r.cluster,
            vendor: r.vendor,
            budget_liters: r.budget_liters,
            budget_xaf: r.budget_xaf,
            implied_xaf_per_liter: impliedRate,
          },
          $setOnInsert: { cycle_key: CYCLE_KEY, card_number: r.card_number },
        },
        upsert: true,
      },
    });
  }

  if (!CONFIRM) {
    console.log(`\n  DRY RUN — ${ops.length} TomCardCycleBudget write(s) would be made. Re-run with --confirm to apply.`);
    return postState;
  }
  if (ops.length) {
    const result = await TomCardCycleBudget.bulkWrite(ops, { ordered: false });
    console.log(`\n  ✓ TomCardCycleBudget: upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);
  } else {
    console.log('\n  Nothing to write.');
  }
  return postState;
}

async function importExtraFuel(rows, cardLimitPostState) {
  console.log(`── Extra-fuel sheets → TomCardCycleBudget (cycle_key="${CYCLE_KEY}") ──────`);

  const cardNumbers = [...new Set(rows.map(r => r.card_number))];
  const existingCards = await TomCardCycleBudget.find({ cycle_key: CYCLE_KEY, card_number: { $in: cardNumbers } })
    .select('card_number cluster budget_liters budget_xaf')
    .lean();
  const existingByCard = new Map(existingCards.map(d => [d.card_number, d]));
  // Overlay the Card Limit phase's post-state — in a --confirm run this
  // just restates what's now really in the DB; in a dry run it's what
  // makes the preview below reflect the full chain instead of stopping
  // short at "no card record exists yet" for every cluster.
  for (const [cardNumber, state] of cardLimitPostState) {
    if (!existingByCard.has(cardNumber)) existingByCard.set(cardNumber, { card_number: cardNumber, ...state });
  }

  const applicable = [];
  const skipped = [];
  for (const r of rows) {
    if (existingByCard.has(r.card_number)) applicable.push(r);
    else skipped.push(r);
  }

  console.log(`  ${applicable.length} extra-fuel event(s) will top up a "${CYCLE_KEY}" card record.`);
  console.log(`  ${skipped.length} event(s) skipped — that card isn't in this workbook's "Card Limit" sheet`
    + ` and has no existing "${CYCLE_KEY}" TomCardCycleBudget doc either.`);
  if (skipped.length) {
    console.log(`    Skipped: ${skipped.map(r => `${r.cluster} card ${r.card_number} (${r.sheetName}, +${r.qty_l} L)`).join('; ')}`);
  }

  // Preview each applicable top-up against its current total, since $inc
  // doesn't show a before/after on its own.
  for (const r of applicable) {
    const cur = existingByCard.get(r.card_number);
    const newL = (cur.budget_liters || 0) + r.qty_l;
    console.log(`    ${r.cluster} (card ${r.card_number}), ${r.event_date}: ${cur.budget_liters?.toLocaleString() ?? 0} L -> ${newL.toLocaleString()} L (+${r.qty_l.toLocaleString()} L)`);
    cur.budget_liters = newL; // update running total so a second event on the same card previews correctly
  }

  if (!CONFIRM) {
    console.log(`\n  DRY RUN — ${applicable.length} TomCardCycleBudget increment(s) would be made. Re-run with --confirm to apply.`);
    return;
  }

  const ops = applicable.map(r => ({
    updateOne: {
      filter: { cycle_key: CYCLE_KEY, card_number: r.card_number },
      update: {
        $inc: { budget_liters: r.qty_l, budget_xaf: r.amount_xaf || 0 },
      },
    },
  }));
  if (ops.length) {
    const result = await TomCardCycleBudget.bulkWrite(ops, { ordered: false });
    console.log(`\n  ✓ TomCardCycleBudget: modified ${result.modifiedCount} card record(s).`);
  } else {
    console.log('\n  Nothing to write.');
  }
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
