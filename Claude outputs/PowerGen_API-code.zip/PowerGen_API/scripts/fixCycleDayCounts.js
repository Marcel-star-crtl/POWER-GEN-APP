/**
 * fixCycleDayCounts.js
 * diesel-system/scripts/fixCycleDayCounts.js
 *
 * Corrects a real, confirmed off-by-one bug in DieselCycle.getOrCreateCurrent()
 * (and this script's own two duplicate implementations in
 * routes/dieselCycleRoutes.js and routes/otherRoutes.js — left unfixed
 * there since they take raw user input for end_date with an unverified
 * format, but not relevant to the bug this script corrects, since every
 * cycle actually in use was created via getOrCreateCurrent()).
 *
 * The bug: days_in_cycle was computed as
 *   Math.round((end_date - start_date) / 86400000) + 1
 * where end_date already includes the final day's near-complete time
 * (23:59:59). The raw millisecond difference already rounds up to the
 * correct inclusive day count on its own — the extra "+1" double-counted
 * the inclusivity, inflating every cycle's day count by exactly one.
 * E.g. a real 31-day cycle (26 Jul – 25 Aug) was stored as 32.
 *
 * This inflated number feeds directly into every run-hours and
 * consumption calculation that uses days_in_cycle (contractual
 * consumption, budget planning's engineering estimate, etc.) —
 * systematically overstating them by roughly 1/30th (~3%) for every
 * cycle ever auto-created.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed — same convention
 * as every other script in this folder.
 *
 * Usage:
 *   node scripts/fixCycleDayCounts.js
 *   node scripts/fixCycleDayCounts.js --confirm
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const DieselCycle = require('../models/DieselCycle');

const CONFIRM = process.argv.includes('--confirm');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const cycles = await DieselCycle.find({}).select('cycle_key label start_date end_date days_in_cycle').lean();
  console.log(`Found ${cycles.length} cycle(s) on file.\n`);

  const toFix = [];
  for (const c of cycles) {
    const correctDays = Math.round((new Date(c.end_date) - new Date(c.start_date)) / 86400000);
    if (correctDays !== c.days_in_cycle) {
      toFix.push({ ...c, correctDays });
    }
  }

  if (toFix.length === 0) {
    console.log('✓ Every cycle already has the correct day count — nothing to fix.');
    await mongoose.disconnect();
    return;
  }

  console.log(`${toFix.length} cycle(s) need correcting:`);
  for (const c of toFix) {
    console.log(`  ${c.cycle_key} (${c.label}): ${c.days_in_cycle} → ${c.correctDays}`);
  }

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to correct ${toFix.length} cycle(s).`);
    console.log('\nNote: any reconciliation or budget plan already computed using the');
    console.log('inflated day count will NOT be automatically recalculated by this');
    console.log('script — this only fixes the cycle record itself. Re-run reconciliation');
    console.log('for affected cycles afterward if you want their figures corrected too.');
    await mongoose.disconnect();
    return;
  }

  const ops = toFix.map(c => ({
    updateOne: {
      filter: { _id: c._id },
      update: { $set: { days_in_cycle: c.correctDays } },
    },
  }));
  const result = await DieselCycle.bulkWrite(ops, { ordered: false });
  console.log(`\n✓ Corrected ${result.modifiedCount} cycle(s).`);
  console.log('Reminder: re-run reconciliation for any affected cycle if you want its');
  console.log('already-computed figures corrected too — this script only fixed the');
  console.log('cycle record\'s day count itself.');

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
