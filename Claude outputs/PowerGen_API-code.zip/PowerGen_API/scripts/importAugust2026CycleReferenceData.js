/**
 * importAugust2026CycleReferenceData.js
 * diesel-system/scripts/importAugust2026CycleReferenceData.js
 *
 * Backfills the LIVE system with real per-site reference data recovered
 * from the AUGUST_2026_CYCLE_ANALYSIS workbook and the Tank Audit Plan
 * document — but ONLY where the live system genuinely has a gap.
 * Never overwrites data already present, since the live system may
 * hold something more current than this one-time Excel snapshot.
 *
 * Fills three distinct gaps:
 *   1. CycleEndStockSnapshot for cycle_key "2026-07" — July's closing
 *      stock, which is August's opening stock. This collection is
 *      "populated going forward, automatically" (see its own model
 *      docstring) — meaning it likely has NO July data at all if the
 *      feature launched after July closed. Filled from the workbook's
 *      Cycle Summary sheet's "Opening Stock (L)" column for August,
 *      which is exactly this figure.
 *   2. Site.Tank_Capacity_1 — filled from the Tank Audit Plan's
 *      "Data Entry Tank Capacity" column, only where currently null.
 *   3. CycleReconciliation.ccph for cycle_key "2026-08" — filled from
 *      the workbook's CCPH sheet, only where currently null/missing.
 *      (Not the Tank Audit Plan's own separate CPH reference column —
 *      confirmed in the earlier Excel analysis that CCPH sheet is the
 *      established authoritative source, matching the one real audit
 *      example already in that workbook.)
 *
 * Usage:
 *   node scripts/importAugust2026CycleReferenceData.js           (dry run)
 *   node scripts/importAugust2026CycleReferenceData.js --confirm (writes)
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');
const CONFIRM = process.argv.includes('--confirm');

const DATA_DIR = path.join(__dirname, 'tank_audit_data');
const WORKBOOK = path.join(DATA_DIR, 'AUGUST_2026_CYCLE_ANALYSIS.xlsx');

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function parseCycleSummary() {
  const wb = XLSX.readFile(WORKBOOK);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Cycle Summary'], { header: 1, defval: null, raw: true });
  const records = [];
  for (const row of rows.slice(4)) {
    if (!row || !row[0] || row[0] === 'IHS SITE ID') continue;
    const openingStock = row[12];
    if (typeof openingStock === 'string') continue; // skips genuine #N/A rows — see Phase 106's own Excel work for why these exist
    records.push({ site_id: String(row[0]).trim(), opening_stock_l: toNum(openingStock) });
  }
  return records;
}

function parseCcph() {
  const wb = XLSX.readFile(WORKBOOK);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['CCPH'], { header: 1, defval: null, raw: true });
  const ccph = {};
  for (const row of rows.slice(2)) {
    if (row && row[0] && !(row[0] in ccph)) ccph[row[0]] = toNum(row[1]);
  }
  return ccph;
}

/**
 * Cross-validation against a second, independent source for the same
 * figure. Confirmed directly (not assumed) that Cycle Summary's
 * "Opening Stock (L)" and SITE VISITS' "QTY OF FUEL PREVIOUSLY Left"
 * (from each site's earliest visit within the cycle) are the same
 * underlying data — 158 of 159 comparable sites matched exactly. The
 * one real mismatch found (IHS_BNB_021: 180 vs 470) is reported here
 * rather than silently accepted, since agreeing with your own source
 * 99% of the time is exactly the situation where the 1% disagreement
 * is worth a human's attention, not averaging over.
 */
function parseSiteVisitsOpeningStock() {
  const wb = XLSX.readFile(WORKBOOK);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['SITE VISITS'], { header: 1, defval: null, raw: true });
  const dataRows = rows.slice(2).filter(r => r && r[0]);
  const cycleStart = new Date(2026, 6, 26); // this cycle's own start date — see DieselCycle for the live equivalent
  const earliest = {};
  for (const r of dataRows) {
    const visitDateRaw = r[9];
    if (typeof visitDateRaw !== 'number') continue;
    const visitDate = new Date(Math.round((visitDateRaw - 25569) * 86400 * 1000));
    if (visitDate < cycleStart) continue;
    const prevLeft = toNum(r[15]);
    if (prevLeft === null) continue;
    if (!earliest[r[0]] || visitDate < earliest[r[0]].date) {
      earliest[r[0]] = { date: visitDate, opening_stock_l: prevLeft };
    }
  }
  return Object.fromEntries(Object.entries(earliest).map(([k, v]) => [k, v.opening_stock_l]));
}

async function main() {
  console.log('── Parsing source files ──────────────────────────────────');
  const cycleSummary = parseCycleSummary();
  const ccph = parseCcph();
  const siteVisitsOpening = parseSiteVisitsOpeningStock();
  console.log(`Cycle Summary: ${cycleSummary.length} site(s) with a real (non-error) opening stock figure.`);
  console.log(`CCPH sheet: ${Object.keys(ccph).length} site(s).`);
  console.log(`SITE VISITS (cross-check): ${Object.keys(siteVisitsOpening).length} site(s) with an earliest-cycle visit reading.`);

  const discrepancies = [];
  for (const rec of cycleSummary) {
    const alt = siteVisitsOpening[rec.site_id];
    if (alt != null && rec.opening_stock_l != null && Math.abs(alt - rec.opening_stock_l) >= 0.5) {
      discrepancies.push({ site_id: rec.site_id, cycle_summary: rec.opening_stock_l, site_visits: alt });
    }
  }
  if (discrepancies.length) {
    console.log(`\n⚠ ${discrepancies.length} site(s) where Cycle Summary's opening stock disagrees with SITE VISITS' own recorded reading:`);
    for (const d of discrepancies) console.log(`  ${d.site_id}: Cycle Summary says ${d.cycle_summary} L, SITE VISITS says ${d.site_visits} L`);
    console.log('  Cycle Summary\'s figure is still used below (the established source for this workbook) — this is flagged for manual review, not auto-corrected.');
  } else {
    console.log('\n✓ No discrepancies found between Cycle Summary and SITE VISITS for any comparable site.');
  }

  // Tank capacity — read via the same docx table extraction verified
  // earlier in this engagement (python's python-docx was used
  // interactively; here we re-derive it from a pre-extracted JSON
  // companion file to avoid a Node-side docx table parser dependency
  // this project doesn't already have).
  const fs = require('fs');
  const tankCapacityPath = path.join(DATA_DIR, 'tank_capacity_reference.json');
  if (!fs.existsSync(tankCapacityPath)) {
    console.log(`⚠ ${tankCapacityPath} not found — tank capacity backfill will be skipped this run. See README in this folder for how to regenerate it from TANK AUDIT PLAN.docx.`);
  }
  const tankCapacity = fs.existsSync(tankCapacityPath) ? JSON.parse(fs.readFileSync(tankCapacityPath, 'utf8')) : {};
  console.log(`Tank capacity reference: ${Object.keys(tankCapacity).length} site(s).`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log('Re-run with --confirm to write to the database.');
    console.log('(Connect + per-collection gap counts are only computed on a real run, since they require live queries.)');
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const Site = require('../models/Site');
  const CycleReconciliation = require('../models/CycleReconciliation');
  const CycleEndStockSnapshot = require('../models/CycleEndStockSnapshot');

  // ── 1. CycleEndStockSnapshot for 2026-07 ──────────────────────────
  let snapshotsCreated = 0, snapshotsSkippedExisting = 0;
  const snapshotsNoSiteMatch = [];
  for (const rec of cycleSummary) {
    if (rec.opening_stock_l == null) continue;
    const site = await Site.findOne({ IHS_ID_SITE: rec.site_id }).select('_id IHS_ID_SITE Site_Name GRATO_Cluster Region Tank_Capacity_1').lean();
    if (!site) { snapshotsNoSiteMatch.push(rec.site_id); continue; }

    const existing = await CycleEndStockSnapshot.findOne({ cycle_key: '2026-07', site: site._id });
    if (existing) { snapshotsSkippedExisting++; continue; }

    await CycleEndStockSnapshot.create({
      cycle_key: '2026-07',
      site: site._id,
      site_id: site.IHS_ID_SITE,
      site_name: site.Site_Name,
      cluster: site.GRATO_Cluster,
      region: site.Region,
      stock_l: rec.opening_stock_l,
      tank_capacity_l: site.Tank_Capacity_1 ?? null,
      fuel_level_source: 'field_visit',
      reading_age_hours: null, // unknown — this is a backfilled historical figure, not a fresh capture
    });
    snapshotsCreated++;
  }
  console.log(`\n── CycleEndStockSnapshot (2026-07, backfilled as August's opening stock) ──`);
  console.log(`  Created: ${snapshotsCreated} | Already existed (untouched): ${snapshotsSkippedExisting} | No matching Site record: ${snapshotsNoSiteMatch.length}`);
  if (snapshotsNoSiteMatch.length) {
    console.log(`  Site ID(s) with no matching live Site record: ${snapshotsNoSiteMatch.join(', ')}`);
  }
  if (snapshotsCreated === 0 && snapshotsSkippedExisting === 0 && snapshotsNoSiteMatch.length > 0) {
    console.log(`  ⚠ Every site failed to match against the live Site collection. This usually means the site_id format in this workbook (e.g. "${cycleSummary[0]?.site_id}") doesn't match what's stored as Site.IHS_ID_SITE in your database — worth checking one directly (e.g. via your admin panel or a quick findOne) before re-running.`);
  } else if (snapshotsCreated === 0 && snapshotsSkippedExisting > 0) {
    console.log(`  ℹ Nothing new was created because every matched site already has a snapshot for this cycle — that's the expected, successful outcome on a second run, not a failure.`);
  }

  // ── 2. Tank capacity backfill on Site ─────────────────────────────
  let capacityFilled = 0, capacitySkippedExisting = 0;
  const capacityNoSiteMatch = [];
  for (const [siteId, capacity] of Object.entries(tankCapacity)) {
    if (capacity == null) continue;
    const site = await Site.findOne({ IHS_ID_SITE: siteId });
    if (!site) { capacityNoSiteMatch.push(siteId); continue; }
    if (site.Tank_Capacity_1 != null) { capacitySkippedExisting++; continue; }
    site.Tank_Capacity_1 = toNum(capacity);
    await site.save();
    capacityFilled++;
  }
  console.log(`\n── Site.Tank_Capacity_1 backfill ──`);
  console.log(`  Filled: ${capacityFilled} | Already had a value (untouched): ${capacitySkippedExisting} | No matching Site record: ${capacityNoSiteMatch.length}`);
  if (capacityNoSiteMatch.length) {
    console.log(`  Site ID(s) with no matching live Site record: ${capacityNoSiteMatch.join(', ')}`);
  }

  // ── 3. CCPH backfill on CycleReconciliation ───────────────────────
  let ccphFilled = 0, ccphSkippedExisting = 0, ccphSkippedNoRecord = 0;
  for (const [siteId, val] of Object.entries(ccph)) {
    if (val == null) continue;
    const recon = await CycleReconciliation.findOne({ site_id: siteId, cycle_key: '2026-08' });
    if (!recon) { ccphSkippedNoRecord++; continue; }
    if (recon.ccph != null) { ccphSkippedExisting++; continue; }
    recon.ccph = val;
    await recon.save();
    ccphFilled++;
  }
  console.log(`\n── CycleReconciliation.ccph backfill (2026-08) ──`);
  console.log(`  Filled: ${ccphFilled} | Already had a value (untouched): ${ccphSkippedExisting} | No CycleReconciliation record yet for this site/cycle: ${ccphSkippedNoRecord}`);

  console.log('\n── Done. Nothing that already had real data was overwritten. ──');
  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
