/**
 * importMidCycleBudgetRelease.js
 * diesel-system/scripts/importMidCycleBudgetRelease.js
 *
 * Imports the mid-cycle partial budget release recovered from email
 * archives (the "August Refueling Details [50per] Budget_updated
 * [date].xlsx" thread) — August 2026's budget released early, in tiers
 * (50%, later 80%), in direct response to the same fuel shortage that
 * produced the ad-hoc requests (Phase 60). A genuinely distinct concept
 * from both the regular monthly cycle and ad-hoc requests — see
 * models/MidCycleBudgetRelease.js for the full reasoning.
 *
 * WHY ONLY THE SINGLE LATEST FILE:
 * Same verified pattern as the ad-hoc requests import (Phase 60) — each
 * update is a fuller snapshot of the same tracker, not an independent
 * daily file. Checked directly: the sheet itself was even renamed
 * between versions ("Sheet1" in the earliest recovered copy, "Planning
 * Progress" from 03-August onward), and the daily "done" columns grow
 * with each version. The file behind `MidCycleRelease_Aug2026_Latest.xlsx`
 * is now the 24-August snapshot (Phase 170 — the previously-latest
 * 05-August version is kept alongside it as
 * `MidCycleRelease_Aug2026_V1_ARCHIVE.xlsx` for reference, not used by
 * this script). Verified directly before swapping: the 24-August file's
 * "Planning Progress" still carries every column this parser requires
 * (`Site ID IHS`, `SITE NAME`, `Grato Cluster`, `Delivered`, `Budget`),
 * plus a later `80% Aug Budget` tier column in place of the older `50%
 * of Aug Budget`/`To be Added`/`Bud VS Delv Var` columns — all four are
 * optional fields here (looked up defensively via `idx[...] !==
 * undefined`), so their absence in this later file just means those
 * specific optional fields come back null, not a parse failure. "Recap"
 * and "Service desk Recap" both still resolve their date columns
 * dynamically (via `excelSerialToJs` over every header cell), so the
 * longer 26-Jul→24-Aug date range in this version needed no code change
 * — confirmed with a dry run: 164 site records, 191 cluster-day
 * records, 111,988 L delivered against 96,341 L released.
 *
 * WHY THE DAILY PER-SITE "DONE" COLUMNS ARE DELIBERATELY NOT PARSED:
 * Checked these directly before deciding — dozens of per-site daily
 * status columns, inconsistently labeled ("done 27-07-2027" vs.
 * "Done 31-07-2027" vs. "Ongoing 03-08-2027" — note the source file's
 * own typo year, 2027, kept as-is since it's what the file actually
 * says), and unclear whether a cell holds a boolean, a quantity, or a
 * status string. Too fragile to parse reliably. The "Recap" sheet
 * already aggregates daily delivery at the cluster level, cleanly and
 * consistently — used that for the daily trend instead of reconstructing
 * it unreliably from the messy per-site columns.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importMidCycleBudgetRelease.js
 *   node scripts/importMidCycleBudgetRelease.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const { MidCycleBudgetRelease, MidCycleReleaseDailyProgress } = require('../models/MidCycleBudgetRelease');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'MidCycleRelease_Aug2026_Latest.xlsx';
const RELEASE_CYCLE_KEY = '2026-08';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

// Same conversion already verified and used in importAdHocFuelRequests.js
// (Phase 60) — Excel serial date -> JS Date. Reused here since the
// Recap sheet's date column headers come through as raw serial numbers
// with the xlsx package, not auto-converted Date objects (verified
// directly against this real file before writing this parser).
function excelSerialToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400 * 1000));
  if (typeof v === 'string') {
    const d = new Date(v);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}

function parsePlanningProgress(rows) {
  const header = rows[1]; // verified directly: header is row index 1
  const idx = {};
  header.forEach((h, i) => { if (typeof h === 'string') idx[h.trim()] = i; });

  const required = ['Site ID IHS', 'SITE NAME', 'Grato Cluster', 'Delivered', 'Budget'];
  const missing = required.filter(c => !(c in idx));
  if (missing.length) {
    throw new Error(`"Planning Progress" is missing expected column(s): ${missing.join(', ')}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx['Site ID IHS']]) continue;
    records.push({
      site_id: String(row[idx['Site ID IHS']]).trim(),
      site_name: row[idx['SITE NAME']] ?? null,
      cluster: row[idx['Grato Cluster']] ?? null,
      region: idx['REGION'] !== undefined ? row[idx['REGION']] : null,
      topology: idx['Functional topology'] !== undefined ? row[idx['Functional topology']] : null,
      priority: idx['Site priority'] !== undefined ? row[idx['Site priority']] : null,
      delivered_l: toNum(row[idx['Delivered']]),
      released_budget_l: toNum(row[idx['Budget']]),
      variance_l: idx['Bud VS Delv Var'] !== undefined ? toNum(row[idx['Bud VS Delv Var']]) : null,
      to_be_added_l: idx['To be Added'] !== undefined ? toNum(row[idx['To be Added']]) : null,
      tier_50pct_l: idx['50% of Aug Budget'] !== undefined ? toNum(row[idx['50% of Aug Budget']]) : null,
      tier_80pct_l: idx['80% Aug Budget'] !== undefined ? toNum(row[idx['80% Aug Budget']]) : null,
    });
  }
  return records;
}

function parseRecap(rows) {
  const header = rows[1]; // 'Cluster', 'Refueling done', <date serials...>, 'Comment'
  const dateColumns = [];
  header.forEach((h, i) => {
    if (i <= 1) return; // skip 'Cluster', 'Refueling done'
    if (typeof h === 'string' && h.toLowerCase() === 'comment') return;
    const date = excelSerialToJs(h);
    if (date) dateColumns.push({ colIndex: i, date });
  });

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[0]) continue;
    const cluster = String(row[0]).trim();
    for (const { colIndex, date } of dateColumns) {
      const delivered = toNum(row[colIndex]);
      if (delivered === null) continue; // no entry for this cluster/day — skip, don't fabricate a zero
      records.push({ cluster, date, delivered_l: delivered });
    }
  }
  return records;
}

// Merges the Service Desk team's own independently-tracked figures into
// the main Recap records, matched by exact cluster name + date. Checked
// directly before writing this: both sheets use identical cluster name
// spellings (including the source's own inconsistent capitalization,
// e.g. "pouma 1" lowercase) — no normalization needed for the match
// itself. The two sources' numbers genuinely disagree for the same
// cluster/day; both are kept, not merged into one.
function mergeServiceDeskRecap(mainRecords, sdRows) {
  const sdMap = new Map(); // "cluster|date" -> delivered_l
  const header = sdRows[1];
  const dateColumns = [];
  header.forEach((h, i) => {
    if (i <= 1) return;
    if (typeof h === 'string' && h.toLowerCase() === 'comment') return;
    const date = excelSerialToJs(h);
    if (date) dateColumns.push({ colIndex: i, date });
  });
  for (const row of sdRows.slice(2)) {
    if (!row || !row[0]) continue;
    const cluster = String(row[0]).trim();
    for (const { colIndex, date } of dateColumns) {
      const delivered = toNum(row[colIndex]);
      if (delivered === null) continue;
      sdMap.set(`${cluster}|${date.toISOString().slice(0, 10)}`, delivered);
    }
  }

  let matched = 0, sdOnly = [];
  for (const r of mainRecords) {
    const key = `${r.cluster}|${r.date.toISOString().slice(0, 10)}`;
    if (sdMap.has(key)) {
      r.service_desk_delivered_l = sdMap.get(key);
      matched++;
      sdMap.delete(key);
    }
  }
  // Any Service Desk entries with no corresponding main Recap record —
  // added as their own record rather than silently dropped.
  for (const [key, delivered] of sdMap.entries()) {
    const [cluster, dateStr] = key.split('|');
    sdOnly.push({ cluster, date: new Date(dateStr), delivered_l: null, service_desk_delivered_l: delivered });
  }
  return { matched, sdOnlyCount: sdOnly.length, records: [...mainRecords, ...sdOnly] };
}

async function main() {
  const filePath = path.join(DATA_DIR, SOURCE_FILE);
  const wb = XLSX.readFile(filePath);
  console.log(`Reading ${SOURCE_FILE} — sheets: ${wb.SheetNames.join(', ')}\n`);

  const ppRows = XLSX.utils.sheet_to_json(wb.Sheets['Planning Progress'], { header: 1, defval: null, raw: true });
  const siteRecords = parsePlanningProgress(ppRows);
  console.log(`"Planning Progress": ${siteRecords.length} site record(s) parsed.`);

  const recapRows = XLSX.utils.sheet_to_json(wb.Sheets['Recap'], { header: 1, defval: null, raw: true });
  let dailyRecords = parseRecap(recapRows);
  console.log(`"Recap": ${dailyRecords.length} cluster-day record(s) parsed.`);

  if (wb.SheetNames.includes('Service desk Recap')) {
    const sdRows = XLSX.utils.sheet_to_json(wb.Sheets['Service desk Recap'], { header: 1, defval: null, raw: true });
    const merged = mergeServiceDeskRecap(dailyRecords, sdRows);
    dailyRecords = merged.records;
    console.log(`"Service desk Recap": merged into ${merged.matched} existing record(s), ${merged.sdOnlyCount} additional Service-Desk-only entry(ies) — kept as separate figures, not reconciled to one number.`);
  }

  const totalDelivered = siteRecords.reduce((s, r) => s + (r.delivered_l || 0), 0);
  const totalReleased = siteRecords.reduce((s, r) => s + (r.released_budget_l || 0), 0);
  console.log(`\nTotals: ${Math.round(totalDelivered).toLocaleString()} L delivered against ${Math.round(totalReleased).toLocaleString()} L released.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${siteRecords.length} site record(s) and ${dailyRecords.length} daily record(s).`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const siteOps = siteRecords.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id },
      update: { $set: { ...r, release_cycle_key: RELEASE_CYCLE_KEY, source_file: SOURCE_FILE, source_date: new Date() } },
      upsert: true,
    },
  }));
  const siteResult = await MidCycleBudgetRelease.bulkWrite(siteOps, { ordered: false });
  console.log(`✓ Site snapshots: upserted ${siteResult.upsertedCount}, modified ${siteResult.modifiedCount}.`);

  const dailyOps = dailyRecords.map(r => ({
    updateOne: {
      filter: { release_cycle_key: RELEASE_CYCLE_KEY, cluster: r.cluster, date: r.date },
      update: { $set: { ...r, release_cycle_key: RELEASE_CYCLE_KEY, source_file: SOURCE_FILE } },
      upsert: true,
    },
  }));
  const dailyResult = await MidCycleReleaseDailyProgress.bulkWrite(dailyOps, { ordered: false });
  console.log(`✓ Daily cluster progress: upserted ${dailyResult.upsertedCount}, modified ${dailyResult.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
