/**
 * importMarch2026EstimateToClose.js
 * diesel-system/scripts/importMarch2026EstimateToClose.js
 *
 * Imports March 2026's mid-cycle "estimate to close" snapshot — see
 * models/MidCycleEstimateSnapshot.js for why this is a genuinely
 * different document type from everything else recovered.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importMarch2026EstimateToClose.js
 *   node scripts/importMarch2026EstimateToClose.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const MidCycleEstimateSnapshot = require('../models/MidCycleEstimateSnapshot');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'MarEstimateToClose_19Mar2026.xlsx';
const MONTH_KEY = '2026-03';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelSerialToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400 * 1000));
  return null;
}

function findCol(header, name) {
  const target = String(name).replace(/\s+/g, ' ').trim();
  const i = header.findIndex(h => typeof h === 'string' && h.replace(/\s+/g, ' ').trim() === target);
  return i === -1 ? null : i;
}

async function main() {
  const filePath = path.join(DATA_DIR, SOURCE_FILE);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Sheet1'], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findCol(header, 'IHS Site ID'),
    cluster: findCol(header, 'Cluster'),
    site_name: findCol(header, 'Site Name'),
    region: findCol(header, 'State'),
    sbc: findCol(header, 'SBC'),
    topology: findCol(header, 'Site Topology'),
    date: findCol(header, 'Date'),
    initial_budget: findCol(header, 'Initial Budget'),
    first_extra: findCol(header, '1st Extra'),
    second_extra: findCol(header, '2nd Extra'),
    combined: findCol(header, 'Init + 1st Extra + 2nd Extra'),
    refuel_done: findCol(header, 'Total Refuel done'),
    balance: findCol(header, 'Balance'),
    qty_left: findCol(header, 'Qty Left'),
  };

  const missing = Object.entries(idx).filter(([, v]) => v === null);
  if (missing.length) {
    throw new Error(`${SOURCE_FILE} missing expected column(s): ${missing.map(([k]) => k).join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      cluster: row[idx.cluster] ?? null,
      site_name: row[idx.site_name] ?? null,
      region: row[idx.region] ?? null,
      sbc: row[idx.sbc] ?? null,
      topology: row[idx.topology] ?? null,
      month_key: MONTH_KEY,
      snapshot_date: excelSerialToJs(row[idx.date]),
      initial_budget_l: toNum(row[idx.initial_budget]),
      first_extra_l: toNum(row[idx.first_extra]),
      second_extra_l: toNum(row[idx.second_extra]),
      combined_budget_l: toNum(row[idx.combined]),
      total_refuel_done_l: toNum(row[idx.refuel_done]),
      balance_l: toNum(row[idx.balance]),
      qty_left_l: toNum(row[idx.qty_left]),
      source_file: SOURCE_FILE,
    });
  }

  console.log(`Parsed ${records.length} site record(s) for ${MONTH_KEY} (mid-cycle snapshot, 19 March 2026 reference date).`);
  const totalInitial = records.reduce((s, r) => s + (r.initial_budget_l || 0), 0);
  const totalExtra1 = records.reduce((s, r) => s + (r.first_extra_l || 0), 0);
  const totalExtra2 = records.reduce((s, r) => s + (r.second_extra_l || 0), 0);
  const totalRefuel = records.reduce((s, r) => s + (r.total_refuel_done_l || 0), 0);
  console.log(`  Initial budget: ${Math.round(totalInitial).toLocaleString()} L. 1st extra: ${Math.round(totalExtra1).toLocaleString()} L. 2nd extra: ${Math.round(totalExtra2).toLocaleString()} L. Total refuel done: ${Math.round(totalRefuel).toLocaleString()} L.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${records.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  await MidCycleEstimateSnapshot.deleteMany({ source_file: SOURCE_FILE });
  const result = await MidCycleEstimateSnapshot.insertMany(records);
  console.log(`✓ Inserted ${result.length} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
