/**
 * restoreClusterRemovalBackup.js
 * diesel-system/scripts/restoreClusterRemovalBackup.js
 *
 * Phase 133. Restores everything removeNonKeptClusters.js (Phase 129)
 * deleted, from the automatic backup that script wrote before it
 * touched anything. This is exactly what that backup step existed
 * for — the user decided the cluster removal was broader than what
 * they actually wanted and asked for a full restore.
 *
 * Reuses the EXACT SAME label→model mapping from
 * removeNonKeptClusters.js (SITE_ID_COLLECTIONS, CLUSTER_ONLY_
 * COLLECTIONS, and the same loadModel() helper) rather than
 * redefining it separately — a hand-written second mapping here could
 * silently drift out of sync with what was actually deleted and
 * backed up, which is exactly the kind of mistake that matters most
 * on a restore.
 *
 * Re-inserts every document with its ORIGINAL _id preserved — critical
 * so that if anything else in the database still references these
 * IDs (even indirectly, or added since the deletion), those references
 * resolve correctly again rather than pointing at nothing.
 *
 * Safe to re-run: uses insertMany with ordered:false and reports
 * duplicate-key skips separately from real insertions, so re-running
 * against a partially-restored database won't double-insert or crash
 * on the records already restored.
 *
 * Usage:
 *   node scripts/restoreClusterRemovalBackup.js <backup-folder-path>            (dry run)
 *   node scripts/restoreClusterRemovalBackup.js <backup-folder-path> --confirm  (writes)
 *
 * Example:
 *   node scripts/restoreClusterRemovalBackup.js scripts/cluster_removal_backup_1787925434713 --confirm
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const CONFIRM = process.argv.includes('--confirm');
const backupDirArg = process.argv[2];

// Identical to removeNonKeptClusters.js — see that file for the full
// reasoning behind each entry. Kept in sync deliberately, not
// re-derived.
const SITE_ID_COLLECTIONS = [
  { model: 'AdHocFuelRequest', field: 'site_id' },
  { model: 'BudgetRequestApproval', field: 'site_id' },
  { model: 'CmsDailyRecord', field: 'site_id' },
  { model: 'CycleEndStockSnapshot', field: 'site_id' },
  { model: 'CycleReconciliation', field: 'site_id' },
  { model: 'DieselAlert', field: 'site_id' },
  { model: 'FieldVisitRecord', field: 'site_id' },
  { model: 'FuelConsumption', field: 'site_id' },
  { model: 'FuelDeliveryEvent', field: 'site_id' },
  { model: 'FuelPurchase', field: 'site_id' },
  { model: 'FuelRequest', field: 'site_id' },
  { model: 'GeneratorAssignmentLedger', field: 'site_id' },
  { model: 'GeneratorUpdate', field: 'site_id' },
  { model: 'HistoricalFieldVisit', field: 'site_id' },
  { model: 'HistoricalMonthlyRecord', field: 'site_id' },
  { model: 'HistoricalSiteStockSnapshot', field: 'site_id' },
  { model: 'Maintenance', field: 'site_id' },
  { model: 'MidCycleBudgetRelease', field: 'site_id', key: 'MidCycleBudgetRelease' },
  { model: 'MidCycleEstimateSnapshot', field: 'site_id' },
  { model: 'PlannedVsSuppliedDelivery', field: 'site_id' },
  { model: 'SiteBudget', field: 'site_id' },
  { model: 'SiteConsumptionHistory', field: 'site_id' },
  { model: 'SiteEngineeringParams', field: 'site_id' },
  { model: 'SiteVisit', field: 'site_id' },
  { model: 'TankAudit', field: 'site_id_ihs' },
  { model: 'TankLevelReading', field: 'site_id' },
  { model: 'TankLevelUpload', field: 'site_id' },
  { model: 'TechnicianSiteAudit', field: 'site_id_ihs' },
  { model: 'TomCardTransaction', field: 'site_id' },
  { model: 'ValidationRecord', field: 'site_id' },
  { model: 'PartRequest', field: 'site' },
];
const CLUSTER_ONLY_COLLECTIONS = [
  { model: 'TomCardAllocation', field: 'Cluster' },
  { model: 'TomCardCycleBudget', field: 'Cluster', key: 'TomCardCycleBudget' },
  { model: 'TomCardCycleBudget', field: 'cluster', key: 'TomCardCycleBudgetUpload', label: 'TomCardCycleBudgetUpload' },
  { model: 'TomCardMapping', field: 'cluster', key: 'TomCardMapping' },
  { model: 'TomCardMapping', field: 'cluster', key: 'TomCardUpload', label: 'TomCardUpload' },
  { model: 'Tower', field: 'Cluster' },
  { model: 'MidCycleBudgetRelease', field: 'cluster', key: 'MidCycleReleaseDailyProgress', label: 'MidCycleReleaseDailyProgress' },
];

function loadModel(entry) {
  const mod = require(`../models/${entry.model}`);
  if (!entry.key) return mod;
  return mod[entry.key];
}

// Build label -> Model lookup, same labels removeNonKeptClusters.js
// used as backup filenames.
function buildLabelMap() {
  const map = new Map();
  for (const entry of [...SITE_ID_COLLECTIONS, ...CLUSTER_ONLY_COLLECTIONS]) {
    const label = entry.label || entry.key || entry.model;
    map.set(label, loadModel(entry));
  }
  return map;
}

async function main() {
  if (!backupDirArg) {
    console.error('Usage: node scripts/restoreClusterRemovalBackup.js <backup-folder-path> [--confirm]');
    console.error('Example: node scripts/restoreClusterRemovalBackup.js scripts/cluster_removal_backup_1787925434713 --confirm');
    process.exit(1);
  }
  const backupDir = path.resolve(backupDirArg);
  if (!fs.existsSync(backupDir)) {
    console.error(`✗ Backup folder not found: ${backupDir}`);
    process.exit(1);
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const Site = require('../models/Site');
  const ClusterModel = require('../models/Cluster');
  const SiteAuditChecklist = require('../models/SiteAuditChecklist');
  const labelMap = buildLabelMap();

  // Special-cased, same as the delete script: Site, Cluster, and
  // SiteAuditChecklist aren't in either config array above.
  labelMap.set('Site', Site);
  labelMap.set('Cluster', ClusterModel);
  labelMap.set('SiteAuditChecklist', SiteAuditChecklist);

  const files = fs.readdirSync(backupDir).filter(f => f.endsWith('.json'));
  console.log(`Found ${files.length} backup file(s) in ${backupDir}\n`);

  const plan = [];
  for (const file of files) {
    const label = file.replace(/\.json$/, '');
    const Model = labelMap.get(label);
    if (!Model) {
      console.log(`  ⚠ ${file}: no known model for label "${label}" — skipping this file, not guessing`);
      continue;
    }
    const raw = fs.readFileSync(path.join(backupDir, file), 'utf8');
    let docs;
    try {
      docs = JSON.parse(raw);
    } catch (err) {
      console.log(`  ⚠ ${file}: not valid JSON (${err.message}) — skipping`);
      continue;
    }
    if (!Array.isArray(docs) || docs.length === 0) continue; // empty backups (collections that had 0 matches) — nothing to restore
    plan.push({ label, Model, docs });
    console.log(`  ${label}: ${docs.length} document(s) to restore`);
  }

  const totalDocs = plan.reduce((sum, p) => sum + p.docs.length, 0);
  console.log(`\nTotal documents to restore: ${totalDocs}`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log('Re-run with --confirm to actually restore these documents.');
    await mongoose.disconnect();
    return;
  }

  console.log('\n── Restoring ──');
  let totalInserted = 0, totalSkippedExisting = 0, totalErrored = 0;
  for (const { label, Model, docs } of plan) {
    try {
      const result = await Model.insertMany(docs, { ordered: false });
      totalInserted += result.length;
      console.log(`  ✓ ${label}: restored ${result.length}`);
    } catch (err) {
      // insertMany with ordered:false throws a BulkWriteError that
      // still reports how many succeeded before/around the failures —
      // duplicate-key errors here mean "already restored," not a real
      // problem, since this script is meant to be safely re-runnable.
      const inserted = err.insertedDocs?.length ?? err.result?.insertedCount ?? 0;
      const dupKeyErrors = (err.writeErrors || []).filter(e => e.code === 11000);
      const otherErrors = (err.writeErrors || []).filter(e => e.code !== 11000);
      totalInserted += inserted;
      totalSkippedExisting += dupKeyErrors.length;
      totalErrored += otherErrors.length;
      console.log(`  ${label}: restored ${inserted}, already existed (skipped) ${dupKeyErrors.length}${otherErrors.length ? `, ✗ ${otherErrors.length} real error(s)` : ''}`);
      for (const e of otherErrors.slice(0, 3)) console.log(`      ✗ ${e.errmsg || e.message}`);
    }
  }

  console.log(`\n✓ Done. Restored: ${totalInserted} | Already existed (skipped): ${totalSkippedExisting} | Errored: ${totalErrored}`);
  if (totalErrored > 0) {
    console.log('Some documents had real errors during restore — review the messages above. The backup files themselves are untouched, so this can be retried.');
  }

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
