/**
 * lookupTechnicianTankAudits.js
 * diesel-system/scripts/lookupTechnicianTankAudits.js
 *
 * Read-only. Looks up a technician by email and lists their recent
 * TankAudit records (both 'draft' and 'submitted'), with site,
 * status, and timestamps — so what has actually landed on the server
 * can be checked directly against what the technician reports having
 * done in the field.
 *
 * This CANNOT see anything still sitting in a device's local offline
 * queue — that data genuinely doesn't exist on the server until it
 * syncs. What this can do is confirm exactly what HAS arrived, which
 * is the other half of the picture needed to know what's actually
 * still missing.
 *
 * Usage:
 *   node scripts/lookupTechnicianTankAudits.js <email> [--days=14]
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const TankAudit = require('../models/TankAudit');

async function main() {
  const email = process.argv[2];
  if (!email) {
    console.error('Usage: node scripts/lookupTechnicianTankAudits.js <email> [--days=14]');
    process.exit(1);
  }
  const daysArg = process.argv.find(a => a.startsWith('--days='));
  const days = daysArg ? parseInt(daysArg.split('=')[1], 10) : 14;

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const user = await User.findOne({ email: email.trim().toLowerCase() }).lean();
  if (!user) {
    console.log(`✗ No user found with email "${email}". Checked exact match, lowercase — if this is wrong, the record may use a different casing or a typo may exist in either place.`);
    await mongoose.disconnect();
    return;
  }
  console.log(`Found user: ${user.fullName || user.email} (${user.role}), id ${user._id}\n`);

  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const audits = await TankAudit.find({ created_by: user._id, updatedAt: { $gte: since } })
    .sort({ updatedAt: -1 })
    .select('site_id_ihs site_name status createdAt updatedAt client_id')
    .lean();

  if (!audits.length) {
    console.log(`No TankAudit records (draft or submitted) found for this user in the last ${days} day(s).`);
    console.log('This means: either nothing has synced yet for this window, or everything that was going to sync already did, further back than this window.');
    await mongoose.disconnect();
    return;
  }

  console.log(`── ${audits.length} record(s) on the server in the last ${days} day(s): ──\n`);
  for (const a of audits) {
    const created = new Date(a.createdAt).toLocaleString();
    const updated = new Date(a.updatedAt).toLocaleString();
    console.log(`${a.status === 'submitted' ? '✓ SUBMITTED' : '… draft    '}  ${a.site_name || a.site_id_ihs}  |  created ${created}  |  last updated ${updated}`);
  }
  console.log('\nCross-check this list against what the technician reports having done in the field.');
  console.log('A site they say they audited that does NOT appear here is genuinely still sitting');
  console.log('unsynced in their device\'s local queue — the only fix is that specific device coming');
  console.log('online with the app open (or foregrounded, after the Phase 103 fix).');

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
