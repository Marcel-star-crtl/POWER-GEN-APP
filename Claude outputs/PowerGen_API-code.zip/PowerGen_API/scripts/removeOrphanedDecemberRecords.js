/**
 * removeOrphanedDecemberRecords.js
 * diesel-system/scripts/removeOrphanedDecemberRecords.js
 *
 * Optional cleanup — same purpose as removeOrphanedMarchRecord.js, but for
 * December 2025's larger gap (up to 20 records, not just one). Deletes
 * HistoricalMonthlyRecord documents for month_key '2025-12' that have no
 * final_consumption_l (i.e. never touched by the real Dec2025_Validation.xlsx
 * import) — sites that were budgeted in SbcBudget_Dec2025.xlsx (184 sites)
 * but have no reconciliation data anywhere for December.
 *
 * This is a real, meaningful data point (budgeted but unaccounted for),
 * not necessarily an error — the exact same judgment call as March's
 * single orphan. Read the surrounding conversation, and run
 * findOrphanedDecemberRecords.js first, before running this. Only run it
 * if you've decided you specifically want every December
 * HistoricalMonthlyRecord to represent a site with real consumption data.
 *
 * Scoped precisely: only touches month_key '2025-12' AND a null
 * final_consumption_l together — never a record that has real consumption
 * data, regardless of its source_file (see findOrphanedDecemberRecords.js's
 * docblock for why source_file alone isn't a safe filter here).
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/removeOrphanedDecemberRecords.js
 *   node scripts/removeOrphanedDecemberRecords.js --confirm
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const FILTER = { month_key: '2025-12', final_consumption_l: null };

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const matches = await HistoricalMonthlyRecord.find(FILTER, { site_id: 1, source_file: 1, budget_liters: 1 }).sort({ site_id: 1 }).lean();

  if (matches.length === 0) {
    console.log('No matching records found — nothing to do (they may have already been removed, or the data has changed since this script was written).');
    await mongoose.disconnect();
    return;
  }

  console.log(`Found ${matches.length} record(s) to remove:`);
  for (const r of matches) {
    console.log(`  site_id: ${r.site_id} | source_file: ${r.source_file} | budget_liters: ${r.budget_liters}`);
  }

  if (!CONFIRM) {
    console.log('\n── DRY RUN — nothing was deleted. ─────────────────────────────');
    console.log(`Re-run with --confirm to actually delete these ${matches.length} record(s).`);
    await mongoose.disconnect();
    return;
  }

  const result = await HistoricalMonthlyRecord.deleteMany(FILTER);
  console.log(`\n✓ Deleted ${result.deletedCount} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
