/**
 * importHistoricalFuelPurchases.js
 * diesel-system/scripts/importHistoricalFuelPurchases.js
 *
 * Imports individual fuel card purchase transactions from each
 * recovered validation file's own "Purchases" / "Purchases breakdown
 * (Update)" sheet. See models/HistoricalFuelPurchase.js for why this is
 * a distinct concept from the field-visit delivery data (Phase 68) —
 * procurement vs. distribution.
 *
 * WHY DATE + HOUR ARE COMBINED:
 * Verified directly against the real file with the xlsx package before
 * writing this — "Date" and "Hour" are two separate columns (Date as a
 * whole-number Excel serial, Hour as a same-day fractional serial), not
 * one combined timestamp. Tested the combination against a known real
 * value before trusting it: Date=46015, Hour=0.4256597222222222
 * combines to 2025-12-24T10:12:57Z, matching what was independently
 * observed exploring the same row with a different library.
 *
 * WHY THE SHEET NAME IS RESOLVED PER FILE, NOT HARDCODED:
 * December's file names this sheet "Purchases"; every other recovered
 * month names it "Purchases breakdown (Update)" — checked directly
 * rather than assumed consistent, same as every other sheet-name
 * variance found in this recovery effort (Validation/Validations,
 * Analysis, etc.).
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importHistoricalFuelPurchases.js
 *   node scripts/importHistoricalFuelPurchases.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalFuelPurchase = require('../models/HistoricalFuelPurchase');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

const MONTHS = [
  // 2025 months (Phase 90) — April/May use a singular "Purchase" sheet
  // name and several different column names, both handled by the
  // flexible matching added to this script. November genuinely has no
  // Purchases sheet at all — confirmed directly, not included below.
  { month_key: '2025-04', file: 'Apr2025_Validation.xlsx' },
  { month_key: '2025-05', file: 'May2025_Validation.xlsx' },
  { month_key: '2025-06', file: 'Jun2025_Validation.xlsx' },
  { month_key: '2025-07', file: 'Jul2025_Validation.xlsx' },
  { month_key: '2025-08', file: 'Aug2025_Validation.xlsx' },
  { month_key: '2025-09', file: 'Sep2025_Validation.xlsx' },
  { month_key: '2025-10', file: 'Oct2025_Validation.xlsx' },
  { month_key: '2025-12', file: 'Dec2025_Validation.xlsx' },
  { month_key: '2026-01', file: 'Jan2026_Validation.xlsx' },
  { month_key: '2026-02', file: 'Feb2026_Validation.xlsx' },
  { month_key: '2026-04', file: 'Apr2026_Validation.xlsx' },
  { month_key: '2026-05', file: 'May2026_Validation.xlsx' },
  { month_key: '2026-03', file: 'Mar2026_Validation.xlsx' }, // found Phase 83 — standard row 1 alignment, same sheet name as other months
  // July has no Purchases sheet — consistent with it being the least
  // mature recovered month (no Debit sheet either, see Phase 67).
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelSerialToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400 * 1000));
  return null;
}

function findCol(header, name) {
  const i = header.findIndex(h => typeof h === 'string' && h.trim() === name);
  return i === -1 ? null : i;
}

function findColAny(header, names) {
  for (const name of names) {
    const idx = findCol(header, name);
    if (idx !== null) return idx;
  }
  return null;
}

function parsePurchasesSheet(filePath, month_key) {
  const wb = XLSX.readFile(filePath);
  // April/May 2025 genuinely use singular "Purchase" — verified
  // directly, the existing startsWith('purchases') fallback wouldn't
  // have matched it (a shorter string can't start with a longer one).
  const sheetName = wb.SheetNames.includes('Purchases')
    ? 'Purchases'
    : (wb.SheetNames.includes('Purchase')
      ? 'Purchase'
      : wb.SheetNames.find(n => n.toLowerCase().startsWith('purchase')));
  if (!sheetName) {
    console.log(`  No Purchases sheet found for ${month_key} — skipped, not fabricated.`);
    return [];
  }

  const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    card: findColAny(header, ['Card num/', 'Card num', 'Card num.']),
    date: findCol(header, 'Date'),
    hour: findCol(header, 'Hour'),
    quantity: findCol(header, 'Quantity'),
    unit_price: findColAny(header, ['Unit price', 'Unit Price']),
    amount: findCol(header, 'Amount'),
    place: findCol(header, 'Place'),
    service: findColAny(header, ['Service', 'Service / Product', 'Product']),
    vendor: findCol(header, 'Vendor'),
    usage: findCol(header, 'Usage'),
    user: findColAny(header, ['User', 'Nom']),
    region: findCol(header, 'Region'),
    sbc: findCol(header, 'SBC'),
    comments: findColAny(header, ['Comments', 'Comment']),
  };

  const missing = Object.entries(idx).filter(([k, v]) => v === null && !['comments', 'service', 'user'].includes(k));
  if (missing.length) {
    throw new Error(`"${sheetName}" for ${month_key} is missing expected column(s): ${missing.map(([k]) => k).join(', ')}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || row[idx.card] == null) continue;
    const dateSerial = row[idx.date];
    const hourSerial = row[idx.hour];
    const combined = (typeof dateSerial === 'number')
      ? excelSerialToJs(dateSerial + (typeof hourSerial === 'number' ? hourSerial : 0))
      : excelSerialToJs(dateSerial);
    if (!combined) continue; // no real date — skip rather than guess

    records.push({
      card_number: String(row[idx.card]),
      purchase_date: combined,
      quantity_l: toNum(row[idx.quantity]),
      unit_price_xaf: toNum(row[idx.unit_price]),
      amount_xaf: toNum(row[idx.amount]),
      place: row[idx.place] ?? null,
      service: row[idx.service] ?? null,
      vendor: row[idx.vendor] ?? null,
      usage: row[idx.usage] ?? null,
      purchase_user: row[idx.user] ?? null,
      region: row[idx.region] ?? null,
      sbc: row[idx.sbc] ?? null,
      comments: idx.comments !== null ? (row[idx.comments] || null) : null,
      month_key,
    });
  }
  return records;
}

// Storage Tank Usage — a single bulk purchase for external-tank
// refilling, found only in April's file. Maps cleanly onto the same
// HistoricalFuelPurchase shape as card transactions (date, quantity,
// unit price, amount, place, vendor) despite being a genuinely
// different purchase mechanism (bulk storage tank refill, vendor
// CITEC, not a card transaction at a normal station) — same target
// model, not a separate one, since the shape is identical.
function parseStorageTankUsage() {
  const filePath = path.join(DATA_DIR, 'Apr2026_Validation.xlsx');
  const wb = XLSX.readFile(filePath);
  if (!wb.SheetNames.includes('Storage Tank Usage')) return [];
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Storage Tank Usage'], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idx = {}; header.forEach((h, i) => { if (typeof h === 'string') idx[h.trim()] = i; });

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || row[idx['Date']] == null) continue;
    records.push({
      card_number: null, // this is a bulk tank refill, not a card transaction — no card number applies
      purchase_date: excelSerialToJs(row[idx['Date']]),
      quantity_l: toNum(row[idx['QTY']]),
      unit_price_xaf: toNum(row[idx['UP']]),
      amount_xaf: toNum(row[idx['Amount']]),
      place: row[idx['Place']] ?? null,
      service: row[idx['Product']] ?? null,
      vendor: row[idx['vendor']] ?? null,
      usage: row[idx['Usage']] ?? null,
      purchase_user: null,
      region: null,
      sbc: row[idx['SBC']] ?? null,
      comments: 'Storage Tank Usage — bulk external-tank refill, not a card transaction',
      month_key: '2026-04',
      source_file: 'Apr2026_Validation.xlsx',
    });
  }
  return records;
}

// Standalone "GRATO PURCHASE" files — a separate, recurring email
// thread (subject: "GRATO PURCHASE" / "FW: GRATO PURCHASE"), genuinely
// distinct from the Validation workbooks' own Purchases sheets. Found
// during a deeper investigation after the user confirmed this data
// exists in the archive under different naming than first assumed —
// these files were never opened before. Each row's own date determines
// its month_key, since a single file can span a month boundary (the
// first file here runs 26 June through 24 July in one sheet).
function parseStandalonePurchaseFile(fileName, sheetName = 'Sheet1', excludeMonths = []) {
  const filePath = path.join(DATA_DIR, fileName);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idx = {}; header.forEach((h, i) => { if (typeof h === 'string') idx[h.trim()] = i; });
  // "Card num" vs "Card num/" — verified directly: the embedded June
  // sheet has a trailing slash the standalone files don't. Resolved
  // once here rather than assumed identical across sources.
  const cardKey = idx['Card num'] !== undefined ? 'Card num' : (idx['Card num/'] !== undefined ? 'Card num/' : 'Card num');

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || row[idx[cardKey]] == null) continue;
    const dateSerial = row[idx['Date']];
    const hourSerial = row[idx['Hour']];
    const purchaseDate = (typeof dateSerial === 'number')
      ? excelSerialToJs(dateSerial + (typeof hourSerial === 'number' ? hourSerial : 0))
      : excelSerialToJs(dateSerial);
    if (!purchaseDate) continue;
    const monthKey = `${purchaseDate.getUTCFullYear()}-${String(purchaseDate.getUTCMonth() + 1).padStart(2, '0')}`;
    if (excludeMonths.includes(monthKey)) continue; // covered by a more authoritative embedded source instead — see caller

    records.push({
      card_number: String(row[idx[cardKey]]),
      purchase_date: purchaseDate,
      quantity_l: toNum(row[idx['Quantity']]),
      unit_price_xaf: toNum(row[idx['Unit price']]),
      amount_xaf: toNum(row[idx['Amount']]),
      place: idx['Place'] !== undefined ? row[idx['Place']] : null, // genuinely absent in some of these files — left null, not guessed
      service: idx['Product'] !== undefined ? row[idx['Product']] : null,
      vendor: row[idx['Vendor']] ?? null,
      usage: row[idx['Usage']] ?? null,
      purchase_user: row[idx['User']] ?? null,
      region: row[idx['Region']] ?? null,
      sbc: row[idx['SBC']] ?? null,
      comments: idx['Comments'] !== undefined ? (row[idx['Comments']] || null) : null,
      month_key: monthKey,
      source_file: fileName,
    });
  }

  const monthsFound = [...new Set(records.map(r => r.month_key))].sort();
  const excludedNote = excludeMonths.length ? ` (excluding ${excludeMonths.join(', ')} — covered by a more authoritative embedded source)` : '';
  console.log(`── ${fileName}: ${records.length} transaction(s) spanning ${monthsFound.join(', ')}${excludedNote}.`);
  return records;
}

async function main() {
  const allRecords = [];
  for (const m of MONTHS) {
    const filePath = path.join(DATA_DIR, m.file);
    const records = parsePurchasesSheet(filePath, m.month_key).map(r => ({ ...r, source_file: m.file }));
    const totalQty = records.reduce((s, r) => s + (r.quantity_l || 0), 0);
    const totalAmount = records.reduce((s, r) => s + (r.amount_xaf || 0), 0);
    console.log(`── ${m.month_key} (${m.file}): ${records.length} transaction(s), ${Math.round(totalQty).toLocaleString()} L, ${Math.round(totalAmount).toLocaleString()} XAF.`);
    allRecords.push(...records);
  }

  const tankUsage = parseStorageTankUsage();
  if (tankUsage.length) {
    console.log(`── 2026-04 (Storage Tank Usage, separate sheet): ${tankUsage.length} record(s), ${Math.round(tankUsage.reduce((s, r) => s + (r.quantity_l || 0), 0)).toLocaleString()} L.`);
    allRecords.push(...tankUsage);
  }

  // Standalone "GRATO PURCHASE" thread files — fill June entirely (no
  // Validation file existed for June until Phase 82) and originally
  // extended July's coverage too. Phase 87 found July's own V2.0
  // Validation file has a real embedded Purchases sheet — cross-checked
  // it against these standalone files' July-dated rows before deciding
  // what to do: 161 vs 160 rows, 142,623L vs 142,473L, a ~0.1%
  // difference — genuinely the same underlying transactions, not two
  // different datasets. Importing both would double-count ~142,000L.
  // The embedded sheet is part of the official signed-off file, so
  // it's used as authoritative for July; July-dated rows are excluded
  // from both standalone files below to avoid the duplication.
  const STANDALONE_FILES = ['JunJul2026_Purchases_1.xlsx', 'JunJul2026_Purchases_2.xlsx'];
  const standaloneRecords = [];
  for (const f of STANDALONE_FILES) {
    standaloneRecords.push(...parseStandalonePurchaseFile(f, 'Sheet1', ['2026-07']));
  }
  // June's own Validation file (found in Phase 82) has an embedded
  // Purchases sheet too — checked its date range directly before
  // trusting it wasn't a duplicate of the standalone files above: it
  // covers 26 May through 25 June, genuinely earlier than
  // JunJul2026_Purchases_1.xlsx's own 26 June start, so this is real,
  // additional coverage, not an overlap. Parsed with the same per-row
  // date logic since it also spans a month boundary.
  const juneEmbeddedRecords = parseStandalonePurchaseFile('Jun2026_Validation.xlsx', 'Purchases breakdown (Update)');
  standaloneRecords.push(...juneEmbeddedRecords);
  // July's own embedded Purchases sheet (Phase 87) — the authoritative
  // source for July, per the exclusion above.
  const julyEmbeddedRecords = parseStandalonePurchaseFile('Jul2026_Validation.xlsx', 'Purchases breakdown (Update)');
  standaloneRecords.push(...julyEmbeddedRecords);
  allRecords.push(...standaloneRecords);

  console.log(`\n── Total: ${allRecords.length} transaction(s) across ${MONTHS.length} month(s) plus the standalone files above. ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  for (const m of MONTHS) {
    await HistoricalFuelPurchase.deleteMany({ month_key: m.month_key, source_file: m.file });
  }
  for (const f of STANDALONE_FILES) {
    await HistoricalFuelPurchase.deleteMany({ source_file: f });
  }
  await HistoricalFuelPurchase.deleteMany({ source_file: 'Jun2026_Validation.xlsx' });
  await HistoricalFuelPurchase.deleteMany({ source_file: 'Jul2026_Validation.xlsx' });
  const result = await HistoricalFuelPurchase.insertMany(allRecords);
  console.log(`✓ Inserted ${result.length} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
