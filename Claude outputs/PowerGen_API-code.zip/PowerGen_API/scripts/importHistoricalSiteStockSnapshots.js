/**
 * importHistoricalSiteStockSnapshots.js
 * diesel-system/scripts/importHistoricalSiteStockSnapshots.js
 *
 * Imports the two one-off, site-level stock snapshot sheets found
 * during the full multi-sheet investigation: "HO Stock" (December
 * 2025's file only) and "BB Site Stock" (April 2026's file only). See
 * models/HistoricalSiteStockSnapshot.js for why these are modeled
 * together despite being genuinely different documents.
 *
 * Row alignment verified directly with the real xlsx package before
 * writing this — HO Stock: header row 1, data row 2. BB Site Stock:
 * header row 2 (one extra blank row above it), data row 3. Neither
 * assumed to match the other or any other recovered file.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importHistoricalSiteStockSnapshots.js
 *   node scripts/importHistoricalSiteStockSnapshots.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalSiteStockSnapshot = require('../models/HistoricalSiteStockSnapshot');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelSerialToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400 * 1000));
  return null;
}

function parseHoStock() {
  const wb = XLSX.readFile(path.join(DATA_DIR, 'Dec2025_Validation.xlsx'));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['HO Stock'], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idx = {}; header.forEach((h, i) => { if (typeof h === 'string') idx[h.trim()] = i; });

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx['IHS site ID']]) continue;
    const meterRaw = row[idx['Generetor Current Meter']];
    records.push({
      site_id: String(row[idx['IHS site ID']]).trim(),
      site_name: row[idx['IHS SITES NAMES']] ?? null,
      sbc: row[idx['SBC']] ?? null,
      snapshot_type: 'ho_stock',
      snapshot_date: excelSerialToJs(row[idx['Date of Current Visit']]),
      month_key: '2025-12',
      generator_capacity_kva: toNum(row[idx['Generator Capacity']]),
      generator_meter_reading: meterRaw === 'FAULTY' ? null : toNum(meterRaw),
      generator_meter_faulty: meterRaw === 'FAULTY',
      stock_left_l: toNum(row[idx['QTY LEFT']]),
      source_file: 'Dec2025_Validation.xlsx',
      source_sheet: 'HO Stock',
    });
  }
  return records;
}

function parseBbSiteStock() {
  const wb = XLSX.readFile(path.join(DATA_DIR, 'Apr2026_Validation.xlsx'));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['BB Site Stock'], { header: 1, defval: null, raw: true });
  const header = rows[2]; // verified directly: one extra blank row above the header here
  const idx = {}; header.forEach((h, i) => { if (typeof h === 'string') idx[h.trim()] = i; });

  const records = [];
  for (const row of rows.slice(3)) {
    if (!row || !row[idx['NEW IHS ID']]) continue;
    records.push({
      site_id: String(row[idx['NEW IHS ID']]).trim(),
      site_name: row[idx['Site Name']] ?? null,
      sbc: row[idx['SBC']] ?? null,
      snapshot_type: 'bb_site_stock',
      snapshot_date: excelSerialToJs(row[idx['End Stock Date - April 2026']]),
      month_key: '2026-04',
      stock_allocated_l: toNum(row[idx['Stock allocated for BB sites']]),
      qty_refuelled_l: toNum(row[idx['Qty refuelled on site']]),
      stock_left_l: toNum(row[idx['Fuel Stock left at April 2026']]),
      source_file: 'Apr2026_Validation.xlsx',
      source_sheet: 'BB Site Stock',
    });
  }
  return records;
}

function parseSmallTankUsage() {
  const wb = XLSX.readFile(path.join(DATA_DIR, 'May2026_Validation.xlsx'));
  if (!wb.SheetNames.includes('Stock Usage')) return [];
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Stock Usage'], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idx = {}; header.forEach((h, i) => { if (typeof h === 'string') idx[h.trim()] = i; });

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx['IHS ID']]) continue;
    records.push({
      site_id: String(row[idx['IHS ID']]).trim(),
      site_name: row[idx['Small Tank Site Name']] ?? null,
      sbc: row[idx['SBC']] ?? null,
      snapshot_type: 'small_tank_usage',
      snapshot_date: excelSerialToJs(row[idx['Cycle']]),
      month_key: '2026-05',
      usage_l: toNum(row[idx['Qty Used']]),
      source_file: 'May2026_Validation.xlsx',
      source_sheet: 'Stock Usage',
    });
  }
  return records;
}

async function main() {
  const hoStock = parseHoStock();
  console.log(`HO Stock (Dec 2025): ${hoStock.length} site(s) parsed.`);
  const bbStock = parseBbSiteStock();
  console.log(`BB Site Stock (Apr 2026): ${bbStock.length} site(s) parsed.`);
  const totalBbAllocated = bbStock.reduce((s, r) => s + (r.stock_allocated_l || 0), 0);
  console.log(`  Total BB stock allocated: ${Math.round(totalBbAllocated).toLocaleString()} L.`);
  const smallTank = parseSmallTankUsage();
  console.log(`Small Tank Usage (May 2026): ${smallTank.length} site(s) parsed.`);
  const totalSmallTank = smallTank.reduce((s, r) => s + (r.usage_l || 0), 0);
  console.log(`  Total small tank usage: ${Math.round(totalSmallTank).toLocaleString()} L.`);

  const allRecords = [...hoStock, ...bbStock, ...smallTank];
  console.log(`\n── Total: ${allRecords.length} snapshot(s). ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  await HistoricalSiteStockSnapshot.deleteMany({ source_sheet: { $in: ['HO Stock', 'BB Site Stock', 'Stock Usage'] } });
  const result = await HistoricalSiteStockSnapshot.insertMany(allRecords);
  console.log(`✓ Inserted ${result.length} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
