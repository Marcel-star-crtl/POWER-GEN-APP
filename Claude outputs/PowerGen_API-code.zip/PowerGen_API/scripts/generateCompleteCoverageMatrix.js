/**
 * generateCompleteCoverageMatrix.js
 * diesel-system/scripts/generateCompleteCoverageMatrix.js
 *
 * Phase 136. Queries the real, live state of every collection the
 * Historical Data dashboard page depends on (confirmed directly from
 * that page's own actual imports and its route file's own model
 * requires — not recalled from memory, which would risk being stale
 * after everything that's changed this project: cluster removal,
 * restores, newer tracker imports), for every month from December
 * 2025 through the current month.
 *
 * Read-only. No writes, no --confirm needed — this only reports.
 *
 * Usage:
 *   node scripts/generateCompleteCoverageMatrix.js
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');

// One row per real month, Dec 2025 through whatever the current month
// is — computed from the real system clock, not hardcoded to a
// specific end date that would go stale.
function monthRange(startYear, startMonth) {
  const months = [];
  const now = new Date();
  let y = startYear, m = startMonth;
  while (y < now.getFullYear() || (y === now.getFullYear() && m <= now.getMonth() + 1)) {
    months.push(`${y}-${String(m).padStart(2, '0')}`);
    m++;
    if (m > 12) { m = 1; y++; }
  }
  return months;
}

// { column label, model, dateField, dateFieldType: 'string_month_key' | 'date' }
// dateFieldType matters: a real Date field needs a range query for the
// month, while a "YYYY-MM" string field is matched directly.
const SOURCES = [
  { label: 'Monthly Reconciliation', model: 'HistoricalMonthlyRecord', dateField: 'month_key', type: 'string_month_key' },
  { label: 'Ad-Hoc Emergency Requests', model: 'AdHocFuelRequest', dateField: 'planned_date', type: 'date' },
  { label: 'Mid-Cycle Budget Release', model: 'MidCycleBudgetRelease', dateField: 'release_cycle_key', type: 'string_month_key', submodelKey: 'MidCycleBudgetRelease' },
  { label: 'Tom Card / Card Funding', model: 'TomCardAllocation', dateField: 'funded_cycle_key', type: 'string_month_key' },
  { label: 'Budget Request Approval', model: 'BudgetRequestApproval', dateField: 'cycle_key', type: 'string_month_key' },
  { label: 'Monthly Debit/Credit', model: 'MonthlyDebitSummary', dateField: 'cycle_key', type: 'string_month_key' },
  { label: 'Individual Field Visits', model: 'HistoricalFieldVisit', dateField: 'month_key', type: 'string_month_key' },
  { label: 'Individual Fuel Purchases', model: 'HistoricalFuelPurchase', dateField: 'month_key', type: 'string_month_key' },
  { label: 'Site Stock Snapshots', model: 'HistoricalSiteStockSnapshot', dateField: 'month_key', type: 'string_month_key' },
  { label: 'Mid-Cycle Estimate Snapshot', model: 'MidCycleEstimateSnapshot', dateField: 'month_key', type: 'string_month_key' },
  { label: 'Planned vs Supplied Delivery', model: 'PlannedVsSuppliedDelivery', dateField: 'month_key', type: 'string_month_key' },
];

function loadModel(src) {
  const mod = require(`../models/${src.model}`);
  if (!src.submodelKey) return mod;
  return mod[src.submodelKey];
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const months = monthRange(2025, 12);
  console.log(`Checking ${months.length} month(s): ${months[0]} through ${months[months.length - 1]}\n`);

  // counts[label][month] = record count
  const counts = {};
  for (const src of SOURCES) {
    const Model = loadModel(src);
    counts[src.label] = {};
    for (const month of months) {
      let query;
      if (src.type === 'string_month_key') {
        query = { [src.dateField]: month };
      } else {
        const [y, m] = month.split('-').map(Number);
        const start = new Date(y, m - 1, 1);
        const end = new Date(y, m, 1);
        query = { [src.dateField]: { $gte: start, $lt: end } };
      }
      counts[src.label][month] = await Model.countDocuments(query);
    }
    process.stdout.write(`  checked ${src.label}\n`);
  }

  // ── Print the matrix ──
  console.log('\n══════════════════════════════════════════════════════════════════');
  console.log(' COMPLETE COVERAGE MATRIX — December 2025 to Present');
  console.log('══════════════════════════════════════════════════════════════════\n');

  const labelWidth = Math.max(...SOURCES.map(s => s.label.length)) + 2;
  const header = 'Data Type'.padEnd(labelWidth) + months.map(m => m.slice(2).padStart(8)).join('');
  console.log(header);
  console.log('─'.repeat(header.length));

  for (const src of SOURCES) {
    let row = src.label.padEnd(labelWidth);
    for (const month of months) {
      const c = counts[src.label][month];
      const cell = c === 0 ? '—' : String(c);
      row += cell.padStart(8);
    }
    console.log(row);
  }

  console.log('\n(— = zero records found for that month; a real number = confirmed real coverage)');
  console.log('\nThis reflects the ACTUAL current database state, queried directly — not a prior summary, which may be stale after any import, cleanup, or restore run since it was last written.');

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
