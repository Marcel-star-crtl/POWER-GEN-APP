/**
 * findOrphanedMarchRecord.js
 * diesel-system/scripts/findOrphanedMarchRecord.js
 *
 * Read-only diagnostic — finds the one extra HistoricalMonthlyRecord
 * for March 2026 (165 in the database, 164 in the real Validation
 * file). Doesn't write or delete anything; just identifies the
 * specific site_id so it can be reviewed before any cleanup.
 *
 * Usage:
 *   node scripts/findOrphanedMarchRecord.js
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const records = await HistoricalMonthlyRecord.find(
    { month_key: '2026-03' },
    { site_id: 1, source_file: 1, budget_liters: 1, final_consumption_l: 1 }
  ).sort({ site_id: 1 }).lean();

  console.log(`Found ${records.length} record(s) for 2026-03 (expected 164 from the real Validation file).\n`);

  const bySource = {};
  for (const r of records) {
    const key = r.source_file || '(none)';
    bySource[key] = (bySource[key] || 0) + 1;
  }
  console.log('Breakdown by source_file:');
  for (const [file, count] of Object.entries(bySource)) {
    console.log(`  ${file}: ${count}`);
  }

  const orphans = records.filter(r => r.source_file !== 'Mar2026_Validation.xlsx');
  console.log(`\n${orphans.length} record(s) NOT from the real Validation file:`);
  for (const r of orphans) {
    console.log(`  site_id: ${r.site_id} | source_file: ${r.source_file} | budget_liters: ${r.budget_liters} | final_consumption_l: ${r.final_consumption_l}`);
  }

  if (orphans.length === 0) {
    console.log('\nNo orphan found by source_file — checking for a null final_consumption_l instead (a site the real file never touched):');
    const nullCons = records.filter(r => r.final_consumption_l == null);
    for (const r of nullCons) {
      console.log(`  site_id: ${r.site_id} | source_file: ${r.source_file} | budget_liters: ${r.budget_liters} | final_consumption_l: ${r.final_consumption_l}`);
    }
  }

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
