/**
 * importBudgetPlanningData.js
 * diesel-system/scripts/importBudgetPlanningData.js
 *
 * Imports two real data sources for the automated budget-planning
 * feature:
 *   1. "Grato Diesel Conso" sheet (Grato_Fuel_Analysis_OK.xlsx) —
 *      7 months (Jan–July 2026) of ACTUAL historical fuel consumption
 *      per site → SiteConsumptionHistory
 *   2. Book16.xlsx — current engineering parameters per site (Genset
 *      CPH, Final Grid Availability, DG KVA, topology, hybrid
 *      expectation) → SiteEngineeringParams
 *
 * Both files' structure and data quality were verified directly against
 * the real uploaded spreadsheets before writing this script — see the
 * corresponding changelog phase for the full verification (formula
 * cross-checked to near-exact precision across 10 sites, site-ID overlap
 * confirmed 164/164, data completeness checked for nulls/negatives).
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed — same convention
 * as scripts/backfillSiteCoordinates.js.
 *
 * Usage:
 *   node scripts/importBudgetPlanningData.js
 *   node scripts/importBudgetPlanningData.js --confirm
 *
 * Expects both source files sitting alongside this script (bundled at
 * import time) unless overridden with --conso=/path --params=/path.
 */
'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const SiteConsumptionHistory = require('../models/SiteConsumptionHistory');
const SiteEngineeringParams = require('../models/SiteEngineeringParams');

const CONFIRM = process.argv.includes('--confirm');
const argFile = (flag) => {
  const arg = process.argv.find(a => a.startsWith(`--${flag}=`));
  return arg ? arg.split('=').slice(1).join('=') : null;
};

const CONSO_FILE  = argFile('conso')  || path.join(__dirname, 'Grato_Fuel_Analysis_OK__1_.xlsx');
const PARAMS_FILE = argFile('params') || path.join(__dirname, 'Book16__1_.xlsx');

// "July-26" -> "2026-07"
const MONTH_MAP = {
  'Jan-26': '2026-01', 'Feb-26': '2026-02', 'March-26': '2026-03', 'April-26': '2026-04',
  'May-26': '2026-05', 'June-26': '2026-06', 'July-26': '2026-07',
};
// Column groups in the Conso sheet — [monthLabel, actualColIdx, submittedColIdx, approvedColIdx]
const CONSO_MONTH_COLS = [
  ['July-26', 6, 7, 8], ['June-26', 9, 10, 11], ['May-26', 12, 13, 14],
  ['April-26', 15, 16, 17], ['March-26', 18, 19, 20], ['Feb-26', 21, 22, 23], ['Jan-26', 24, 25, 26],
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function parseConsoFile(filePath) {
  const wb = XLSX.readFile(filePath);
  const sheetName = wb.SheetNames.find(n => /conso/i.test(n)) || wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  // Header is at row index 3 in SheetJS's reading of this specific file
  // (verified directly — differs by one from an initial openpyxl-based
  // check, which is why this was tested against the real file with the
  // actual xlsx package before trusting it, not assumed to carry over).
  const dataRows = rows.slice(4).filter(r => r && r[0]);

  const records = [];
  const skipped = [];
  for (const row of dataRows) {
    const site_id = String(row[0]).trim();
    for (const [monthLabel, actualIdx, submittedIdx, approvedIdx] of CONSO_MONTH_COLS) {
      const actual = toNum(row[actualIdx]);
      if (actual === null) continue; // no data for this site/month — skip, don't fabricate a zero
      records.push({
        site_id,
        cycle_key: MONTH_MAP[monthLabel],
        // Floored at zero — a handful of genuine negative correction
        // values exist in the real data (meter/reading corrections);
        // negative "consumption" doesn't make physical sense as a trend
        // input, so treat as zero rather than letting it skew an average.
        actual_consumption_l: Math.max(0, actual),
        submitted_contractual_l: toNum(row[submittedIdx]),
        approved_contractual_l: toNum(row[approvedIdx]),
      });
    }
  }
  return { records, sheetName, totalRows: dataRows.length };
}

function parseParamsFile(filePath) {
  const wb = XLSX.readFile(filePath);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  // Header is row index 1 (0-based) — verified directly against the real file.
  const dataRows = rows.slice(2).filter(r => r && r[0]);

  // Source cycle inferred from the "Genset CPH"-adjacent column headers
  // (e.g. "Days in  July-26 Cycle") rather than hardcoded, so this script
  // keeps working correctly if re-run with a different month's snapshot.
  const headerRow = rows[1];
  const daysHeader = headerRow.find(h => typeof h === 'string' && /^Days in\s+/i.test(h));
  const monthLabelMatch = daysHeader && daysHeader.match(/([A-Za-z]+-\d{2})/);
  const sourceCycleKey = monthLabelMatch ? (MONTH_MAP[monthLabelMatch[1]] || null) : null;

  const records = [];
  const skippedNoCph = [];
  const skippedNoGrid = [];
  for (const row of dataRows) {
    const site_id = String(row[0]).trim();
    const genset_cph = toNum(row[24]);
    const final_grid_availability = toNum(row[27]);

    if (genset_cph === null) { skippedNoCph.push(site_id); continue; }
    if (final_grid_availability === null) { skippedNoGrid.push(site_id); continue; }

    records.push({
      site_id,
      site_name: row[1] || undefined,
      cluster: row[3] || undefined,
      region: row[6] || undefined,
      topology: row[5] || undefined,
      actual_dg_kva: toNum(row[8]),
      genset_capacity_mapped_kva: toNum(row[9]),
      genset_cph,
      final_grid_availability,
      hybrid_expectation_hrs: toNum(row[28]),
      is_fueling_site: String(row[30] || '').trim().toLowerCase() === 'yes',
      source_cycle_key: sourceCycleKey,
    });
  }
  return { records, skippedNoCph, skippedNoGrid, totalRows: dataRows.length, sourceCycleKey };
}

async function main() {
  if (!fs.existsSync(CONSO_FILE))  throw new Error(`Consumption file not found: ${CONSO_FILE}`);
  if (!fs.existsSync(PARAMS_FILE)) throw new Error(`Engineering params file not found: ${PARAMS_FILE}`);

  console.log(`Consumption source: ${CONSO_FILE}`);
  console.log(`Engineering params source: ${PARAMS_FILE}\n`);

  const conso = parseConsoFile(CONSO_FILE);
  console.log(`Consumption sheet: "${conso.sheetName}", ${conso.totalRows} site rows, ${conso.records.length} site-month records parsed.\n`);

  const params = parseParamsFile(PARAMS_FILE);
  console.log(`Engineering params: ${params.totalRows} site rows, ${params.records.length} usable, source cycle: ${params.sourceCycleKey || 'unknown'}`);
  if (params.skippedNoCph.length)  console.log(`  Skipped (no CPH): ${params.skippedNoCph.length} — ${params.skippedNoCph.slice(0, 10).join(', ')}${params.skippedNoCph.length > 10 ? ' …' : ''}`);
  if (params.skippedNoGrid.length) console.log(`  Skipped (no grid availability): ${params.skippedNoGrid.length} — ${params.skippedNoGrid.slice(0, 10).join(', ')}${params.skippedNoGrid.length > 10 ? ' …' : ''}`);
  console.log('');

  if (!CONFIRM) {
    console.log('── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${conso.records.length} consumption record(s) and ${params.records.length} engineering param record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  console.log(`── Writing ${conso.records.length} consumption record(s) ──────────────────`);
  const consoOps = conso.records.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id, cycle_key: r.cycle_key },
      update: { $set: { ...r, source_file: path.basename(CONSO_FILE) } },
      upsert: true,
    },
  }));
  const consoResult = await SiteConsumptionHistory.bulkWrite(consoOps, { ordered: false });
  console.log(`✓ Consumption history: upserted ${consoResult.upsertedCount}, modified ${consoResult.modifiedCount}, matched ${consoResult.matchedCount}`);

  console.log(`\n── Writing ${params.records.length} engineering param record(s) ───────────`);
  const paramsOps = params.records.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id },
      update: { $set: { ...r, source_file: path.basename(PARAMS_FILE) } },
      upsert: true,
    },
  }));
  const paramsResult = await SiteEngineeringParams.bulkWrite(paramsOps, { ordered: false });
  console.log(`✓ Engineering params: upserted ${paramsResult.upsertedCount}, modified ${paramsResult.modifiedCount}, matched ${paramsResult.matchedCount}`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
