/**
 * enrichHistoricalRecordsWithAnalysis.js
 * diesel-system/scripts/enrichHistoricalRecordsWithAnalysis.js
 *
 * Adds three genuinely meaningful fields from each recovered validation
 * file's "Analysis" sheet to the HistoricalMonthlyRecord documents
 * already imported by importHistoricalEmailData.js. An enrichment, not
 * a fresh import — this UPDATES existing records by (site_id,
 * month_key), it doesn't create new ones.
 *
 * WHY ONLY THREE FIELDS OUT OF A 52-COLUMN SHEET:
 * Checked the actual fill rate and value distribution of every comment
 * column before including anything — several "100% filled" columns
 * turned out to be a placeholder, not real data (e.g. "Site Comment" is
 * literally the number 0 for 155 of 164 December sites — that's a
 * default, not a comment). Only included columns confirmed to carry
 * real, varying information:
 *   - "CMS Vs Field Comment": binary, "CMS Team to investigate" (94
 *     sites in December) vs "OK" (70) — a real investigation flag.
 *   - "DG Comment": "OK" / "Use SBC DG KVA" / "Use IHS DG KVA" — which
 *     generator-capacity source is actually trusted for that site.
 *   - "Site Comment", but ONLY where it's real text, not the "0"
 *     placeholder — flags real site lifecycle events (ID changes, new
 *     sites) for a small number of sites where it matters.
 *
 * WHY MAY AND JULY ARE HANDLED DIFFERENTLY:
 * Checked directly before writing this — May's "Analysis" sheet only
 * has "Site Comment", missing the other two entirely (consistent with
 * May's Analysis sheet being unusually narrow, already noted in Phase
 * 57). July has no "Analysis" sheet at all. Both handled by leaving the
 * missing fields null rather than guessing or skipping the month
 * entirely.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/enrichHistoricalRecordsWithAnalysis.js
 *   node scripts/enrichHistoricalRecordsWithAnalysis.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

const MONTHS = [
  // 2025 months (Phase 90) — June's "IHS ID" variant handled by
  // findColAny above, verified directly against the raw file.
  { month_key: '2025-04', file: 'Apr2025_Validation.xlsx' },
  { month_key: '2025-05', file: 'May2025_Validation.xlsx' },
  { month_key: '2025-06', file: 'Jun2025_Validation.xlsx' },
  { month_key: '2025-07', file: 'Jul2025_Validation.xlsx' },
  { month_key: '2025-08', file: 'Aug2025_Validation.xlsx' },
  { month_key: '2025-09', file: 'Sep2025_Validation.xlsx' },
  { month_key: '2025-10', file: 'Oct2025_Validation.xlsx' },
  { month_key: '2025-11', file: 'Nov2025_Validation.xlsx' },
  { month_key: '2025-12', file: 'Dec2025_Validation.xlsx' },
  { month_key: '2026-01', file: 'Jan2026_Validation.xlsx' },
  { month_key: '2026-02', file: 'Feb2026_Validation.xlsx' },
  { month_key: '2026-04', file: 'Apr2026_Validation.xlsx' },
  { month_key: '2026-05', file: 'May2026_Validation.xlsx' },
  { month_key: '2026-06', file: 'Jun2026_Validation.xlsx' },
  { month_key: '2026-03', file: 'Mar2026_Validation.xlsx' }, // found Phase 83 — standard row 1 alignment
  // July — found Phase 87. A more complete V2.0 revision (with real
  // Debit/Analysis/Purchases sheets) replaced the earlier V1.0 file
  // that genuinely had no Analysis sheet at all.
  { month_key: '2026-07', file: 'Jul2026_Validation.xlsx' },
];

function findCol(header, name) {
  const i = header.findIndex(h => typeof h === 'string' && h.trim() === name);
  return i === -1 ? null : i;
}

// June 2025's Analysis sheet uses "IHS ID" (no periods) instead of
// "I.H.S SITE ID" — verified directly, same variant already found in
// June's Validation sheet. Tried in order, first match wins.
function findColAny(header, names) {
  for (const name of names) {
    const idx = findCol(header, name);
    if (idx !== null) return idx;
  }
  return null;
}

function parseAnalysisSheet(filePath) {
  const wb = XLSX.readFile(filePath);
  // July 2025's sheet is literally named "Analysis " (trailing space) —
  // verified directly. Resolved by trimmed match rather than exact,
  // so this month isn't silently skipped.
  const sheetName = wb.SheetNames.includes('Analysis')
    ? 'Analysis'
    : wb.SheetNames.find(n => n.trim() === 'Analysis');
  if (!sheetName) return [];
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findColAny(header, ['I.H.S SITE ID', 'IHS ID']),
    site_comment: findCol(header, 'Site Comment'),
    cms_field: findCol(header, 'CMS Vs Field Comment'),
    dg_comment: findCol(header, 'DG Comment'),
  };
  if (idx.site_id === null) return [];

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const siteComment = idx.site_comment !== null ? row[idx.site_comment] : null;
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      needs_cms_investigation: idx.cms_field !== null
        ? row[idx.cms_field] === 'CMS Team to investigate'
        : null,
      dg_kva_source_used: idx.dg_comment !== null ? (row[idx.dg_comment] || null) : null,
      // "0" is the sheet's own placeholder for "nothing to note" — real
      // text is anything else.
      site_lifecycle_note: (siteComment != null && siteComment !== 0 && siteComment !== '0') ? String(siteComment) : null,
    });
  }
  return records;
}

async function main() {
  const allUpdates = [];
  for (const m of MONTHS) {
    const records = parseAnalysisSheet(path.join(DATA_DIR, m.file));
    const needsInvestigation = records.filter(r => r.needs_cms_investigation === true).length;
    const withLifecycleNote = records.filter(r => r.site_lifecycle_note).length;
    console.log(`── ${m.month_key} (${m.file}): ${records.length} site(s) — ${needsInvestigation} flagged "CMS Team to investigate", ${withLifecycleNote} with a real lifecycle note.`);
    allUpdates.push(...records.map(r => ({ ...r, month_key: m.month_key })));
  }

  console.log(`\n── Total: ${allUpdates.length} site-month enrichment(s) across ${MONTHS.length} month(s). ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to update ${allUpdates.length} existing HistoricalMonthlyRecord document(s).`);
    console.log('Note: this only updates records that already exist (from importHistoricalEmailData.js) — run that first if you haven\'t.');
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = allUpdates.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id, month_key: r.month_key },
      update: { $set: {
        needs_cms_investigation: r.needs_cms_investigation,
        dg_kva_source_used: r.dg_kva_source_used,
        site_lifecycle_note: r.site_lifecycle_note,
      }},
      // Deliberately NOT upserting — this only enriches records that
      // already exist from the primary import. A record that doesn't
      // exist yet means importHistoricalEmailData.js hasn't been run
      // for that month, and this script shouldn't create a partial one.
    },
  }));
  const result = await HistoricalMonthlyRecord.bulkWrite(ops, { ordered: false });
  console.log(`✓ Matched ${result.matchedCount}, modified ${result.modifiedCount}.`);
  if (result.matchedCount < allUpdates.length) {
    console.log(`⚠ ${allUpdates.length - result.matchedCount} record(s) had no matching existing document — run importHistoricalEmailData.js --confirm first if you haven't.`);
  }

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
