/**
 * cleanupDuplicateSubmittedAudits.js
 * diesel-system/scripts/cleanupDuplicateSubmittedAudits.js
 *
 * Phase 127. Follow-up to investigateSuspectedDuplicateSubmittedAudits.js
 * (Phase 126), which found 9 real duplicate groups across 89 submitted
 * audits, all sharing the same real cause: the mobile app's submit flow
 * generates a brand-new client_id on every attempt instead of reusing a
 * stable one, so the backend's own idempotency check (which only works
 * by matching an existing client_id) never has anything to match
 * against and lets every retry through as a "new" record. This is a
 * mobile-side bug and outside what this session touches — this script
 * only cleans up the duplicates it already created.
 *
 * SAFETY, deliberately stricter than cleanupDuplicateTankAuditDrafts.js
 * (Phase 100), because a submitted record is the source of truth
 * True CPH and Gain/Loss already depend on, unlike a draft:
 *
 *   - Reuses the EXACT SAME grouping and evidence logic as the
 *     investigation script (same site + same calendar day, flagged
 *     only with real evidence: a missing client_id or near-identical
 *     Gen Card notes text) — not a looser rule invented separately for
 *     this script, so what gets investigated and what gets cleaned up
 *     can never silently diverge.
 *   - Within a flagged group, ONLY deletes if dip_reading_l is
 *     genuinely identical across every record in the group (or absent
 *     from all of them). If the values actually differ, that group is
 *     skipped entirely and reported separately — a real difference in
 *     the physical reading is real evidence these might not be
 *     duplicates after all, and this script does not guess past that.
 *   - Keeps the EARLIEST-created record in each group (the first real
 *     submission attempt) and deletes the later, redundant retries.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/cleanupDuplicateSubmittedAudits.js
 *   node scripts/cleanupDuplicateSubmittedAudits.js --confirm
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');

const CONFIRM = process.argv.includes('--confirm');

function dayKey(date) {
  if (!date) return 'no-date';
  return new Date(date).toISOString().slice(0, 10);
}

function textSimilarity(a, b) {
  if (!a || !b) return 0;
  const na = a.trim().toLowerCase();
  const nb = b.trim().toLowerCase();
  if (na === nb) return 1;
  if (na.length === 0 || nb.length === 0) return 0;
  if (na.includes(nb) || nb.includes(na)) return 0.9;
  return 0;
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const TankAudit = require('../models/TankAudit');

  const audits = await TankAudit.find({ status: 'submitted' })
    .select('site_id_ihs site_name auditor_name audit_date createdAt client_id dip_reading_l audit_run_hours_reading check_gen_cards_faulty.notes')
    .sort({ createdAt: 1 }) // earliest first, so records[0] in each group below is genuinely the first real attempt
    .lean();

  console.log(`Total submitted audits: ${audits.length}`);

  const groups = new Map();
  for (const a of audits) {
    const key = `${a.site_id_ihs}__${dayKey(a.audit_date || a.createdAt)}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(a);
  }

  const flagged = [];
  for (const [key, group] of groups) {
    if (group.length < 2) continue;
    const missingClientId = group.filter(a => !a.client_id);
    const notesTexts = group.map(a => a.check_gen_cards_faulty?.notes).filter(Boolean);
    let hasIdenticalNotes = false;
    for (let i = 0; i < notesTexts.length; i++) {
      for (let j = i + 1; j < notesTexts.length; j++) {
        if (textSimilarity(notesTexts[i], notesTexts[j]) >= 0.9) hasIdenticalNotes = true;
      }
    }
    if (missingClientId.length > 0 || hasIdenticalNotes) {
      flagged.push({ key, group });
    }
  }

  console.log(`Suspicious groups (same evidence as the investigation script): ${flagged.length}\n`);

  if (!flagged.length) {
    console.log('Nothing to clean up.');
    await mongoose.disconnect();
    return;
  }

  const idsToDelete = [];
  const skippedGroups = [];

  for (const { key, group } of flagged) {
    const [siteId, day] = key.split('__');
    const dipValues = new Set(group.map(a => a.dip_reading_l ?? null));

    if (dipValues.size > 1) {
      // The physical reading genuinely differs across records in this
      // group — real evidence these might not be simple duplicates
      // after all. Skipped entirely, not guessed past.
      skippedGroups.push({ siteId, day, group, reason: `dip_reading_l differs across records (${[...dipValues].join(', ')}) — not a confirmed duplicate, needs manual review` });
      continue;
    }

    const [keep, ...toDelete] = group; // already sorted createdAt asc — group[0] is the earliest
    idsToDelete.push(...toDelete.map(a => a._id));

    console.log(`── ${siteId} — ${day} (${group.length} audits, dip_reading_l identical: ${[...dipValues][0] ?? '(none recorded)'})`);
    console.log(`   ✓ KEEP:   ${keep._id} (created ${new Date(keep.createdAt).toLocaleString()}, client_id ${keep.client_id})`);
    for (const a of toDelete) {
      console.log(`   ✗ DELETE: ${a._id} (created ${new Date(a.createdAt).toLocaleString()}, client_id ${a.client_id})`);
    }
    console.log('');
  }

  if (skippedGroups.length) {
    console.log(`── ${skippedGroups.length} group(s) skipped — flagged as suspicious but NOT auto-resolved, needs a human look: ──\n`);
    for (const { siteId, day, group, reason } of skippedGroups) {
      console.log(`${siteId} — ${day} (${group.length} audits): ${reason}`);
      for (const a of group) {
        console.log(`    [${String(a._id).slice(-6)}] dip: ${a.dip_reading_l ?? '—'} | notes: ${(a.check_gen_cards_faulty?.notes || '').slice(0, 60)}`);
      }
    }
    console.log('');
  }

  console.log(`── Total: ${idsToDelete.length} confirmed duplicate record(s) to delete across ${flagged.length - skippedGroups.length} group(s). ──`);

  if (!idsToDelete.length) {
    console.log('\nNothing safe to auto-delete — every flagged group needs manual review (see skipped list above).');
    await mongoose.disconnect();
    return;
  }

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log('Review the KEEP/DELETE decisions above carefully before re-running with --confirm.');
    console.log('Re-run with --confirm to actually delete the records listed above.');
    await mongoose.disconnect();
    return;
  }

  // Back up the full, real documents before touching anything —
  // submitted audits are the source of truth Gain/Loss and True CPH
  // already depend on, and deletion here has no other undo path.
  // Refuses to proceed with the actual delete if the backup doesn't
  // contain exactly the expected count, rather than delete first and
  // hope the backup worked.
  const fs = require('fs');
  const docsToBackUp = await TankAudit.find({ _id: { $in: idsToDelete } }).lean();
  if (docsToBackUp.length !== idsToDelete.length) {
    console.error(`\n✗ Aborting — expected to back up ${idsToDelete.length} document(s) but found ${docsToBackUp.length}. Not deleting anything until this is understood.`);
    await mongoose.disconnect();
    process.exit(1);
  }
  const backupFilename = `duplicate_audits_backup_${Date.now()}.json`;
  fs.writeFileSync(backupFilename, JSON.stringify(docsToBackUp, null, 2));
  console.log(`\n✓ Backed up ${docsToBackUp.length} full document(s) to ${backupFilename} before deleting anything.`);
  console.log('  Keep this file — each object in it is the complete original document, everything needed to restore if ever necessary.');

  const result = await TankAudit.deleteMany({ _id: { $in: idsToDelete } });
  console.log(`\n✓ Deleted ${result.deletedCount} duplicate submitted audit record(s).`);
  console.log('Note: this does not fix the mobile app\'s client_id generation bug — new duplicates can still be created until that\'s fixed at the source. Re-run investigateSuspectedDuplicateSubmittedAudits.js periodically until then.');

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
