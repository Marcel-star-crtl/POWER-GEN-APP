/**
 * importSbcBudgetFiles.js
 * diesel-system/scripts/importSbcBudgetFiles.js
 *
 * Imports the "SBC Diesel Budget" per-site file family for December
 * 2025 specifically — the one month where no other approved-figure
 * source exists at all (see pairSbcRequestWithExistingApproval.js's
 * own "WHY DECEMBER IS STILL HANDLED SEPARATELY" note). February,
 * April, March, and January versions of the same file family are
 * handled by that other script instead, paired against the
 * already-imported multi-month-rollup figure rather than treated as
 * HistoricalMonthlyRecord's `budget_liters`.
 *
 * PHASE 151 — March removed from this script's SOURCES. It had been
 * left in from before Phase 83, but
 * pairSbcRequestWithExistingApproval.js's own docblock already
 * documents that March's `budget_liters` is correctly sourced from
 * the multi-month rollup via importHistoricalEmailData.js as of that
 * phase — this script still listing March meant running it
 * `--confirm` today would silently overwrite March's already-correct
 * rollup-sourced budget_liters with the wrong "Requested Quantity"
 * figure again (the same mistake Phase 83 already caught and fixed
 * once). Left as a stale entry, not touched, until this pass found it
 * while investigating December's reserve gap. Whether March's live
 * data is currently affected wasn't checked here — this sandbox has
 * no network path to the production database (see Phase 150) — flagged
 * in the changelog as worth a one-time check.
 *
 * PHASE 151 — also now computes reserve_liters/fully_exhausted, not
 * just budget_liters. Previously this script's own `$set` never
 * touched those two fields at all, so even a real, correct
 * budget_liters written here left Reserve blank — the exact gap the
 * user reported for December ("Consumed" was already populated from
 * Dec2025_Validation.xlsx via importHistoricalEmailData.js; only
 * budget_liters, and therefore reserve_liters, was missing). Since
 * `final_consumption_l` for the same site+month already lives on the
 * existing HistoricalMonthlyRecord doc (imported separately), this
 * script now reads it back per site before writing, and computes
 * reserve_liters/fully_exhausted from it — the same arithmetic
 * importHistoricalEmailData.js and backfillJuneReserve2026.js already
 * use. This means the dry run now needs a database connection too
 * (read-only until --confirm), unlike before — the preview needs the
 * existing consumption figures to show a real reserve number.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importSbcBudgetFiles.js
 *   node scripts/importSbcBudgetFiles.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

// Only December — see the module docblock's Phase 151 note for why
// March was removed from this list (superseded by
// pairSbcRequestWithExistingApproval.js as of Phase 83, and stale here
// since). January, February, April, and May all have a genuinely
// different, existing "approved" figure already imported from the
// multi-month rollup (Total [Month]-26 Budget given to the SBCs), and
// this file's own "Requested Quantity" column is a real, different
// number from that — request vs. approval, not the same figure twice
// — so they're paired properly in pairSbcRequestWithExistingApproval.js
// instead, writing to BudgetRequestApproval, not touching
// HistoricalMonthlyRecord. December has no such second figure at all.
const SOURCES = [
  { month_key: '2025-12', file: 'SbcBudget_Dec2025.xlsx', sheet: 'Feuil1' },
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function findCol(header, name) {
  const target = String(name).replace(/\s+/g, ' ').trim();
  const i = header.findIndex(h => typeof h === 'string' && h.replace(/\s+/g, ' ').trim() === target);
  return i === -1 ? null : i;
}

function parseSource(src) {
  const filePath = path.join(DATA_DIR, src.file);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[src.sheet], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findCol(header, 'IHS Site ID'),
    site_name: findCol(header, 'Site Name'),
    cluster: findCol(header, 'Cluster'),
    region: findCol(header, 'State'),
    topology: findCol(header, 'Site Topology'),
    requested_l: findCol(header, 'Requested Quantity (L)'),
  };

  const missing = Object.entries(idx).filter(([, v]) => v === null);
  if (missing.length) {
    throw new Error(`${src.file} missing expected column(s): ${missing.map(([k]) => k).join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      month_key: src.month_key,
      budget_liters: toNum(row[idx.requested_l]),
      source_file: src.file,
    });
  }
  return records;
}

async function main() {
  const allRecords = [];
  for (const src of SOURCES) {
    const records = parseSource(src);
    const total = records.reduce((s, r) => s + (r.budget_liters || 0), 0);
    console.log(`── ${src.month_key} (${src.file}): ${records.length} site(s). Total budget: ${Math.round(total).toLocaleString()} L.`);
    allRecords.push(...records);
  }

  console.log(`\n── Total: ${allRecords.length} record(s) across ${SOURCES.length} month(s). ──`);

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB (read-only until --confirm)');

  // Phase 151 — read back each site's already-recovered
  // final_consumption_l (from the same month's own Validation-sheet
  // import) so reserve_liters/fully_exhausted can be computed here
  // too, not just budget_liters. Read-only lookup, not a write.
  const monthKeys = [...new Set(allRecords.map(r => r.month_key))];
  const existing = await HistoricalMonthlyRecord.find(
    { month_key: { $in: monthKeys } },
    { site_id: 1, month_key: 1, final_consumption_l: 1 }
  ).lean();
  const consumptionByKey = new Map(existing.map(e => [`${e.site_id}|${e.month_key}`, e.final_consumption_l ?? null]));

  let withReserve = 0, noConsumption = 0;
  const ops = allRecords.map(r => {
    const final_consumption_l = consumptionByKey.get(`${r.site_id}|${r.month_key}`) ?? null;
    const reserve_liters = (r.budget_liters != null && final_consumption_l != null)
      ? Math.round((r.budget_liters - final_consumption_l) * 10) / 10
      : null;
    const fully_exhausted = reserve_liters != null ? reserve_liters <= 0 : null;
    if (reserve_liters != null) withReserve++; else noConsumption++;

    return {
      updateOne: {
        filter: { site_id: r.site_id, month_key: r.month_key },
        update: { $set: {
          budget_liters: r.budget_liters, source_file: r.source_file,
          site_name: r.site_name, cluster: r.cluster, region: r.region, topology: r.topology,
          reserve_liters, fully_exhausted,
        } },
        upsert: true,
      },
    };
  });
  console.log(`  ${withReserve} record(s) will get a real reserve_liters figure (had a recovered final_consumption_l to compare against).`);
  console.log(`  ${noConsumption} record(s) still won't — no final_consumption_l recovered for them (or no existing HistoricalMonthlyRecord doc yet).`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${ops.length} record(s) to the database.`);
    await mongoose.disconnect();
    return;
  }

  const result = await HistoricalMonthlyRecord.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
