/**
 * cleanupOrphanedTankAudits.js
 * diesel-system/scripts/cleanupOrphanedTankAudits.js
 *
 * Phase 132. User reported deleted sites still appearing on the Tank
 * Audit dashboard's "Full audit list" table after running
 * removeNonKeptClusters.js. Traced the real cause: listAudits (the
 * endpoint that powers that table) queries TankAudit directly, with
 * no join or filter against the current Site collection at all — so
 * if a Site document is gone but its TankAudit records aren't, the
 * dashboard has no way to know and will keep showing them
 * indefinitely, regardless of how the orphaning happened (a partial
 * cascade failure, a manual deletion that bypassed the cleanup
 * script, or anything else).
 *
 * This script doesn't assume a specific cause — it just looks at the
 * CURRENT state: any TankAudit whose site_id_ihs doesn't match any
 * currently-existing Site document is orphaned, regardless of why.
 *
 * Same safety pattern as every destructive script in this project:
 * dry run by default, full backup written before any deletion, and
 * the deletion refused entirely if the backup doesn't match the
 * expected count exactly.
 *
 * Usage:
 *   node scripts/cleanupOrphanedTankAudits.js           (dry run)
 *   node scripts/cleanupOrphanedTankAudits.js --confirm (writes)
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const CONFIRM = process.argv.includes('--confirm');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const Site = require('../models/Site');
  const TankAudit = require('../models/TankAudit');

  const existingSiteIds = new Set(await Site.distinct('IHS_ID_SITE'));
  console.log(`Sites currently in the live database: ${existingSiteIds.size}`);

  const allAudits = await TankAudit.find({})
    .select('site_id_ihs site_name cluster status audit_date auditor_name')
    .lean();
  console.log(`Total TankAudit records: ${allAudits.length}`);

  const orphaned = allAudits.filter(a => !existingSiteIds.has(a.site_id_ihs));
  console.log(`Orphaned (site_id_ihs matches no current Site document): ${orphaned.length}\n`);

  if (!orphaned.length) {
    console.log('Nothing orphaned — the Tank Audit dashboard should already only show real, current sites.');
    console.log('If you\'re still seeing removed sites there, try a hard refresh (Ctrl+Shift+R) — this may be a cached page, not a data problem.');
    await mongoose.disconnect();
    return;
  }

  const byCluster = new Map();
  for (const a of orphaned) {
    const key = a.cluster || '(no cluster recorded)';
    byCluster.set(key, (byCluster.get(key) || 0) + 1);
  }
  console.log('Orphaned audits by cluster (as recorded on the audit itself, not the live Site — that\'s gone):');
  for (const [cluster, count] of byCluster) console.log(`  ${cluster}: ${count}`);

  const bySite = new Map();
  for (const a of orphaned) {
    const key = `${a.site_id_ihs} (${a.site_name || 'unknown name'})`;
    bySite.set(key, (bySite.get(key) || 0) + 1);
  }
  console.log(`\nOrphaned audits by site (${bySite.size} distinct sites):`);
  for (const [site, count] of [...bySite.entries()].slice(0, 20)) console.log(`  ${site}: ${count}`);
  if (bySite.size > 20) console.log(`  ...and ${bySite.size - 20} more sites.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to delete these ${orphaned.length} orphaned audit record(s).`);
    await mongoose.disconnect();
    return;
  }

  const backupDir = path.join(__dirname, `orphaned_audits_backup_${Date.now()}`);
  fs.mkdirSync(backupDir, { recursive: true });
  const fullOrphanedDocs = await TankAudit.find({ _id: { $in: orphaned.map(a => a._id) } }).lean();
  if (fullOrphanedDocs.length !== orphaned.length) {
    console.error(`\n✗ Aborting — expected to back up ${orphaned.length} but found ${fullOrphanedDocs.length}. Not deleting anything until this is understood.`);
    await mongoose.disconnect();
    process.exit(1);
  }
  const backupFile = path.join(backupDir, 'TankAudit.json');
  fs.writeFileSync(backupFile, JSON.stringify(fullOrphanedDocs, null, 2));
  console.log(`\n✓ Backed up ${fullOrphanedDocs.length} full document(s) to ${backupFile} before deleting anything.`);

  const result = await TankAudit.deleteMany({ _id: { $in: orphaned.map(a => a._id) } });
  console.log(`✓ Deleted ${result.deletedCount} orphaned audit record(s).`);
  console.log('These will no longer appear on the Tank Audit dashboard.');

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
