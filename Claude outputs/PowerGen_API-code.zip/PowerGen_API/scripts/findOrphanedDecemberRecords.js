/**
 * findOrphanedDecemberRecords.js
 * diesel-system/scripts/findOrphanedDecemberRecords.js
 *
 * Read-only diagnostic — same purpose as findOrphanedMarchRecord.js, but
 * for December 2025, where verifyHistoricalDataImports.js's own dry run
 * surfaced a live count of 184 HistoricalMonthlyRecord documents for
 * 2025-12 against an expected, verified-correct 164 (Dec2025_Validation.xlsx's
 * real "Validation" sheet has exactly 164 data rows — see Phase 172).
 *
 * Likely mechanism, not yet confirmed against live data: importSbcBudgetFiles.js
 * upserts on { site_id, month_key } for December's 184-site
 * SbcBudget_Dec2025.xlsx (budget_liters only — it never touches
 * final_consumption_l) — so if it ran, it would have created 20 new
 * HistoricalMonthlyRecord documents for sites present in the 184-site
 * budget file but absent from the 164-site real Validation reconciliation,
 * on top of $set-ing `source_file` on every one of the 184 it touches,
 * including the 164 that already came from Dec2025_Validation.xlsx. That
 * means source_file is NOT a reliable signal here (unlike March) if
 * importSbcBudgetFiles.js ran after the Validation import — this script
 * leads with final_consumption_l (never written by importSbcBudgetFiles.js)
 * as the primary signal instead, and reports source_file only for context.
 *
 * Doesn't write or delete anything; just identifies the specific site_ids
 * so they can be reviewed before any cleanup decision.
 *
 * Usage:
 *   node scripts/findOrphanedDecemberRecords.js
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const records = await HistoricalMonthlyRecord.find(
    { month_key: '2025-12' },
    { site_id: 1, source_file: 1, budget_liters: 1, final_consumption_l: 1 }
  ).sort({ site_id: 1 }).lean();

  console.log(`Found ${records.length} record(s) for 2025-12 (expected 164 from the real Validation file).\n`);

  const bySource = {};
  for (const r of records) {
    const key = r.source_file || '(none)';
    bySource[key] = (bySource[key] || 0) + 1;
  }
  console.log('Breakdown by source_file (see this script\'s docblock — may not be a reliable signal for December):');
  for (const [file, count] of Object.entries(bySource)) {
    console.log(`  ${file}: ${count}`);
  }

  const nullCons = records.filter(r => r.final_consumption_l == null);
  console.log(`\n${nullCons.length} record(s) with no final_consumption_l — sites the real Validation file never touched (budgeted but not reconciled):`);
  for (const r of nullCons) {
    console.log(`  site_id: ${r.site_id} | source_file: ${r.source_file} | budget_liters: ${r.budget_liters} | final_consumption_l: ${r.final_consumption_l}`);
  }

  if (nullCons.length !== records.length - 164) {
    console.log(`\nNote: ${nullCons.length} null-consumption record(s) found, but ${records.length - 164} extra record(s) exist over the expected 164 — these two numbers should match if the "budgeted but not reconciled" theory fully explains the gap. If they don't, something else is going on and this needs a closer look before any cleanup.`);
  }

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
