/**
 * importAugustCyclePrecisionData.js
 * diesel-system/scripts/importAugustCyclePrecisionData.js
 *
 * Phase 115. Three real gaps, closed in priority order (mail data
 * preferred over the Excel workbook, per the user's own instruction —
 * the workbook can lag behind what's actually been delivered, confirmed
 * directly during this phase: Cycle Summary's own "Total Delivered"
 * figure for site IHS_BNB_004 only reflected the FIRST of three real
 * August deliveries, understating the true total by more than half):
 *
 *   1. Opening Meter (hrs) — generator run-hours taken alongside
 *      opening stock at cycle start. Backfilled into
 *      CycleEndStockSnapshot.run_hours for cycle_key "2026-07", same
 *      collection Phase 107 used for opening stock itself. Excel-only
 *      source; no mail equivalent exists for this specific reading.
 *
 *   2. Total delivered this cycle, exact — summed from real per-
 *      delivery-event rows in the "Month to Date GRATO Refueling
 *      Tracker August 2026" email (the dip-stick "Refuelled Qty (L)"
 *      reading, matching the measurement method used everywhere else
 *      in this reconciliation chain), filtered to the August cycle's
 *      own date window. Falls back to the Excel's aggregate "Total
 *      Delivered (Added)(L)" column only for sites with zero events
 *      found in the mail tracker.
 *
 *   3. Closing Meter (hrs) — the RH reading taken on the LAST date
 *      fuel was delivered to a site this cycle. Taken from that same
 *      last delivery event's "Gen running hour" column in the mail
 *      tracker. Falls back to the Excel's "Closing Meter (hrs)"
 *      column (a single value, no exact date) only when no mail data
 *      exists for a site.
 *
 * Additive only — every write checks the live document first and
 * skips anything already populated, exactly like Phase 107's script.
 *
 * Usage:
 *   node scripts/importAugustCyclePrecisionData.js           (dry run)
 *   node scripts/importAugustCyclePrecisionData.js --confirm (writes)
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');
const CONFIRM = process.argv.includes('--confirm');

const DATA_DIR = path.join(__dirname, 'tank_audit_data');
const WORKBOOK = path.join(DATA_DIR, 'AUGUST_2026_CYCLE_ANALYSIS.xlsx');
const TRACKER = path.join(DATA_DIR, 'RefuelingTracker_27Aug2026.xlsx'); // Phase 135 — newer, more complete than the original 20 Aug version this constant used to point to
const TRACKER_ASOF_DATE = new Date(2026, 7, 27); // single source of truth for this file's as-of date, used everywhere below instead of a repeated hardcoded value

const CYCLE_START = new Date(2026, 6, 26); // 26 Jul 2026
const CYCLE_END = new Date(2026, 7, 25, 23, 59, 59); // 25 Aug 2026

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelDateToJs(serial) {
  if (typeof serial !== 'number') return null;
  return new Date(Math.round((serial - 25569) * 86400 * 1000));
}

/** Excel fallback: Opening Meter (hrs), Closing Meter (hrs), Total Delivered (Added)(L) per site. */
function parseCycleSummaryFallbacks() {
  const wb = XLSX.readFile(WORKBOOK);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Cycle Summary'], { header: 1, defval: null, raw: true });
  const out = {};
  for (const row of rows.slice(4)) {
    if (!row || !row[0] || row[0] === 'IHS SITE ID') continue;
    const openingMeter = row[14];
    const closingMeter = row[15];
    const totalDelivered = row[9];
    out[String(row[0]).trim()] = {
      opening_meter_hours: typeof openingMeter === 'number' ? openingMeter : null,
      closing_meter_hours: typeof closingMeter === 'number' ? closingMeter : null,
      total_delivered_l: typeof totalDelivered === 'number' ? totalDelivered : null,
    };
  }
  return out;
}

/**
 * Mail tracker: sums dip-stick "Refuelled Qty (L)" per site within the
 * cycle window, and finds each site's chronologically LAST delivery
 * event (for closing_meter_hours + its exact date).
 */
/**
 * Finds a column's index by its header text, rather than a hardcoded
 * position — Phase 135. A newer version of this same tracker shifted
 * one column two positions to the right while every earlier column
 * stayed exactly where it was; a purely positional approach would
 * have silently pulled the wrong field with no indication anything
 * had moved. This resolves and logs the real index every time the
 * script runs, so a future shift is visible immediately instead of
 * silently wrong.
 *
 * @param {Array} headerRow
 * @param {string} text - exact header text to find
 * @param {number} [occurrence=1] - which match to use when the same
 *   header text appears more than once (1 = first, 2 = second, ...) —
 *   needed specifically for "Refuelled Qty (L)", which legitimately
 *   appears twice: the dip-stick reading, then the RMS reading.
 * @returns {number} the resolved column index
 * @throws if the header text isn't found at all, or the requested
 *   occurrence doesn't exist — a missing column should stop the
 *   import loudly, not silently produce all-null data for that field.
 */
function findColumnIndex(headerRow, text, occurrence = 1) {
  let seen = 0;
  const target = text.trim();
  for (let i = 0; i < headerRow.length; i++) {
    if (typeof headerRow[i] === 'string' && headerRow[i].trim() === target) {
      seen++;
      if (seen === occurrence) return i;
    }
  }
  throw new Error(`Column "${text}" (occurrence ${occurrence}) not found in the tracker's header row — the file's structure may have changed. Refusing to guess; update the column resolution below after checking the real header row.`);
}

function parseRefuelingTracker() {
  const wb = XLSX.readFile(TRACKER);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Refueling Tracker'], { header: 1, defval: null, raw: true });
  const headerRow = rows[3];

  const COL = {
    date: findColumnIndex(headerRow, 'Date'),
    siteId: findColumnIndex(headerRow, 'Site ID'),
    siteName: findColumnIndex(headerRow, 'Site name'),
    cluster: findColumnIndex(headerRow, 'Cluster'),
    dipStickQty: findColumnIndex(headerRow, 'Refuelled Qty (L)', 1),
    rmsQty: findColumnIndex(headerRow, 'Refuelled Qty (L)', 2),
    flowMeterQty: findColumnIndex(headerRow, 'Truck Flow Meter Refuelled Qty (L)'),
    truckPlate: findColumnIndex(headerRow, 'TruckPlateNumber'),
    genHour: findColumnIndex(headerRow, 'Gen running hour'),
    raison: findColumnIndex(headerRow, 'Raison'),
  };
  console.log('Resolved tracker column positions (by header text, not hardcoded):', COL);

  const dataRows = rows.slice(4).filter(r => r && r[COL.siteId]);

  const bySite = {};
  const allEvents = [];
  for (const r of dataRows) {
    const siteId = r[COL.siteId];
    const eventDate = excelDateToJs(r[COL.date]);
    if (!eventDate || eventDate < CYCLE_START || eventDate > CYCLE_END) continue; // outside this cycle — not counted

    const qty = toNum(r[COL.dipStickQty]); // dip-stick "Refuelled Qty (L)" — the primary reading, matching opening/closing stock's own measurement method
    const rmsQty = toNum(r[COL.rmsQty]);
    const flowMeterQty = toNum(r[COL.flowMeterQty]);
    const genHour = toNum(r[COL.genHour]);

    if (!bySite[siteId]) bySite[siteId] = { total_delivered_l: 0, eventCount: 0, lastEvent: null };
    if (qty != null) {
      bySite[siteId].total_delivered_l += qty;
      bySite[siteId].eventCount++;

      allEvents.push({
        site_id: siteId,
        site_name: r[COL.siteName] ?? null,
        cluster: r[COL.cluster] ?? null,
        delivery_date: eventDate,
        quantity_l: Math.round(qty * 100) / 100,
        dip_stick_qty_l: qty,
        rms_qty_l: rmsQty,
        truck_flow_meter_qty_l: flowMeterQty,
        gen_running_hour: genHour,
        truck_plate_number: r[COL.truckPlate] ?? null,
        raison: r[COL.raison] ?? null,
      });
    }
    if (!bySite[siteId].lastEvent || eventDate > bySite[siteId].lastEvent.date) {
      bySite[siteId].lastEvent = { date: eventDate, gen_hour: genHour };
    }
  }
  return { bySite, allEvents };
}

async function main() {
  console.log('── Parsing source files ──────────────────────────────────');
  const excelFallbacks = parseCycleSummaryFallbacks();
  const { bySite: mailData, allEvents } = parseRefuelingTracker();
  console.log(`Excel Cycle Summary: ${Object.keys(excelFallbacks).length} site(s) with fallback figures.`);
  console.log(`Mail refueling tracker: ${Object.keys(mailData).length} site(s) with at least one delivery event in the August cycle window (${allEvents.length} individual delivery events total).`);

  const mailSitesWithNoGenHour = Object.entries(mailData).filter(([, d]) => d.lastEvent && d.lastEvent.gen_hour == null).map(([id]) => id);
  if (mailSitesWithNoGenHour.length) {
    console.log(`  ⚠ ${mailSitesWithNoGenHour.length} site(s) have mail delivery events but no Gen running hour on the last one — will fall back to Excel for closing_meter_hours: ${mailSitesWithNoGenHour.slice(0, 10).join(', ')}${mailSitesWithNoGenHour.length > 10 ? '…' : ''}`);
  }

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log('Re-run with --confirm to write to the database.');
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const Site = require('../models/Site');
  const CycleReconciliation = require('../models/CycleReconciliation');
  const CycleEndStockSnapshot = require('../models/CycleEndStockSnapshot');
  const FuelDeliveryEvent = require('../models/FuelDeliveryEvent');

  // Individual delivery events — inserted with upsert on the
  // collection's own unique index, so re-running this script never
  // creates duplicates, and any event already present is left as-is
  // rather than re-written unnecessarily.
  let eventsInserted = 0, eventsAlreadyExisted = 0, eventsErrored = 0;
  for (const ev of allEvents) {
    try {
      const result = await FuelDeliveryEvent.updateOne(
        { site_id: ev.site_id, cycle_key: '2026-08', delivery_date: ev.delivery_date, quantity_l: ev.quantity_l },
        { $setOnInsert: { ...ev, cycle_key: '2026-08', source_file: 'RefuelingTracker_20Aug2026.xlsx' } },
        { upsert: true }
      );
      if (result.upsertedCount > 0) eventsInserted++; else eventsAlreadyExisted++;
    } catch (err) {
      eventsErrored++;
      console.error(`  ✗ Delivery event for ${ev.site_id} on ${ev.delivery_date.toISOString().slice(0, 10)}: ${err.message}`);
    }
  }
  console.log(`\n── Individual delivery events (FuelDeliveryEvent) ──`);
  console.log(`  Inserted: ${eventsInserted} | Already existed: ${eventsAlreadyExisted} | Errored: ${eventsErrored}`);

  const allSiteIds = new Set([...Object.keys(excelFallbacks), ...Object.keys(mailData)]);

  let openingMeterFilled = 0, openingMeterSkippedExisting = 0, openingMeterNoSite = [];
  let deliveredMailFilled = 0, deliveredExcelFallback = 0, deliveredSkippedExisting = 0, deliveredNoData = [];
  let closingMeterMailFilled = 0, closingMeterExcelFallback = 0, closingMeterSkippedExisting = 0, closingMeterNoData = [];

  for (const siteId of allSiteIds) {
    const site = await Site.findOne({ IHS_ID_SITE: siteId }).select('_id').lean();
    if (!site) continue; // Phase 113's diagnostic already surfaces unmatched sites via the other import script — not repeated here

    // 1. Opening meter hours — CycleEndStockSnapshot for prior cycle 2026-07
    const snapshot = await CycleEndStockSnapshot.findOne({ cycle_key: '2026-07', site: site._id });
    const excelFb = excelFallbacks[siteId];
    if (snapshot) {
      if (snapshot.run_hours == null && excelFb?.opening_meter_hours != null) {
        snapshot.run_hours = excelFb.opening_meter_hours;
        await snapshot.save();
        openingMeterFilled++;
      } else if (snapshot.run_hours != null) {
        openingMeterSkippedExisting++;
      }
    } else {
      openingMeterNoSite.push(siteId); // no snapshot at all — Phase 107's script handles snapshot creation, not this one
    }

    // 2 & 3. Delivered total + closing meter — CycleReconciliation for 2026-08
    let recon = await CycleReconciliation.findOne({ site_id: siteId, cycle_key: '2026-08' });
    if (!recon) continue; // this site has no reconciliation record for the cycle at all — out of scope for this script

    const mail = mailData[siteId];

    // Phase 135: refresh when a genuinely newer tracker source is
    // available, rather than permanently skip any site an earlier,
    // less-complete import already touched. A record with no as-of
    // date at all came from the Excel fallback (a weaker source than
    // a real per-delivery-event tracker) and is always worth
    // upgrading once real mail data exists for that site.
    const existingIsStale = recon.mail_verified_delivered_l == null
      || recon.mail_verified_delivered_asof == null
      || recon.mail_verified_delivered_asof < TRACKER_ASOF_DATE;

    if (!existingIsStale) {
      deliveredSkippedExisting++;
    } else if (mail && mail.eventCount > 0) {
      recon.mail_verified_delivered_l = Math.round(mail.total_delivered_l * 100) / 100;
      recon.mail_verified_delivered_asof = TRACKER_ASOF_DATE;
      deliveredMailFilled++;
    } else if (recon.mail_verified_delivered_l == null && excelFb?.total_delivered_l != null) {
      recon.mail_verified_delivered_l = excelFb.total_delivered_l;
      recon.mail_verified_delivered_asof = null; // Excel fallback has no exact as-of date
      deliveredExcelFallback++;
    } else if (recon.mail_verified_delivered_l == null) {
      deliveredNoData.push(siteId);
    } else {
      // Already had a value from an earlier, less-complete source, but
      // this newer tracker has no data for this specific site — leave
      // the existing (older but real) value in place rather than
      // overwrite it with nothing.
      deliveredSkippedExisting++;
    }

    // Phase 135: refresh when this tracker's own last-delivery-event
    // date is genuinely later than what's already stored — comparing
    // the real event dates directly is more precise than an import
    // timestamp, since it's comparing the actual thing that matters
    // (has a later real delivery been found for this site).
    const existingClosingIsStale = recon.closing_meter_hours == null
      || recon.closing_meter_date == null
      || (mail?.lastEvent?.date && recon.closing_meter_date < mail.lastEvent.date);

    if (!existingClosingIsStale) {
      closingMeterSkippedExisting++;
    } else if (mail?.lastEvent?.gen_hour != null) {
      recon.closing_meter_hours = mail.lastEvent.gen_hour;
      recon.closing_meter_date = mail.lastEvent.date;
      recon.closing_meter_source = 'mail_verified';
      closingMeterMailFilled++;
    } else if (recon.closing_meter_hours == null && excelFb?.closing_meter_hours != null) {
      recon.closing_meter_hours = excelFb.closing_meter_hours;
      recon.closing_meter_date = null; // Excel fallback has no exact date for this reading
      recon.closing_meter_source = 'cycle_summary_backfill';
      closingMeterExcelFallback++;
    } else if (recon.closing_meter_hours == null) {
      closingMeterNoData.push(siteId);
    } else {
      closingMeterSkippedExisting++;
    }

    await recon.save();
  }

  console.log(`\n── Opening Meter Hours (CycleEndStockSnapshot, 2026-07) ──`);
  console.log(`  Filled from Excel: ${openingMeterFilled} | Already had a value: ${openingMeterSkippedExisting} | No snapshot exists yet: ${openingMeterNoSite.length}`);

  console.log(`\n── Total Delivered, exact (CycleReconciliation.mail_verified_delivered_l, 2026-08) ──`);
  console.log(`  Filled from mail tracker: ${deliveredMailFilled} | Filled from Excel fallback: ${deliveredExcelFallback} | Already had a value: ${deliveredSkippedExisting} | No data in either source: ${deliveredNoData.length}`);
  if (deliveredNoData.length) console.log(`  Site(s) with no delivery data anywhere: ${deliveredNoData.join(', ')}`);

  console.log(`\n── Closing Meter Hours (CycleReconciliation, 2026-08) ──`);
  console.log(`  Filled from mail tracker: ${closingMeterMailFilled} | Filled from Excel fallback: ${closingMeterExcelFallback} | Already had a value: ${closingMeterSkippedExisting} | No data in either source: ${closingMeterNoData.length}`);
  if (closingMeterNoData.length) console.log(`  Site(s) with no closing meter data anywhere: ${closingMeterNoData.join(', ')}`);

  console.log('\n── Done. Nothing that already had real data was overwritten. ──');
  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
