/**
 * importTomCardAllocation.js
 * diesel-system/scripts/importTomCardAllocation.js
 *
 * Imports the recovered Tom Card allocation document — cluster-level
 * fuel card funding submitted ahead of a cycle (see
 * models/TomCardAllocation.js and scripts/historical_email_data/README.md
 * for the full "why" and the source email this came from).
 *
 * WHY A KNOWN-CLUSTER-NAME LOOKUP INSTEAD OF POSITIONAL/SPACING PARSING:
 * Checked this directly before writing the parser — extracted this same
 * PDF with two different libraries during investigation (pdfplumber,
 * used to explore the file, vs. pdf-parse, the one actually used here)
 * and they collapsed whitespace completely differently. pdfplumber kept
 * "Bonaberi 1 470 828 ..." cleanly spaced; pdf-parse (the library this
 * script actually uses) produces "Bonaberi 1470 828 ..." — the cluster
 * name runs directly into its own quantity with no separating space.
 * A regex built and tested against one library's output would have
 * silently failed against the other. Rebuilt and re-verified the parser
 * against pdf-parse's actual real output before trusting it. Since the
 * cluster list is small and fixed, matching against a known-name lookup
 * sidesteps the whitespace ambiguity entirely rather than trying to
 * out-guess it with a smarter regex.
 *
 * WHY THE VENDOR BREAKDOWN IS ANCHOR-MATCHED, NOT POSITION-MATCHED:
 * Also checked directly: pdf-parse's line order for the vendor section
 * doesn't match reading order at all — "TOTALENERGIES" and "TRADEX"
 * labels appear several lines *after* their own numbers in the raw
 * extracted text, not before. Rather than assume a text-extraction
 * order that's already been shown to be unreliable, each amount is
 * found by matching the specific line it appears on directly (e.g. the
 * "Fuel for JAN 2026 Cycle" line), independent of surrounding order.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importTomCardAllocation.js
 *   node scripts/importTomCardAllocation.js --confirm
 */
'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const pdfParse = require('pdf-parse');

const TomCardAllocation = require('../models/TomCardAllocation');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'TomCard_Allocation_Dec2025.pdf';
const FUNDED_CYCLE_KEY = '2026-01'; // confirmed from the document's own "Fuel for JAN 2026 Cycle" text, not its stale title

const KNOWN_CLUSTERS = ['Bonaberi 1', 'Bonaberi 2', 'Ndogbong', 'Kotto', 'Edea', 'Pouma 1', 'Pouma 2', 'Sup Edea', 'Sup Dla'];

function toNum(s) {
  if (!s) return null;
  const n = Number(String(s).replace(/,/g, '').trim());
  return Number.isFinite(n) ? n : null;
}

function parseClusterRows(lines) {
  const records = [];
  for (const line of lines) {
    const cluster = KNOWN_CLUSTERS.find(c => line.startsWith(c));
    if (!cluster) continue;
    const rest = line.slice(cluster.length).trim();
    const m = rest.match(/^(\d+)\s+(\d+)\s+([\d,]+)\s+Total(\d+)\s*$/);
    if (!m) {
      console.log(`  ⚠ ${cluster}: no allocation recorded this cycle — skipped.`);
      continue;
    }
    records.push({
      cluster,
      quantity_l: Number(m[1]),
      unit_price_xaf: Number(m[2]),
      amount_xaf: toNum(m[3]),
      card_number: m[4],
    });
  }
  return records;
}

async function main() {
  const filePath = path.join(DATA_DIR, SOURCE_FILE);
  const data = await pdfParse(fs.readFileSync(filePath));
  const lines = data.text.split('\n').map(l => l.trim()).filter(Boolean);

  const clusterRecords = parseClusterRows(lines);
  console.log(`Parsed ${clusterRecords.length} cluster allocation(s).`);

  const fuelLine = lines.find(l => l.startsWith('Fuel for JAN 2026 Cycle'));
  const fuelMatch = fuelLine?.match(/Fuel for JAN 2026 Cycle([\d,]+)\s+(\d+)\s+([\d,]+)/);
  const fuel_amount_xaf = fuelMatch ? toNum(fuelMatch[3]) : null;

  const rechargeLine = lines.find(l => l.startsWith('Recharge Fee'));
  const rechargeMatch = rechargeLine?.match(/([\d,]+)\s*$/);
  const recharge_fee_xaf = rechargeMatch ? toNum(rechargeMatch[1]) : null;

  const grandTotalLine = lines.find(l => l.startsWith('GRAND TOTAL'));
  const grandTotalMatch = grandTotalLine?.match(/GRAND TOTAL([\d,]+)/);
  const grand_total_xaf = grandTotalMatch ? toNum(grandTotalMatch[1]) : null;

  const tradexLine = lines.find(l => l.startsWith('Fuel for JAN 2026') && !l.includes('Cycle'));
  const tradex_amount_xaf = tradexLine?.includes('-') ? 0 : null; // this document shows no TRADEX charge this cycle

  const dateLine = lines.find(l => /^\d{2}\/\d{2}\/\d{4}$/.test(l));
  const submitted_date = dateLine ? new Date(dateLine.split('/').reverse().join('-')) : null;

  const nameIdx = dateLine ? lines.indexOf(dateLine) - 1 : -1;
  const submitted_by = nameIdx >= 0 ? lines[nameIdx] : null;

  console.log(`Fuel funding: ${fuel_amount_xaf?.toLocaleString()} XAF | Recharge fee: ${recharge_fee_xaf?.toLocaleString()} XAF | Grand total: ${grand_total_xaf?.toLocaleString()} XAF`);
  console.log(`Submitted by: ${submitted_by || '(not found)'}, dated ${submitted_date?.toISOString().slice(0,10) || '(not found)'}`);

  const records = clusterRecords.map(r => ({
    ...r,
    funded_cycle_key: FUNDED_CYCLE_KEY,
    fuel_amount_xaf,
    recharge_fee_xaf,
    totalenergies_total_xaf: (fuel_amount_xaf || 0) + (recharge_fee_xaf || 0),
    tradex_amount_xaf,
    grand_total_xaf,
    submitted_date,
    submitted_by,
    source_file: SOURCE_FILE,
  }));

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${records.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = records.map(r => ({
    updateOne: {
      filter: { cluster: r.cluster, funded_cycle_key: r.funded_cycle_key },
      update: { $set: r },
      upsert: true,
    },
  }));
  const result = await TomCardAllocation.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
