/**
 * findSiteRecordHistory.js
 * diesel-system/scripts/findSiteRecordHistory.js
 *
 * Read-only. Searches every collection in this system that could
 * plausibly reference a site for records tied to a given site name,
 * and prints a consolidated, chronological history.
 *
 * Built to be robust to the real ambiguity a name search has to deal
 * with:
 *   - The site's real name in the Site collection might not exactly
 *     match what's being searched for (different spacing, partial
 *     name, a name recorded slightly differently elsewhere) — resolves
 *     the Site record with a flexible, case-insensitive, partial match
 *     first, rather than requiring an exact string.
 *   - The site might not exist in the Site collection at all (a real,
 *     confirmed possibility in this system — Phase 113 found a site
 *     with real historical data but no live Site record). If no Site
 *     match is found, this still runs a direct name-text search across
 *     every collection that carries a site_name-style field, rather
 *     than give up.
 *   - Three genuinely different ways collections reference a site were
 *     found while building this: a string ID field (site_id,
 *     site_id_ihs, IHS_ID_SITE — the common case), a plain-string
 *     siteId field (Notifications), and a MongoDB ObjectId reference
 *     field (RefuelWorkflow, TechnicianLocationPing) — checked each
 *     model's actual schema directly before writing this, not assumed
 *     from the common case alone. All three are queried where relevant;
 *     MongoDB simply returns no match for a condition that doesn't
 *     apply to a given collection's real schema, so this is safe to do
 *     uniformly without needing a hand-tuned per-model field list.
 *
 * This is read-only — it does not modify anything.
 *
 * Usage:
 *   node scripts/findSiteRecordHistory.js "Ndokoti Brasseries"
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');

const searchName = process.argv[2];

// Every model checked directly against its own schema before being
// added here (see the file-level comment) — not a guess at what
// "probably" has a site reference. objectIdField is set only for the
// two models confirmed to use a real ObjectId reference rather than a
// string.
const MODELS_TO_SEARCH = [
  'AdHocFuelRequest', 'BudgetRequestApproval', 'CmsDailyRecord', 'CycleEndStockSnapshot',
  'CycleReconciliation', 'DieselAlert', 'FieldVisitRecord', 'FuelConsumption',
  'FuelDeliveryEvent', 'FuelPurchase', 'FuelRequest', 'GeneratorAssignmentLedger',
  'GeneratorUpdate', 'HistoricalFieldVisit', 'HistoricalMonthlyRecord',
  'HistoricalSiteStockSnapshot', 'Maintenance', 'MidCycleBudgetRelease',
  'MidCycleEstimateSnapshot', 'Notifications', 'PlannedVsSuppliedDelivery',
  'SiteAuditChecklist', 'SiteBudget', 'SiteConsumptionHistory', 'SiteEngineeringParams',
  'SiteVisit', 'TankAudit', 'TankLevelReading', 'TankLevelUpload',
  'TechnicianSiteAudit', 'TomCardTransaction', 'ValidationRecord',
];
const OBJECTID_REF_MODELS = ['RefuelWorkflow', 'TechnicianLocationPing'];

const STRING_ID_FIELDS = ['site_id', 'site_id_ihs', 'IHS_ID_SITE', 'siteId'];
const NAME_FIELDS = ['site_name', 'Site_Name', 'siteName'];

function findDateField(doc) {
  for (const f of ['audit_date', 'delivery_date', 'visit_date', 'date', 'snapshot_date', 'createdAt', 'updatedAt']) {
    if (doc[f]) return { field: f, value: doc[f] };
  }
  return null;
}

async function main() {
  if (!searchName) {
    console.error('Usage: node scripts/findSiteRecordHistory.js "<site name>"');
    process.exit(1);
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const Site = require('../models/Site');
  const escaped = searchName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const nameRegex = new RegExp(escaped, 'i');

  console.log(`── Resolving Site record for "${searchName}" ──`);
  const siteMatches = await Site.find({
    $or: [{ Site_Name: nameRegex }, { site_name: nameRegex }],
  }).select('IHS_ID_SITE Site_Name Region GRATO_Cluster isActive').lean();

  let siteIds = [];
  let siteObjectIds = [];
  if (siteMatches.length) {
    console.log(`Found ${siteMatches.length} matching Site record(s):`);
    for (const s of siteMatches) {
      console.log(`  ${s.IHS_ID_SITE} — "${s.Site_Name}" (${s.GRATO_Cluster || 'no cluster'}, ${s.Region || 'no region'}) — active: ${s.isActive}`);
      siteIds.push(s.IHS_ID_SITE);
      siteObjectIds.push(s._id);
    }
  } else {
    console.log(`⚠ No Site record found matching "${searchName}" — searching every other collection by name text directly instead. If this site genuinely has data but no live Site record, this will still find it (a real, confirmed possibility in this system — see Phase 113).`);
  }
  console.log('');

  const allResults = [];

  for (const modelName of MODELS_TO_SEARCH) {
    let Model;
    try {
      Model = require(`../models/${modelName}`);
    } catch (err) {
      continue; // model file doesn't export a plain model (e.g. exports multiple) — skip rather than crash
    }

    const orConditions = [];
    for (const field of STRING_ID_FIELDS) {
      if (siteIds.length) orConditions.push({ [field]: { $in: siteIds } });
    }
    for (const field of NAME_FIELDS) {
      orConditions.push({ [field]: nameRegex });
    }
    if (!orConditions.length) continue;

    try {
      const docs = await Model.find({ $or: orConditions }).limit(200).lean();
      if (docs.length) {
        allResults.push({ model: modelName, count: docs.length, docs });
      }
    } catch (err) {
      console.log(`  (skipped ${modelName}: ${err.message})`);
    }
  }

  for (const modelName of OBJECTID_REF_MODELS) {
    if (!siteObjectIds.length) continue;
    let Model;
    try {
      Model = require(`../models/${modelName}`);
    } catch (err) {
      continue;
    }
    try {
      const docs = await Model.find({ siteId: { $in: siteObjectIds } }).limit(200).lean();
      if (docs.length) {
        allResults.push({ model: modelName, count: docs.length, docs });
      }
    } catch (err) {
      console.log(`  (skipped ${modelName}: ${err.message})`);
    }
  }

  console.log(`══════════════════════════════════════════════════════════`);
  console.log(` RESULTS — ${allResults.length} collection(s) with matching records`);
  console.log(`══════════════════════════════════════════════════════════\n`);

  if (!allResults.length) {
    console.log('No records found in any searched collection for this site name.');
    console.log('Worth double-checking the spelling, or trying a shorter/partial name — this search is case-insensitive and matches partial text, but requires the substring to actually appear in a name field somewhere.');
  } else {
    let totalRecords = 0;
    for (const { model, count, docs } of allResults) {
      totalRecords += count;
      console.log(`── ${model} (${count} record${count === 1 ? '' : 's'}) ──`);
      // Sorted chronologically where a usable date field exists, most
      // recent first — otherwise left in natural (insertion) order.
      const withDates = docs.map(d => ({ doc: d, dateInfo: findDateField(d) }));
      withDates.sort((a, b) => {
        if (!a.dateInfo && !b.dateInfo) return 0;
        if (!a.dateInfo) return 1;
        if (!b.dateInfo) return -1;
        return new Date(b.dateInfo.value) - new Date(a.dateInfo.value);
      });
      for (const { doc, dateInfo } of withDates.slice(0, 20)) {
        const dateStr = dateInfo ? `${dateInfo.field}: ${new Date(dateInfo.value).toISOString().slice(0, 10)}` : 'no date field found';
        const { _id, __v, ...rest } = doc;
        // Trim any large embedded arrays (photo arrays especially) down
        // to a count rather than dumping every element — this is a
        // history overview, not a full data export.
        for (const key of Object.keys(rest)) {
          if (Array.isArray(rest[key]) && rest[key].length > 3) {
            rest[key] = `[${rest[key].length} items]`;
          }
        }
        console.log(`  [${String(_id).slice(-6)}] ${dateStr}`);
        console.log(`    ${JSON.stringify(rest)}`);
      }
      if (docs.length > 20) console.log(`  ...and ${docs.length - 20} more record(s) in this collection.`);
      console.log('');
    }
    console.log(`── Total: ${totalRecords} record(s) found across ${allResults.length} collection(s). ──`);
  }

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
