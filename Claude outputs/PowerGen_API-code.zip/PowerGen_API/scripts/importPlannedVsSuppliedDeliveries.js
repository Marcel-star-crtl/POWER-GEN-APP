/**
 * importPlannedVsSuppliedDeliveries.js
 * diesel-system/scripts/importPlannedVsSuppliedDeliveries.js
 *
 * Imports the "ALL DATA" sheet from a "GRATO_FUEL PLAN JUNE-26"
 * workbook — genuinely spans 26 May through 29 June 2026 in one sheet,
 * not just June despite the filename. See
 * models/PlannedVsSuppliedDelivery.js for why this is a distinct
 * concept from field visits and purchases.
 *
 * NOTE ON THE WORKBOOK'S OTHER SHEETS:
 * This file also has "ALL DATA (2)", "PIVOT TABLE", "UNPLANNED REF",
 * and per-day tabs (20260526, 20260528, etc.). "ALL DATA" is used here
 * as the single most complete sheet (245 rows spanning the file's full
 * date range) — but this was checked, not assumed: the per-day tabs do
 * NOT cleanly reduce to "ALL DATA" filtered by date (e.g. the 26 May
 * tab has 83 real data rows; "ALL DATA" filtered to DATE DONE = 26 May
 * has only 47). This is a genuine, unreconciled discrepancy between
 * sheets in the source file itself, not a parsing issue — flagged
 * directly rather than silently resolved by picking whichever number
 * was more convenient. "ALL DATA" was still chosen as the import
 * source since it's the one sheet covering the entire date range in
 * one place; the day-tabs may hold additional records not reflected
 * here, and haven't been reconciled against this import.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importPlannedVsSuppliedDeliveries.js
 *   node scripts/importPlannedVsSuppliedDeliveries.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const PlannedVsSuppliedDelivery = require('../models/PlannedVsSuppliedDelivery');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'JuneFuelPlan_PlannedVsSupplied.xlsx';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelSerialToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400 * 1000));
  return null;
}

function findCol(header, name) {
  const target = String(name).replace(/\s+/g, ' ').trim();
  const i = header.findIndex(h => typeof h === 'string' && h.replace(/\s+/g, ' ').trim() === target);
  return i === -1 ? null : i;
}

async function main() {
  const filePath = path.join(DATA_DIR, SOURCE_FILE);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['ALL DATA'], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    region: findCol(header, 'REGION'),
    cluster: findCol(header, 'Grato Cluster'),
    site_id: findCol(header, 'Site ID IHS'),
    site_name: findCol(header, 'SITE NAME'),
    topology: findCol(header, 'Functional topology'),
    priority: findCol(header, 'Site priority'),
    date_passage: findCol(header, 'DATE DE PASSAGE'),
    date_done: findCol(header, 'DATE DONE'),
    date_submitted: findCol(header, 'DATE SUBMITTED'),
    planned: findCol(header, 'PLANNED'),
    supplied: findCol(header, 'SUPPLIED'),
    gap: findCol(header, 'GAP'),
    gap_type: findCol(header, 'GAP TYPE'),
    ref_type: findCol(header, 'REF TYPE'),
    comment: findCol(header, 'COMMENT'),
  };

  const required = ['site_id', 'date_done', 'planned'];
  const missing = required.filter(k => idx[k] === null);
  if (missing.length) {
    throw new Error(`Missing expected column(s): ${missing.join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const dateDone = excelSerialToJs(row[idx.date_done]);
    if (!dateDone) continue;
    const monthKey = `${dateDone.getUTCFullYear()}-${String(dateDone.getUTCMonth() + 1).padStart(2, '0')}`;

    records.push({
      site_id: String(row[idx.site_id]).trim(),
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      site_priority: row[idx.priority] ?? null,
      month_key: monthKey,
      date_de_passage: excelSerialToJs(row[idx.date_passage]),
      date_done: dateDone,
      date_submitted: excelSerialToJs(row[idx.date_submitted]),
      planned_l: toNum(row[idx.planned]),
      supplied_l: toNum(row[idx.supplied]),
      gap_l: toNum(row[idx.gap]),
      gap_type: row[idx.gap_type] ?? null,
      ref_type: row[idx.ref_type] ?? null,
      comment: row[idx.comment] ?? null,
      source_file: SOURCE_FILE,
    });
  }

  console.log(`Parsed ${records.length} record(s) from ${SOURCE_FILE} (${rows.length - 2} raw rows total — the rest have no "DATE DONE" value, meaning they were still-planned, not-yet-completed deliveries at the time this file was exported, correctly excluded rather than treated as a real delivery date).`);
  const byMonth = {};
  for (const r of records) {
    byMonth[r.month_key] = byMonth[r.month_key] || { count: 0, planned: 0, supplied: 0 };
    byMonth[r.month_key].count++;
    byMonth[r.month_key].planned += r.planned_l || 0;
    byMonth[r.month_key].supplied += r.supplied_l || 0;
  }
  for (const [month, d] of Object.entries(byMonth).sort()) {
    console.log(`  ${month}: ${d.count} record(s), ${Math.round(d.planned).toLocaleString()} L planned, ${Math.round(d.supplied).toLocaleString()} L supplied.`);
  }
  const gapTypes = {};
  for (const r of records) {
    const t = r.gap_type || '(none)';
    gapTypes[t] = (gapTypes[t] || 0) + 1;
  }
  console.log('  Gap type distribution:', JSON.stringify(gapTypes));

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${records.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  await PlannedVsSuppliedDelivery.deleteMany({ source_file: SOURCE_FILE });
  const result = await PlannedVsSuppliedDelivery.insertMany(records);
  console.log(`✓ Inserted ${result.length} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
