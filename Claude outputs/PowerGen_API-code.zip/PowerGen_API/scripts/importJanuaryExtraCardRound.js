/**
 * importJanuaryExtraCardRound.js
 * diesel-system/scripts/importJanuaryExtraCardRound.js
 *
 * WHY THIS EXISTS (Phase 162):
 * `TomCard_Allocation_Dec2025.pdf` is January's ONLY base Tom Card
 * funding record (470/470/440/450/480/480/-/420/380 L per cluster,
 * 3,590 L fleet-wide — confirmed genuine against the real chat total in
 * Phase 159). But that PDF is a single snapshot submitted 26/12/2025 for
 * the start of the January cycle. It was never the whole story: cards
 * get topped up again mid-cycle, the same way June 2026 has three
 * recorded "extra round" top-ups already (see models/TomCardAllocation.js
 * and importCardLimitData.js). January had no round data recovered at
 * all until now — `extra_round1_approved_l` etc. have sat null for
 * every January TomCardAllocation document, so the Cluster Cycle
 * Report's "Card Funding incl. Extra Rounds" tile has only ever shown
 * the base 470L for Bonaberi 1, never the real mid-cycle top-up.
 *
 * `GRATO_Jan26_Budget_approved.xlsx`'s "Jan Limits" sheet is that
 * missing round. It is NOT a duplicate of anything already imported —
 * checked directly:
 *   - Its "Extra 19-01-2025" column (2,000 / 5,431 / 500 / 2,500 /
 *     3,500 / 2,500 L for the 6 known clusters, sum 16,431L) happens to
 *     equal the fleet-wide "Extra Fuel Requests — Approved(L)" total
 *     already shown for January elsewhere in the app. That is a
 *     DIFFERENT table (site-level extra-fuel approval, AdHocFuelRequest/
 *     SS-approval workflow) recording the same real-world approval
 *     event from the budget side. This file records the same event from
 *     the CARD side — the actual card recharge that made those
 *     approved liters purchasable. Both are real; neither substitutes
 *     for the other on this page, which is specifically about card
 *     funding, not budget approval.
 *   - The sheet is internally self-consistent, which is why it's
 *     trusted here: for every one of the 6 rows,
 *     "New Limit on 19-01-2026" = "New Limit on 01 January 2026" +
 *     "Extra 19-01-2025 Amount" exactly (e.g. Bonaberi 1:
 *     3,066,852 + 1,656,000 = 4,722,852 ✓), and each row's own
 *     Extra Amount / Extra L ratio matches that same cluster's unit
 *     price from the original PDF exactly (828 XAF/L for Bonaberi 1/2/
 *     Kotto/Ndogbong, 837 XAF/L for Edea/Pouma 1 — identical split to
 *     the PDF's own per-cluster pricing). That consistency is real
 *     evidence this is a genuine, coherent ledger entry, not noise.
 *
 * Card numbers in this sheet (84948, 84950, 84953, 121720, 84946,
 * 84951) independently match Phase 161's CONFIRMED_CARD_NUMBERS exactly
 * — a second, independent corroboration of that fix, not used to
 * re-derive it here.
 *
 * NOT covered by this file, deliberately left null: Pouma 2, Sup Edea,
 * Sup Dla — this sheet only ever lists the same 6 clusters as the
 * "CARD LIMIT UPDATE" email thread. No 19-Jan extra-round figure for
 * those three exists in any source found so far. Not guessed.
 *
 * Writes ONLY extra_round1_approved_l / extra_round1_approved_xaf /
 * extra_round1_new_limit_xaf on the 6 existing TomCardAllocation
 * documents (cluster + funded_cycle_key: '2026-01'). Does not touch
 * quantity_l/amount_xaf/card_number (the base allocation, already
 * correct/fixed by Phase 161).
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importJanuaryExtraCardRound.js
 *   node scripts/importJanuaryExtraCardRound.js --confirm
 */
'use strict';
require('dotenv').config();
const path = require('path');
const XLSX = require('xlsx');
const mongoose = require('mongoose');
const TomCardAllocation = require('../models/TomCardAllocation');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'GRATO_Jan26_Budget_approved.xlsx';
const SHEET_NAME = 'Jan Limits';
const CYCLE_KEY = '2026-01';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(String(v).replace(/,/g, '').trim());
  return Number.isFinite(n) ? n : null;
}

async function main() {
  const wb = XLSX.readFile(path.join(DATA_DIR, SOURCE_FILE));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[SHEET_NAME], { header: 1, defval: null, raw: true });
  const header = rows[0];
  const idx = {
    cluster: header.indexOf('Cluster'),
    cardNumber: header.indexOf('Card Number'),
    extraL: header.findIndex(h => typeof h === 'string' && h.startsWith('Extra 19-01') && !h.includes('Amount')),
    extraXaf: header.findIndex(h => typeof h === 'string' && h.startsWith('Extra 19-01') && h.includes('Amount')),
    newLimit: header.indexOf('New Limit on 19-01-2026'),
  };
  if ([idx.cluster, idx.extraL, idx.extraXaf, idx.newLimit].some(i => i === -1)) {
    throw new Error(`Expected columns not found in "${SHEET_NAME}". Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r || !r[idx.cluster]) continue;
    const extra_l = toNum(r[idx.extraL]);
    const extra_xaf = toNum(r[idx.extraXaf]);
    if (extra_l === null || extra_xaf === null) continue; // no round for this cluster — skip, don't guess
    records.push({
      cluster: r[idx.cluster],
      card_number: r[idx.cardNumber] != null ? String(r[idx.cardNumber]) : null,
      extra_round1_approved_l: extra_l,
      extra_round1_approved_xaf: extra_xaf,
      extra_round1_new_limit_xaf: toNum(r[idx.newLimit]),
    });
  }

  console.log(`── Parsed ${records.length} cluster row(s) with a 19-Jan-2026 extra round from "${SHEET_NAME}" ──`);
  let totalL = 0, totalXaf = 0;
  for (const rec of records) {
    console.log(`   ${rec.cluster} (card ${rec.card_number}): +${rec.extra_round1_approved_l} L / ${rec.extra_round1_approved_xaf.toLocaleString()} XAF -> new limit ${rec.extra_round1_new_limit_xaf?.toLocaleString()} XAF`);
    totalL += rec.extra_round1_approved_l;
    totalXaf += rec.extra_round1_approved_xaf;
  }
  console.log(`   TOTAL: ${totalL.toLocaleString()} L / ${totalXaf.toLocaleString()} XAF\n`);

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const existing = await TomCardAllocation.find({ funded_cycle_key: CYCLE_KEY }).lean();
  const ops = [];
  for (const rec of records) {
    const doc = existing.find(d => d.cluster === rec.cluster);
    if (!doc) {
      console.log(`  ⚠ ${rec.cluster}: no existing TomCardAllocation document for ${CYCLE_KEY} — skipped (base allocation must exist first).`);
      continue;
    }
    if (doc.card_number !== rec.card_number) {
      console.log(`  ⚠ ${rec.cluster}: stored card_number (${doc.card_number}) doesn't match this sheet's (${rec.card_number}) — skipped rather than risk writing the wrong cluster's numbers.`);
      continue;
    }
    if (doc.extra_round1_approved_l != null) {
      console.log(`  ⚠ ${rec.cluster}: extra_round1 already has data (${doc.extra_round1_approved_l} L) — skipped rather than overwrite.`);
      continue;
    }
    ops.push({
      updateOne: {
        filter: { _id: doc._id },
        update: {
          $set: {
            extra_round1_approved_l: rec.extra_round1_approved_l,
            extra_round1_approved_xaf: rec.extra_round1_approved_xaf,
            extra_round1_new_limit_xaf: rec.extra_round1_new_limit_xaf,
            extra_rounds_comment: `Round 1 (19-Jan-2026) from ${SOURCE_FILE}, sheet "${SHEET_NAME}"`,
          },
        },
      },
    });
  }

  console.log(`\n${ops.length} document(s) would be updated.`);
  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. Re-run with --confirm to apply. ──');
    await mongoose.disconnect();
    return;
  }
  if (!ops.length) { console.log('Nothing to write.'); await mongoose.disconnect(); return; }

  const result = await TomCardAllocation.bulkWrite(ops, { ordered: false });
  console.log(`✓ Modified ${result.modifiedCount} document(s).`);
  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
