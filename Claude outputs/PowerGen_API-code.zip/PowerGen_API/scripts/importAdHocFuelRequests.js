/**
 * importAdHocFuelRequests.js
 * diesel-system/scripts/importAdHocFuelRequests.js
 *
 * Imports ad-hoc/emergency fuel requests recovered from real email
 * archives (the "Specil Refueling of [date]_Edea_pouma1_Pouma2.xlsx"
 * thread) — a real fuel shortage response spanning late July into early
 * August 2026.
 *
 * WHY ONLY THE SINGLE LATEST FILE, NOT EVERY VERSION SENT:
 * Verified directly before writing this: each new day's email attaches
 * a file that's a cumulative superset of every previous day's file, not
 * a standalone daily update. Spot-checked 27-July's data between the
 * original standalone file and its later copy inside the 04-August
 * cumulative file — the later version had 105 rows vs. the original's
 * 28, confirming it's genuinely more complete, not just a duplicate.
 * Using every version sent would double- and triple-count the same
 * entries; using only the single most recent file captures everything
 * correctly.
 *
 * WHY NAME-BASED LOOKUP WITH A POSITIONAL FALLBACK:
 * Checked every date-sheet's header row inside the latest file before
 * writing a parser — the quantity column's header text varies wildly
 * between sheets ("Qty To Add", "Quantity on 26-07-2026", and one stale
 * label with a typo year repeated verbatim across five different
 * sheets). The identifying columns (Site ID, Cluster, etc.) are named
 * consistently, so those are matched by name; the quantity column is
 * always the sheet's last column regardless of its label, so that's
 * matched positionally instead of trusting its text.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importAdHocFuelRequests.js
 *   node scripts/importAdHocFuelRequests.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const AdHocFuelRequest = require('../models/AdHocFuelRequest');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'AdHoc_SpecialRefueling_Latest.xlsx';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelDateToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') {
    // Excel serial date -> JS Date (days since 1899-12-30)
    return new Date(Math.round((v - 25569) * 86400 * 1000));
  }
  if (typeof v === 'string') {
    const d = new Date(v);
    if (!isNaN(d.getTime())) return d;
  }
  return null;
}

function parseSheet(rows, sheetName) {
  const header = rows[0];
  if (!header) return [];

  const idx = {};
  header.forEach((h, i) => { if (typeof h === 'string') idx[h.trim()] = i; });

  const siteIdCol = idx['Site ID IHS'];
  const siteNameCol = idx['SITE NAME'];
  const clusterCol = idx['Grato Cluster'];
  const regionCol = idx['REGION']; // missing entirely on at least one sheet (26-07) — handled as optional
  const topologyCol = idx['Functional topology'];
  const priorityCol = idx['Site priority'];
  const plannedDateCol = idx['Planned Date'];
  // Quantity column: always the sheet's last column, regardless of its
  // (inconsistent) header text — verified directly against the real file.
  const qtyCol = header.length - 1;

  if (siteIdCol === undefined || plannedDateCol === undefined) {
    console.log(`  ⚠ Sheet "${sheetName}" missing expected core columns — skipped. Header: ${JSON.stringify(header)}`);
    return [];
  }

  const records = [];
  for (const row of rows.slice(1)) {
    if (!row || !row[siteIdCol]) continue;
    const plannedDate = excelDateToJs(row[plannedDateCol]);
    const qty = toNum(row[qtyCol]);
    if (!plannedDate || qty === null) continue; // incomplete row — skip rather than guess

    records.push({
      site_id: String(row[siteIdCol]).trim(),
      site_name: siteNameCol !== undefined ? row[siteNameCol] : null,
      cluster: clusterCol !== undefined ? row[clusterCol] : null,
      region: regionCol !== undefined ? row[regionCol] : null,
      topology: topologyCol !== undefined ? row[topologyCol] : null,
      priority: priorityCol !== undefined ? row[priorityCol] : null,
      planned_date: plannedDate,
      quantity_requested_l: qty,
      source_sheet: sheetName,
    });
  }
  return records;
}

async function main() {
  const filePath = path.join(DATA_DIR, SOURCE_FILE);
  const wb = XLSX.readFile(filePath);
  console.log(`Reading ${SOURCE_FILE} — ${wb.SheetNames.length} date-sheet(s): ${wb.SheetNames.join(', ')}\n`);

  const allRecords = [];
  for (const sheetName of wb.SheetNames) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { header: 1, defval: null, raw: true });
    const records = parseSheet(rows, sheetName);
    console.log(`  ${sheetName}: ${records.length} request(s) parsed.`);
    allRecords.push(...records.map(r => ({ ...r, source_file: SOURCE_FILE })));
  }

  const totalQty = allRecords.reduce((s, r) => s + r.quantity_requested_l, 0);
  console.log(`\n── Total: ${allRecords.length} ad-hoc request(s), ${Math.round(totalQty).toLocaleString()} L combined. ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  // Not upserted on a unique key (see the model's own reasoning) —
  // cleared and re-inserted for this source file instead, so re-running
  // this script after a newer cumulative file arrives doesn't leave
  // stale entries from an older, less-complete snapshot behind.
  await AdHocFuelRequest.deleteMany({ source_file: SOURCE_FILE });
  const result = await AdHocFuelRequest.insertMany(allRecords);
  console.log(`✓ Inserted ${result.length} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
