/**
 * backfillSiteCoordinates.js
 * diesel-system/scripts/backfillSiteCoordinates.js
 *
 * Reads the "GRATO Sites Distribution" sheet from the GRATO Portfolio
 * spreadsheet (columns: IHS ID, Latitude, Longitude, among others) and
 * writes Latitude/Longitude onto the matching Site record for each row.
 *
 * This is what the Live Site Map (Phase 24) and the mobile check-in
 * geofence verification both depend on — they already handle sites with
 * no coordinates gracefully (the map just doesn't show them, geofence
 * verification reports "unverifiable" rather than failing), so this
 * script only needs to fill in what it can; it doesn't need to be 100%
 * complete to be useful.
 *
 * SAFE BY DEFAULT: running this script with no flags does a full dry run
 * — it reads the file, matches every row against the database, and
 * prints exactly what it WOULD change, without writing anything. Add
 * --confirm to actually apply the updates.
 *
 * Usage:
 *   node scripts/backfillSiteCoordinates.js /path/to/GRATO_Portfolio.xlsx
 *   node scripts/backfillSiteCoordinates.js /path/to/GRATO_Portfolio.xlsx --confirm
 *
 * If no path is given, defaults to looking for a file matching
 * GRATO_Portfolio*.xlsx in the scripts/ directory (matching the existing
 * convention in this folder — see TOMCARDS.xlsx sitting alongside
 * Importtomcards.js).
 */
'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const Site = require('../models/Site');

const CONFIRM = process.argv.includes('--confirm');
const fileArg = process.argv.slice(2).find(a => !a.startsWith('--'));

function resolveInputFile() {
  if (fileArg) {
    if (!fs.existsSync(fileArg)) {
      throw new Error(`File not found: ${fileArg}`);
    }
    return fileArg;
  }
  const scriptsDir = __dirname;
  const candidate = fs.readdirSync(scriptsDir).find(f => /^GRATO_Portfolio.*\.xlsx$/i.test(f));
  if (!candidate) {
    throw new Error(
      'No file path given and no GRATO_Portfolio*.xlsx found in scripts/. ' +
      'Usage: node scripts/backfillSiteCoordinates.js /path/to/file.xlsx [--confirm]'
    );
  }
  return path.join(scriptsDir, candidate);
}

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

async function main() {
  const inputFile = resolveInputFile();
  console.log(`Reading: ${inputFile}\n`);

  const wb = XLSX.readFile(inputFile);
  const sheetName = wb.SheetNames.find(n => /sites distribution/i.test(n)) || wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: true });
  console.log(`Using sheet: "${sheetName}"`);

  // Columns are fixed-position (verified against the real file before
  // writing this script) rather than matched by header text, since a
  // couple of header cells have inconsistent trailing whitespace.
  const COL = { ihs_id: 3, lat: 10, lon: 11 };

  const dataRows = rows.slice(1).filter(r => r && r.some(c => c !== null && c !== ''));
  console.log(`Total data rows: ${dataRows.length}\n`);

  // ── Parse + validate every row first, before touching the database ──────────
  const parsed = [];
  const skippedNoId = [];
  const skippedNoCoords = [];
  const skippedBadCoords = [];

  for (const row of dataRows) {
    const rawId = row[COL.ihs_id];
    const ihs_id = rawId ? String(rawId).trim() : null;
    if (!ihs_id) { skippedNoId.push(row); continue; }

    const lat = toNum(row[COL.lat]);
    const lon = toNum(row[COL.lon]);
    if (lat === null || lon === null) { skippedNoCoords.push(ihs_id); continue; }
    if (lat < -90 || lat > 90 || lon < -180 || lon > 180) { skippedBadCoords.push(ihs_id); continue; }

    parsed.push({ ihs_id, lat, lon });
  }

  console.log(`Parsed OK:              ${parsed.length}`);
  console.log(`Skipped — no IHS ID:    ${skippedNoId.length}`);
  console.log(`Skipped — no coords:    ${skippedNoCoords.length}${skippedNoCoords.length ? ' (' + skippedNoCoords.join(', ') + ')' : ''}`);
  console.log(`Skipped — bad coords:   ${skippedBadCoords.length}${skippedBadCoords.length ? ' (' + skippedBadCoords.join(', ') + ')' : ''}`);
  console.log('');

  // ── Connect and match against the real Site collection ──────────────────────
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) {
    throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  }
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const ihsIds = parsed.map(p => p.ihs_id);
  const existingSites = await Site.find({ IHS_ID_SITE: { $in: ihsIds } })
    .select('IHS_ID_SITE Site_Name Latitude Longitude')
    .lean();
  const siteByIhsId = new Map(existingSites.map(s => [s.IHS_ID_SITE, s]));

  const toUpdate = [];       // sites found in DB, coordinates differ (or missing) — will be written
  const alreadyCorrect = [];  // sites found in DB, coordinates already match — no write needed
  const notFoundInDb = [];    // IHS IDs in the spreadsheet with no matching Site document

  for (const row of parsed) {
    const site = siteByIhsId.get(row.ihs_id);
    if (!site) { notFoundInDb.push(row.ihs_id); continue; }

    const sameLat = site.Latitude != null && Math.abs(site.Latitude - row.lat) < 1e-7;
    const sameLon = site.Longitude != null && Math.abs(site.Longitude - row.lon) < 1e-7;
    if (sameLat && sameLon) { alreadyCorrect.push(row.ihs_id); continue; }

    toUpdate.push({ ...row, site_name: site.Site_Name, hadExisting: site.Latitude != null || site.Longitude != null });
  }

  console.log('── Match summary ───────────────────────────────────────────────');
  console.log(`Sites matched in DB, will be updated:     ${toUpdate.length}`);
  console.log(`Sites matched in DB, already correct:     ${alreadyCorrect.length}`);
  console.log(`IHS IDs in file with no matching Site:    ${notFoundInDb.length}`);
  if (notFoundInDb.length > 0 && notFoundInDb.length <= 30) {
    console.log(`  (${notFoundInDb.join(', ')})`);
  } else if (notFoundInDb.length > 30) {
    console.log(`  (first 30: ${notFoundInDb.slice(0, 30).join(', ')} ...)`);
  }
  console.log('');

  const overwrites = toUpdate.filter(s => s.hadExisting);
  if (overwrites.length > 0) {
    console.log(`⚠ Of those, ${overwrites.length} already have DIFFERENT coordinates on file and will be overwritten:`);
    for (const s of overwrites.slice(0, 20)) {
      const existing = siteByIhsId.get(s.ihs_id);
      console.log(`  ${s.ihs_id} (${s.site_name}): ${existing.Latitude}, ${existing.Longitude} → ${s.lat}, ${s.lon}`);
    }
    if (overwrites.length > 20) console.log(`  ... and ${overwrites.length - 20} more`);
    console.log('');
  }

  if (!CONFIRM) {
    console.log('── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${toUpdate.length} site update(s) to the database.`);
    await mongoose.disconnect();
    return;
  }

  if (toUpdate.length === 0) {
    console.log('Nothing to update.');
    await mongoose.disconnect();
    return;
  }

  console.log(`── Writing ${toUpdate.length} update(s) ────────────────────────────────────`);
  const bulkOps = toUpdate.map(s => ({
    updateOne: {
      filter: { IHS_ID_SITE: s.ihs_id },
      update: { $set: { Latitude: s.lat, Longitude: s.lon } },
    },
  }));

  const result = await Site.bulkWrite(bulkOps, { ordered: false });
  console.log(`✓ Done. Matched: ${result.matchedCount}, modified: ${result.modifiedCount}`);

  const stillMissing = await Site.countDocuments({
    $or: [{ Latitude: null }, { Longitude: null }, { Latitude: { $exists: false } }, { Longitude: { $exists: false } }],
  });
  console.log(`Sites still without coordinates in the database: ${stillMissing}`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
