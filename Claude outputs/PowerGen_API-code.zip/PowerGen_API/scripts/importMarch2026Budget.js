/**
 * importMarch2026Budget.js
 * diesel-system/scripts/importMarch2026Budget.js
 *
 * Imports March 2026's site-level budget — genuinely new data, found
 * after the user pushed back on the earlier conclusion that March had
 * no recoverable data at all (Phase 63/73 confirmed no Validation file
 * exists for March in either email batch; this is a DIFFERENT document
 * type — a budget request/planning file — not a monthly reconciliation
 * file, so it doesn't contradict that earlier finding, it fills a
 * different gap).
 *
 * Source file structurally unlike every other recovered budget file:
 * has "Requested Quantity (L)" and "Budget (XAF)" per site, but no
 * separate "approved" figure and no consumption data at all — this is
 * genuinely a budget-only source. Populates HistoricalMonthlyRecord's
 * budget_liters for March; final_consumption_l, reserve_liters, and
 * fully_exhausted are deliberately left null — there is still no
 * monthly reconciliation source for March, so consumption remains
 * unknown even with this budget figure now known.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importMarch2026Budget.js
 *   node scripts/importMarch2026Budget.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'GRATO_SBC_DIESEL_BUDGET_March_2026.xlsx';
const MONTH_KEY = '2026-03';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function findCol(header, name) {
  const target = String(name).replace(/\s+/g, ' ').trim();
  const i = header.findIndex(h => typeof h === 'string' && h.replace(/\s+/g, ' ').trim() === target);
  return i === -1 ? null : i;
}

async function main() {
  const filePath = path.join(DATA_DIR, SOURCE_FILE);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Feuil1'], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findCol(header, 'IHS Site ID'),
    site_name: findCol(header, 'Site Name'),
    cluster: findCol(header, 'Cluster'),
    region: findCol(header, 'State'),
    topology: findCol(header, 'Site Topology'),
    requested_l: findCol(header, 'Requested Quantity (L)'),
    budget_xaf: findCol(header, 'Budget (XAF)'),
    unit_price: findCol(header, 'Unit Price'),
    card_number: findCol(header, 'Card Number'),
    vendor: findCol(header, 'Fuel Vendor'),
  };

  const missing = Object.entries(idx).filter(([, v]) => v === null);
  if (missing.length) {
    throw new Error(`Missing expected column(s): ${missing.map(([k]) => k).join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      month_key: MONTH_KEY,
      budget_liters: toNum(row[idx.requested_l]),
      // final_consumption_l, reserve_liters, fully_exhausted deliberately
      // left unset — no reconciliation source exists for March.
      source_file: SOURCE_FILE,
      source_version: null,
      sign_off_status: 'unknown',
      sign_off_verified: false,
    });
  }

  console.log(`Parsed ${records.length} site record(s) for ${MONTH_KEY}.`);
  const totalBudget = records.reduce((s, r) => s + (r.budget_liters || 0), 0);
  console.log(`  Total March budget: ${Math.round(totalBudget).toLocaleString()} L.`);
  console.log(`  Note: consumption data for March is still unknown — no Validation/reconciliation file has been found for this month.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${records.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = records.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id, month_key: r.month_key },
      update: { $set: r },
      upsert: true,
    },
  }));
  const result = await HistoricalMonthlyRecord.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
