/**
 * writeDecemberBudgetRequestApproval.js
 * diesel-system/scripts/writeDecemberBudgetRequestApproval.js
 *
 * WHY THIS EXISTS (Phase 158):
 * The user uploaded "GRATO SBC DIESEL BUDGET December.xlsx" and
 * "...January.xlsx" directly, reporting that both cycles still show no
 * "Requested (Regular)" figure on the Site/Cluster Cycle Report pages.
 * Diffed both against what's already in this project's own
 * `historical_email_data/` folder before writing anything:
 *
 *   - December: byte-identical, all 184 sites, to the already-recovered
 *     `SbcBudget_Dec2025.xlsx` — same file, not new data. So the gap
 *     isn't a missing source file at all. It's that
 *     `importSbcBudgetFiles.js` only ever writes this file's
 *     "Requested Quantity (L)" into `HistoricalMonthlyRecord.budget_liters`
 *     (the figure Reserve is computed from) — it never writes anything
 *     into `BudgetRequestApproval`, the collection the "Requested
 *     (Regular)" / "Approved (Regular)" cards on the Site/Cluster Cycle
 *     Report actually read from. December's budget number has been
 *     correctly feeding Reserve the whole time; it was just never
 *     mirrored into the other collection. This script closes that gap.
 *
 *   - January: also byte-identical, all 165 sites, to the already-
 *     recovered `SbcBudget_Jan2026.xlsx` — and that file is ALREADY
 *     wired into `pairSbcRequestWithExistingApproval.js` (added Phase
 *     151, earlier in this same recovery effort). A dry run of that
 *     existing script reproduces exactly what its own docblock already
 *     documents: 108,310 L requested vs. 111,582 L approved across 164
 *     of 165 sites. No code change was needed for January — if it's
 *     still showing nothing live, `pairSbcRequestWithExistingApproval.js
 *     --confirm` simply hasn't been run against the production database
 *     yet. Run that script for January; this one is for December only.
 *
 * WHY DECEMBER GETS THE SAME NUMBER IN BOTH FIELDS, NOT A REAL PAIR:
 * Checked directly whether "Budget (XAF)" could be an independent
 * second (approved) figure before assuming it wasn't: it's exactly
 * `Requested Quantity (L) × Unit Price` for every row checked, not an
 * independently-set figure — a derived column, not a second data
 * point. No file recovered anywhere in this project carries a distinct
 * "December approved" figure (the multi-month rollup starts at
 * January). So unlike February/March/April/May/January — where a
 * genuinely separate approved figure exists and a real gap between
 * request and approval is a real finding — December only ever had one
 * real number. Writing that same number into both `sbc_requested_l`
 * and `ihs_approved_l` keeps this collection consistent with how the
 * rest of the app already treats it (as December's approved budget,
 * feeding Reserve), while making it visible as "Requested" too, rather
 * than leaving Approved blank on a page family that already shows this
 * exact figure as the approved budget everywhere else. `variance_l` is
 * therefore always 0 for December by construction — that's not a
 * finding, it's mechanical, and `source_file` documents this so it's
 * never mistaken for a verified zero-variance result later.
 *
 * Writes to BudgetRequestApproval ONLY. Does not touch
 * HistoricalMonthlyRecord.budget_liters/reserve_liters — those are
 * already correct for December via importSbcBudgetFiles.js.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/writeDecemberBudgetRequestApproval.js
 *   node scripts/writeDecemberBudgetRequestApproval.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const BudgetRequestApproval = require('../models/BudgetRequestApproval');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const CYCLE_KEY = '2025-12';
const SOURCE_FILE = 'SbcBudget_Dec2025.xlsx';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function findCol(header, name) {
  const target = String(name).replace(/\s+/g, ' ').trim();
  const i = header.findIndex(h => typeof h === 'string' && h.replace(/\s+/g, ' ').trim() === target);
  return i === -1 ? null : i;
}

function parseSource() {
  const wb = XLSX.readFile(path.join(DATA_DIR, SOURCE_FILE));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Feuil1'], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idx = {
    site_id: findCol(header, 'IHS Site ID'),
    site_name: findCol(header, 'Site Name'),
    cluster: findCol(header, 'Cluster'),
    region: findCol(header, 'State'),
    topology: findCol(header, 'Site Topology'),
    requested_l: findCol(header, 'Requested Quantity (L)'),
  };
  const missing = Object.entries(idx).filter(([, v]) => v === null);
  if (missing.length) {
    throw new Error(`${SOURCE_FILE} missing expected column(s): ${missing.map(([k]) => k).join(', ')}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const known_l = toNum(row[idx.requested_l]);
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      cycle_key: CYCLE_KEY,
      sbc_requested_l: known_l,
      ihs_approved_l: known_l, // same single known figure — see docblock. Not two independent sources.
      variance_l: 0,
      source_file: `${SOURCE_FILE} (single figure — no independent approval source exists for December; mirrored into both fields, see script docblock)`,
    });
  }
  return records;
}

async function main() {
  const records = parseSource();
  const total = records.reduce((s, r) => s + (r.sbc_requested_l || 0), 0);
  console.log(`── ${CYCLE_KEY} (${SOURCE_FILE}): ${records.length} site(s). Total: ${Math.round(total).toLocaleString()} L (same figure written to both Requested and Approved — see docblock). ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${records.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = records.map(r => ({
    updateOne: { filter: { site_id: r.site_id, cycle_key: r.cycle_key }, update: { $set: r }, upsert: true },
  }));
  const result = await BudgetRequestApproval.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
