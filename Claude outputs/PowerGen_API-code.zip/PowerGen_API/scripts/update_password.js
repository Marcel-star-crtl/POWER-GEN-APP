// update_password.js
//
// Usage:
//   node scripts/update_password.js <email> <newPassword>
//
// Reads the DB connection from MONGO_URI / MONGODB_URI in the environment —
// never hardcode credentials or a target password in this file. (This file
// used to contain a live Atlas connection string and a real user's plaintext
// password directly in source; both must be rotated if they haven't been.)
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const MONGO_URI = process.env.MONGO_URI || process.env.MONGODB_URI;
const [, , email, newPassword] = process.argv;

async function updatePassword() {
  if (!MONGO_URI) {
    throw new Error('Set MONGO_URI or MONGODB_URI in the environment before running this script.');
  }
  if (!email || !newPassword) {
    throw new Error('Usage: node scripts/update_password.js <email> <newPassword>');
  }

  await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  const User = mongoose.model('User', new mongoose.Schema({}, { strict: false, collection: 'users' }));

  const hash = await bcrypt.hash(newPassword, 12); // 12 rounds as in your .env
  const result = await User.updateOne({ email }, { $set: { password: hash } });

  console.log('Update result:', result);
  await mongoose.disconnect();
}

updatePassword().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
