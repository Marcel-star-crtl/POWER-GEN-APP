/**
 * retrySiteFeedback.js
 * diesel-system/scripts/retrySiteFeedback.js
 *
 * Phase 117. A real Site.save() validation bug (Current_Generators
 * violating its own max-2 rule on some pre-existing site documents —
 * unrelated to anything this feature writes) caused feedBackToSite to
 * fail for 58 audits during the Phase 116 backfill. That bug is now
 * fixed (feedBackToSite uses a targeted updateOne instead of a full
 * document .save(), so it can no longer be blocked by validation on
 * fields it doesn't touch) — but the 58 audits it already failed for
 * are left with site_state_updated: false and a Site record that
 * never got their real fuel-level data written back.
 *
 * Re-running backfillTankAuditReconciliation.js won't retry these —
 * their audit-side reconciliation fields are already complete, so
 * that script's own "what still needs resolving" query correctly
 * skips them. This script targets exactly the narrower, real gap:
 * submitted audits with real dip readings whose site feedback never
 * succeeded.
 *
 * Usage:
 *   node scripts/retrySiteFeedback.js           (dry run)
 *   node scripts/retrySiteFeedback.js --confirm (writes)
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const CONFIRM = process.argv.includes('--confirm');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const TankAudit = require('../models/TankAudit');

  const affected = await TankAudit.find({
    status: 'submitted',
    dip_reading_l: { $ne: null },
    site_state_updated: { $ne: true },
  });

  console.log(`Submitted audits with a real dip reading but no successful site feedback yet: ${affected.length}`);
  if (!affected.length) {
    console.log('Nothing to do.');
    await mongoose.disconnect();
    return;
  }

  const preview = affected.slice(0, 10);
  console.log('\nFirst few affected (site — audit date):');
  for (const a of preview) {
    console.log(`  ${a.site_id_ihs || '(no site)'} — ${a.audit_date ? a.audit_date.toISOString().slice(0, 10) : '(no date)'}`);
  }
  if (affected.length > preview.length) console.log(`  ...and ${affected.length - preview.length} more.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log('Re-run with --confirm to retry site feedback for these audits.');
    await mongoose.disconnect();
    return;
  }

  console.log('\n── Re-saving each document (re-triggers feedBackToSite with the fixed code) ──');
  let succeeded = 0, stillFailing = 0, errored = 0;
  for (const audit of affected) {
    try {
      // No need to clear cycle_key here — the audit-side reconciliation
      // fields are already correct; only the post-save feedBackToSite
      // hook needs another attempt, and it runs on every save
      // regardless of whether the pre-save resolution block re-runs.
      await audit.save();
      const refreshed = await TankAudit.findById(audit._id).select('site_state_updated').lean();
      if (refreshed?.site_state_updated) succeeded++; else stillFailing++;
    } catch (err) {
      errored++;
      console.error(`  ✗ ${audit._id} (${audit.site_id_ihs}): ${err.message}`);
    }
  }

  console.log(`\n── Done. ──`);
  console.log(`  Site feedback now succeeded: ${succeeded}`);
  console.log(`  Still not marked as updated (check server logs for the specific error — likely a different, real issue on that site's record): ${stillFailing}`);
  console.log(`  Errored: ${errored}`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
