/**
 * importSiteControllerLogSummary.js
 * diesel-system/scripts/importSiteControllerLogSummary.js
 *
 * Imports the per-site GRATO controller-log analysis (see
 * SiteControllerLogSummary model docblock for what this data is and
 * isn't) from the already-computed, already-verified JSON snapshot at
 * scripts/site_controller_logs/grato_log_analysis_2026_08.json — 48
 * records, one per source log file. That JSON was produced by parsing
 * three distinct raw controller-log export formats directly (not
 * re-parsed here in Node — the parsing logic is Python/pandas and
 * already validated; this script's job is only to load the finished
 * result into the database).
 *
 * Upserts on `archive_relpath` (the true unique key — 3 of the 48 files
 * have no resolvable `site_id`, so that field can't be the key).
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importSiteControllerLogSummary.js
 *   node scripts/importSiteControllerLogSummary.js --confirm
 */
'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const SiteControllerLogSummary = require('../models/SiteControllerLogSummary');

const CONFIRM = process.argv.includes('--confirm');
const SOURCE_FILE = path.join(__dirname, 'site_controller_logs', 'grato_log_analysis_2026_08.json');

async function main() {
  const records = JSON.parse(fs.readFileSync(SOURCE_FILE, 'utf8'));

  const byFormat = {};
  const byCluster = {};
  let unidentified = 0, mismatched = 0, withAugRuntime = 0, withFuel = 0;
  for (const r of records) {
    byFormat[r.format] = (byFormat[r.format] || 0) + 1;
    const cluster = r.official_cluster || '(unidentified)';
    byCluster[cluster] = (byCluster[cluster] || 0) + 1;
    if (!r.site_id) unidentified++;
    if (r.cluster_label_mismatch) mismatched++;
    if (r.aug2026_dg_runtime_hours != null) withAugRuntime++;
    if (r.dg_fuel_consumed_l_window != null) withFuel++;
  }

  console.log(`Parsed ${records.length} record(s) from ${path.basename(SOURCE_FILE)}.`);
  console.log(`  By format: ${JSON.stringify(byFormat)}`);
  console.log(`  By official cluster: ${JSON.stringify(byCluster)}`);
  console.log(`  ${unidentified} record(s) with no resolvable site_id.`);
  console.log(`  ${mismatched} record(s) where the archive folder disagrees with the official cluster (the confirmed Bonaberi1/2 swap).`);
  console.log(`  ${withAugRuntime} record(s) with a usable August-2026 generator-runtime figure.`);
  console.log(`  ${withFuel} record(s) with a usable fuel-consumption figure (expected: 0 — see model docblock).`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${records.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = records.map((r) => ({
    updateOne: {
      filter: { archive_relpath: r.archive_relpath },
      update: { $set: r },
      upsert: true,
    },
  }));
  const result = await mongoose.model('SiteControllerLogSummary').bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch((err) => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
