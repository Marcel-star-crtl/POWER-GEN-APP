/**
 * verifyHistoricalDataImports.js
 * diesel-system/scripts/verifyHistoricalDataImports.js
 *
 * Connects directly to MongoDB and checks every collection from the
 * historical email-data recovery effort against the counts each import
 * script actually reported when it last ran successfully — a direct
 * database check, independent of the frontend or the API layer.
 *
 * Expected counts below are taken verbatim from confirmed --confirm
 * run output across this whole recovery effort, not recomputed or
 * guessed — if a script's real source data changes (a file is
 * re-copied, a new month is added), update the corresponding EXPECTED
 * value here to match that script's own new reported output.
 *
 * Exits with a non-zero status code if anything doesn't match, so this
 * can be used as a real pass/fail check, not just a printout to read.
 *
 * Usage:
 *   node scripts/verifyHistoricalDataImports.js
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');
const AdHocFuelRequest = require('../models/AdHocFuelRequest');
const { MidCycleBudgetRelease, MidCycleReleaseDailyProgress } = require('../models/MidCycleBudgetRelease');
const TomCardAllocation = require('../models/TomCardAllocation');
const BudgetRequestApproval = require('../models/BudgetRequestApproval');
const MonthlyDebitSummary = require('../models/MonthlyDebitSummary');
const HistoricalFieldVisit = require('../models/HistoricalFieldVisit');
const HistoricalFuelPurchase = require('../models/HistoricalFuelPurchase');
const HistoricalSiteStockSnapshot = require('../models/HistoricalSiteStockSnapshot');
const MidCycleEstimateSnapshot = require('../models/MidCycleEstimateSnapshot');
const PlannedVsSuppliedDelivery = require('../models/PlannedVsSuppliedDelivery');
const SiteControllerLogSummary = require('../models/SiteControllerLogSummary');

let failures = 0;

function check(label, actual, expected) {
  const ok = actual === expected;
  if (!ok) failures++;
  console.log(`${ok ? '✓' : '✗ MISMATCH'}  ${label}: ${actual} (expected ${expected})`);
}

async function checkBreakdown(label, model, groupField, expectedByGroup) {
  const results = await model.aggregate([{ $group: { _id: `$${groupField}`, count: { $sum: 1 } } }]);
  const actualByGroup = Object.fromEntries(results.map(r => [r._id, r.count]));
  console.log(`\n${label} — by ${groupField}:`);
  const allKeys = new Set([...Object.keys(expectedByGroup), ...Object.keys(actualByGroup)]);
  for (const key of [...allKeys].sort()) {
    const actual = actualByGroup[key] ?? 0;
    const expected = expectedByGroup[key] ?? 0;
    const ok = actual === expected;
    if (!ok) failures++;
    console.log(`  ${ok ? '✓' : '✗ MISMATCH'}  ${key}: ${actual} (expected ${expected})`);
  }
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');
  console.log('══════════════════════════════════════════════════════════');
  console.log(' HISTORICAL DATA RECOVERY — DATABASE VERIFICATION');
  console.log('══════════════════════════════════════════════════════════\n');

  // HistoricalMonthlyRecord — 3075 total (was 1332). Phase 90 added 8
  // months of 2025 (April-November), verified via a real refactor of
  // the column-matching logic to support multiple candidate names per
  // field — checked against the already-confirmed 2026 months first
  // (identical output) before trusting it on new data.
  // HistoricalMonthlyRecord — 3239 total, the correct sum of the
  // per-month breakdown below for a clean 164-site March. (An earlier
  // version of this check said 3075, which never actually matched its
  // own breakdown — a real bug, not a rounding choice. If your real
  // count is 3096, that's a separate, genuine leftover from an earlier
  // March import predating the real Validation file — see
  // scripts/findOrphanedMarchRecord.js to identify the specific site.)
  //
  // Phase 172 — while wiring up August (below), a full dry run of
  // importHistoricalEmailData.js surfaced a SEPARATE, pre-existing
  // discrepancy unrelated to August: this file's breakdown previously
  // claimed 184 records for 2025-12, but Dec2025_Validation.xlsx's real
  // "Validation" sheet — opened directly with the actual XLSX package —
  // has exactly 164 data rows (verified two ways: filtering on column 0
  // and filtering on the resolved "I.H.S SITE ID" column both give 164,
  // not 184). No file in scripts/historical_email_data/ changed for
  // December this session, so 184 was never actually correct for the
  // file currently in use — corrected here to the verified 164 rather
  // than perpetuated. Old total: 246+247+245+248+249+182+173+173+184+
  // 164*7 = 3095 (never actually achievable against the real December
  // file). New total: with 2025-12 corrected to 164, pre-August sum is
  // 3075; + August's 164 (dry-run verified, see MONTHS['2026-08']) =
  // 3239 — matches this script's own dry-run output exactly. Imported
  // with sign_off_status: 'draft' / sign_off_verified: false — GRATO
  // had not yet countersigned as of the most recent source email, same
  // honest-uncertainty treatment as May 2026's entry.
  // A later real run against the live database found exactly the "if
  // your real count is X" scenario this comment already anticipated:
  // 2025-12 came back 184, not 164, and separately 2026-03 came back
  // 165, not 164 (the single known orphan; see
  // scripts/findOrphanedMarchRecord.js). Both are the same kind of fact
  // — a site that was budgeted for that month but has no reconciliation
  // (Validation) data — December's being ~20 sites' worth of the exact
  // same gap (see scripts/findOrphanedDecemberRecords.js). Phase 173
  // explicitly decided to keep these as real, meaningful data points
  // rather than clean them up (the same call already made for March
  // originally) — so these EXPECTED values are set to the live 184/165,
  // not the clean 164/164. Total: 3239 + 20 (December) + 1 (March) =
  // 3260. If that decision is ever reversed, running
  // removeOrphanedDecemberRecords.js --confirm and
  // removeOrphanedMarchRecord.js --confirm would bring both back down to
  // 164, and these two entries (and the total) should move back down to
  // match.
  check('HistoricalMonthlyRecord (total)',
    await HistoricalMonthlyRecord.countDocuments(), 3260);
  await checkBreakdown('HistoricalMonthlyRecord', HistoricalMonthlyRecord, 'month_key', {
    '2025-04': 246, '2025-05': 247, '2025-06': 245, '2025-07': 248,
    '2025-08': 249, '2025-09': 182, '2025-10': 173, '2025-11': 173,
    '2025-12': 184, '2026-01': 164, '2026-02': 164, '2026-03': 165,
    '2026-04': 164, '2026-05': 164, '2026-06': 164, '2026-07': 164,
    '2026-08': 164,
  });

  // AdHocFuelRequest — 1,266 total. 284 of these come from
  // importAdHocFuelRequests.js's original July/August shortage data
  // (untouched by this phase — different source_file values, never
  // touched by this script's deleteMany). The remaining 982 are
  // entirely managed by importMarch2026ExtraFuelRequests.js: March's 4
  // rounds + April's 3 (508, unchanged) plus this phase's additions —
  // December's 2 rounds, January's 1, February's 3, June's 4th round,
  // and July's 1st round (474 new). 792 (previous total) - 508 (old
  // managed set) + 982 (new managed set) = 1,266.
  console.log('');
  check('AdHocFuelRequest (total)',
    await AdHocFuelRequest.countDocuments(), 1266);

  // TomCardAllocation — 58 total (was 57), across all 7 cycles that have
  // real Card Limit data (Dec, Jan, Feb, Mar, Apr, Jun, Jul, Aug — 8
  // cycles, 7 clusters each except January, which has 9: 8 from the
  // original PDF source, +1 for Pouma 2/TRADEX/card 5807, recovered in
  // Phase 163's replaceJanuaryCardFundingBaseline.js from
  // Jan2026_Budget.xlsx's "Card Limit" sheet — no TomCardAllocation
  // document existed for Pouma 2/2026-01 anywhere before that phase, so
  // this is a genuine new document, not an overwrite. This expected
  // value was never updated after that phase actually ran --confirm,
  // which is what a later dry run's 58-vs-57 mismatch was actually
  // reporting — not a data problem.
  // June's source file was swapped in Phase 102 for a later, richer
  // snapshot of the same tracker (adding extra-fuel-round fields) — the
  // cluster count for June stays 7 either way, verified directly, since
  // the new file's missing Pouma 2/TRADEX row is backfilled from the
  // original file rather than left out.
  console.log('');
  check('TomCardAllocation (total)',
    await TomCardAllocation.countDocuments(), 58);
  await checkBreakdown('TomCardAllocation', TomCardAllocation, 'funded_cycle_key', {
    '2025-12': 7, '2026-01': 9, '2026-02': 7, '2026-03': 7, '2026-04': 7, '2026-06': 7, '2026-07': 7, '2026-08': 7,
  });

  // Every June record should carry a non-null extra_rounds_comment —
  // verified directly this is true for all 6 main-sheet clusters plus
  // Pouma 2's merged supplement (which always sets a synthetic note).
  // Deliberately NOT checking extra_round1_approved_l here: verified
  // directly only 5 of 7 clusters have a real round-1 figure (Bonaberi
  // 2 and Pouma 1 genuinely show no round-1 approval in the source) —
  // checking for 7 there would be checking against a number that was
  // never actually true.
  console.log('');
  check('TomCardAllocation with June extra-rounds comment',
    await TomCardAllocation.countDocuments({ funded_cycle_key: '2026-06', extra_rounds_comment: { $ne: null } }), 7);

  // BudgetRequestApproval — 1667 total (was 1318): 824 from before Phase
  // 83, + 165 (March, newly paired) + 165 (May, newly paired) = 1154, +
  // 164 (September, Phase 170) = 1318, + 184 (December,
  // writeDecemberBudgetRequestApproval.js) + 165 (January,
  // pairSbcRequestWithExistingApproval.js) = 1667. Both December and
  // January's writes were built and their --confirm run explicitly asked
  // for back in Phase 158, but this collection's expected breakdown never
  // actually gained '2025-12'/'2026-01' entries afterward — confirmed by
  // re-running both scripts' dry runs directly against the current
  // source files: December still parses to exactly 184 site(s),
  // January (via pairSbcRequestWithExistingApproval.js) to exactly 165 —
  // matching a later dry run's live counts exactly. Stale expected
  // values, not a data problem.
  console.log('');
  check('BudgetRequestApproval (total)',
    await BudgetRequestApproval.countDocuments(), 1667);
  await checkBreakdown('BudgetRequestApproval', BudgetRequestApproval, 'cycle_key', {
    '2025-12': 184, '2026-01': 165, '2026-02': 165, '2026-03': 165, '2026-04': 165, '2026-05': 165,
    '2026-06': 164, '2026-07': 166, '2026-08': 164, '2026-09': 164,
  });

  // MonthlyDebitSummary — 16 months (was 8). 8 new 2025 months added
  // Phase 90 — April 2025 genuinely has its header at row 2, not row 1
  // like every other month, verified directly before adding it.
  console.log('');
  check('MonthlyDebitSummary (total)',
    await MonthlyDebitSummary.countDocuments(), 16);

  // HistoricalFieldVisit — 15,699 across 16 months (8 new 2025 months
  // added Phase 90 — all required columns were already present under
  // existing names, no column-matching changes needed here).
  console.log('');
  check('HistoricalFieldVisit (total)',
    await HistoricalFieldVisit.countDocuments(), 15699);

  // HistoricalFuelPurchase — 3,323 (was 1,389). 7 of the 8 new 2025
  // months added real Purchases data (November genuinely has no
  // Purchases sheet at all, confirmed directly, not included). April
  // 2025's total (134,938L) cross-checked against its own Debit
  // sheet's "Purchases (L)" figure (134,937.76L) before trusting it —
  // matches almost exactly.
  console.log('');
  check('HistoricalFuelPurchase (total)',
    await HistoricalFuelPurchase.countDocuments(), 3323);

  // HistoricalSiteStockSnapshot — 39 (9 HO Stock + 25 BB Site Stock + 5 Small Tank Usage)
  console.log('');
  check('HistoricalSiteStockSnapshot (total)',
    await HistoricalSiteStockSnapshot.countDocuments(), 39);

  // MidCycleBudgetRelease / MidCycleReleaseDailyProgress — August only.
  // Phase 170: MidCycleRelease_Aug2026_Latest.xlsx now points to the
  // 24-August snapshot (was 05-August) — site snapshot count is
  // unchanged (same 164 sites, upserted by site_id, values refreshed),
  // but the daily cluster progress count grew from 70 to 191 since the
  // new file's Recap/Service-desk-Recap sheets cover a longer date
  // range (26-Jul through 24-Aug vs. the old file's shorter window) and
  // the daily upsert key (release_cycle_key, cluster, date) is a strict
  // superset, not a replacement — no stale dates left behind.
  console.log('');
  check('MidCycleBudgetRelease (total, Aug site snapshots)',
    await MidCycleBudgetRelease.countDocuments(), 164);
  check('MidCycleReleaseDailyProgress (total, Aug daily cluster records)',
    await MidCycleReleaseDailyProgress.countDocuments(), 191);

  // MidCycleEstimateSnapshot — 77 (March 19-March snapshot)
  console.log('');
  check('MidCycleEstimateSnapshot (total)',
    await MidCycleEstimateSnapshot.countDocuments(), 77);

  // PlannedVsSuppliedDelivery — 114 across May (81) and June (33)
  console.log('');
  check('PlannedVsSuppliedDelivery (total)',
    await PlannedVsSuppliedDelivery.countDocuments(), 114);
  await checkBreakdown('PlannedVsSuppliedDelivery', PlannedVsSuppliedDelivery, 'month_key', {
    '2026-05': 81, '2026-06': 33,
  });

  // SiteControllerLogSummary — NOT part of the email-archive recovery
  // effort the rest of this script checks; a separate one-time import
  // from the user's own "GRATO-LOG-FILES.zip" controller-log upload
  // (2026-09-17). 48 records, keyed by archive_relpath (not site_id — 3
  // of the 48 source files have no resolvable site_id). Included here
  // anyway since this is the project's one "did everything land" check.
  console.log('');
  check('SiteControllerLogSummary (total)',
    await SiteControllerLogSummary.countDocuments(), 48);

  console.log('\n══════════════════════════════════════════════════════════');
  if (failures === 0) {
    console.log(' ✓ ALL CHECKS PASSED — every collection matches its last confirmed import.');
  } else {
    console.log(` ✗ ${failures} MISMATCH(ES) FOUND — see above for which collection/month.`);
    console.log('   A mismatch usually means: a script was never run with --confirm,');
    console.log('   a --confirm run failed partway through (check its own output),');
    console.log('   or this script\'s EXPECTED values are stale relative to a newer import.');
  }
  console.log('══════════════════════════════════════════════════════════');

  await mongoose.disconnect();
  process.exit(failures === 0 ? 0 : 1);
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
