/**
 * printHistoricalAnalysisSummary.js
 * diesel-system/scripts/printHistoricalAnalysisSummary.js
 *
 * Read-only. Prints a plain-text summary of the same four reports the
 * Historical Data / History Analysis pages show — Global Summary,
 * Site Cycle Analysis, Cluster Cycle Analysis, Complete Monthly
 * Summary — to the terminal, sized to be copy/pasted into a chat for
 * interpretation rather than opened as a spreadsheet.
 *
 * Reuses the exact data-gathering functions in
 * services/historicalExcelExport.js (same batched queries that feed
 * the "Export to Excel" button), so the numbers here are guaranteed to
 * match what that export — and the app's own endpoints — would show.
 * This script only prints; nothing here writes to the database, so
 * there's no --confirm gate.
 *
 * Full site-cycle and complete-monthly tables can run to hundreds of
 * rows across 9 cycles / many months, which is too much to usefully
 * paste into a chat. So by default this prints:
 *   - Global Summary in full (it's already small — one row per month).
 *   - Cluster Cycle Analysis in full (at most 8 clusters × 9 cycles = 72 rows).
 *   - Site Cycle Analysis: only the LATEST cycle in full, plus a
 *     flagged list (currently exhausted, or negative reserve) across
 *     all cycles.
 *   - Complete Monthly Summary: an aggregate reserve/consumption trend
 *     by month (not one row per site per month).
 *
 * Usage:
 *   node scripts/printHistoricalAnalysisSummary.js
 *   node scripts/printHistoricalAnalysisSummary.js --full-site-cycle   # every site, every cycle (long)
 *   node scripts/printHistoricalAnalysisSummary.js --full-monthly      # every site, every month (long)
 *   node scripts/printHistoricalAnalysisSummary.js --json              # machine-readable instead of tables
 */
'use strict';
require('dotenv').config();
const mongoose = require('mongoose');

const {
  CYCLES, REAL_CLUSTERS, GLOBAL_MIN_MONTH_KEY,
  fetchGlobalSummaryData, fetchSiteCycleData, fetchClusterCycleData, fetchCompleteMonthlyData,
  monthLabel,
} = require('../services/historicalExcelExport');
const MonthlyDebitSummary = require('../models/MonthlyDebitSummary');

const ARGS = process.argv.slice(2);
const FULL_SITE_CYCLE = ARGS.includes('--full-site-cycle');
const FULL_MONTHLY = ARGS.includes('--full-monthly');
const AS_JSON = ARGS.includes('--json');

// ─── tiny plain-text table renderer (no external dependency) ──────────────
function printTable(headers, rows) {
  if (!rows.length) { console.log('  (no rows)'); return; }
  const widths = headers.map((h, i) => Math.max(String(h).length, ...rows.map(r => String(r[i] ?? '—').length)));
  const line = (cells) => cells.map((c, i) => String(c ?? '—').padEnd(widths[i])).join('  ');
  console.log('  ' + line(headers));
  console.log('  ' + widths.map(w => '-'.repeat(w)).join('  '));
  for (const r of rows) console.log('  ' + line(r));
}

function fmtNum(v) { return v == null ? null : Math.round(v).toLocaleString(); }
function section(title) {
  console.log('\n' + '='.repeat(78));
  console.log(title);
  console.log('='.repeat(78));
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.error('Connected to MongoDB (read-only — this script never writes).\n');

  const debitRaw = await MonthlyDebitSummary.find({ cycle_key: { $in: CYCLES } }).lean();
  const fleetDebitByCycle = new Map(debitRaw.map(d => [d.cycle_key, d]));

  const [globalData, siteRows, clusterRows, completeData] = await Promise.all([
    fetchGlobalSummaryData(GLOBAL_MIN_MONTH_KEY),
    fetchSiteCycleData(CYCLES),
    fetchClusterCycleData(CYCLES, REAL_CLUSTERS, fleetDebitByCycle),
    fetchCompleteMonthlyData(),
  ]);

  if (AS_JSON) {
    const latestCycle = CYCLES[CYCLES.length - 1];
    console.log(JSON.stringify({
      generated_at: new Date().toISOString(),
      scope: { since: GLOBAL_MIN_MONTH_KEY, cycles: CYCLES, real_clusters: REAL_CLUSTERS, latest_cycle: latestCycle },
      global: globalData,
      cluster_cycle: clusterRows,
      site_cycle: FULL_SITE_CYCLE ? siteRows : siteRows.filter(r => r.cycle === latestCycle || r.status === 'Exhausted' || (r.reserve_l != null && r.reserve_l < 0)),
      complete_monthly: FULL_MONTHLY ? completeData.rows : undefined,
      complete_monthly_reserve_trend: completeData.fleetReserveByMonth,
    }, null, 2));
    await mongoose.disconnect();
    return;
  }

  console.log(`Historical Analysis Summary — generated ${new Date().toISOString().slice(0, 19).replace('T', ' ')} UTC`);
  console.log(`Scope: cycles ${CYCLES[0]}..${CYCLES[CYCLES.length - 1]} (${CYCLES.length} cycles) · Global Summary since ${GLOBAL_MIN_MONTH_KEY} · ${REAL_CLUSTERS.length} real clusters`);

  // ── Global Summary ────────────────────────────────────────────────────
  section('GLOBAL SUMMARY — Fleet-Wide Monthly Trend');
  printTable(
    ['Month', 'Sites', 'w/Budget', 'Budget(L)', 'Consumed(L)', 'Reserve(L)', 'Exhausted', 'Theft-flag'],
    globalData.byMonth.map(m => [monthLabel(m._id), m.site_count, m.sites_with_budget, fmtNum(m.total_budget_l), fmtNum(m.total_consumption_l), fmtNum(m.total_reserve_l), m.exhausted_count, m.theft_flagged_count])
  );

  section('GLOBAL SUMMARY — Debit / Credit by Cycle');
  printTable(
    ['Cycle', 'Submitted(L)', 'Approved(L)', 'Purchases(L)', 'Debit(-)/Credit(+) XAF'],
    globalData.debitMonths.map(m => [monthLabel(m.cycle_key), fmtNum(m.submitted_consumption_l), fmtNum(m.approved_consumption_l), fmtNum(m.purchases_l), fmtNum(m.debit_credit_amount_xaf)])
  );
  const totalDebitCredit = globalData.debitMonths.reduce((s, m) => s + (m.debit_credit_amount_xaf || 0), 0);
  console.log(`\n  Fleet-wide total across shown cycles: ${fmtNum(totalDebitCredit)} XAF (${totalDebitCredit < 0 ? 'net DEBIT — owed by SBC' : 'net CREDIT — owed to SBC'})`);

  section('GLOBAL SUMMARY — Extra Fuel Requests by Month');
  printTable(
    ['Month', 'Requested(L)', 'Approved(L)', 'Delivered(L)'],
    globalData.adhocByMonth.map(m => [monthLabel(m.month_key), fmtNum(m.total_l), fmtNum(m.total_approved_l), fmtNum(m.total_delivered_l)])
  );

  section('GLOBAL SUMMARY — Tom Card Funding by Cycle');
  printTable(['Cycle', 'Funded (L)'], globalData.tomCardByCycle.map(([cycle, l]) => [monthLabel(cycle), fmtNum(l)]));

  section(`GLOBAL SUMMARY — Chronically Exhausted Sites (every recovered month since ${GLOBAL_MIN_MONTH_KEY}, worst 20 by avg reserve)`);
  printTable(
    ['Site ID', 'Site Name', 'Cluster', 'Months w/Budget', 'Months Exhausted', 'Avg Reserve(L)'],
    globalData.chronicallyExhausted.map(s => [s._id, s.site_name, s.cluster, s.months_with_budget, s.months_exhausted, s.avg_reserve_l != null ? Math.round(s.avg_reserve_l * 10) / 10 : null])
  );

  // ── Cluster Cycle Analysis ────────────────────────────────────────────
  section(`CLUSTER CYCLE ANALYSIS — all ${REAL_CLUSTERS.length} real clusters × ${CYCLES.length} cycles (${clusterRows.length} rows with data)`);
  printTable(
    ['Cycle', 'Cluster', 'Req(L)', 'Appr(L)', 'ExtraReq(L)', 'ExtraAppr(L)', 'Purch(L)', 'Purch(XAF)', 'Consumed(L)', 'Reserve(L)', 'Coverage', 'Fleet D/C(XAF)', 'Est. Share(XAF)'],
    clusterRows.map(r => [monthLabel(r.cycle), r.cluster, fmtNum(r.requested_l), fmtNum(r.approved_l), fmtNum(r.extra_requested_l), fmtNum(r.extra_approved_l), fmtNum(r.purchases_l), fmtNum(r.purchases_xaf), fmtNum(r.total_consumed_l), fmtNum(r.total_reserve_l), r.site_coverage, fmtNum(r.fleet_debit_credit_xaf), fmtNum(r.estimated_share_xaf)])
  );

  // ── Site Cycle Analysis ───────────────────────────────────────────────
  const latestCycle = CYCLES[CYCLES.length - 1];
  if (FULL_SITE_CYCLE) {
    section(`SITE CYCLE ANALYSIS — every site, every cycle (${siteRows.length} rows)`);
    printTable(
      ['Cycle', 'Site', 'Site ID', 'Cluster', 'ReqInit(L)', 'ReqExtra(L)', 'ApprInit(L)', 'ApprExtra(L)', 'Delivered(L)', 'Visits', 'Consumed(L)', 'Reserve(L)', 'Status'],
      siteRows.map(r => [monthLabel(r.cycle), r.site_name, r.site_id, r.cluster, fmtNum(r.initial_requested_l), fmtNum(r.extra_requested_l), fmtNum(r.initial_approved_l), fmtNum(r.extra_approved_l), fmtNum(r.delivered_to_site_l), r.visit_count, fmtNum(r.consumed_l), fmtNum(r.reserve_l), r.status])
    );
  } else {
    section(`SITE CYCLE ANALYSIS — latest cycle only (${monthLabel(latestCycle)})`);
    const latestRows = siteRows.filter(r => r.cycle === latestCycle);
    printTable(
      ['Site', 'Site ID', 'Cluster', 'Total Req(L)', 'Total Appr(L)', 'Delivered(L)', 'Visits', 'Consumed(L)', 'Reserve(L)', 'Status'],
      latestRows.map(r => [r.site_name, r.site_id, r.cluster, fmtNum(r.total_requested_l), fmtNum(r.total_approved_l), fmtNum(r.delivered_to_site_l), r.visit_count, fmtNum(r.consumed_l), fmtNum(r.reserve_l), r.status])
    );

    section('SITE CYCLE ANALYSIS — flagged rows across ALL cycles (Exhausted or negative Reserve)');
    const flagged = siteRows.filter(r => r.status === 'Exhausted' || (r.reserve_l != null && r.reserve_l < 0));
    console.log(`  ${flagged.length} flagged row(s) out of ${siteRows.length} total site-cycle rows.`);
    printTable(
      ['Cycle', 'Site', 'Site ID', 'Cluster', 'Reserve(L)', 'Status'],
      flagged.slice(0, 60).map(r => [monthLabel(r.cycle), r.site_name, r.site_id, r.cluster, fmtNum(r.reserve_l), r.status])
    );
    if (flagged.length > 60) console.log(`  …and ${flagged.length - 60} more. Re-run with --full-site-cycle to see everything.`);
    console.log('\n  (Re-run with --full-site-cycle to print every site × every cycle instead.)');
  }

  // ── Complete Monthly Summary ──────────────────────────────────────────
  section(`COMPLETE MONTHLY SUMMARY — reserve/consumption trend, ${completeData.allMonths.length} recovered month(s) (${completeData.allMonths[0]}..${completeData.allMonths[completeData.allMonths.length - 1]}, unscoped — matches the page's own dropdown)`);
  printTable(
    ['Month', 'Total Consumed(L)', 'Total Reserve(L)'],
    completeData.fleetReserveByMonth.map(m => [monthLabel(m.month), fmtNum(m.total_consumed_l), fmtNum(m.total_reserve_l)])
  );
  if (FULL_MONTHLY) {
    section(`COMPLETE MONTHLY SUMMARY — every site, every month (${completeData.rows.length} rows)`);
    printTable(
      ['Month', 'Site', 'Site ID', 'Cluster', 'Requested(L)', 'Approved(L)', 'Extra(L)', 'Consumed(L)', 'Reserve(L)', 'Status'],
      completeData.rows.map(r => [monthLabel(r.month), r.site_name, r.site_id, r.cluster, fmtNum(r.requested_l), fmtNum(r.approved_l), fmtNum(r.extra_fuel_l), fmtNum(r.consumed_l), fmtNum(r.reserve_l), r.status])
    );
  } else {
    console.log('\n  (Re-run with --full-monthly to print every site × every month instead of just the trend.)');
  }

  console.log('\n' + '='.repeat(78));
  console.log('Done. Copy everything above and paste it back for interpretation.');
  console.log('='.repeat(78));

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
