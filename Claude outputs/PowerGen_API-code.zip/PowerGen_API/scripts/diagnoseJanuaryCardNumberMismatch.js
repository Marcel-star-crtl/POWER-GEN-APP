/**
 * diagnoseJanuaryCardNumberMismatch.js
 * diesel-system/scripts/diagnoseJanuaryCardNumberMismatch.js
 *
 * WHY THIS EXISTS (Phase 161):
 * After Phase 160 loaded real per-transaction purchase data for
 * January, the Cluster Cycle Report still shows 0 L / 0 txns
 * Purchases for every cluster (confirmed directly on Edea's card:
 * funding 480 L correct, consumed 19,255 L correct, purchases 0).
 *
 * Root cause, found by direct comparison, not assumed:
 * `TomCard_Allocation_Dec2025.pdf` — still the only source for
 * `TomCardAllocation`, tagged funded_cycle_key '2026-01' — carries ONE
 * set of card numbers per cluster (e.g. Edea: 85215, Kotto: 85213,
 * Bonaberi 1: 121428). A separate, genuinely real email thread for the
 * same month ("...JANUARY 2026 : CARD LIMIT UPDATE", 23 Dec 2025–9 Jan
 * 2026, found in Phase 158's email scan) carries a COMPLETELY
 * DIFFERENT set of card numbers for the same six clusters (Edea:
 * 84953, Kotto: 121720, Bonaberi 1: 84948, Bonaberi 2: 84950,
 * Ndogbong: 84946, Pouma 1: 84951).
 *
 * Checked directly which set is real, rather than assuming either:
 * parsed all 172 of January's actual purchase transactions (from
 * `Jan2026_Validation.xlsx`'s own "Purchases breakdown (Update)"
 * sheet, loaded in Phase 160) and counted which card numbers actually
 * appear. Every single one of the PDF's card numbers — zero
 * exceptions — appears in zero real transactions. Every one of the
 * email thread's six card numbers appears repeatedly (17–31
 * transactions each). A seventh card, "5807," appears 40 times (the
 * most of any card) and matches none of the known clusters from
 * either document — see below.
 *
 * So the PDF's card numbers are stale for January — from a different
 * card series, not the ones actually used in the field — and that's
 * exactly why `HistoricalFuelPurchase.find({ card_number: { $in: [...] } })`
 * in the cluster route (which builds its card-number set from
 * `TomCardAllocation`) matches nothing for every cluster.
 *
 * CONFIRMED mapping (real email evidence, cross-validated against real
 * purchase card usage — both agree):
 *   Bonaberi 1 -> 84948   Bonaberi 2 -> 84950   Edea -> 84953
 *   Kotto      -> 121720  Ndogbong   -> 84946   Pouma 1 -> 84951
 *
 * NOT fixed here, deliberately: Pouma 2 has no TomCardAllocation
 * record at all for January (the PDF's own text literally has a blank
 * "Pouma 2" row with no quantity or card number — confirmed directly
 * against the raw PDF text, not a parsing gap). "5807" (40 real
 * transactions, the single most active card in January) is a strong
 * circumstantial candidate for Pouma 2's real card — Pouma 2 is a
 * real, sizable cluster that month (17,106 L requested) with zero
 * other explanation for a missing card — but no document found so far
 * names "5807" directly, so it is NOT written here. Guessing a card
 * number for real money/liters attribution is exactly the kind of
 * inference this project has repeatedly refused to make elsewhere
 * (e.g. April/May's bare "Approved" status, August's null
 * sbc_requested_l). Yassa has no January data at all in any source
 * checked so far and is left alone too.
 *
 * Writes ONLY the `card_number` field on the 6 confirmed
 * TomCardAllocation documents (cluster + funded_cycle_key: '2026-01').
 * Does not touch quantity_l/amount_xaf (the funding figures) or any
 * other cluster/cycle.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/diagnoseJanuaryCardNumberMismatch.js
 *   node scripts/diagnoseJanuaryCardNumberMismatch.js --confirm
 */
'use strict';
require('dotenv').config();
const path = require('path');
const XLSX = require('xlsx');
const mongoose = require('mongoose');
const TomCardAllocation = require('../models/TomCardAllocation');
const HistoricalFuelPurchase = require('../models/HistoricalFuelPurchase');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const CYCLE_KEY = '2026-01';

// Confirmed directly from the real "...JANUARY 2026 : CARD LIMIT
// UPDATE" email thread (23 Dec 2025 – 9 Jan 2026) — see docblock.
const CONFIRMED_CARD_NUMBERS = {
  'Bonaberi 1': '84948',
  'Bonaberi 2': '84950',
  'Edea': '84953',
  'Kotto': '121720',
  'Ndogbong': '84946',
  'Pouma 1': '84951',
};

async function main() {
  // ── Re-derive the real card-usage counts directly from the source file,
  // not from memory, so this script stays correct if the file ever changes ──
  const wb = XLSX.readFile(path.join(DATA_DIR, 'Jan2026_Validation.xlsx'));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Purchases breakdown (Update)'], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const cardIdx = header.indexOf('Card num/');
  const cardCounts = new Map();
  for (let i = 2; i < rows.length; i++) {
    const r = rows[i];
    if (!r || r[cardIdx] == null) continue;
    const c = String(r[cardIdx]);
    cardCounts.set(c, (cardCounts.get(c) || 0) + 1);
  }
  console.log('── Real card numbers actually used in January\'s purchase transactions ──');
  for (const [card, count] of [...cardCounts.entries()].sort((a, b) => b[1] - a[1])) {
    const cluster = Object.entries(CONFIRMED_CARD_NUMBERS).find(([, c]) => c === card)?.[0];
    console.log(`   ${card}: ${count} transaction(s)${cluster ? ` -> ${cluster} (confirmed)` : ' -> UNIDENTIFIED cluster'}`);
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('\n✓ Connected to MongoDB\n');

  const rowsInDb = await TomCardAllocation.find({ funded_cycle_key: CYCLE_KEY }).lean();
  console.log(`── Live TomCardAllocation for ${CYCLE_KEY}: ${rowsInDb.length} document(s) ──`);
  const ops = [];
  for (const doc of rowsInDb) {
    const correct = CONFIRMED_CARD_NUMBERS[doc.cluster];
    const status = !correct ? '(no confirmed replacement — left as-is)'
      : doc.card_number === correct ? '(already correct)'
      : `MISMATCH: stored ${doc.card_number}, real card is ${correct}`;
    console.log(`   ${doc.cluster}: stored card_number = ${doc.card_number} ${status}`);
    if (correct && doc.card_number !== correct) {
      ops.push({ updateOne: { filter: { _id: doc._id }, update: { $set: { card_number: correct } } } });
    }
  }

  const missingClusters = Object.keys(CONFIRMED_CARD_NUMBERS).filter(c => !rowsInDb.some(d => d.cluster === c));
  if (missingClusters.length) console.log(`\nClusters with a confirmed card number but no TomCardAllocation document at all: ${missingClusters.join(', ')}`);
  console.log(`\nUnidentified card "5807" (40 real transactions, the most active card this month) has no TomCardAllocation document and no confirmed cluster — NOT guessed here. Pouma 2 has no January TomCardAllocation record in any source checked, which is circumstantial but not proof.`);

  console.log(`\n${ops.length} document(s) would be corrected.`);
  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. Re-run with --fix to apply. ──'.replace('--fix', '--confirm'));
    await mongoose.disconnect();
    return;
  }
  if (!ops.length) { console.log('Nothing to write.'); await mongoose.disconnect(); return; }

  const result = await TomCardAllocation.bulkWrite(ops, { ordered: false });
  console.log(`✓ Modified ${result.modifiedCount} document(s).`);
  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
