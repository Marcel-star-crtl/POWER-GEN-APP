/**
 * importMarch2026ExtraFuelRequests.js
 * diesel-system/scripts/importMarch2026ExtraFuelRequests.js
 *
 * Imports March and April 2026's shortage-response "Extra Fuel
 * Request" tracker files — genuinely new data, found after the user
 * pushed back on the earlier "March is a dead end" conclusion (which
 * was correct for monthly reconciliation data specifically, but this
 * is a different document type entirely: multi-round emergency
 * request trackers, the same kind of event already modeled for
 * July/August but with richer detail here).
 *
 * All four of March's rounds are now covered (1st-4th) — the 1st
 * round's own file was genuinely missing through several phases
 * (76-81), and was only found in a later email batch (Phase 85).
 * Also covers all three of April's rounds (1st-3rd).
 *
 * WHY ROW ALIGNMENT IS HANDLED PER FILE:
 * Verified each file directly with the real xlsx package rather than
 * assumed consistent — most round files have their header at row 1
 * (data row 2, the usual pattern in this project), but March's 3rd
 * round file ("Armel") genuinely has its header at row 0 instead.
 *
 * WHY THREE COLUMNS ARE OPTIONAL, NOT REQUIRED:
 * Checked real fill rates before deciding what to trust: "EXTRA FUEL"
 * (the requested figure) is 100% populated in all three files, but "SS
 * approval" and "Extra Given" (actual delivered) are only populated in
 * the earlier rounds — the 4th round has neither at all (0/64 filled),
 * consistent with it being the most recent request, not yet processed
 * at the time this snapshot was taken. Left null rather than
 * backfilled or guessed.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importMarch2026ExtraFuelRequests.js
 *   node scripts/importMarch2026ExtraFuelRequests.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const AdHocFuelRequest = require('../models/AdHocFuelRequest');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

const SOURCES = [
  { file: 'MarExtra1_13Mar2026.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '1st', cycle_month: '2026-03' },
  { file: 'MarExtra2_17Mar2026.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '2nd', cycle_month: '2026-03' },
  { file: 'MarExtra3_23Mar2026.xlsx', sheet: 'Sheet1', headerRow: 0, request_round: '3rd', cycle_month: '2026-03' },
  { file: 'MarExtra4_24Mar2026.xlsx', sheet: 'Sheet1', headerRow: 1, request_round: '4th', cycle_month: '2026-03' },
  { file: 'AprExtra1_13Apr2026.xlsx', sheet: 'Sheet1', headerRow: 1, request_round: '1st', cycle_month: '2026-04' },
  { file: 'AprExtra2_14Apr2026.xlsx', sheet: 'Sheet1', headerRow: 1, request_round: '2nd', cycle_month: '2026-04', knownDateBug: { wrongSerial: 45396, fallbackDate: new Date(2026, 3, 14) } },
  { file: 'AprExtra3_22Apr2026.xlsx', sheet: 'Sheet1', headerRow: 1, request_round: '3rd', cycle_month: '2026-04' },
  // December 2025 / January 2026 / February 2026 — a genuinely different
  // template variant than March/April's: no per-row "Date" column at
  // all (only "Last visit Date," a different field), and the real
  // approval figure lives in "Qty to approve," not "SS approval" (which
  // is present in this variant but genuinely empty in every file
  // checked — verified directly, not assumed). Falls back to this
  // file's own known email-send date for every row, the same honest
  // choice used for April's date-bug file, since no other per-row date
  // exists to use.
  //
  // Where multiple revisions existed for the same round, the version
  // used was picked by real fill rate, not by timestamp — checked
  // every revision directly rather than assume the chronologically
  // latest carries the most complete approval data. December 16 has
  // only one version, genuinely 0/84 approved — a real snapshot from
  // before approvals were logged, not a parsing gap. February's three
  // rounds show 0 approvals in every single revision found (checked
  // all of them) — a real, consistent finding, not a fluke of which
  // copy was picked.
  { file: 'DecExtra1_16Dec2025.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '1st', cycle_month: '2025-12', approvedColumn: 'Qty to approve', deliveredColumn: null, fixedDate: new Date(2025, 11, 16) },
  { file: 'DecExtra2_22Dec2025.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '2nd', cycle_month: '2025-12', approvedColumn: 'Qty to approve', deliveredColumn: null, fixedDate: new Date(2025, 11, 24) },
  { file: 'JanExtra1_15Jan2026.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '1st', cycle_month: '2026-01', approvedColumn: 'Qty to approve', deliveredColumn: null, fixedDate: new Date(2026, 0, 19) },
  { file: 'FebExtra1_10Feb2026.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '1st', cycle_month: '2026-02', approvedColumn: 'Qty to approve', deliveredColumn: null, fixedDate: new Date(2026, 1, 10) },
  { file: 'FebExtra2_17Feb2026.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '2nd', cycle_month: '2026-02', approvedColumn: 'Qty to approve', deliveredColumn: null, fixedDate: new Date(2026, 1, 17) },
  { file: 'FebExtra3_20Feb2026.xlsx', sheet: 'Sheet2', headerRow: 1, request_round: '3rd', cycle_month: '2026-02', approvedColumn: 'Qty to approve', deliveredColumn: null, fixedDate: new Date(2026, 1, 23) },
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function excelSerialToJs(v) {
  if (v instanceof Date) return v;
  if (typeof v === 'number') return new Date(Math.round((v - 25569) * 86400 * 1000));
  return null;
}

function findCol(header, name) {
  const target = String(name).replace(/\s+/g, ' ').trim();
  const i = header.findIndex(h => typeof h === 'string' && h.replace(/\s+/g, ' ').trim() === target);
  return i === -1 ? null : i;
}

function parseSource(src) {
  const filePath = path.join(DATA_DIR, src.file);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[src.sheet], { header: 1, defval: null, raw: true });
  const header = rows[src.headerRow];

  const idx = {
    site_id: findCol(header, 'IHS ID'),
    cluster: findCol(header, 'Cluster'),
    site_name: findCol(header, 'Site Name'),
    region: findCol(header, 'Region'),
    date: src.fixedDate ? null : findCol(header, 'Date'),
    requested: findCol(header, 'EXTRA FUEL'),
    approved: findCol(header, src.approvedColumn ?? 'SS approval'),
    delivered: src.deliveredColumn === null ? null : findCol(header, src.deliveredColumn ?? 'Extra Given'),
  };

  const required = ['site_id', 'cluster', 'requested', ...(src.fixedDate ? [] : ['date'])];
  const missing = required.filter(k => idx[k] === null);
  if (missing.length) {
    throw new Error(`${src.file} missing expected column(s): ${missing.join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  const monthMismatches = [];
  for (const row of rows.slice(src.headerRow + 1)) {
    if (!row || !row[idx.site_id]) continue;
    const requested = toNum(row[idx.requested]);
    if (requested === null) continue; // no real request figure — skip, don't fabricate
    const rawDate = idx.date !== null ? row[idx.date] : null;
    const plannedDate = src.fixedDate
      ? src.fixedDate
      : (src.knownDateBug && rawDate === src.knownDateBug.wrongSerial)
        ? src.knownDateBug.fallbackDate
        : excelSerialToJs(rawDate);
    if (!plannedDate) continue;

    const rowMonthKey = `${plannedDate.getUTCFullYear()}-${String(plannedDate.getUTCMonth() + 1).padStart(2, '0')}`;
    if (rowMonthKey !== src.cycle_month) monthMismatches.push(rowMonthKey);

    records.push({
      site_id: String(row[idx.site_id]).trim(),
      cluster: row[idx.cluster] ?? null,
      site_name: row[idx.site_name] ?? null,
      region: row[idx.region] ?? null,
      planned_date: plannedDate,
      quantity_requested_l: requested,
      approved_l: idx.approved !== null ? toNum(row[idx.approved]) : null,
      delivered_l: idx.delivered !== null ? toNum(row[idx.delivered]) : null,
      request_round: src.request_round,
      source_file: src.file,
    });
  }
  if (monthMismatches.length) {
    console.log(`  ⚠ ${src.file}: ${monthMismatches.length} row(s) had a date outside the expected ${src.cycle_month} cycle (found: ${[...new Set(monthMismatches)].join(', ')}) — included anyway, but worth checking the source.`);
  }
  return records;
}

// A second, genuinely different template family — found for June's 4th
// round and July's 1st round. Unlike Family 1 above: has real per-row
// dates (no fixedDate needed), uses "NEW IHS ID" as its site
// identifier column rather than "IHS ID" (verified directly against
// real data — "SITE ID" in this template is a different, physical
// T-number/LIT code, not the IHS_XXX_NNN scheme used as site_id
// everywhere else), and its approval column mixes real numbers with
// status strings ("Approved", "Not approved") rather than being purely
// numeric. June's file has no approval column at all — a real request
// snapshot with nothing yet decided, not a parsing gap.
const FAMILY2_SOURCES = [
  { file: 'JunExtra4_23Jun2026.xlsx', request_round: '4th', cycle_month: '2026-06' },
  { file: 'JulExtra1_22Jul2026.xlsx', request_round: '1st', cycle_month: '2026-07' },
];

function parseFamily2Source(src) {
  const filePath = path.join(DATA_DIR, src.file);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Sheet1'], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findCol(header, 'NEW IHS ID'),
    cluster: findCol(header, 'Cluster'),
    site_name: findCol(header, 'Site Name'),
    region: findCol(header, 'State'),
    date: findCol(header, 'Date'),
    requested: findCol(header, 'EXTRA'),
    approved: findCol(header, 'TL Approval'), // absent in June's file — findCol correctly returns null
  };

  const required = ['site_id', 'cluster', 'date', 'requested'];
  const missing = required.filter(k => idx[k] === null);
  if (missing.length) {
    throw new Error(`${src.file} missing expected column(s): ${missing.join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  const monthMismatches = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const requested = toNum(row[idx.requested]);
    if (requested === null) continue; // no real request figure — skip, don't fabricate
    const plannedDate = excelSerialToJs(row[idx.date]);
    if (!plannedDate) continue;

    const rowMonthKey = `${plannedDate.getUTCFullYear()}-${String(plannedDate.getUTCMonth() + 1).padStart(2, '0')}`;
    if (rowMonthKey !== src.cycle_month) monthMismatches.push(rowMonthKey);

    // "TL Approval" mixes real numbers with status strings. A number is
    // used directly. "Not approved" is a real, explicit rejection — 0,
    // not null (a decision was made, it just wasn't yes). The bare
    // string "Approved" with no figure is deliberately left null rather
    // than assumed to equal the requested amount — that would be
    // inferring a number the source never actually gave.
    let approved_l = null;
    const rawApproval = idx.approved !== null ? row[idx.approved] : null;
    if (typeof rawApproval === 'number') approved_l = rawApproval;
    else if (typeof rawApproval === 'string' && rawApproval.trim().toLowerCase() === 'not approved') approved_l = 0;

    records.push({
      site_id: String(row[idx.site_id]).trim(),
      cluster: row[idx.cluster] ?? null,
      site_name: row[idx.site_name] ?? null,
      region: row[idx.region] ?? null,
      planned_date: plannedDate,
      quantity_requested_l: requested,
      approved_l,
      delivered_l: null, // this template never carries a real delivered figure
      request_round: src.request_round,
      source_file: src.file,
    });
  }
  if (monthMismatches.length) {
    console.log(`  ⚠ ${src.file}: ${monthMismatches.length} row(s) had a date outside the expected ${src.cycle_month} cycle (found: ${[...new Set(monthMismatches)].join(', ')}) — included anyway, but worth checking the source.`);
  }
  return records;
}

async function main() {
  const allRecords = [];
  for (const src of SOURCES) {
    const records = parseSource(src);
    const totalRequested = records.reduce((s, r) => s + (r.quantity_requested_l || 0), 0);
    const withApproval = records.filter(r => r.approved_l != null).length;
    const withDelivery = records.filter(r => r.delivered_l != null).length;
    console.log(`── ${src.request_round} round (${src.file}): ${records.length} site(s), ${Math.round(totalRequested).toLocaleString()} L requested. ${withApproval} with an approval figure, ${withDelivery} with a delivered figure.`);
    allRecords.push(...records);
  }

  for (const src of FAMILY2_SOURCES) {
    const records = parseFamily2Source(src);
    const totalRequested = records.reduce((s, r) => s + (r.quantity_requested_l || 0), 0);
    const withApproval = records.filter(r => r.approved_l != null).length;
    console.log(`── ${src.request_round} round (${src.file}): ${records.length} site(s), ${Math.round(totalRequested).toLocaleString()} L requested. ${withApproval} with an approval figure.`);
    allRecords.push(...records);
  }

  console.log(`\n── Total: ${allRecords.length} record(s) across ${SOURCES.length + FAMILY2_SOURCES.length} request round(s). ──`);
  console.log('December 2025 (2 rounds), January 2026 (1 round), February 2026 (3 rounds), June\'s 4th round, and July\'s 1st round are now also covered — all from a genuinely different template family than March/April\'s (see FAMILY2_SOURCES).');

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  for (const src of [...SOURCES, ...FAMILY2_SOURCES]) {
    await AdHocFuelRequest.deleteMany({ source_file: src.file });
  }
  const result = await AdHocFuelRequest.insertMany(allRecords);
  console.log(`✓ Inserted ${result.length} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
