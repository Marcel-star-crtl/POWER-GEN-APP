/**
 * cleanupDuplicateTankAuditDrafts.js
 * diesel-system/scripts/cleanupDuplicateTankAuditDrafts.js
 *
 * One-time cleanup for the duplicate-draft bug: repeated draft saves
 * for the same site, by the same technician, previously created a new
 * record on every save instead of updating one (root cause: a fresh
 * client_id was generated on every create-attempt, defeating the
 * backend's own idempotency check — fixed in the mobile app and with a
 * database-level unique constraint, see models/TankAudit.js). This
 * script cleans up the duplicates that bug already created.
 *
 * Groups DRAFT records by (site_id_ihs, created_by) — deliberately not
 * touching SUBMITTED records at all, even if a site has multiple; a
 * site legitimately gets re-audited over time, and each submitted
 * audit is a real, distinct historical event, not a duplicate.
 *
 * For each group with more than one draft, keeps the most recently
 * updated one and deletes the rest. This is a reasonable default (the
 * mobile app always sends the complete current form state on every
 * save, not an incremental diff, so a later save should generally be
 * at least as complete as an earlier one for the same draft session) —
 * but it is a real, lossy decision if any of the duplicates were
 * filled in via genuinely different, non-overlapping sessions. Review
 * the dry-run output before confirming.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/cleanupDuplicateTankAuditDrafts.js
 *   node scripts/cleanupDuplicateTankAuditDrafts.js --confirm
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const TankAudit = require('../models/TankAudit');

const CONFIRM = process.argv.includes('--confirm');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const drafts = await TankAudit.find({ status: 'draft' })
    .select('site_id_ihs site_name created_by updatedAt createdAt')
    .sort({ updatedAt: -1 })
    .lean();

  const groups = new Map(); // key: `${site_id_ihs}::${created_by}`
  for (const d of drafts) {
    const key = `${d.site_id_ihs}::${d.created_by || 'unknown'}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(d);
  }

  const duplicateGroups = [...groups.entries()].filter(([, records]) => records.length > 1);

  if (!duplicateGroups.length) {
    console.log('No duplicate draft groups found — nothing to clean up.');
    await mongoose.disconnect();
    return;
  }

  console.log(`Found ${duplicateGroups.length} site(s) with duplicate draft records:\n`);

  let totalToDelete = 0;
  const idsToDelete = [];

  for (const [key, records] of duplicateGroups) {
    const [siteId] = key.split('::');
    // Already sorted updatedAt desc from the query above, per site the
    // relative order is preserved — first one in this filtered array
    // is genuinely the most recently updated.
    const [keep, ...toDelete] = records;
    totalToDelete += toDelete.length;
    idsToDelete.push(...toDelete.map(r => r._id));

    console.log(`── ${records[0].site_name || siteId} (${siteId}) — ${records.length} draft(s)`);
    console.log(`   ✓ KEEP:   ${keep._id} (updated ${new Date(keep.updatedAt).toLocaleString()})`);
    for (const r of toDelete) {
      console.log(`   ✗ DELETE: ${r._id} (updated ${new Date(r.updatedAt).toLocaleString()})`);
    }
  }

  console.log(`\n── Total: ${totalToDelete} duplicate draft record(s) to delete across ${duplicateGroups.length} site(s). ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log('Review the KEEP/DELETE decisions above carefully before re-running with --confirm.');
    console.log('Re-run with --confirm to actually delete the records listed above.');
    await mongoose.disconnect();
    return;
  }

  const result = await TankAudit.deleteMany({ _id: { $in: idsToDelete } });
  console.log(`\n✓ Deleted ${result.deletedCount} duplicate draft record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
