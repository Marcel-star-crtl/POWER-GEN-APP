/**
 * removeNonKeptClusters.js
 * diesel-system/scripts/removeNonKeptClusters.js
 *
 * Phase 129. Removes every site NOT in the 7 kept clusters — BONABERI
 * 1, BONABERI 2, EDEA, KOTTO, NDOGBONG, POUMA 1, POUMA 2 — along with
 * every related record across every collection this system has that
 * references a site or cluster.
 *
 * This is the single most destructive script in this project. Built
 * with the heaviest safeguards used anywhere here, refined through
 * actually attempting to load every model referenced (not just
 * checking file existence), which caught three real, otherwise-
 * missed collections and a broken model-loading assumption before
 * this ever touched a real database:
 *
 *   1. Every model in this codebase was checked directly for a site or
 *      cluster reference (37 files matched) before deciding scope —
 *      not assumed from memory.
 *
 *   2. Actually REQUIRED every model referenced, not just confirmed
 *      the file exists — caught that MidCycleBudgetRelease.js,
 *      TomCardCycleBudget.js, and TomCardMapping.js each export an
 *      OBJECT with multiple named models, not a single default export.
 *      A naive `require(...).countDocuments()` against any of these
 *      would have crashed immediately. Handled with an explicit
 *      per-entry `key` for the few models that need one.
 *
 *   3. That same investigation surfaced three real collections this
 *      script would have otherwise completely missed:
 *      MidCycleReleaseDailyProgress and TomCardCycleBudgetUpload
 *      (both cluster-level), and confirmed TomCardMapping itself has
 *      a `site_ids` array field alongside `cluster` — a document
 *      could reference a removed site even if its cluster field
 *      doesn't match, so it's matched on either condition.
 *
 *   4. EXPLICITLY EXCLUDED, never touched regardless of --confirm:
 *      User (assignedClusters is who MANAGES a cluster, not data that
 *      belongs to one — deleting a person's account over a cluster
 *      reassignment would be a completely different, more dangerous
 *      mistake) and AuditLog (a compliance/history record — logs stay
 *      immutable regardless of what the data they describe later
 *      becomes).
 *
 *   5. PartRequest.site is a free-text optional string, not a strict
 *      site_id reference — included, flagged as lower-confidence.
 *
 *   6. Dry run by default. Requires --confirm AND an explicit
 *      --expect=<N> matching the real site count from THIS run — a
 *      second, deliberate acknowledgment of scale, given how much
 *      larger this operation is than anything else in this project.
 *
 *   7. Full backup of every document about to be deleted, one file per
 *      collection, in a timestamped folder, BEFORE any deletion —
 *      and the deletion is refused entirely if any single collection's
 *      backup count doesn't match what was about to be removed.
 *
 * Usage:
 *   node scripts/removeNonKeptClusters.js                         (dry run — always safe)
 *   node scripts/removeNonKeptClusters.js --confirm --expect=157   (writes — only after reviewing the dry run's real numbers)
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const CONFIRM = process.argv.includes('--confirm');
const expectArg = process.argv.find(a => a.startsWith('--expect='));
const EXPECTED_SITE_COUNT = expectArg ? parseInt(expectArg.split('=')[1], 10) : null;

const KEEP_CLUSTERS = ['BONABERI 1', 'BONABERI 2', 'EDEA', 'KOTTO', 'NDOGBONG', 'POUMA 1', 'POUMA 2'];
const normalize = s => (s || '').toString().trim().toUpperCase();
const KEEP_SET = new Set(KEEP_CLUSTERS.map(normalize));

// `key` is only needed for models whose file exports an object with
// multiple named models rather than a single default export —
// confirmed directly per-file, not assumed uniform across the project.
const SITE_ID_COLLECTIONS = [
  { model: 'AdHocFuelRequest', field: 'site_id' },
  { model: 'BudgetRequestApproval', field: 'site_id' },
  { model: 'CmsDailyRecord', field: 'site_id' },
  { model: 'CycleEndStockSnapshot', field: 'site_id' },
  { model: 'CycleReconciliation', field: 'site_id' },
  { model: 'DieselAlert', field: 'site_id' },
  { model: 'FieldVisitRecord', field: 'site_id' },
  { model: 'FuelConsumption', field: 'site_id' },
  { model: 'FuelDeliveryEvent', field: 'site_id' },
  { model: 'FuelPurchase', field: 'site_id' },
  { model: 'FuelRequest', field: 'site_id' },
  { model: 'GeneratorAssignmentLedger', field: 'site_id' },
  { model: 'GeneratorUpdate', field: 'site_id' },
  { model: 'HistoricalFieldVisit', field: 'site_id' },
  { model: 'HistoricalMonthlyRecord', field: 'site_id' },
  { model: 'HistoricalSiteStockSnapshot', field: 'site_id' },
  { model: 'Maintenance', field: 'site_id' },
  { model: 'MidCycleBudgetRelease', field: 'site_id', key: 'MidCycleBudgetRelease' },
  { model: 'MidCycleEstimateSnapshot', field: 'site_id' },
  { model: 'PlannedVsSuppliedDelivery', field: 'site_id' },
  { model: 'SiteBudget', field: 'site_id' },
  { model: 'SiteConsumptionHistory', field: 'site_id' },
  { model: 'SiteEngineeringParams', field: 'site_id' },
  { model: 'SiteVisit', field: 'site_id' },
  { model: 'TankAudit', field: 'site_id_ihs' },
  { model: 'TankLevelReading', field: 'site_id' },
  { model: 'TankLevelUpload', field: 'site_id' },
  { model: 'TechnicianSiteAudit', field: 'site_id_ihs' },
  { model: 'TomCardTransaction', field: 'site_id' },
  { model: 'ValidationRecord', field: 'site_id' },
  { model: 'PartRequest', field: 'site', note: '(free-text field, lower confidence)' },
];

// Cluster-level-only collections, no site_id at all — matched by
// cluster name directly. TomCardMapping is matched on cluster OR its
// site_ids array, since a document there could reference a removed
// site even when its own cluster field doesn't match.
const CLUSTER_ONLY_COLLECTIONS = [
  { model: 'TomCardAllocation', field: 'Cluster' },
  { model: 'TomCardCycleBudget', field: 'Cluster', key: 'TomCardCycleBudget' },
  { model: 'TomCardCycleBudget', field: 'cluster', key: 'TomCardCycleBudgetUpload', label: 'TomCardCycleBudgetUpload' },
  { model: 'TomCardMapping', field: 'cluster', key: 'TomCardMapping', extraSiteIdsField: 'site_ids' },
  { model: 'TomCardMapping', field: 'cluster', key: 'TomCardUpload', label: 'TomCardUpload' },
  { model: 'Tower', field: 'Cluster' },
  { model: 'MidCycleBudgetRelease', field: 'cluster', key: 'MidCycleReleaseDailyProgress', label: 'MidCycleReleaseDailyProgress' },
];

function loadModel(entry) {
  const mod = require(`../models/${entry.model}`);
  if (!entry.key) return mod; // plain default export
  return mod[entry.key];
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const Site = require('../models/Site');
  const ClusterModel = require('../models/Cluster');
  const SiteAuditChecklist = require('../models/SiteAuditChecklist');

  console.log('══════════════════════════════════════════════════════════');
  console.log(' KEEPING these clusters (everything else is removed):');
  for (const c of KEEP_CLUSTERS) console.log(`   - ${c}`);
  console.log('══════════════════════════════════════════════════════════\n');

  const allSites = await Site.find({}).select('_id IHS_ID_SITE Site_Name GRATO_Cluster').lean();
  const clustersFound = new Map();
  for (const s of allSites) {
    const key = normalize(s.GRATO_Cluster);
    if (!clustersFound.has(key)) clustersFound.set(key, { real_name: s.GRATO_Cluster, count: 0 });
    clustersFound.get(key).count++;
  }

  console.log('Clusters actually found in the live Site collection:');
  const unmatchedKeepClusters = new Set(KEEP_SET);
  for (const [key, info] of clustersFound) {
    const kept = KEEP_SET.has(key);
    if (kept) unmatchedKeepClusters.delete(key);
    console.log(`  ${kept ? '✓ KEEP  ' : '✗ REMOVE'}  "${info.real_name}" — ${info.count} site(s)`);
  }
  if (unmatchedKeepClusters.size) {
    console.log(`\n⚠ ${unmatchedKeepClusters.size} of the requested keep-clusters were NOT found in the live data at all: ${[...unmatchedKeepClusters].join(', ')}`);
    console.log('  Check for a naming/spelling mismatch before proceeding — a cluster that should be kept but doesn\'t match anything here would have every one of its sites removed.');
  }

  const sitesToRemove = allSites.filter(s => !KEEP_SET.has(normalize(s.GRATO_Cluster)));
  const sitesToKeep = allSites.filter(s => KEEP_SET.has(normalize(s.GRATO_Cluster)));
  const removeSiteIds = [...new Set(sitesToRemove.map(s => s.IHS_ID_SITE))];
  const removeSiteObjectIds = sitesToRemove.map(s => s._id);

  console.log(`\nTotal sites: ${allSites.length} | Keeping: ${sitesToKeep.length} | Removing: ${sitesToRemove.length}\n`);

  console.log('══════════════════════════════════════════════════════════');
  console.log(' Impact across every related collection');
  console.log('══════════════════════════════════════════════════════════\n');

  const impact = []; // { label, Model, filter, count }
  const skippedCollections = [];

  for (const entry of SITE_ID_COLLECTIONS) {
    const Model = loadModel(entry);
    const label = entry.key || entry.model;
    process.stdout.write(`  checking ${label}...`);
    const filter = { [entry.field]: { $in: removeSiteIds } };
    let count;
    try {
      count = await Model.countDocuments(filter).maxTimeMS(20000);
    } catch (err) {
      console.log(` ✗ TIMED OUT OR FAILED: ${err.message}`);
      console.log(`    This is the real stuck point — likely a missing index on "${entry.field}" for a large collection. Skipping and continuing with the rest.`);
      skippedCollections.push(label);
      continue;
    }
    impact.push({ label, Model, filter, count });
    console.log(count > 0 ? ` ${count}${entry.note ? '  ⚠ ' + entry.note : ''}` : ' 0');
  }

  for (const entry of CLUSTER_ONLY_COLLECTIONS) {
    const Model = loadModel(entry);
    const label = entry.label || entry.key || entry.model;
    process.stdout.write(`  checking ${label}...`);
    let count;
    let filter;
    try {
      const distinctValues = await Model.distinct(entry.field).maxTimeMS(20000);
      const removeValues = distinctValues.filter(v => !KEEP_SET.has(normalize(v)));
      filter = { [entry.field]: { $in: removeValues } };
      if (entry.extraSiteIdsField) {
        filter = { $or: [filter, { [entry.extraSiteIdsField]: { $in: removeSiteIds } }] };
      }
      count = await Model.countDocuments(filter).maxTimeMS(20000);
    } catch (err) {
      console.log(` ✗ TIMED OUT OR FAILED: ${err.message}`);
      skippedCollections.push(label);
      continue;
    }
    impact.push({ label, Model, filter, count });
    console.log(count > 0 ? ` ${count}` : ' 0');
  }

  const clusterDefsToRemove = await ClusterModel.find({}).select('_id name').lean()
    .then(all => all.filter(c => !KEEP_SET.has(normalize(c.name))));
  console.log(`  Cluster (definitions themselves): ${clusterDefsToRemove.length}`);

  const siteAuditChecklistCount = await SiteAuditChecklist.countDocuments({ site: { $in: removeSiteObjectIds } });
  console.log(`  SiteAuditChecklist (site ObjectId ref): ${siteAuditChecklistCount}`);

  console.log(`\n  Site (the sites themselves): ${sitesToRemove.length}`);

  console.log('\n══════════════════════════════════════════════════════════');
  console.log(' EXPLICITLY EXCLUDED — never touched by this script:');
  console.log('   User (cluster ASSIGNMENT, not data belonging to a cluster — a person\'s account is not deleted by this)');
  console.log('   AuditLog (compliance/history — stays immutable regardless of what the data it describes later becomes)');
  console.log('══════════════════════════════════════════════════════════');

  if (skippedCollections.length) {
    console.log('\n⚠⚠⚠ WARNING — the following collection(s) timed out and were SKIPPED, not counted: ⚠⚠⚠');
    for (const label of skippedCollections) console.log(`   - ${label}`);
    console.log('This means the numbers above are INCOMPLETE. Proceeding to --confirm now would leave orphaned records behind in whatever was skipped — likely because that collection is missing an index on the field being queried. Do not proceed until this is resolved.');
  }

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Review every number above carefully. Re-run with --confirm --expect=${sitesToRemove.length} to actually delete — the --expect value must match this run's real site count exactly, or nothing will be deleted.`);
    await mongoose.disconnect();
    return;
  }

  if (skippedCollections.length) {
    console.error(`\n✗ Aborting — ${skippedCollections.length} collection(s) were skipped due to a timeout (see warning above). Refusing to proceed with --confirm while any collection's real impact is unknown.`);
    await mongoose.disconnect();
    process.exit(1);
  }

  if (EXPECTED_SITE_COUNT !== sitesToRemove.length) {
    console.error(`\n✗ Aborting — --expect=${EXPECTED_SITE_COUNT ?? '(not provided)'} does not match the real site count about to be removed (${sitesToRemove.length}). This mismatch check exists specifically to stop a stale or copy-pasted command from running against different data than what was actually reviewed.`);
    await mongoose.disconnect();
    process.exit(1);
  }

  const backupDir = path.join(__dirname, `cluster_removal_backup_${Date.now()}`);
  fs.mkdirSync(backupDir, { recursive: true });
  console.log(`\n── Backing up every affected document to ${backupDir} ──`);

  fs.writeFileSync(path.join(backupDir, 'Site.json'), JSON.stringify(sitesToRemove, null, 2));
  fs.writeFileSync(path.join(backupDir, 'Cluster.json'), JSON.stringify(clusterDefsToRemove, null, 2));
  const checklistDocs = await SiteAuditChecklist.find({ site: { $in: removeSiteObjectIds } }).lean();
  fs.writeFileSync(path.join(backupDir, 'SiteAuditChecklist.json'), JSON.stringify(checklistDocs, null, 2));

  let backupMismatch = false;
  for (const item of impact) {
    const docs = await item.Model.find(item.filter).lean();
    if (docs.length !== item.count) {
      console.error(`  ✗ ${item.label}: expected to back up ${item.count} but found ${docs.length} — data changed between the count and the backup, or a real bug. Aborting before any deletion.`);
      backupMismatch = true;
    }
    fs.writeFileSync(path.join(backupDir, `${item.label}.json`), JSON.stringify(docs, null, 2));
    if (docs.length) console.log(`  ✓ ${item.label}: ${docs.length} document(s) backed up`);
  }
  if (checklistDocs.length !== siteAuditChecklistCount) {
    console.error(`  ✗ SiteAuditChecklist: expected ${siteAuditChecklistCount} but backed up ${checklistDocs.length}. Aborting before any deletion.`);
    backupMismatch = true;
  }

  if (backupMismatch) {
    console.error('\n✗ Aborting — at least one collection\'s backup did not match its expected count. Nothing was deleted. Review the backup files already written before retrying.');
    await mongoose.disconnect();
    process.exit(1);
  }

  console.log('\n✓ All backups verified complete and matching. Proceeding with deletion.\n');

  for (const item of impact) {
    const result = await item.Model.deleteMany(item.filter);
    if (result.deletedCount) console.log(`  ✓ ${item.label}: deleted ${result.deletedCount}`);
  }
  const checklistResult = await SiteAuditChecklist.deleteMany({ site: { $in: removeSiteObjectIds } });
  if (checklistResult.deletedCount) console.log(`  ✓ SiteAuditChecklist: deleted ${checklistResult.deletedCount}`);
  const clusterResult = await ClusterModel.deleteMany({ _id: { $in: clusterDefsToRemove.map(c => c._id) } });
  if (clusterResult.deletedCount) console.log(`  ✓ Cluster: deleted ${clusterResult.deletedCount}`);
  const siteResult = await Site.deleteMany({ _id: { $in: sitesToRemove.map(s => s._id) } });
  console.log(`  ✓ Site: deleted ${siteResult.deletedCount}`);

  console.log(`\n✓ Done. Backup of everything removed is in ${backupDir} — keep it.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
