# Tank Audit reference data

Source files for `scripts/importAugust2026CycleReferenceData.js`.

- `AUGUST_2026_CYCLE_ANALYSIS.xlsx` — the workbook provided directly,
  used for its "Cycle Summary" sheet (opening stock) and "CCPH" sheet
  (contractual consumption per hour).
- `TANK AUDIT PLAN.docx` — recovered from the August-cycle email
  archive (12 Aug 2026), used for its 164-site reference table (tank
  capacity, topology, DG card status).
- `tank_capacity_reference.json` — a pre-generated extraction from the
  Plan document's table, keyed by IHS Site ID. Generated once with:

  ```python
  from docx import Document
  import json
  doc = Document('TANK AUDIT PLAN.docx')
  plan_table = [t for t in doc.tables if len(t.rows) > 15][0]
  ref = {}
  for row in plan_table.rows[1:]:
      c = [cell.text.strip() for cell in row.cells]
      if not c[0]: continue
      cap = c[9]
      cap_num = None
      if cap:
          first = cap.replace(' ', '').split('/')[0]
          try: cap_num = float(first)
          except ValueError: cap_num = None
      ref[c[0]] = cap_num
  json.dump(ref, open('tank_capacity_reference.json', 'w'), indent=2)
  ```

  Generated as a JSON companion rather than parsed live from the .docx
  on every run, since this project doesn't have a Node docx-table-
  parsing dependency and adding one for a single one-time import
  wasn't worth it. 163 of 164 sites have a real capacity value — one
  site (IHS_DLA_272) genuinely has no capacity listed in the source
  document itself, confirmed directly rather than assumed to be a
  parsing gap.

  Compound values like "1000/100" (multiple tanks) keep only the first
  number — the document never states a combined total, so one wasn't
  invented here either.
