/**
 * removeOrphanedMarchRecord.js
 * diesel-system/scripts/removeOrphanedMarchRecord.js
 *
 * Optional cleanup — deletes the single March 2026 record left over
 * from before the real Validation file was found (site IHS_EDA_042,
 * "Ngambe," Pouma 2 cluster). Confirmed directly: this site is
 * genuinely absent from the real Validation file — it was budgeted for
 * in March but has no reconciliation data anywhere for that month.
 *
 * This is a real, meaningful data point (budgeted but unaccounted for),
 * not necessarily an error — read the surrounding conversation before
 * running this. Only run it if you've decided you specifically want
 * every March record to represent a site with real consumption data.
 *
 * Precisely scoped to avoid touching anything else: matches on
 * site_id, month_key, AND source_file together, not just site_id.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/removeOrphanedMarchRecord.js
 *   node scripts/removeOrphanedMarchRecord.js --confirm
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const FILTER = { site_id: 'IHS_EDA_042', month_key: '2026-03', source_file: 'SbcBudget_Mar2026.xlsx' };

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const match = await HistoricalMonthlyRecord.findOne(FILTER).lean();
  if (!match) {
    console.log('No matching record found — nothing to do (it may have already been removed, or the data has changed since this script was written).');
    await mongoose.disconnect();
    return;
  }

  console.log('Found the record to remove:');
  console.log(` site_id: ${match.site_id} | month_key: ${match.month_key} | source_file: ${match.source_file} | budget_liters: ${match.budget_liters}`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — nothing was deleted. ─────────────────────────────');
    console.log('Re-run with --confirm to actually delete this one record.');
    await mongoose.disconnect();
    return;
  }

  const result = await HistoricalMonthlyRecord.deleteOne(FILTER);
  console.log(`\n✓ Deleted ${result.deletedCount} record.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
