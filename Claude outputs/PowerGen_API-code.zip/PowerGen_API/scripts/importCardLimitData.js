/**
 * importCardLimitData.js
 * diesel-system/scripts/importCardLimitData.js
 *
 * Imports "Card Limit"-style cluster-level card budget/funding sheets —
 * genuinely different document shape from the TOMCARD-REFILL PDF
 * already imported (models/TomCardAllocation.js), same collection.
 *
 * Now covers two cycles, found in two separate source threads:
 *   - December 2025 (from "Jan2026_Budget.xlsx"'s "Card Limit" sheet)
 *   - July 2026 (from "Book23.xlsx"'s "Sheet2" — found during a deeper
 *     search after the user confirmed this data existed in the archive
 *     under different naming than first assumed; traced to the same
 *     "GRATO July Diesel Budget" thread as the already-imported
 *     BudgetRequestApproval data, but a genuinely different document)
 *
 * WHY ROW ALIGNMENT AND COLUMN SET DIFFER BY FILE:
 * Verified each file individually with the real xlsx package rather
 * than assume consistency. Both happen to share header row 0 / data
 * row 1 (unlike most other recovered files, which use row 1 / row 2),
 * but July's sheet adds a "Strategic Tank Usage" column December's
 * doesn't have, and the "new limit" date is baked into that column's
 * own header text in both files (26/12/2025 for December, 26/06/2026
 * for July) — not a cell value, so it's hardcoded per source rather
 * than parsed.
 *
 * WHY TWO COLUMNS ARE READ POSITIONALLY, NOT BY NAME:
 * Both files have a genuine duplicate header — "Initial % Recharge
 * Amount" appears twice, once holding a percentage and once an XAF
 * amount. Name-based lookup can't tell these apart in either file, so
 * both are read positionally, relative to the known budget_xaf column.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importCardLimitData.js
 *   node scripts/importCardLimitData.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const TomCardAllocation = require('../models/TomCardAllocation');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

const SOURCES = [
  {
    cycle_key: '2025-12',
    file: 'Jan2026_Budget.xlsx',
    sheet: 'Card Limit',
    budgetLColumn: 'Diesel Budget -December 2025 (L)',
    budgetXafColumn: 'Budget Amount- December 2025 XAF',
    newLimitColumn: 'New limit on 26/12/2025',
    newLimitDate: new Date(2025, 11, 26),
  },
  {
    cycle_key: '2026-02',
    file: 'CardLimit_Feb2026.xlsx',
    sheet: 'Card Limit',
    headerRow: 2, // genuinely different from every other Card Limit source — verified directly
    budgetLColumn: 'Diesel Budget -February 2026 (L)',
    budgetXafColumn: 'Diesel Budget Amount- February 2026 XAF',
    newLimitColumn: 'New limit on 26/01/2026',
    newLimitDate: new Date(2026, 0, 26),
  },
  {
    cycle_key: '2026-03',
    file: 'CardLimit_Mar2026.xlsx',
    sheet: 'Card Limit',
    headerRow: 1, // genuinely different from Dec/Jul/Aug (row 0) — verified directly
    budgetLColumn: 'Diesel Budget -March 2026 (L)',
    budgetXafColumn: 'Diesel Budget Amount- March 2026 XAF',
    newLimitColumn: 'New limit on 26/02/2026',
    newLimitDate: new Date(2026, 1, 26),
  },
  {
    cycle_key: '2026-04',
    file: 'CardLimit_Apr2026.xlsx',
    sheet: 'Limit',
    headerRow: 3, // genuinely different from every other Card Limit source — verified directly
    budgetLColumn: 'Diesel Budget -April 2026 (L)',
    budgetXafColumn: ' Diesel Budget Amount- April 2026 (XAF)',
    newLimitColumn: 'New limit on 26/04/2026',
    newLimitDate: new Date(2026, 3, 26),
    strategicTankColumn: 'Strategic Tank Usage',
  },
  {
    cycle_key: '2026-06',
    // Phase 102: replaced with a later, richer snapshot of the exact
    // same running Card Limit tracker — verified the base numbers
    // (budget, recharge %, actual limit) are identical between the two
    // files before switching, not just assumed compatible. The
    // original file is kept in the archive for provenance (same
    // precedent as Jan2026_Budget.xlsx) but is no longer the active
    // source — this one is a strict superset, extended further into
    // June's cycle to record three extra-fuel rounds' cluster-level
    // approvals, genuinely absent from the earlier snapshot.
    file: 'CardLimit_Jun2026_ExtraRounds.xlsx',
    sheet: 'Total',
    headerRow: 0, // this snapshot has no separate summary row above the header — verified directly, differs from the original file's row 1
    budgetLColumn: 'Diesel Budget -June 2026 (L)',
    budgetXafColumn: 'Diesel Budget Amount- June 2026 (XAF)',
    // Same stale copy-paste header as the original file — see the
    // comment on the December/July/August entries above. Kept for the
    // same reason: the column's position and values are genuinely
    // June's even though its own header text says otherwise.
    newLimitColumn: 'New limit on 26/04/2026',
    newLimitDate: null,
    // Absent from this snapshot (present, always null, in the original
    // — not a real loss).
    strategicTankColumn: null,
    extraRoundsColumns: {
      round1: { approved: '1st Extra Fuel 08 june Approved', amount: '1st Extra Amount', newLimit: '11 June New Limit' },
      round2: { approved: '2nd Extra Fuel 08 june Approved', amount: '2nd Extra Amount', newLimit: '12 june New Limit' },
      round3: { approved: '3rd Extra Fuel 08 june Approved', amount: '3rd Extra Amount', newLimit: '17 june New Limit' },
      comment: '04th June Comment',
    },
    // Genuine gap in this new snapshot's "Total" sheet: Pouma 2/TRADEX
    // isn't in it at all — it's tracked in a separate "Tradex" sheet in
    // this file, with a much sparser structure (no budget or actual-
    // limit fields, only its extra-fuel figure). Rather than silently
    // lose the base data this cluster already had, or fabricate it,
    // this pulls Pouma 2's full base record from the *original* file
    // (verified unchanged — see the file-replacement comment above)
    // and layers the new file's extra-fuel figure on top of it.
    tradexSupplement: {
      baseFile: 'CardLimit_Jun2026.xlsx',
      baseSheet: 'Card Limit Update June-26',
      baseHeaderRow: 1,
      extraFile: 'CardLimit_Jun2026_ExtraRounds.xlsx',
      extraSheet: 'Tradex',
    },
  },
  {
    cycle_key: '2026-07',
    file: 'CardLimit_Jul2026.xlsx',
    sheet: 'Sheet2',
    budgetLColumn: 'Diesel Budget -July 2026 (L)',
    budgetXafColumn: ' Diesel Budget Amount- July 2026 (XAF)', // leading space in the source header itself, kept as-is
    newLimitColumn: 'New limit on 26/06/2026',
    newLimitDate: new Date(2026, 5, 26),
    strategicTankColumn: 'Strategic Tank Usage', // not present in the December source
  },
  {
    cycle_key: '2026-08',
    file: 'CardLimit_Aug2026.xlsx',
    sheet: 'Sheet1',
    budgetLColumn: 'Diesel Budget -August 2026 (L)', // source header has a leading \r\n, stripped by findCol's own trim()
    budgetXafColumn: 'Diesel Budget Amount- August 2026 XAF', // same — leading \r\n in the source, trimmed on lookup
    newLimitColumn: 'New limit on 26/07/2026',
    newLimitDate: new Date(2026, 6, 26),
    strategicTankColumn: 'Strategic Tank Usage',
    newCardNumberColumn: 'New Card Number', // a genuine addition in this month's file — a card reissue, not present in Dec/Jul
  },
];

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function normalizeHeader(s) {
  return String(s).replace(/\s+/g, ' ').trim();
}

function findCol(header, name) {
  const target = normalizeHeader(name);
  const i = header.findIndex(h => typeof h === 'string' && normalizeHeader(h) === target);
  return i === -1 ? null : i;
}

function parseTradexSupplement(cfg, cycle_key, sourceFileForRecord) {
  const baseWb = XLSX.readFile(path.join(DATA_DIR, cfg.baseFile));
  const baseRows = XLSX.utils.sheet_to_json(baseWb.Sheets[cfg.baseSheet], { header: 1, defval: null, raw: true });
  const baseHeader = baseRows[cfg.baseHeaderRow];
  const bIdx = {
    cluster: findCol(baseHeader, 'Cluster'),
    vendor: findCol(baseHeader, 'Vendor'),
    card: findCol(baseHeader, 'Card Number'),
    budget_l: findCol(baseHeader, `Diesel Budget -${cycle_key === '2026-06' ? 'June 2026' : ''} (L)`) ?? findCol(baseHeader, 'Diesel Budget -June 2026 (L)'),
    budget_xaf: findCol(baseHeader, 'Diesel Budget Amount- June 2026 (XAF)'),
    actual_limit: findCol(baseHeader, 'Actual Card Limit'),
  };
  const baseRow = baseRows.slice(cfg.baseHeaderRow + 1).find(r => r && bIdx.vendor !== null && String(r[bIdx.vendor]).trim().toUpperCase() === 'TRADEX');
  if (!baseRow) throw new Error(`${cfg.baseFile}: no TRADEX row found for the Pouma 2 supplement.`);
  const rechargePctIdx = bIdx.budget_xaf + 1;
  const rechargeAmountIdx = bIdx.budget_xaf + 2;

  const extraWb = XLSX.readFile(path.join(DATA_DIR, cfg.extraFile));
  const extraRows = XLSX.utils.sheet_to_json(extraWb.Sheets[cfg.extraSheet], { header: 1, defval: null, raw: true });
  const extraHeader = extraRows[0];
  const eIdx = {
    extra_l: findCol(extraHeader, 'EXTRA'),
    extra_xaf: findCol(extraHeader, 'AMOUNT IN XAF'),
    card: findCol(extraHeader, 'CARD NUMBER'),
  };
  const extraRow = extraRows.slice(1).find(r => r && r[0]);
  if (!extraRow) throw new Error(`${cfg.extraFile} (${cfg.extraSheet}): no data row found for the Pouma 2 supplement.`);

  return {
    cluster: String(baseRow[bIdx.cluster]).trim(),
    funded_cycle_key: cycle_key,
    vendor: baseRow[bIdx.vendor] ?? null,
    card_number: baseRow[bIdx.card] != null ? String(baseRow[bIdx.card]) : null,
    new_card_number: null,
    budget_l: toNum(baseRow[bIdx.budget_l]),
    budget_xaf: toNum(baseRow[bIdx.budget_xaf]),
    initial_recharge_pct: toNum(baseRow[rechargePctIdx]),
    initial_recharge_amount_xaf: toNum(baseRow[rechargeAmountIdx]),
    actual_card_limit_xaf: toNum(baseRow[bIdx.actual_limit]),
    new_limit_xaf: null,
    new_limit_date: null,
    // This cluster's extra-fuel figure isn't broken into 1st/2nd/3rd
    // rounds like the TOTAL-vendor clusters — the Tradex sheet reports
    // one combined total for the cycle. Stored under round1 as the
    // best-fit single field rather than invent a 3-way split the
    // source doesn't provide.
    extra_round1_approved_l: toNum(extraRow[eIdx.extra_l]),
    extra_round1_approved_xaf: toNum(extraRow[eIdx.extra_xaf]),
    extra_round1_new_limit_xaf: null,
    extra_rounds_comment: 'Combined extra-fuel total for the cycle, not split by round — this cluster is tracked on a separate sheet with a different structure than the TOTAL-vendor clusters.',
    source_file: sourceFileForRecord,
  };
}

function parseSource(src) {
  const filePath = path.join(DATA_DIR, src.file);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[src.sheet], { header: 1, defval: null, raw: true });
  const headerRowIdx = src.headerRow ?? 0; // most sources have header at row 0, verified individually; April's genuinely differs
  const header = rows[headerRowIdx];

  const idx = {
    cluster: findCol(header, 'Cluster'),
    vendor: findCol(header, 'Vendor'),
    card: findCol(header, 'Card Number'),
    budget_l: findCol(header, src.budgetLColumn),
    budget_xaf: findCol(header, src.budgetXafColumn),
    actual_limit: findCol(header, 'Actual Card Limit'),
    new_limit: findCol(header, src.newLimitColumn),
    strategic_tank: src.strategicTankColumn ? findCol(header, src.strategicTankColumn) : null,
    new_card: src.newCardNumberColumn ? findCol(header, src.newCardNumberColumn) : null,
  };
  const rechargePctIdx = idx.budget_xaf + 1;
  const rechargeAmountIdx = idx.budget_xaf + 2;

  const extraIdx = {};
  if (src.extraRoundsColumns) {
    for (const round of ['round1', 'round2', 'round3']) {
      const cfg = src.extraRoundsColumns[round];
      extraIdx[round] = {
        approved: findCol(header, cfg.approved),
        amount: findCol(header, cfg.amount),
        newLimit: findCol(header, cfg.newLimit),
      };
    }
    extraIdx.comment = findCol(header, src.extraRoundsColumns.comment);
  }

  const required = ['cluster', 'vendor', 'card', 'budget_l', 'budget_xaf', 'actual_limit', 'new_limit'];
  const missing = required.filter(k => idx[k] === null);
  if (missing.length) {
    throw new Error(`${src.file} (${src.sheet}) missing expected column(s): ${missing.join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(headerRowIdx + 1)) {
    if (!row || !row[idx.cluster]) continue;
    records.push({
      cluster: String(row[idx.cluster]).trim(),
      funded_cycle_key: src.cycle_key,
      vendor: row[idx.vendor] ?? null,
      card_number: row[idx.card] != null ? String(row[idx.card]) : null,
      new_card_number: idx.new_card !== null && row[idx.new_card] != null ? String(row[idx.new_card]) : null,
      budget_l: toNum(row[idx.budget_l]),
      budget_xaf: toNum(row[idx.budget_xaf]),
      initial_recharge_pct: toNum(row[rechargePctIdx]),
      initial_recharge_amount_xaf: toNum(row[rechargeAmountIdx]),
      actual_card_limit_xaf: toNum(row[idx.actual_limit]),
      new_limit_xaf: toNum(row[idx.new_limit]),
      new_limit_date: src.newLimitDate,
      ...(src.extraRoundsColumns ? {
        extra_round1_approved_l: toNum(row[extraIdx.round1.approved]),
        extra_round1_approved_xaf: toNum(row[extraIdx.round1.amount]),
        extra_round1_new_limit_xaf: toNum(row[extraIdx.round1.newLimit]),
        extra_round2_approved_l: toNum(row[extraIdx.round2.approved]),
        extra_round2_approved_xaf: toNum(row[extraIdx.round2.amount]),
        extra_round2_new_limit_xaf: toNum(row[extraIdx.round2.newLimit]),
        extra_round3_approved_l: toNum(row[extraIdx.round3.approved]),
        extra_round3_approved_xaf: toNum(row[extraIdx.round3.amount]),
        extra_round3_new_limit_xaf: toNum(row[extraIdx.round3.newLimit]),
        extra_rounds_comment: extraIdx.comment !== null ? (row[extraIdx.comment] ?? null) : null,
      } : {}),
      source_file: src.file,
    });
  }
  if (src.tradexSupplement) {
    records.push(parseTradexSupplement(src.tradexSupplement, src.cycle_key, src.file));
  }
  return records;
}

async function main() {
  const allRecords = [];
  for (const src of SOURCES) {
    const records = parseSource(src);
    const totalBudget = records.reduce((s, r) => s + (r.budget_l || 0), 0);
    const totalNewLimit = records.reduce((s, r) => s + (r.new_limit_xaf || 0), 0);
    console.log(`── ${src.cycle_key} (${src.file}): ${records.length} cluster(s). Budget: ${Math.round(totalBudget).toLocaleString()} L. New card limit set: ${Math.round(totalNewLimit).toLocaleString()} XAF.`);
    allRecords.push(...records);
  }

  console.log(`\n── Total: ${allRecords.length} record(s) across ${SOURCES.length} cycle(s). ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = allRecords.map(r => ({
    updateOne: {
      filter: { cluster: r.cluster, funded_cycle_key: r.funded_cycle_key },
      update: { $set: r },
      upsert: true,
    },
  }));
  const result = await TomCardAllocation.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
