/**
 * importBudgetRequestApproval.js
 * diesel-system/scripts/importBudgetRequestApproval.js
 *
 * Imports the site-level budget request/approval exchange between Grato
 * and IHS Towers — "SBC Request" (what Grato asked for) vs. the
 * approved figure (what IHS Towers actually granted), submitted by
 * email directly, not through this system. See
 * models/BudgetRequestApproval.js for the full reasoning on why this is
 * a distinct concept from every other historical model recovered so far.
 *
 * WHY NAME-BASED COLUMN LOOKUP FOR THE MONTH-SPECIFIC COLUMNS:
 * The approved/RH/days columns are literally named with the month
 * baked in ("July-26 Diesel Budget - approved", "RH July-26") — a
 * different recovered month's file would have differently-named
 * columns, not just different values. Building the column list by
 * partial name match (ends with "Diesel Budget - approved", starts
 * with "RH ", etc.) rather than an exact hardcoded string makes this
 * reusable for a future month's file without editing the parser itself.
 *
 * CROSS-CHECKED BEFORE TRUSTING: this file's July "approved" column was
 * compared against the already-verified multi-month rollup's own July
 * budget column (Phase 59) before building anything on top of it —
 * 95.1% exact match across all 164 common sites, strong independent
 * confirmation of both sources. The remaining ~5% differ by a flat
 * 500-1000L for a handful of specific sites, consistent with a later,
 * targeted top-up rather than a parsing error — noted, not silently
 * resolved either way.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/importBudgetRequestApproval.js
 *   node scripts/importBudgetRequestApproval.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const BudgetRequestApproval = require('../models/BudgetRequestApproval');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'BudgetRequestApproval_Jul2026.xlsx';
const CYCLE_KEY = '2026-07'; // confirmed from the file's own column names ("July-26 ...")

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function findCol(header, matcher) {
  const i = header.findIndex(h => typeof h === 'string' && matcher(h.trim()));
  return i === -1 ? null : i;
}

function findColExact(header, name) {
  const i = header.findIndex(h => typeof h === 'string' && h.trim() === name.trim());
  return i === -1 ? null : i;
}

// August's file is structurally different from July's — no "SBC
// Request" column at all, just a single "August-26 DIESEL BUDGET (L)"
// figure per site (the filename itself says "Estimated," not
// "Request/Approval"). Rather than force this into the same
// request-vs-approval shape July's file has, sbc_requested_l is left
// genuinely null here — there's no request side in this source
// document to report.
// Config-driven — each recovered month's "Estimated Budget" file has its
// own exact column names (case and RH-reference-month vary — June's RH
// column is "RH MAY -26", referencing the *prior* month as the basis
// for the estimate, not its own cycle month; verified individually
// rather than assumed to follow the same pattern as August).
const ESTIMATED_BUDGET_SOURCES = [
  {
    cycle_key: '2026-08',
    file: 'EstimatedBudget_Aug2026.xlsx',
    daysColumn: 'NUMBER OF DAYS August CYCLE',
    rhColumn: 'RH August -26',
    budgetColumn: 'August-26 DIESEL BUDGET (L)',
  },
  // Phase 170 — "GRATO Estimated Budget September 2026.xlsx" (received
  // 2026-08-18, "September Diesel Budget" thread), same exact shape as
  // August's file, column names verified directly against this file
  // (not assumed): 'NUMBER OF DAYS September CYCLE', 'RH September -26',
  // 'September-26 DIESEL BUDGET (L)' — note the sheet ALSO has a
  // 'September-26 DIESEL BUDGET - New CPH' column, a different figure,
  // deliberately not used here (budgetColumn matches August's exact
  // "-26 DIESEL BUDGET (L)" suffix pattern, not the New-CPH variant).
  {
    cycle_key: '2026-09',
    file: 'EstimatedBudget_Sep2026.xlsx',
    daysColumn: 'NUMBER OF DAYS September CYCLE',
    rhColumn: 'RH September -26',
    budgetColumn: 'September-26 DIESEL BUDGET (L)',
  },
];

function parseEstimatedBudgetFile(src) {
  const filePath = path.join(DATA_DIR, src.file);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Budget'], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findColExact(header, 'NEW IHS ID'),
    site_name: findColExact(header, 'SITE NAME'),
    cluster: findColExact(header, 'CLUSTER'),
    region: findColExact(header, 'STATE/REGION'),
    topology: findColExact(header, 'UPDATED TOPOLOGY'),
    genset_cph: findColExact(header, 'GENSET CPH'),
    days: findColExact(header, src.daysColumn),
    rh: findColExact(header, src.rhColumn),
    grid_avail: findColExact(header, 'GRID AVAIL'),
    fueling_site: findColExact(header, 'FUELING SITES (Yes/No)'),
    budget_l: findColExact(header, src.budgetColumn),
  };

  const missing = Object.entries(idx).filter(([, v]) => v === null);
  if (missing.length) {
    throw new Error(`${src.file} missing expected column(s): ${missing.map(([k]) => k).join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      cycle_key: src.cycle_key,
      days_in_cycle: toNum(row[idx.days]),
      sbc_requested_l: null, // genuinely absent from this source type — not a parsing gap
      ihs_approved_l: toNum(row[idx.budget_l]),
      variance_l: null,
      genset_cph: toNum(row[idx.genset_cph]),
      final_grid_availability: toNum(row[idx.grid_avail]),
      run_hours: toNum(row[idx.rh]),
      fueling_site: row[idx.fueling_site] === 'Yes',
      comments: null,
      source_file: src.file,
    });
  }
  return records;
}

// June — a genuine correction, not just a new addition. The earlier
// single-figure "EstimatedBudget_Jun2026.xlsx" import (now removed)
// was mislabeled: cross-checked its "JUNE-26 DIESEL BUDGET (L)" figure
// against this file's own two columns before trusting either — it
// matched "Submitted" (the requested figure) exactly for 158 of 164
// sites, and "Final June-26 Budget given to the SBCs (L)" (the real
// approved figure) for zero. What was previously stored as
// ihs_approved_l for June was actually the requested figure all along.
function parseJuneRequestApproval() {
  const fileName = 'RequestApproval_Jun2026.xlsx';
  const filePath = path.join(DATA_DIR, fileName);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Matrix Budget June-26'], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findColExact(header, 'NEW IHS ID'),
    site_name: findColExact(header, 'Site Name'),
    cluster: findColExact(header, 'Cluster'),
    region: findColExact(header, 'State'),
    topology: findColExact(header, 'June-26 Update Topology'),
    submitted: findColExact(header, 'Submitted'),
    approved: findColExact(header, 'Final June-26 Budget given to the SBCs (L)'),
    variance: findColExact(header, 'Variance'),
    grid_avail: findColExact(header, 'MTD Grid Availibity'),
    rh: findColExact(header, 'RH Per Day'),
    comments: findColExact(header, 'Comment 2'),
  };

  const missing = Object.entries(idx).filter(([k, v]) => v === null && k !== 'comments');
  if (missing.length) {
    throw new Error(`${fileName} missing expected column(s): ${missing.map(([k]) => k).join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const sbc_requested_l = toNum(row[idx.submitted]);
    const ihs_approved_l = toNum(row[idx.approved]);
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      cycle_key: '2026-06',
      days_in_cycle: null,
      sbc_requested_l,
      ihs_approved_l,
      variance_l: toNum(row[idx.variance]) ?? ((sbc_requested_l != null && ihs_approved_l != null)
        ? Math.round((ihs_approved_l - sbc_requested_l) * 10) / 10 : null),
      genset_cph: null,
      final_grid_availability: toNum(row[idx.grid_avail]),
      run_hours: toNum(row[idx.rh]),
      fueling_site: null,
      comments: idx.comments !== null ? (row[idx.comments] || null) : null,
      source_file: fileName,
    });
  }
  return records;
}

async function main() {
  const filePath = path.join(DATA_DIR, SOURCE_FILE);
  const wb = XLSX.readFile(filePath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Sheet1'], { header: 1, defval: null, raw: true });
  const header = rows[1];

  const idx = {
    site_id: findCol(header, h => h === 'NEW IHS ID'),
    site_name: findCol(header, h => h === 'Site Name'),
    cluster: findCol(header, h => h === 'Cluster'),
    region: findCol(header, h => h === 'State'),
    topology: findCol(header, h => h.endsWith('Update Topology')),
    genset_cph: findCol(header, h => h === 'Genset CPH'),
    days: findCol(header, h => h.startsWith('Days in')),
    rh: findCol(header, h => h.startsWith('RH ')),
    grid_avail: findCol(header, h => h === 'Final Grid Availability'),
    fueling_site: findCol(header, h => h === 'Fueling Sites (Yes/No)'),
    approved: findCol(header, h => h.includes('Diesel Budget - approved')),
    sbc_request: findCol(header, h => h === 'SBC Request'),
    comments: findCol(header, h => h === 'COMMENTS'),
  };

  const missing = Object.entries(idx).filter(([k, v]) => v === null && k !== 'comments');
  if (missing.length) {
    throw new Error(`Missing expected column(s): ${missing.map(([k]) => k).join(', ')}. Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (const row of rows.slice(2)) {
    if (!row || !row[idx.site_id]) continue;
    const sbc_requested_l = toNum(row[idx.sbc_request]);
    const ihs_approved_l = toNum(row[idx.approved]);
    records.push({
      site_id: String(row[idx.site_id]).trim(),
      site_name: row[idx.site_name] ?? null,
      cluster: row[idx.cluster] ?? null,
      region: row[idx.region] ?? null,
      topology: row[idx.topology] ?? null,
      cycle_key: CYCLE_KEY,
      days_in_cycle: toNum(row[idx.days]),
      sbc_requested_l,
      ihs_approved_l,
      variance_l: (sbc_requested_l != null && ihs_approved_l != null)
        ? Math.round((ihs_approved_l - sbc_requested_l) * 10) / 10 : null,
      genset_cph: toNum(row[idx.genset_cph]),
      final_grid_availability: toNum(row[idx.grid_avail]),
      run_hours: toNum(row[idx.rh]),
      fueling_site: row[idx.fueling_site] === 'Yes',
      comments: idx.comments !== null ? (row[idx.comments] || null) : null,
      source_file: SOURCE_FILE,
    });
  }

  console.log(`Parsed ${records.length} site record(s) for cycle ${CYCLE_KEY}.`);
  const withBoth = records.filter(r => r.sbc_requested_l != null && r.ihs_approved_l != null);
  const approvedLess = withBoth.filter(r => r.variance_l < 0);
  const approvedMore = withBoth.filter(r => r.variance_l > 0);
  const totalRequested = withBoth.reduce((s, r) => s + r.sbc_requested_l, 0);
  const totalApproved = withBoth.reduce((s, r) => s + r.ihs_approved_l, 0);
  console.log(`  ${withBoth.length} site(s) with both figures. Total requested: ${Math.round(totalRequested).toLocaleString()} L, total approved: ${Math.round(totalApproved).toLocaleString()} L.`);
  console.log(`  ${approvedLess.length} site(s) approved for less than requested, ${approvedMore.length} approved for more.`);
  const withComments = records.filter(r => r.comments);
  console.log(`  ${withComments.length} site(s) carry a real justification comment.`);

  const juneRecords = parseJuneRequestApproval();
  const juneWithBoth = juneRecords.filter(r => r.sbc_requested_l != null && r.ihs_approved_l != null);
  const juneReq = juneWithBoth.reduce((s, r) => s + r.sbc_requested_l, 0);
  const juneApp = juneWithBoth.reduce((s, r) => s + r.ihs_approved_l, 0);
  console.log(`\n── 2026-06 (RequestApproval_Jun2026.xlsx): ${juneRecords.length} site(s). Total requested: ${Math.round(juneReq).toLocaleString()} L, total approved: ${Math.round(juneApp).toLocaleString()} L.`);

  const estimatedRecords = [];
  for (const src of ESTIMATED_BUDGET_SOURCES) {
    const recs = parseEstimatedBudgetFile(src);
    const total = recs.reduce((s, r) => s + (r.ihs_approved_l || 0), 0);
    console.log(`\n── ${src.cycle_key} (${src.file}): ${recs.length} site(s). Total budget: ${Math.round(total).toLocaleString()} L. No "requested" figure in this source — sbc_requested_l is genuinely null for every record.`);
    estimatedRecords.push(...recs);
  }

  const allRecords = [...records, ...juneRecords, ...estimatedRecords];

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allRecords.length} record(s) to the database.`);
    return;
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('\n✓ Connected to MongoDB');

  const ops = allRecords.map(r => ({
    updateOne: {
      filter: { site_id: r.site_id, cycle_key: r.cycle_key },
      update: { $set: r },
      upsert: true,
    },
  }));
  const result = await BudgetRequestApproval.bulkWrite(ops, { ordered: false });
  console.log(`✓ Upserted ${result.upsertedCount}, modified ${result.modifiedCount}.`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
