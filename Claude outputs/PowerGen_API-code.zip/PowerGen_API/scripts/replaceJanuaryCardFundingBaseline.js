/**
 * replaceJanuaryCardFundingBaseline.js
 * diesel-system/scripts/replaceJanuaryCardFundingBaseline.js
 *
 * WHY THIS EXISTS (Phase 163):
 * `TomCard_Allocation_Dec2025.pdf` has been the sole base-allocation
 * source for January's TomCardAllocation since it was first imported —
 * but the user has repeatedly and explicitly said that document is not
 * to be relied on, and to use the budget file they supplied instead
 * (`GRATO_Jan26_Budget_approved.xlsx` / `Jan2026_Budget.xlsx` — same
 * "Card Limit" data, already in the archive with full float precision).
 *
 * This script replaces the base `quantity_l` / `amount_xaf` on every
 * January TomCardAllocation document with that sheet's own
 * "Diesel Budget -December 2025 (L)" / "Budget Amount- December 2025
 * XAF" columns — the per-cluster diesel entitlement that funds each
 * card, as opposed to the PDF's much smaller incremental top-up
 * figures. Card numbers are NOT touched here (Phase 161 already fixed
 * those from an independent source and this sheet's numbers agree with
 * it exactly).
 *
 * SECOND FIX, same source, same run: Pouma 2. Row 7 of this exact
 * sheet — missed in every earlier pass — reads:
 *   Pouma 2 | TRADEX | card 5807 | 15,286.38 L | 12,947,562 XAF
 * "5807" is the previously unidentified card with 40 real January
 * purchase transactions (the most active card that month, see Phase
 * 161). No TomCardAllocation document exists for Pouma 2 / 2026-01 at
 * all (the PDF's TOTALENERGIES table has no Pouma 2 row because Pouma 2
 * runs on TRADEX, a different vendor entirely — consistent with the
 * PDF's own TRADEX line item, not a gap). This script creates that
 * missing document.
 *
 * Note this exact "Card Limit" sheet is already imported into
 * TomCardAllocation once before — but tagged `funded_cycle_key:
 * '2025-12'` by `importCardLimitData.js`, matching its own December-
 * labeled column headers. That December-tagged document is untouched
 * by this script; this writes a SEPARATE January-tagged record, since
 * the frontend's January views filter on `funded_cycle_key: '2026-01'`
 * and never see the December one.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed.
 *
 * Usage:
 *   node scripts/replaceJanuaryCardFundingBaseline.js
 *   node scripts/replaceJanuaryCardFundingBaseline.js --confirm
 */
'use strict';
require('dotenv').config();
const path = require('path');
const XLSX = require('xlsx');
const mongoose = require('mongoose');
const TomCardAllocation = require('../models/TomCardAllocation');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const SOURCE_FILE = 'Jan2026_Budget.xlsx';
const SHEET_NAME = 'Card Limit';
const CYCLE_KEY = '2026-01';

// Confirmed card numbers (Phase 161) — used only as a safety cross-check
// before overwriting an existing document, never re-derived here.
const CONFIRMED_CARD_NUMBERS = {
  'Bonaberi 1': '84948',
  'Bonaberi 2': '84950',
  'Edea': '84953',
  'Kotto': '121720',
  'Ndogbong': '84946',
  'Pouma 1': '84951',
};

async function main() {
  const wb = XLSX.readFile(path.join(DATA_DIR, SOURCE_FILE));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[SHEET_NAME], { header: 1, defval: null, raw: true });
  const header = rows[0];
  const idx = {
    cluster: header.indexOf('Cluster'),
    vendor: header.indexOf('Vendor'),
    cardNumber: header.indexOf('Card Number'),
    budgetL: header.indexOf('Diesel Budget -December 2025 (L)'),
    budgetXaf: header.indexOf('Budget Amount- December 2025 XAF'),
  };
  if (Object.values(idx).some(i => i === -1)) {
    throw new Error(`Expected columns not found in "${SHEET_NAME}". Header: ${JSON.stringify(header)}`);
  }

  const records = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r || !r[idx.cluster]) continue;
    records.push({
      cluster: r[idx.cluster],
      vendor: r[idx.vendor],
      card_number: r[idx.cardNumber] != null ? String(r[idx.cardNumber]) : null,
      quantity_l: r[idx.budgetL],
      amount_xaf: r[idx.budgetXaf],
    });
  }

  console.log(`── Parsed ${records.length} cluster row(s) from "${SHEET_NAME}" (${SOURCE_FILE}) ──`);
  for (const rec of records) {
    console.log(`   ${rec.cluster} (${rec.vendor}, card ${rec.card_number}): ${rec.quantity_l.toFixed(2)} L / ${Math.round(rec.amount_xaf).toLocaleString()} XAF`);
  }

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('\n✓ Connected to MongoDB\n');

  const existing = await TomCardAllocation.find({ funded_cycle_key: CYCLE_KEY }).lean();
  const updateOps = [];
  const createOps = [];

  for (const rec of records) {
    const doc = existing.find(d => d.cluster === rec.cluster);
    const expectedCard = CONFIRMED_CARD_NUMBERS[rec.cluster]; // undefined for Pouma 2 — no prior confirmation needed, this IS the confirmation

    if (!doc) {
      // No existing January document — create one (this is the Pouma 2 case).
      console.log(`  + ${rec.cluster}: no existing ${CYCLE_KEY} document — will CREATE.`);
      createOps.push({
        insertOne: {
          document: {
            cluster: rec.cluster,
            funded_cycle_key: CYCLE_KEY,
            vendor: rec.vendor,
            card_number: rec.card_number,
            quantity_l: rec.quantity_l,
            amount_xaf: rec.amount_xaf,
            source_file: `${SOURCE_FILE} ("${SHEET_NAME}" sheet)`,
          },
        },
      });
      continue;
    }

    if (expectedCard && doc.card_number !== expectedCard) {
      console.log(`  ⚠ ${rec.cluster}: stored card_number (${doc.card_number}) doesn't match Phase 161's confirmed mapping (${expectedCard}) — skipped rather than risk writing the wrong cluster's funding.`);
      continue;
    }

    console.log(`  ~ ${rec.cluster}: base ${doc.quantity_l ?? '(null)'} L / ${doc.amount_xaf ?? '(null)'} XAF -> ${rec.quantity_l.toFixed(2)} L / ${Math.round(rec.amount_xaf).toLocaleString()} XAF`);
    updateOps.push({
      updateOne: {
        filter: { _id: doc._id },
        update: {
          $set: {
            quantity_l: rec.quantity_l,
            amount_xaf: rec.amount_xaf,
            vendor: rec.vendor,
            source_file: `${SOURCE_FILE} ("${SHEET_NAME}" sheet) — replaces TomCard_Allocation_Dec2025.pdf per user direction (Phase 163)`,
          },
        },
      },
    });
  }

  const ops = [...updateOps, ...createOps];
  console.log(`\n${updateOps.length} document(s) would be updated, ${createOps.length} would be created.`);
  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. Re-run with --confirm to apply. ──');
    await mongoose.disconnect();
    return;
  }
  if (!ops.length) { console.log('Nothing to write.'); await mongoose.disconnect(); return; }

  const result = await TomCardAllocation.bulkWrite(ops, { ordered: false });
  console.log(`✓ Modified ${result.modifiedCount}, inserted ${result.insertedCount}.`);
  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
