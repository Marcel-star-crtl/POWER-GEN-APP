/**
 * backfillTankAuditReconciliation.js
 * diesel-system/scripts/backfillTankAuditReconciliation.js
 *
 * Phase 116. Catches TWO distinct groups of submitted audits that
 * never got the pre-save hook's full reconciliation treatment:
 *
 *   1. Never resolved at all — no cycle_key, from before Phase 106
 *      shipped. (Phase 111's original scope.)
 *
 *   2. Resolved once, but BEFORE Phase 115 added opening_meter_hours,
 *      closing_meter_hours, and total_refueled_source — these audits
 *      already have a cycle_key, which the pre-save hook treats as
 *      "already resolved" and skips re-processing entirely. Left
 *      alone, these audits permanently show no Consumption, no True
 *      CPH, and no Gain/Loss, even after Phase 115's data backfill
 *      populated the underlying CycleReconciliation/CycleEndStockSnapshot
 *      records they'd need to read from.
 *
 * Group 2 is handled by clearing cycle_key before re-saving — the only
 * way to make the pre-save hook treat the document as unresolved again
 * and actually re-run its full logic against the now-richer source data.
 * This does not touch dip_reading_l, audit_run_hours_reading, or any
 * other real, technician-entered field — only the fields the hook
 * itself owns and recomputes every time it runs.
 *
 * Safe to re-run: on a second pass, every audit already has all the
 * Phase 115 fields, so the query in Group 2 naturally returns nothing
 * further to do.
 *
 * Usage:
 *   node scripts/backfillTankAuditReconciliation.js           (dry run)
 *   node scripts/backfillTankAuditReconciliation.js --confirm (writes)
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const CONFIRM = process.argv.includes('--confirm');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const TankAudit = require('../models/TankAudit');

  const neverResolved = await TankAudit.find({
    status: 'submitted',
    $or: [{ cycle_key: { $exists: false } }, { cycle_key: null }],
  });

  const resolvedButStale = await TankAudit.find({
    status: 'submitted',
    cycle_key: { $exists: true, $ne: null },
    $or: [
      { opening_meter_hours: { $exists: false } },
      { closing_meter_hours: { $exists: false } },
      { total_refueled_source: { $exists: false } },
    ],
  });

  console.log(`Group 1 — never resolved at all: ${neverResolved.length}`);
  console.log(`Group 2 — resolved before Phase 115, missing the newer fields: ${resolvedButStale.length}`);

  const total = neverResolved.length + resolvedButStale.length;
  if (!total) {
    console.log('\nNothing to do — every submitted audit already has the full Phase 115 field set.');
    await mongoose.disconnect();
    return;
  }

  const preview = [...neverResolved, ...resolvedButStale].slice(0, 10);
  console.log('\nFirst few affected (site — audit date):');
  for (const a of preview) {
    console.log(`  ${a.site_id_ihs || '(no site)'} — ${a.audit_date ? a.audit_date.toISOString().slice(0, 10) : '(no audit_date — cannot resolve a cycle for this one)'}`);
  }
  if (total > preview.length) console.log(`  ...and ${total - preview.length} more.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log('Re-run with --confirm to actually re-save these and compute their reconciliation fields.');
    await mongoose.disconnect();
    return;
  }

  console.log('\n── Re-saving each document (triggers the same pre-save hook new audits use) ──');
  let resolved = 0, stillUnresolved = 0, errored = 0;

  for (const audit of neverResolved) {
    try {
      await audit.save();
      if (audit.cycle_key) resolved++;
      else stillUnresolved++; // genuinely no matching DieselCycle for this audit_date — not a bug, a real gap
    } catch (err) {
      errored++;
      console.error(`  ✗ ${audit._id} (${audit.site_id_ihs}): ${err.message}`);
    }
  }

  for (const audit of resolvedButStale) {
    try {
      // Force the pre-save hook to treat this as unresolved again —
      // it only re-runs its resolution logic when cycle_key is unset.
      // Every field it recomputes gets overwritten with fresh values
      // from the now-richer source data; nothing the technician
      // actually entered (dip_reading_l, audit_run_hours_reading, the
      // physical checks, etc.) is touched by this.
      audit.cycle_key = undefined;
      await audit.save();
      if (audit.cycle_key) resolved++;
      else stillUnresolved++;
    } catch (err) {
      errored++;
      console.error(`  ✗ ${audit._id} (${audit.site_id_ihs}): ${err.message}`);
    }
  }

  console.log(`\n── Done. ──`);
  console.log(`  Resolved: ${resolved}`);
  console.log(`  Still unresolved (no matching DieselCycle for that audit_date — a real gap, not fixed by re-running this): ${stillUnresolved}`);
  console.log(`  Errored: ${errored}`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
