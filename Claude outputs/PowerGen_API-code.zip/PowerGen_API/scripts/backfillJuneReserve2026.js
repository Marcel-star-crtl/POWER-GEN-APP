/**
 * backfillJuneReserve2026.js
 * diesel-system/scripts/backfillJuneReserve2026.js
 *
 * Phase 150 — targeted fix for a real gap the user reported directly:
 * every site's Reserve (L) showed "—" for June 2026 on both the
 * Historical Data page's Complete Monthly Summary table and the History
 * Analysis page's Site Cycle Analysis tab.
 *
 * Root cause (verified before writing this, not assumed): June 2026 was
 * imported by `importHistoricalEmailData.js` with NO budget source at
 * all — `BUDGET_MONTH_LABELS['2026-06']` was deliberately left `null`,
 * because the only budget figure that script's multi-month rollup file
 * offers for June (147,014L) had already been checked and found to
 * disagree with two other verified numbers (61,410L in
 * BudgetRequestApproval; 113,121L in June's own Debit sheet — a
 * different concept entirely). Rather than guess which was right, the
 * earlier phase that made that call left `budget_liters` (and therefore
 * `reserve_liters`, which needs it) null for every June
 * HistoricalMonthlyRecord — correctly cautious at the time, but it left
 * June's Reserve column genuinely empty rather than wrong.
 *
 * What's changed: `importHistoricalEmailData.js` now sources June's
 * budget from `RequestApproval_Jun2026.xlsx`'s own "Matrix Budget
 * June-26" sheet ("Final June-26 Budget given to the SBCs (L)" column)
 * instead of the multi-month rollup — the SAME 61,410L figure already
 * cited as verified above (it's where `BudgetRequestApproval
 * .ihs_approved_l` for June comes from too), not a new or guessed
 * number. Verified directly against the real files before wiring it
 * in: all 164 of June's Validation-sheet sites have a matching row in
 * this file (see the long comment on `BUDGET_MONTH_LABELS['2026-06']`
 * in importHistoricalEmailData.js for the exact numbers).
 *
 * Re-running the full `importHistoricalEmailData.js --confirm` would
 * also pick up this fix (it upserts every month), but this script is
 * narrower and safer for a one-off correction: it touches only the 164
 * already-imported `HistoricalMonthlyRecord` docs with
 * `month_key: '2026-06'`, setting `budget_liters` / `budget_xaf` /
 * `budget_source_file` / `reserve_liters` / `fully_exhausted` on each,
 * and leaves every other field (and every other month) completely
 * untouched.
 *
 * SAFE BY DEFAULT: dry run unless --confirm is passed — same convention
 * as every other script in this folder. The dry run prints, per site,
 * the budget figure it would set and the resulting reserve, so the
 * numbers can be checked before anything is written.
 *
 * Usage:
 *   node scripts/backfillJuneReserve2026.js
 *   node scripts/backfillJuneReserve2026.js --confirm
 */
'use strict';

require('dotenv').config();
const path = require('path');
const mongoose = require('mongoose');
const XLSX = require('xlsx');

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');
const JUNE_BUDGET_FILE = 'RequestApproval_Jun2026.xlsx';

function toNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function parseJuneBudget() {
  const wb = XLSX.readFile(path.join(DATA_DIR, JUNE_BUDGET_FILE));
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Matrix Budget June-26'], { header: 1, defval: null, raw: true });
  const header = rows[1];
  const idIdx = header.indexOf('NEW IHS ID');
  const budgetIdx = header.indexOf('Final June-26 Budget given to the SBCs (L)');
  if (idIdx === -1 || budgetIdx === -1) {
    throw new Error(`${JUNE_BUDGET_FILE} "Matrix Budget June-26" is missing an expected column. Header: ${JSON.stringify(header)}`);
  }
  const budgetBySite = new Map();
  for (const row of rows.slice(2)) {
    if (!row || !row[idIdx]) continue;
    budgetBySite.set(String(row[idIdx]).trim(), toNum(row[budgetIdx]));
  }
  return budgetBySite;
}

async function main() {
  const budgetBySite = parseJuneBudget();
  console.log(`Read ${budgetBySite.size} site(s) with a budget figure from ${JUNE_BUDGET_FILE}.`);

  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB');

  const juneRecords = await HistoricalMonthlyRecord.find({ month_key: '2026-06' }).lean();
  console.log(`Found ${juneRecords.length} existing HistoricalMonthlyRecord doc(s) for 2026-06.\n`);

  const ops = [];
  let matched = 0, alreadyHadBudget = 0, noConsumption = 0, notFoundInFile = 0;
  for (const rec of juneRecords) {
    const budget_liters = budgetBySite.get(rec.site_id) ?? null;
    if (rec.budget_liters != null) alreadyHadBudget++;
    if (budget_liters == null) { notFoundInFile++; continue; }
    matched++;
    const reserve_liters = rec.final_consumption_l != null
      ? Math.round((budget_liters - rec.final_consumption_l) * 10) / 10
      : null;
    if (reserve_liters == null) noConsumption++;
    const fully_exhausted = reserve_liters != null ? reserve_liters <= 0 : null;

    console.log(`  ${rec.site_id} (${rec.site_name || 'unknown'}): budget ${budget_liters}L, consumed ${rec.final_consumption_l ?? '—'}L → reserve ${reserve_liters ?? '—'}L`);

    ops.push({
      updateOne: {
        filter: { _id: rec._id },
        update: { $set: { budget_liters, budget_xaf: null, budget_source_file: JUNE_BUDGET_FILE, reserve_liters, fully_exhausted } },
      },
    });
  }

  console.log(`\n── Summary ──`);
  console.log(`  ${matched} of ${juneRecords.length} record(s) matched a budget figure in ${JUNE_BUDGET_FILE}.`);
  console.log(`  ${alreadyHadBudget} record(s) already had a non-null budget_liters before this (should be 0 — June had none).`);
  console.log(`  ${noConsumption} matched record(s) still won't get a reserve figure — no final_consumption_l recovered for them.`);
  if (notFoundInFile > 0) console.log(`  ${notFoundInFile} record(s) have no matching row in ${JUNE_BUDGET_FILE} — left untouched.`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${ops.length} update(s) to the database.`);
    await mongoose.disconnect();
    return;
  }

  if (ops.length) {
    const result = await HistoricalMonthlyRecord.bulkWrite(ops, { ordered: false });
    console.log(`\n✓ Modified ${result.modifiedCount} document(s).`);
  } else {
    console.log('\nNothing to write.');
  }

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
