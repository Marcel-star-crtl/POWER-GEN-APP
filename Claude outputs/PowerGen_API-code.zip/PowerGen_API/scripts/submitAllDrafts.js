/**
 * submitAllDrafts.js
 * diesel-system/scripts/submitAllDrafts.js
 *
 * Phase 134. Changes every TankAudit currently in 'draft' status to
 * 'submitted'. This is a real, consequential change, not just a label
 * flip:
 *
 *   - feedBackToSite (the post-save hook) only runs for status ===
 *     'submitted' — a draft that's never triggered it will, for the
 *     first time, write its dip_reading_l back to the Site record's
 *     live fuel level, and its run-hours reading to the generator's
 *     last_running_hours, once this changes its status.
 *   - Every reconciliation dashboard, True CPH, and Gain/Loss figure
 *     only ever considers status: 'submitted' audits — these drafts
 *     will start counting toward all of that the moment this runs.
 *
 * Uses each document's own .save() method, not a bulk updateOne/
 * updateMany — this is deliberate: a raw update would silently bypass
 * every Mongoose hook (the pre-save reconciliation resolution, the
 * post-save Site feedback), leaving the status flipped but none of the
 * derived fields actually computed. Slower, but correct.
 *
 * Reports a completeness indicator for every draft in the dry run —
 * whether it has a dip reading, and how many of the plan's 7 physical
 * check areas were actually filled in — reusing the exact same
 * checkFields list the model itself uses internally for severity
 * computation, not a separately-invented one. This doesn't block
 * anything; it's here so an incomplete draft doesn't silently become
 * "submitted" (and start counting toward real financial figures)
 * without that being visible first.
 *
 * Backs up every draft's pre-change state before writing anything.
 *
 * Usage:
 *   node scripts/submitAllDrafts.js           (dry run)
 *   node scripts/submitAllDrafts.js --confirm (writes)
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const CONFIRM = process.argv.includes('--confirm');

const CHECK_FIELDS = [
  'check_tank_capacity_verification', 'check_fuel_level', 'check_structural_condition',
  'check_leakage', 'check_caps_locking_security', 'check_pipe_passage_earthing', 'check_sensor_hardware',
  'check_gen_cards_faulty',
];

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const TankAudit = require('../models/TankAudit');

  const drafts = await TankAudit.find({ status: 'draft' });
  console.log(`Drafts found: ${drafts.length}\n`);

  if (!drafts.length) {
    console.log('Nothing to do.');
    await mongoose.disconnect();
    return;
  }

  console.log('── Completeness check (informational — nothing is blocked by this) ──\n');
  let missingDip = 0, noChecksFilled = 0;
  for (const d of drafts) {
    const hasDip = d.dip_reading_l != null;
    const checksFilled = CHECK_FIELDS.filter(f => d[f]?.status != null).length;
    if (!hasDip) missingDip++;
    if (checksFilled === 0) noChecksFilled++;
    console.log(`  ${d.site_id_ihs || '(no site)'} — ${d.audit_date ? new Date(d.audit_date).toISOString().slice(0, 10) : '(no date)'} — dip: ${hasDip ? 'yes' : 'MISSING'} — checks filled: ${checksFilled}/${CHECK_FIELDS.length}`);
  }
  console.log(`\n${missingDip} of ${drafts.length} have no dip reading at all — these won't feed back to their Site's fuel level even after this runs (feedBackToSite requires a real dip_reading_l), but will still start counting toward reconciliation dashboards as "submitted."`);
  console.log(`${noChecksFilled} of ${drafts.length} have NONE of the 7 physical checks filled in — these look like they were barely started, not just missing one field.`);

  // Phase 126/127 found real, confirmed duplicate SUBMITTED audits
  // caused by the mobile app's client_id bug — multiple attempts for
  // the same site/day, treated as separate records. Submitting every
  // draft blindly could recreate the identical pattern if the same
  // site has more than one draft for the same day, so it's worth
  // surfacing here before it happens, not discovered again later the
  // same way it was found before.
  const byDayAndSite = new Map();
  for (const d of drafts) {
    const day = d.audit_date ? new Date(d.audit_date).toISOString().slice(0, 10) : 'no-date';
    const key = `${d.site_id_ihs || 'unknown'}__${day}`;
    if (!byDayAndSite.has(key)) byDayAndSite.set(key, []);
    byDayAndSite.get(key).push(d);
  }
  const multiDraftGroups = [...byDayAndSite.entries()].filter(([, list]) => list.length > 1);
  if (multiDraftGroups.length) {
    console.log(`\n⚠ ${multiDraftGroups.length} site+day combination(s) have MORE THAN ONE draft — submitting all of them would create the same kind of duplicate-submitted-audit pattern found and cleaned up in Phase 126/127:`);
    for (const [key, list] of multiDraftGroups) {
      const [siteId, day] = key.split('__');
      console.log(`  ${siteId} — ${day}: ${list.length} drafts`);
    }
    console.log('  Worth reviewing these specifically before proceeding — this script still submits all of them as requested, but this is flagged so it\'s a decision, not a surprise.');
  }

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to change all ${drafts.length} draft(s) to submitted.`);
    await mongoose.disconnect();
    return;
  }

  const backupDir = path.join(__dirname, `draft_submit_backup_${Date.now()}`);
  fs.mkdirSync(backupDir, { recursive: true });
  const preChangeDocs = await TankAudit.find({ _id: { $in: drafts.map(d => d._id) } }).lean();
  if (preChangeDocs.length !== drafts.length) {
    console.error(`\n✗ Aborting — expected to back up ${drafts.length} but found ${preChangeDocs.length}. Not changing anything until this is understood.`);
    await mongoose.disconnect();
    process.exit(1);
  }
  fs.writeFileSync(path.join(backupDir, 'TankAudit_pre_submit.json'), JSON.stringify(preChangeDocs, null, 2));
  console.log(`\n✓ Backed up ${preChangeDocs.length} draft(s) in their pre-change state to ${backupDir} before changing anything.`);

  console.log('\n── Submitting each draft (re-saves, triggering the real reconciliation + Site feedback logic) ──');
  let succeeded = 0, errored = 0;
  for (const draft of drafts) {
    try {
      draft.status = 'submitted';
      await draft.save();
      succeeded++;
    } catch (err) {
      errored++;
      console.error(`  ✗ ${draft._id} (${draft.site_id_ihs}): ${err.message}`);
    }
  }

  console.log(`\n✓ Done. Submitted: ${succeeded} | Errored (still draft, unchanged): ${errored}`);
  if (errored) console.log('Errored records are untouched — still drafts, safe to investigate and retry.');

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
