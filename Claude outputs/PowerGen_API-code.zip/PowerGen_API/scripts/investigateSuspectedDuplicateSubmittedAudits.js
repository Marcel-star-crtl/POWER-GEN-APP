/**
 * investigateSuspectedDuplicateSubmittedAudits.js
 * diesel-system/scripts/investigateSuspectedDuplicateSubmittedAudits.js
 *
 * Phase 126. Found while reviewing Phase 123-125's live
 * verifyNotesRunHoursScan.js output: IHS_BNB_032 had 3 separate
 * SUBMITTED audit records, same day, same auditor, with WORD-FOR-WORD
 * identical check_gen_cards_faulty.notes text ("91400hrs"). That
 * doesn't look like 3 real visits — it looks like the same submission
 * duplicated.
 *
 * Traced the likely root cause: createAudit's idempotency guard
 * (models/TankAudit.js's client_id unique index, checked in
 * controllers/tankAuditController.js) only runs `if (client_id)` —
 * any submission with a missing/empty client_id skips the check
 * entirely and can freely create a duplicate. The client_id field
 * itself is a SPARSE unique index specifically because client_id is
 * optional, so the database's own constraint doesn't catch this case
 * either.
 *
 * cleanupDuplicateTankAuditDrafts.js (Phase 100) deliberately never
 * touches SUBMITTED records, on the reasoning that each one is a real,
 * distinct historical event. That reasoning holds for a genuine
 * re-audit on a different day — it does NOT hold for what this script
 * is checking: same site, same calendar day, near-identical content.
 * Even so, this script is READ-ONLY. A submitted record is the source
 * of truth people already rely on (True CPH, Gain/Loss, the reconcil-
 * iation dashboard) — wrongly deleting a real, distinct audit would be
 * a worse mistake than leaving a genuine duplicate visible a while
 * longer. This reports what it finds and exactly why each group looks
 * suspicious; a human decides what, if anything, to actually remove.
 *
 * Usage:
 *   node scripts/investigateSuspectedDuplicateSubmittedAudits.js
 */
'use strict';

require('dotenv').config();
const mongoose = require('mongoose');

function dayKey(date) {
  if (!date) return 'no-date';
  const d = new Date(date);
  return d.toISOString().slice(0, 10);
}

function textSimilarity(a, b) {
  if (!a || !b) return 0;
  const na = a.trim().toLowerCase();
  const nb = b.trim().toLowerCase();
  if (na === nb) return 1;
  if (na.length === 0 || nb.length === 0) return 0;
  // A cheap, real similarity check — not a full edit-distance
  // algorithm, which this doesn't need: catches the "essentially the
  // same text" case (one is a substring of the other, e.g. a resubmit
  // with a trivial whitespace or punctuation change) without pulling
  // in a dependency for it.
  if (na.includes(nb) || nb.includes(na)) return 0.9;
  return 0;
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log('✓ Connected to MongoDB\n');

  const TankAudit = require('../models/TankAudit');

  const audits = await TankAudit.find({ status: 'submitted' })
    .select('site_id_ihs auditor_name audit_date createdAt client_id dip_reading_l audit_run_hours_reading check_gen_cards_faulty.notes')
    .sort({ site_id_ihs: 1, audit_date: 1 })
    .lean();

  console.log(`Total submitted audits: ${audits.length}`);

  const groups = new Map();
  for (const a of audits) {
    const key = `${a.site_id_ihs}__${dayKey(a.audit_date || a.createdAt)}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(a);
  }

  const suspicious = [];
  for (const [key, group] of groups) {
    if (group.length < 2) continue;

    const missingClientId = group.filter(a => !a.client_id);
    const notesTexts = group.map(a => a.check_gen_cards_faulty?.notes).filter(Boolean);
    let hasIdenticalNotes = false;
    for (let i = 0; i < notesTexts.length; i++) {
      for (let j = i + 1; j < notesTexts.length; j++) {
        if (textSimilarity(notesTexts[i], notesTexts[j]) >= 0.9) hasIdenticalNotes = true;
      }
    }

    if (missingClientId.length > 0 || hasIdenticalNotes) {
      suspicious.push({ key, group, missingClientIdCount: missingClientId.length, hasIdenticalNotes });
    }
  }

  console.log(`Site+day groups with more than one submitted audit: ${[...groups.values()].filter(g => g.length > 1).length}`);
  console.log(`Of those, flagged as SUSPICIOUS (missing client_id and/or near-identical notes): ${suspicious.length}\n`);

  if (!suspicious.length) {
    console.log('No suspicious groups found — no action needed.');
  } else {
    console.log('── Suspicious groups (review each — nothing is deleted by this script) ──\n');
    for (const { key, group, missingClientIdCount, hasIdenticalNotes } of suspicious) {
      const [siteId, day] = key.split('__');
      console.log(`${siteId} — ${day} (${group.length} audits)`);
      if (missingClientIdCount > 0) console.log(`  ⚠ ${missingClientIdCount} of ${group.length} record(s) have no client_id — the idempotency guard could not have caught these`);
      if (hasIdenticalNotes) console.log(`  ⚠ near-identical Gen Card notes text across records — real evidence of a duplicate, not just a coincidence`);
      for (const a of group) {
        console.log(`    [${String(a._id).slice(-6)}] auditor: ${a.auditor_name || 'unknown'} | client_id: ${a.client_id || '(none)'} | dip: ${a.dip_reading_l ?? '—'} | RH: ${a.audit_run_hours_reading ?? '—'} | notes: ${(a.check_gen_cards_faulty?.notes || '').slice(0, 60)}`);
      }
      console.log('');
    }
    console.log('Each group above needs a human decision, not an automatic one — a legitimate second visit the same day (a follow-up, a different fault) would also show up here if it happens to share similar wording. Verify before removing anything.');
  }

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
