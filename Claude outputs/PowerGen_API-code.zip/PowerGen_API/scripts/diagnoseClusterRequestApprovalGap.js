/**
 * diagnoseClusterRequestApprovalGap.js
 * diesel-system/scripts/diagnoseClusterRequestApprovalGap.js
 *
 * WHY THIS SCRIPT EXISTS:
 * The Cluster Cycle Report's "Requested (Regular)" figure comes from
 * `BudgetRequestApproval.find({ cluster, cycle_key })`
 * (routes/historicalDataRoutes.js, GET /cluster-cycle-report/:cluster/:cycle_key)
 * — a query that filters on this collection's OWN `cluster` string
 * field, set once at import time straight from each source file's
 * "Cluster" column (see importBudgetRequestApproval.js). The Site
 * Cycle Report, by contrast, looks up the SAME collection with
 * `BudgetRequestApproval.findOne({ site_id, cycle_key })` — no cluster
 * filter at all. So a site can show real requested/approved liters on
 * its own Site Cycle Report while contributing nothing to its
 * cluster's total, if the `cluster` string stored on its
 * BudgetRequestApproval document doesn't exactly match the cluster
 * name the report is queried with — whether that's a stray space, a
 * casing difference, a null left over from an earlier partial import,
 * or a genuinely stale value from before a site was reassigned to a
 * different cluster.
 *
 * `HistoricalMonthlyRecord.cluster` is treated as the canonical,
 * currently-trusted cluster assignment here, since it's what the
 * Cluster Cycle Report's own "site coverage" figures, the Site Cycle
 * Analysis tab, and the live cluster-scoped routes all already key
 * off. This script cross-checks every BudgetRequestApproval document
 * for the given cycle against that ground truth and reports exactly
 * which ones disagree — it does not assume the mismatch exists or
 * guess at its shape.
 *
 * Read-only unless --fix is passed. --fix only ever corrects the
 * `cluster` field on an EXISTING BudgetRequestApproval document to
 * match its own site's HistoricalMonthlyRecord.cluster for the same
 * cycle — it never creates, deletes, or touches any other field.
 *
 * Usage:
 *   node scripts/diagnoseClusterRequestApprovalGap.js                          # cluster=Kotto cycle=2026-07 (the reported case)
 *   node scripts/diagnoseClusterRequestApprovalGap.js --cluster=Edea --cycle=2026-06
 *   node scripts/diagnoseClusterRequestApprovalGap.js --fix                    # writes the correction for the mismatches found
 */
'use strict';
require('dotenv').config();
const mongoose = require('mongoose');
const BudgetRequestApproval = require('../models/BudgetRequestApproval');
const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const FIX = process.argv.includes('--fix');
function argVal(name, dflt) {
  const hit = process.argv.find(a => a.startsWith(`--${name}=`));
  return hit ? hit.split('=').slice(1).join('=') : dflt;
}
const CLUSTER = argVal('cluster', 'Kotto');
const CYCLE = argVal('cycle', '2026-07');

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI, { serverSelectionTimeoutMS: 8000 });
  console.log(`✓ Connected to MongoDB\n`);
  console.log(`Checking cluster="${CLUSTER}", cycle="${CYCLE}"\n`);

  // ── Step 1: what the live Cluster Cycle Report route actually sees ──
  const clusterScoped = await BudgetRequestApproval.find({ cluster: CLUSTER, cycle_key: CYCLE }).lean();
  console.log(`── What the Cluster Cycle Report's own query returns ──`);
  console.log(`BudgetRequestApproval.find({ cluster: "${CLUSTER}", cycle_key: "${CYCLE}" }) -> ${clusterScoped.length} document(s).`);
  const reqSum = clusterScoped.reduce((s, r) => s + (r.sbc_requested_l || 0), 0);
  console.log(`Sum of sbc_requested_l across those: ${Math.round(reqSum).toLocaleString()} L.\n`);

  // ── Step 2: every distinct cluster string actually stored for this cycle ──
  const allForCycle = await BudgetRequestApproval.find({ cycle_key: CYCLE }).select('site_id site_name cluster sbc_requested_l').lean();
  const byClusterValue = new Map();
  for (const r of allForCycle) {
    const key = JSON.stringify(r.cluster); // JSON.stringify surfaces null vs "" vs " Kotto" vs "Kotto" distinctly
    if (!byClusterValue.has(key)) byClusterValue.set(key, []);
    byClusterValue.get(key).push(r);
  }
  console.log(`── Every distinct "cluster" value actually stored on BudgetRequestApproval for cycle_key="${CYCLE}" ──`);
  for (const [key, rows] of [...byClusterValue.entries()].sort((a, b) => b[1].length - a[1].length)) {
    console.log(`  ${key.padEnd(20)} -> ${rows.length} document(s)`);
  }
  console.log();

  // ── Step 3: ground truth — which sites does HistoricalMonthlyRecord say belong to this cluster this cycle? ──
  const canonicalSites = await HistoricalMonthlyRecord.find({ cluster: CLUSTER, month_key: CYCLE }).select('site_id site_name').lean();
  console.log(`── Ground truth: HistoricalMonthlyRecord.cluster="${CLUSTER}" for month_key="${CYCLE}" ──`);
  console.log(`${canonicalSites.length} site(s) recorded there.\n`);

  const approvalBySite = new Map(allForCycle.map(r => [r.site_id, r]));
  const mismatches = [];
  const missingEntirely = [];
  for (const site of canonicalSites) {
    const appr = approvalBySite.get(site.site_id);
    if (!appr) { missingEntirely.push(site); continue; }
    if (appr.cluster !== CLUSTER) mismatches.push({ site_id: site.site_id, site_name: site.site_name, stored_cluster: appr.cluster, sbc_requested_l: appr.sbc_requested_l });
  }

  console.log(`── Comparison ──`);
  console.log(`${mismatches.length} site(s) belong to "${CLUSTER}" per HistoricalMonthlyRecord AND have a BudgetRequestApproval document for this cycle, but that document's own "cluster" field says something else:`);
  mismatches.forEach(m => console.log(`   ${m.site_id} (${m.site_name}): stored cluster = ${JSON.stringify(m.stored_cluster)}, sbc_requested_l = ${m.sbc_requested_l}`));
  console.log(`\n${missingEntirely.length} site(s) belong to "${CLUSTER}" per HistoricalMonthlyRecord but have NO BudgetRequestApproval document at all for this cycle (a real, separate gap — not a mislabeling):`);
  missingEntirely.forEach(m => console.log(`   ${m.site_id} (${m.site_name})`));

  if (!mismatches.length) {
    console.log(`\nNo cluster-field mismatches found for "${CLUSTER}"/"${CYCLE}" — if the report is still showing 0 L requested, the cause is elsewhere (worth re-checking the route/frontend directly rather than the data).`);
    await mongoose.disconnect();
    return;
  }

  const recoverable = mismatches.reduce((s, m) => s + (m.sbc_requested_l || 0), 0);
  console.log(`\nIf corrected, "Requested (Regular)" for ${CLUSTER}/${CYCLE} would gain ${Math.round(recoverable).toLocaleString()} L from these ${mismatches.length} site(s) alone.`);

  if (!FIX) {
    console.log('\n── DRY RUN — no changes were made. Re-run with --fix to correct the cluster field on these documents. ──');
    await mongoose.disconnect();
    return;
  }

  const ops = mismatches.map(m => ({
    updateOne: { filter: { site_id: m.site_id, cycle_key: CYCLE }, update: { $set: { cluster: CLUSTER } } },
  }));
  const result = await BudgetRequestApproval.bulkWrite(ops, { ordered: false });
  console.log(`\n✓ Modified ${result.modifiedCount} document(s).`);
  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
