/**
 * backfillJuneJulyRealConsumption2026.js
 * diesel-system/scripts/backfillJuneJulyRealConsumption2026.js
 *
 * Root cause (found directly against the real recovered source files,
 * not guessed): `Jun2026_Validation.xlsx` and `Jul2026_Validation.xlsx`
 * both contain a "Validation" sheet — the one
 * `importHistoricalEmailData.js` is configured to read for these two
 * months — whose "Final Cons" (and every other) column is byte-for-byte
 * identical to May 2026's own "Validation" sheet, for all 164 sites.
 * That's not a coincidence and not a database bug: it's the source
 * workbook itself carrying May's numbers forward unchanged. Confirmed
 * directly by diffing all three files' "Validation" sheets cell by
 * cell (SBC Cons, Final Cons, Cons Var, Final RH, SBC RH, CMS RH, Final
 * DG CPH, fuel added/left — every one identical across May/June/July).
 *
 * The REAL, differentiated per-site consumption for June and July does
 * exist in these files — just in a different sheet, "Validation (2)",
 * which May's workbook doesn't have at all (June and July's workbooks
 * introduce it). It uses its own month-labeled column name rather than
 * the generic "Final Cons" the import script's COLUMN_MAP looks for:
 * "Approved June-26 Cons" / "Approved July-26 Cons". Cross-checked:
 * summing that column across all 164 sites gives 113,121 L for June
 * and 93,945 L for July — which match, to the liter, the "Approved(L)"
 * figures already sitting correctly in `MonthlyDebitSummary` for those
 * two cycles (a separate import script already reads the right place).
 * So `importHistoricalEmailData.js` (which feeds
 * `HistoricalMonthlyRecord.final_consumption_l`, and from it every
 * Reserve figure and exhausted count on the Historical Data / History
 * Analysis pages) is the one place still pointed at the stale sheet.
 *
 * This script does NOT touch `budget_liters` — that side was already
 * importing correctly (June and July's budgets already differ from
 * May's and from each other in the app today). It only replaces
 * `final_consumption_l` with the real "Validation (2)" figure and
 * recomputes `reserve_liters` / `fully_exhausted` from (the site's
 * EXISTING, untouched budget_liters, the corrected consumption) — the
 * same formula `importHistoricalEmailData.js` itself uses:
 * `reserve_liters = round((budget_liters - final_consumption_l) * 10) / 10`,
 * `fully_exhausted = reserve_liters <= 0`.
 *
 * SAFE BY DEFAULT: dry run unless --confirm. Only UPDATES existing
 * HistoricalMonthlyRecord documents (site_id + month_key) — never
 * upserts/creates new ones. Any site present in "Validation (2)" with
 * no matching existing record is reported separately, not written.
 *
 * Usage:
 *   node scripts/backfillJuneJulyRealConsumption2026.js              # dry run, full diff report
 *   node scripts/backfillJuneJulyRealConsumption2026.js --confirm    # writes the correction
 */
'use strict';
require('dotenv').config();
const path = require('path');
const XLSX = require('xlsx');
const mongoose = require('mongoose');
const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');

const CONFIRM = process.argv.includes('--confirm');
const DATA_DIR = path.join(__dirname, 'historical_email_data');

const MONTHS = [
  { month_key: '2026-06', file: 'Jun2026_Validation.xlsx', consColName: 'Approved June-26 Cons' },
  { month_key: '2026-07', file: 'Jul2026_Validation.xlsx', consColName: 'Approved July-26 Cons' },
];

function buildHeaderIndex(headerRow) {
  const index = {};
  headerRow.forEach((cell, i) => { if (typeof cell === 'string') index[cell.trim()] = i; });
  return index;
}

function parseValidation2(filePath, consColName) {
  const wb = XLSX.readFile(filePath);
  if (!wb.SheetNames.includes('Validation (2)')) {
    throw new Error(`"Validation (2)" sheet not found in ${filePath}. Sheets present: ${wb.SheetNames.join(', ')}`);
  }
  const rows = XLSX.utils.sheet_to_json(wb.Sheets['Validation (2)'], { header: 1, raw: true, defval: null });
  const header = rows[2]; // confirmed: header row is index 2 in this sheet (rows 0-1 are summary/total rows)
  const idx = buildHeaderIndex(header);
  const siteCol = idx['NEW IHS ID'];
  const consCol = idx[consColName];
  if (siteCol == null || consCol == null) {
    throw new Error(`Expected columns not found in "Validation (2)" of ${filePath}. Looked for "NEW IHS ID" (got idx ${siteCol}) and "${consColName}" (got idx ${consCol}).`);
  }
  const bySite = new Map();
  for (let i = 3; i < rows.length; i++) {
    const r = rows[i];
    if (!r || !r[siteCol]) continue;
    const v = r[consCol];
    if (typeof v === 'number') bySite.set(String(r[siteCol]).trim(), v);
  }
  return bySite;
}

async function main() {
  const mongoURI = process.env.MONGODB_URI || process.env.MONGO_URI;
  if (!mongoURI) throw new Error('MONGODB_URI (or MONGO_URI) is not set — check your .env file.');
  await mongoose.connect(mongoURI);
  console.log('✓ Connected to MongoDB\n');

  const allOps = [];
  let grandOldSum = 0, grandNewSum = 0;

  for (const m of MONTHS) {
    console.log(`── ${m.month_key} (${m.file}, sheet "Validation (2)", column "${m.consColName}") ──`);
    const newBySite = parseValidation2(path.join(DATA_DIR, m.file), m.consColName);
    console.log(`  Parsed ${newBySite.size} site row(s) with a numeric consumption figure.`);

    const existing = await HistoricalMonthlyRecord.find({ month_key: m.month_key, site_id: { $in: [...newBySite.keys()] } })
      .select('site_id budget_liters final_consumption_l reserve_liters fully_exhausted')
      .lean();
    const existingBySite = new Map(existing.map(r => [r.site_id, r]));

    const missing = [...newBySite.keys()].filter(id => !existingBySite.has(id));
    if (missing.length) {
      console.log(`  ⚠ ${missing.length} site(s) in "Validation (2)" have no existing ${m.month_key} record — NOT written (no upsert): ${missing.slice(0, 10).join(', ')}${missing.length > 10 ? ', …' : ''}`);
    }

    let changed = 0, unchanged = 0, oldSum = 0, newSum = 0;
    let oldExhausted = 0, newExhausted = 0;
    const sampleChanges = [];

    for (const [site_id, rec] of existingBySite) {
      const old_consumption = rec.final_consumption_l;
      const new_consumption = newBySite.get(site_id);
      oldSum += old_consumption || 0;
      newSum += new_consumption || 0;
      if (rec.fully_exhausted) oldExhausted++;

      const budget_liters = rec.budget_liters ?? null;
      const reserve_liters = budget_liters != null ? Math.round((budget_liters - new_consumption) * 10) / 10 : null;
      const fully_exhausted = reserve_liters != null ? reserve_liters <= 0 : null;
      if (fully_exhausted) newExhausted++;

      if (old_consumption !== new_consumption) {
        changed++;
        if (sampleChanges.length < 8) sampleChanges.push([site_id, old_consumption, new_consumption, old_consumption != null ? Math.round((new_consumption - old_consumption) * 10) / 10 : null]);
      } else {
        unchanged++;
      }

      allOps.push({
        updateOne: {
          filter: { site_id, month_key: m.month_key },
          update: { $set: { final_consumption_l: new_consumption, reserve_liters, fully_exhausted, source_sheet: 'Validation (2)' } },
        },
      });
    }

    console.log(`  ${changed} record(s) would change, ${unchanged} already match.`);
    console.log(`  Fleet-wide consumption: ${Math.round(oldSum).toLocaleString()} L (old, stale) -> ${Math.round(newSum).toLocaleString()} L (real, from Validation (2))`);
    console.log(`  Exhausted-site count: ${oldExhausted} (old) -> ${newExhausted} (new)`);
    console.log(`  Sample changes (site, old, new, delta):`);
    sampleChanges.forEach(s => console.log('   ', s));
    console.log();

    grandOldSum += oldSum;
    grandNewSum += newSum;
  }

  console.log(`── Total across both months: ${Math.round(grandOldSum).toLocaleString()} L (old) -> ${Math.round(grandNewSum).toLocaleString()} L (real). ${allOps.length} record(s) to update. ──`);

  if (!CONFIRM) {
    console.log('\n── DRY RUN — no changes were made. ─────────────────────────────');
    console.log(`Re-run with --confirm to write ${allOps.length} record(s) to the database.`);
    await mongoose.disconnect();
    return;
  }

  const result = await HistoricalMonthlyRecord.bulkWrite(allOps, { ordered: false });
  console.log(`\n✓ Modified ${result.modifiedCount} record(s).`);

  await mongoose.disconnect();
}

main().catch(err => {
  console.error('✗ Fatal error:', err.message);
  process.exit(1);
});
