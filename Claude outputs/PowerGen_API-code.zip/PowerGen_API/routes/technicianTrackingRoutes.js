'use strict';

const express = require('express');
const router = express.Router();

const TechnicianLocationPing = require('../models/TechnicianLocationPing');
const RefuelWorkflow = require('../models/RefuelWorkflow');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');

const PING_TTL_MINUTES = 20; // a ping goes stale (and vanishes from the map) if not refreshed within this window
const ACTIVE_STATUSES = ['activated', 'checked-in', 'form_opened', 'form_submitted'];

/**
 * POST /api/technician-tracking/ping
 *
 * Body: { workflowId, latitude, longitude, accuracy? }
 *
 * Rejects the ping unless workflowId refers to a real, currently-active
 * (not checked-out) workflow belonging to THIS technician — this is the
 * actual privacy enforcement, not just a client-side convention. A
 * technician's app cannot report a location without a real, current,
 * their-own job to justify it.
 */
router.post('/ping',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { workflowId, latitude, longitude, accuracy } = req.body;
    if (!workflowId || latitude === undefined || longitude === undefined) {
      return res.status(400).json({ success: false, error: 'workflowId, latitude, and longitude are required' });
    }

    const workflow = await RefuelWorkflow.findOne({
      _id: workflowId,
      technicianId: req.user.userId,
      status: { $in: ACTIVE_STATUSES },
    }).select('siteId status');

    if (!workflow) {
      // Deliberately not a 404 that reveals whether the workflow ID exists
      // at all — just "this isn't a valid basis for a location ping right now".
      return res.status(403).json({ success: false, error: 'No active workflow found for this session — location sharing requires an active, checked-in job.' });
    }

    const expiresAt = new Date(Date.now() + PING_TTL_MINUTES * 60 * 1000);

    await TechnicianLocationPing.findOneAndUpdate(
      { technicianId: req.user.userId },
      {
        technicianId: req.user.userId,
        workflowId: workflow._id,
        siteId: workflow.siteId,
        latitude, longitude, accuracy,
        updatedAt: new Date(),
        expiresAt,
      },
      { upsert: true, new: true }
    );

    res.json({ success: true, data: { sharing: true, expiresAt } });
  })
);

/**
 * DELETE /api/technician-tracking/ping
 *
 * Explicitly stops sharing — called on checkout, or if the technician
 * turns off location sharing manually. Removes the ping immediately
 * rather than waiting for the TTL, so a manager doesn't see a stale
 * "still on site" position for up to 20 more minutes after someone's
 * genuinely done for the day.
 */
router.delete('/ping',
  authenticateToken,
  asyncHandler(async (req, res) => {
    await TechnicianLocationPing.deleteOne({ technicianId: req.user.userId });
    res.json({ success: true });
  })
);

/**
 * GET /api/technician-tracking/active
 *
 * Managers only. Returns the CURRENT position of every technician who is
 * both (a) actively checked into a job right now and (b) has pinged
 * within the last PING_TTL_MINUTES. Deliberately returns nothing more
 * than name, current position, and which site/workflow they're on — no
 * history, no past positions, no data about technicians who aren't
 * presently on an active job.
 */
router.get('/active',
  authenticateToken,
  requireRole(['diesel_manager', 'admin', 'supervisor', 'head_of_business', 'ceo']),
  asyncHandler(async (req, res) => {
    const pings = await TechnicianLocationPing.find({ expiresAt: { $gt: new Date() } })
      .populate('technicianId', 'fullName phone')
      .populate('siteId', 'IHS_ID_SITE Site_Name')
      .lean();

    const data = pings
      .filter(p => p.technicianId) // guard against a since-deleted user
      .map(p => ({
        technician_id:   p.technicianId._id,
        technician_name: p.technicianId.fullName,
        technician_phone: p.technicianId.phone,
        workflow_id: p.workflowId,
        site_id:     p.siteId?.IHS_ID_SITE || null,
        site_name:   p.siteId?.Site_Name || null,
        lat: p.latitude,
        lng: p.longitude,
        accuracy: p.accuracy ?? null,
        last_updated: p.updatedAt,
      }));

    res.json({ success: true, data, total: data.length });
  })
);

module.exports = router;
