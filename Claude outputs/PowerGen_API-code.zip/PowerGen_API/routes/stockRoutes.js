/**
 * stockRoutes.js
 *
 * Live-system stock reporting — genuinely distinct from the historical
 * email-recovery effort (see routes/historicalDataRoutes.js). Two real
 * views:
 *   - "Live": every managed site's current fuel level (Site's own
 *     Fuel_Quantity_Found, the same field every other live diesel view
 *     already reads from), grouped by cluster.
 *   - "End of cycle": a point-in-time snapshot captured either
 *     automatically when a cycle is closed (see the extended
 *     PATCH /:cycle_key/close in otherRoutes.js) or manually on demand
 *     via this file's own /snapshot-now endpoint, since real cycle
 *     closures only happen once a month going forward and the person
 *     asked for "at any given time" — a manual capture directly serves
 *     that, not just the monthly close event.
 */
const express = require('express');
const router = express.Router();
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');

const Site = require('../models/Site');
const DieselCycle = require('../models/DieselCycle');
const CycleEndStockSnapshot = require('../models/CycleEndStockSnapshot');

const ROLES = ['diesel_manager', 'admin', 'supervisor', 'finance', 'head_of_business', 'ceo'];

function clusterSummary(sites, stockField = 'stock_l', capacityField = 'capacity_l') {
  const byCluster = new Map();
  for (const s of sites) {
    const key = s.cluster || 'Unassigned';
    if (!byCluster.has(key)) {
      byCluster.set(key, { cluster: key, site_count: 0, sites_with_reading: 0, total_stock_l: 0, total_capacity_l: 0 });
    }
    const c = byCluster.get(key);
    c.site_count += 1;
    if (s[stockField] != null) {
      c.sites_with_reading += 1;
      c.total_stock_l += s[stockField];
    }
    if (s[capacityField] != null) c.total_capacity_l += s[capacityField];
  }
  return [...byCluster.values()]
    .map(c => ({ ...c, fill_pct: c.total_capacity_l > 0 ? Math.round((c.total_stock_l / c.total_capacity_l) * 1000) / 10 : null }))
    .sort((a, b) => a.cluster.localeCompare(b.cluster));
}

/**
 * GET /api/diesel/stock/live
 *
 * Every managed site's current stock, straight from Site's own
 * Fuel_Quantity_Found — the same field every other live view (Live
 * Site Map, Fuel Planning, Refuel workflow) already reads. "Live"
 * because it reflects whatever the field's current value is the
 * instant this is called, not a stored snapshot.
 */
router.get('/live',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const now = new Date();
    const rawSites = await Site.find({ Grato_Managed: true })
      .select('IHS_ID_SITE Site_Name GRATO_Cluster Region Fuel_Quantity_Found Tank_Capacity_1 Fuel_Level_Source Fuel_Level_Updated_At')
      .lean();

    const sites = rawSites.map(s => ({
      site_id: s.IHS_ID_SITE,
      site_name: s.Site_Name,
      cluster: s.GRATO_Cluster || null,
      region: s.Region || null,
      stock_l: s.Fuel_Quantity_Found ?? null,
      capacity_l: s.Tank_Capacity_1 ?? null,
      fill_pct: (s.Fuel_Quantity_Found != null && s.Tank_Capacity_1 > 0)
        ? Math.round((s.Fuel_Quantity_Found / s.Tank_Capacity_1) * 1000) / 10 : null,
      fuel_level_source: s.Fuel_Level_Source || null,
      reading_age_hours: s.Fuel_Level_Updated_At
        ? Math.round((now - new Date(s.Fuel_Level_Updated_At)) / (1000 * 60 * 60)) : null,
      fuel_level_updated_at: s.Fuel_Level_Updated_At || null,
    }));

    const totals = {
      site_count: sites.length,
      sites_with_reading: sites.filter(s => s.stock_l != null).length,
      total_stock_l: sites.reduce((sum, s) => sum + (s.stock_l || 0), 0),
      total_capacity_l: sites.reduce((sum, s) => sum + (s.capacity_l || 0), 0),
    };

    res.json({
      success: true,
      data: {
        generated_at: now,
        totals,
        by_cluster: clusterSummary(sites),
        sites: sites.sort((a, b) => (a.site_name || '').localeCompare(b.site_name || '')),
      },
    });
  })
);

/**
 * GET /api/diesel/stock/cycle-snapshots
 *
 * List every cycle that has a captured end-of-cycle (or manually
 * captured) stock snapshot, most recent first — so the frontend can
 * offer a real picker instead of guessing which cycles have data.
 */
router.get('/cycle-snapshots',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const cycles = await CycleEndStockSnapshot.aggregate([
      { $group: { _id: '$cycle_key', site_count: { $sum: 1 }, captured_at: { $max: '$captured_at' } } },
      { $sort: { _id: -1 } },
      { $project: { _id: 0, cycle_key: '$_id', site_count: 1, captured_at: 1 } },
    ]);
    res.json({ success: true, data: cycles });
  })
);

/**
 * GET /api/diesel/stock/cycle-snapshots/:cycle_key
 *
 * The actual per-site and per-cluster stock data for one captured
 * snapshot — either a real cycle-close snapshot or a manual capture
 * tagged with that cycle's key.
 */
router.get('/cycle-snapshots/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;
    const rows = await CycleEndStockSnapshot.find({ cycle_key }).lean();
    if (!rows.length) {
      return res.status(404).json({ success: false, message: `No stock snapshot captured for cycle ${cycle_key}.` });
    }

    const sites = rows.map(r => ({
      site_id: r.site_id,
      site_name: r.site_name,
      cluster: r.cluster,
      region: r.region,
      stock_l: r.stock_l,
      capacity_l: r.tank_capacity_l,
      fill_pct: (r.stock_l != null && r.tank_capacity_l > 0) ? Math.round((r.stock_l / r.tank_capacity_l) * 1000) / 10 : null,
      fuel_level_source: r.fuel_level_source,
      reading_age_hours: r.reading_age_hours,
    }));

    const totals = {
      site_count: sites.length,
      sites_with_reading: sites.filter(s => s.stock_l != null).length,
      total_stock_l: sites.reduce((sum, s) => sum + (s.stock_l || 0), 0),
      total_capacity_l: sites.reduce((sum, s) => sum + (s.capacity_l || 0), 0),
    };

    res.json({
      success: true,
      data: {
        cycle_key,
        captured_at: rows[0]?.captured_at || null,
        totals,
        by_cluster: clusterSummary(sites),
        sites: sites.sort((a, b) => (a.site_name || '').localeCompare(b.site_name || '')),
      },
    });
  })
);

/**
 * POST /api/diesel/stock/snapshot-now
 *
 * Manually capture a stock snapshot right now, tagged with the current
 * cycle's key — distinct from the automatic snapshot a real cycle
 * closure triggers. Real cycles only close once a month; this gives
 * "stock at any given time" its own on-demand capture, not just a
 * monthly one. Upserts per site, same as the automatic path, so
 * capturing again the same day just refreshes the existing snapshot
 * rather than creating duplicates.
 */
router.post('/snapshot-now',
  authenticateToken,
  requireRole(['diesel_manager', 'admin']),
  asyncHandler(async (req, res) => {
    const cycle = await DieselCycle.getOrCreateCurrent();
    const sites = await Site.find({ Grato_Managed: true })
      .select('IHS_ID_SITE Site_Name GRATO_Cluster Region Fuel_Quantity_Found Tank_Capacity_1 Fuel_Level_Source Fuel_Level_Updated_At')
      .lean();

    const now = new Date();
    const ops = sites.map(s => ({
      updateOne: {
        filter: { cycle_key: cycle.cycle_key, site: s._id },
        update: { $set: {
          cycle_key: cycle.cycle_key,
          site: s._id,
          site_id: s.IHS_ID_SITE,
          site_name: s.Site_Name,
          cluster: s.GRATO_Cluster,
          region: s.Region,
          stock_l: s.Fuel_Quantity_Found ?? null,
          tank_capacity_l: s.Tank_Capacity_1 ?? null,
          fuel_level_source: s.Fuel_Level_Source ?? null,
          reading_age_hours: s.Fuel_Level_Updated_At
            ? Math.round((now - new Date(s.Fuel_Level_Updated_At)) / (1000 * 60 * 60)) : null,
          captured_at: now,
          captured_by: req.user._id || req.user.userId,
        }},
        upsert: true,
      },
    }));
    if (ops.length) await CycleEndStockSnapshot.bulkWrite(ops, { ordered: false });

    res.json({ success: true, data: { cycle_key: cycle.cycle_key, sites_captured: ops.length, captured_at: now } });
  })
);

/**
 * GET /api/diesel/stock/carryover/:cycle_key
 *
 * What stock rolled into this cycle from the one before it — reads
 * directly from SiteBudget's carried_over_l (see the extended
 * PATCH /:cycle_key/close in otherRoutes.js and
 * services/siteBudgetImportService.js, which are what actually
 * populate this field). Only returns sites where a carryover figure is
 * genuinely known — SiteBudget documents without one (this cycle's
 * budget uploaded before the prior cycle closed, and it hasn't closed
 * since) are simply absent here, not shown as zero.
 */
router.get('/carryover/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const SiteBudget = require('../models/SiteBudget');
    const { cycle_key } = req.params;
    const rows = await SiteBudget.find({ cycle_key, carried_over_l: { $ne: null } })
      .select('site_id site_name cluster region carried_over_l carried_over_from_cycle')
      .lean();

    const total_carried_over_l = rows.reduce((sum, r) => sum + (r.carried_over_l || 0), 0);

    res.json({
      success: true,
      data: {
        cycle_key,
        sites_with_carryover: rows.length,
        total_carried_over_l,
        by_cluster: clusterSummary(
          rows.map(r => ({ cluster: r.cluster, stock_l: r.carried_over_l, capacity_l: null })),
        ),
        sites: rows.sort((a, b) => (b.carried_over_l || 0) - (a.carried_over_l || 0)),
      },
    });
  })
);

module.exports = router;
