const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Fail fast rather than silently signing/verifying tokens with a
// well-known fallback string if these are ever missing from the
// environment (e.g. a misconfigured deploy).
if (!process.env.JWT_SECRET || !process.env.JWT_REFRESH_SECRET) {
  throw new Error('JWT_SECRET and JWT_REFRESH_SECRET must both be set in the environment — refusing to start with insecure defaults.');
}

/**
 * @route   POST /api/auth/login
 * @desc    Login user
 * @access  Public
 */
router.post('/login', async (req, res) => {
  console.log('Login attempt:', req.body.email || req.body.phone || req.body.identifier);
  
  try {
    const { email, phone, identifier, password } = req.body;

    const rawIdentifier = (email ?? phone ?? identifier ?? '').toString();
    const trimmedIdentifier = rawIdentifier.trim();
    const looksLikeEmail = trimmedIdentifier.includes('@');

    const normalizedEmail = looksLikeEmail ? trimmedIdentifier.toLowerCase() : '';
    const normalizedPhone = !looksLikeEmail
      ? trimmedIdentifier.replace(/[\s\-()]/g, '')
      : '';

    // Validate input
    if ((!normalizedEmail && !normalizedPhone) || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email/phone and password'
      });
    }

    // Check if user exists
    const query = looksLikeEmail
      ? { email: normalizedEmail }
      : { phone: normalizedPhone };

    const user = await User.findOne(query).select('+password');
    
    if (!user) {
      console.warn('Login failed: user not found', {
        by: looksLikeEmail ? 'email' : 'phone',
        identifier: looksLikeEmail ? normalizedEmail : normalizedPhone,
      });
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated. Contact administrator.'
      });
    }

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      console.warn('Login failed: invalid password', {
        userId: user._id?.toString?.() || String(user._id),
        by: looksLikeEmail ? 'email' : 'phone',
      });
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Generate tokens
    const accessToken = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );

    const refreshToken = jwt.sign(
      { userId: user._id },
      process.env.JWT_REFRESH_SECRET,
      { expiresIn: '7d' }
    );

    // Update last login
    user.lastLogin = new Date();
    await user.save();

    // Send response
    res.json({
      success: true,
      data: {
        accessToken,
        refreshToken,
        user: {
          id: user._id,
          email: user.email,
          fullName: user.fullName,
          role: user.role,
          phone: user.phone,
          isActive: user.isActive
        }
      }
    });

    console.log('✓ Login successful:', user.email, '-', user.role);

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during login',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

/**
 * @route   POST /api/auth/refresh
 * @desc    Refresh access token
 * @access  Public
 */
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(401).json({
        success: false,
        message: 'Refresh token required'
      });
    }

    // Verify refresh token
    const decoded = jwt.verify(
      refreshToken,
      process.env.JWT_REFRESH_SECRET
    );

    // Get user
    const user = await User.findById(decoded.userId);
    
    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Invalid refresh token'
      });
    }

    // Generate new access token
    const accessToken = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );

    res.json({
      success: true,
      data: {
        accessToken
      }
    });

  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(401).json({
      success: false,
      message: 'Invalid or expired refresh token'
    });
  }
});

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user
 * @access  Public
 */
router.post('/logout', async (req, res) => {
  try {
    // In a production app, you might want to blacklist the token here
    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Logout failed'
    });
  }
});

module.exports = router;


