const express = require('express');
const router = express.Router();
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const controller = require('../controllers/tankAuditController');

const DASHBOARD_ROLES = ['technician', 'admin', 'supervisor', 'diesel_manager', 'finance', 'head_of_business', 'ceo'];

// All sites, for tank audit site selection — not scoped to a
// technician's own assignments, since a tank audit is a one-off task
// any technician may pick up for any site. Must be registered before
// the /tank-audits/:id route family below for the same reason as
// /summary — otherwise a fixed path could be swallowed as an :id.
router.get('/tank-audit-sites', authenticateToken, requireRole(['technician', 'admin']), controller.getAllSitesForAudit);
// Dashboard summary — must be registered BEFORE the /:id route below, or
// Express would try to treat "summary" as an :id value.
router.get('/tank-audits/summary', authenticateToken, requireRole(DASHBOARD_ROLES), controller.getSummary);
// Cycle reconciliation dashboard — every site's system baseline (opening
// stock, refuel, contractual CPH) plus audit findings where they exist,
// the in-app replacement for manually building the Excel Audit sheet.
// Same fixed-path-before-:id requirement as /summary above.
router.get('/tank-audits/reconciliation', authenticateToken, requireRole(DASHBOARD_ROLES), controller.getReconciliationDashboard);
// Fixed path — must be registered BEFORE /delivery-events/:site_id below,
// same reasoning as /summary and /reconciliation above.
router.get('/tank-audits/delivery-events', authenticateToken, requireRole(DASHBOARD_ROLES), controller.getAllDeliveryEventsForCycle);
router.get('/tank-audits/delivery-events/:site_id', authenticateToken, requireRole(DASHBOARD_ROLES), controller.getSiteDeliveryEvents);
// Phase 121 — same fixed-path-before-:id requirement as everything
// else on this list. Caught and fixed before shipping: an earlier
// version of this route was registered AFTER /tank-audits/:id below,
// where Express would have matched "notes-run-hours-candidates" as an
// :id value and this route would never have actually been reached.
router.get('/tank-audits/notes-run-hours-candidates', authenticateToken, requireRole(DASHBOARD_ROLES), controller.getNotesRunHoursCandidates);
router.get('/tank-audits/analytics', authenticateToken, requireRole(DASHBOARD_ROLES), controller.getAuditAnalytics);
// List audits — widened to the same dashboard roles as /summary; this
// was too narrow before and caused real 403s for finance/head_of_business/ceo
// dashboard users.
router.get('/tank-audits', authenticateToken, requireRole(DASHBOARD_ROLES), controller.listAudits);
// Get audit by ID — same widening as the list route above.
router.get('/tank-audits/:id', authenticateToken, requireRole(DASHBOARD_ROLES), controller.getAuditById);
// Create audit
router.post('/tank-audit', authenticateToken, requireRole(['technician', 'admin']), controller.createAudit);
// Update audit
router.put('/tank-audits/:id', authenticateToken, requireRole(['technician', 'admin']), controller.updateAudit);
// Run-hours extraction from the Gen Cards Faulty photo (Phase 119) —
// a suggestion only; accept-extracted-run-hours is the real write.
router.post('/tank-audits/:id/extract-run-hours', authenticateToken, requireRole(DASHBOARD_ROLES), controller.extractRunHours);
router.post('/tank-audits/:id/accept-extracted-run-hours', authenticateToken, requireRole(DASHBOARD_ROLES), controller.acceptExtractedRunHours);
// A narrow correction path for exactly one field, available to the
// same roles that can already view/extract/accept — see the
// controller's own comment for why this is separate from updateAudit.
router.patch('/tank-audits/:id/manual-run-hours', authenticateToken, requireRole(DASHBOARD_ROLES), controller.setManualRunHours);
// Update audit status
router.patch('/tank-audits/:id/status', authenticateToken, requireRole(['technician', 'admin']), controller.updateAuditStatus);

module.exports = router;
