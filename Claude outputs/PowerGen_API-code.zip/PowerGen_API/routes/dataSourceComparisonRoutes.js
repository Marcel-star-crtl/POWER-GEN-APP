'use strict';

const express = require('express');
const router = express.Router();

const { getComparison } = require('../services/dataSourceComparisonService');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');

const ROLES = ['diesel_manager', 'admin', 'supervisor', 'finance', 'head_of_business', 'ceo'];

/**
 * GET /api/diesel/data-sources/:cycle_key
 *
 * Per-site comparison of CMS/ERS telemetry against field-visit data for
 * a cycle — fuel level, run-hours, and consumption side by side, their
 * variance, and the combined figure the rest of the system actually
 * uses (field data preferred, CMS the fallback — see
 * services/dataSourceComparisonService.js for the full reasoning).
 */
router.get('/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const result = await getComparison(req.params.cycle_key);
    res.json({ success: true, data: result });
  })
);

module.exports = router;
