'use strict';

const express = require('express');
const router = express.Router();

const Site = require('../models/Site');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const { getGeofenceStatus } = require('../utils/geofence');
const asyncHandler = require('../middlewares/asyncHandler');

// Simple, fast tank-percentage-based urgency — deliberately NOT using
// fuelPlanningService's predictSiteFuel (which does several DB queries
// PER SITE: SiteBudget, FuelConsumption, CMS averages, FieldVisitRecord —
// appropriate for the detailed Fuel Planning page where a short wait is
// expected, but calling it for every one of 160+ sites on every map load
// was taking 30+ seconds and timing out in production). This computes
// urgency directly from fields already fetched in the one query below —
// zero extra round trips, so the map loads instantly. Less precise than
// the full day-by-day prediction, which is the right trade-off for an
// at-a-glance map view.
function tankUrgency(currentLevel, tankCapacity) {
  if (currentLevel == null || !tankCapacity || tankCapacity <= 0) return 'unknown';
  const pct = currentLevel / tankCapacity;
  if (pct <= 0.10) return 'critical';
  if (pct <= 0.25) return 'high';
  if (pct <= 0.50) return 'medium';
  return 'ok';
}

/**
 * GET /api/diesel/sites-map/:cycle_key
 *
 * All sites with valid coordinates, with a fast tank-percentage urgency
 * indicator — powers the web live-map page. cycle_key is accepted for
 * API-shape consistency with the rest of this app (every other diesel
 * endpoint is cycle-scoped) but isn't currently used in the query itself,
 * since Site.Fuel_Quantity_Found is the live current level, not a
 * per-cycle historical figure.
 */
router.get('/:cycle_key',
  authenticateToken,
  requireRole(['diesel_manager', 'admin', 'supervisor', 'finance', 'head_of_business', 'ceo']),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;

    const sites = await Site.find({
      Latitude:  { $ne: null, $exists: true },
      Longitude: { $ne: null, $exists: true },
      // Excludes sites in clusters no longer under GRATO's management
      // (e.g. Kribi 1, Kribi 2, Yassa) — see models/Site.js's
      // Grato_Managed field and scripts/deactivateClusters.js. $ne
      // false rather than a direct `true` match, so existing sites
      // that predate this field (and so don't have it set at all)
      // aren't accidentally excluded by a strict equality check.
      Grato_Managed: { $ne: false },
    })
      .select('IHS_ID_SITE Site_Name GRATO_Cluster Region Latitude Longitude Geofence_Radius_M Fuel_Quantity_Found Tank_Capacity_1 Fuel_Level_Source Fuel_Level_Updated_At')
      .lean();

    const mapSites = sites.map(s => {
      const currentLevel = s.Fuel_Quantity_Found ?? null;
      const tankCapacity = s.Tank_Capacity_1 ?? null;
      return {
        site_id:   s.IHS_ID_SITE,
        name:      s.Site_Name || s.IHS_ID_SITE,
        cluster:   s.GRATO_Cluster || null,
        region:    s.Region || null,
        lat:       s.Latitude,
        lng:       s.Longitude,
        geofence_radius_m: s.Geofence_Radius_M || 150,
        current_fuel_level: currentLevel,
        tank_capacity:      tankCapacity,
        urgency:         tankUrgency(currentLevel, tankCapacity),
        days_to_empty:   null, // not computed here — see Fuel Planning page for the full prediction
        fuel_level_source:     s.Fuel_Level_Source || null,
        fuel_level_updated_at: s.Fuel_Level_Updated_At || null,
      };
    });

    res.json({
      success: true,
      data: mapSites,
      cycle_key,
      total: mapSites.length,
    });
  })
);

/**
 * POST /api/diesel/sites-map/verify-location
 *
 * Used by the mobile app's check-in step: "am I actually at this site?"
 * Compares the technician's current GPS position against the target
 * site's stored coordinates and its geofence radius.
 *
 * Body: { site_id, latitude, longitude }
 */
router.post('/verify-location',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { site_id, latitude, longitude } = req.body;

    if (site_id === undefined || latitude === undefined || longitude === undefined) {
      return res.status(400).json({ success: false, error: 'site_id, latitude, and longitude are required' });
    }
    const lat = Number(latitude);
    const lng = Number(longitude);
    if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      return res.status(400).json({ success: false, error: 'Invalid latitude/longitude' });
    }

    const site = await Site.findOne({ IHS_ID_SITE: site_id })
      .select('IHS_ID_SITE Site_Name Latitude Longitude Geofence_Radius_M')
      .lean();

    if (!site) {
      return res.status(404).json({ success: false, error: `Site ${site_id} not found` });
    }

    if (site.Latitude == null || site.Longitude == null) {
      // The site itself has no coordinates on file — this isn't the
      // technician's fault, and shouldn't block them from working.
      // Distinct response shape so the mobile app can show "location
      // verification unavailable for this site" rather than a failure.
      return res.json({
        success: true,
        data: {
          verifiable: false,
          reason: 'Site has no coordinates on file — location cannot be verified.',
          site_id: site.IHS_ID_SITE,
          site_name: site.Site_Name,
        },
      });
    }

    const radius = site.Geofence_Radius_M || 150;
    const status = getGeofenceStatus(lat, lng, site.Latitude, site.Longitude, radius);

    res.json({
      success: true,
      data: {
        verifiable: true,
        isInside: status.isInside,
        distanceMeters: status.distanceMeters,
        radiusMeters: status.radiusMeters,
        site_id: site.IHS_ID_SITE,
        site_name: site.Site_Name,
      },
    });
  })
);

module.exports = router;
