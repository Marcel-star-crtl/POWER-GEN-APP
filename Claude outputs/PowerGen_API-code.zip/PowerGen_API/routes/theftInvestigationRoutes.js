'use strict';

const express = require('express');
const router = express.Router();

const CycleReconciliation = require('../models/CycleReconciliation');
const DieselCycle = require('../models/DieselCycle');
const TankLevelReading = require('../models/TankLevelReading');
const FieldVisitRecord = require('../models/FieldVisitRecord');
const FuelConsumption = require('../models/FuelConsumption');
const TomCardTransaction = require('../models/TomCardTransaction');
const GeneratorAssignmentLedger = require('../models/GeneratorAssignmentLedger');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');

/**
 * GET /api/diesel/theft-investigation/:site_id/:cycle_key
 *
 * Pulls together every source of evidence relevant to a theft-suspected
 * (or refuel-mismatch) flag for one site in one cycle, so a manager can
 * actually investigate rather than just seeing a flag with no context:
 *   - the reconciliation figures that triggered the flag in the first place
 *   - tank-level readings across the cycle (the most direct evidence —
 *     an actual fuel-level timeline, if telemetry exists for this site)
 *   - every field visit (technician-reported readings + fuel added)
 *   - every mobile refuel (FuelConsumption)
 *   - every TomCard purchase (what was actually bought, and for how much)
 *   - any generator swap during the cycle (a real, non-theft explanation
 *     for an apparent consumption anomaly — a generator change mid-cycle
 *     can look like a discrepancy if not accounted for)
 *
 * Manager-only, matching the access level for reconciliation/alerts data
 * generally.
 */
router.get('/:site_id/:cycle_key',
  authenticateToken,
  requireRole(['diesel_manager', 'admin', 'supervisor', 'finance', 'head_of_business', 'ceo']),
  asyncHandler(async (req, res) => {
    const { site_id, cycle_key } = req.params;

    const [
      recon, cycleDoc, tankReadings, fieldVisits, mobileRefuels, tomCardPurchases, generatorSwaps,
    ] = await Promise.all([
      CycleReconciliation.findOne({ site_id, cycle_key }).lean(),
      DieselCycle.findOne({ cycle_key }).select('start_date end_date').lean(),
      TankLevelReading.find({ site_id, cycle_key }).sort({ reading_date: 1 }).lean(),
      FieldVisitRecord.getVisitsForCycle(site_id, cycle_key),
      FuelConsumption.find({ site_id }).sort({ record_date: 1 }).lean(),
      TomCardTransaction.find({ site_id, cycle_key }).sort({ date: 1 }).lean(),
      GeneratorAssignmentLedger.find({ site_id, cycles_affected: cycle_key }).sort({ assigned_at: 1 }).lean().catch(() => []),
    ]);

    if (!recon) {
      return res.status(404).json({ success: false, error: `No reconciliation record found for ${site_id} in ${cycle_key}.` });
    }

    // FuelConsumption isn't cycle-keyed on the schema itself — narrow to
    // this cycle's real date range from the DieselCycle record (recon
    // itself has no cycle_start/cycle_end fields — that was a real bug
    // in an earlier draft of this endpoint, caught before shipping).
    const cycleFilteredRefuels = mobileRefuels.filter(r => {
      if (!cycleDoc) return true; // no date range available — include everything rather than silently dropping all of it
      const d = new Date(r.record_date);
      return d >= new Date(cycleDoc.start_date) && d <= new Date(cycleDoc.end_date);
    });

    // Build a single, date-sorted timeline merging every event type —
    // this is what actually lets someone SEE the story, rather than
    // cross-referencing four separate lists by eye.
    const timeline = [
      ...tankReadings.map(t => ({
        date: t.reading_date, type: 'tank_reading',
        label: t.status === 'ok' ? `Tank reading: ${t.fuel_level_l}L` : `Tank reading: ${t.status}`,
        value_l: t.fuel_level_l,
      })),
      ...fieldVisits.map(v => ({
        date: v.current_visit_date, type: 'field_visit',
        label: `Field visit — ${v.fuel_qty_added || 0}L added by ${v.technician_name || 'unknown'}`,
        value_l: v.fuel_qty_added,
      })),
      ...cycleFilteredRefuels.map(r => ({
        date: r.record_date, type: 'mobile_refuel',
        label: `Mobile refuel — ${r.fuel_data?.fuel_added || 0}L added`,
        value_l: r.fuel_data?.fuel_added,
      })),
      ...tomCardPurchases.map(p => ({
        date: p.date, type: 'tomcard_purchase',
        label: `TomCard purchase — ${p.quantity_l || 0}L, XAF ${p.amount_cfa || 0}`,
        value_l: p.quantity_l,
      })),
      ...generatorSwaps.map(g => ({
        date: g.assigned_at, type: 'generator_swap',
        label: `Generator assigned: ${g.generator_id}${g.assigned_reason ? ` (${g.assigned_reason})` : ''}`,
        value_l: null,
      })),
    ]
      .filter(e => e.date)
      .sort((a, b) => new Date(a.date) - new Date(b.date));

    res.json({
      success: true,
      data: {
        site_id, cycle_key,
        site_name: recon.site_name, cluster: recon.cluster, region: recon.region,
        reconciliation: {
          theft_liters:            recon.theft_liters || 0,
          theft_detected:          !!recon.theft_detected,
          cms_consumption:         recon.cms_consumption ?? null,
          contractual_consumption: recon.contractual_consumption ?? null,
          cons_variance_pct:       recon.cons_variance_pct ?? null,
          field_fuel_added:        recon.field_fuel_added ?? null,
          cms_refuel_total:        recon.cms_refuel_total ?? null,
          tomcard_purchased:       recon.tomcard_purchased ?? null,
          refuel_field_vs_cms_var:  recon.refuel_field_vs_cms_var ?? null,
          refuel_field_vs_card_var: recon.refuel_field_vs_card_var ?? null,
          gap_cph_variation:       recon.gap_cph_variation ?? null,
          alerts:                  recon.alerts || {},
        },
        timeline,
        counts: {
          tank_readings: tankReadings.length,
          field_visits: fieldVisits.length,
          mobile_refuels: cycleFilteredRefuels.length,
          tomcard_purchases: tomCardPurchases.length,
          generator_swaps: generatorSwaps.length,
        },
      },
    });
  })
);

module.exports = router;
