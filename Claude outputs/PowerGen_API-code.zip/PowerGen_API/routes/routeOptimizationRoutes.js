'use strict';

const express = require('express');
const router = express.Router();

const Site = require('../models/Site');
const { optimizeRoute } = require('../services/routeOptimizationService');
const { getDrivingMatrix, getDrivingRoute } = require('../services/osrmRoutingService');
const { authenticateToken } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');

/**
 * POST /api/diesel/route-optimize
 *
 * Body: {
 *   site_ids: string[]            // IHS_ID_SITE values to visit
 *   start_lat, start_lng: number  // where the route begins — a
 *                                 // technician's current GPS position,
 *                                 // or a manager-chosen starting point
 *                                 // when planning ahead
 * }
 *
 * Open to any authenticated user (not manager-only) — both a technician
 * planning their own day and a manager planning for someone else are
 * legitimate uses, and this endpoint doesn't expose anything sensitive
 * beyond site locations, which are already visible on the Live Site Map
 * to anyone with access to this app.
 */
router.post('/route-optimize',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { site_ids, start_lat, start_lng } = req.body;

    if (!Array.isArray(site_ids) || site_ids.length === 0) {
      return res.status(400).json({ success: false, error: 'site_ids must be a non-empty array' });
    }
    if (site_ids.length > 30) {
      return res.status(400).json({ success: false, error: 'Route optimization supports up to 30 stops at a time.' });
    }
    const startLat = Number(start_lat);
    const startLng = Number(start_lng);
    if (isNaN(startLat) || isNaN(startLng)) {
      return res.status(400).json({ success: false, error: 'start_lat and start_lng are required' });
    }

    const sites = await Site.find({ IHS_ID_SITE: { $in: site_ids } })
      .select('IHS_ID_SITE Site_Name Latitude Longitude Fuel_Quantity_Found Tank_Capacity_1')
      .lean();

    const missingCoords = [];
    const stops = [];
    for (const id of site_ids) {
      const site = sites.find(s => s.IHS_ID_SITE === id);
      if (!site) {
        missingCoords.push({ site_id: id, reason: 'not found' });
        continue;
      }
      if (site.Latitude == null || site.Longitude == null) {
        missingCoords.push({ site_id: id, reason: 'no coordinates on file' });
        continue;
      }
      const pct = site.Tank_Capacity_1 && site.Fuel_Quantity_Found != null
        ? (site.Fuel_Quantity_Found / site.Tank_Capacity_1) * 100
        : null;
      const urgency = pct == null ? 'unknown' : pct <= 10 ? 'critical' : pct <= 25 ? 'high' : pct <= 50 ? 'medium' : 'ok';
      stops.push({
        site_id: site.IHS_ID_SITE,
        site_name: site.Site_Name || site.IHS_ID_SITE,
        lat: site.Latitude,
        lng: site.Longitude,
        urgency,
      });
    }

    if (stops.length === 0) {
      return res.status(400).json({ success: false, error: 'None of the requested sites have usable coordinates.', missing: missingCoords });
    }

    const startPoint = { lat: startLat, lng: startLng };

    // Real road distances/durations for every pair, in one call — used
    // for BOTH the visiting order and the final leg distances, not just
    // the displayed numbers. Null (not thrown) on any failure, which
    // optimizeRoute treats as "use straight-line" — the whole request
    // still succeeds, just with an honest flag saying which kind of
    // distance was used.
    const drivingMatrix = await getDrivingMatrix(startPoint, stops.map(s => ({ lat: s.lat, lng: s.lng })));
    const result = optimizeRoute(startPoint, stops, drivingMatrix);

    // Real road-path geometry for the decided order, for drawing an
    // actual road route on the map instead of straight lines between
    // pins. A separate call from the matrix above — Table gives
    // distances for ordering, Route gives the actual path for a
    // specific, already-decided sequence.
    let routeGeometry = null;
    if (drivingMatrix) {
      const orderedPoints = [startPoint, ...result.order.map(s => ({ lat: s.lat, lng: s.lng }))];
      const routeResult = await getDrivingRoute(orderedPoints);
      if (routeResult) routeGeometry = routeResult.geometry;
    }

    res.json({
      success: true,
      data: {
        order: result.order,
        total_distance_km: Math.round(result.total_distance_m / 100) / 10,
        total_duration_min: result.total_duration_s != null ? Math.round(result.total_duration_s / 60) : null,
        legs: result.legs,
        skipped: missingCoords,
        used_road_distance: result.used_road_distance,
        route_geometry: routeGeometry, // [lat, lng] pairs tracing the actual roads, or null if unavailable — draw a straight line between pins as the fallback
      },
    });
  })
);

module.exports = router;
