const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const logger = require('../utils/logger');

// User Management Routes
router.get('/users', authenticateToken, requireRole(['admin']), adminController.getAllUsers);
router.post('/users', authenticateToken, requireRole(['admin']), adminController.createUser);
router.put('/users/:id', authenticateToken, requireRole(['admin']), adminController.updateUser);
router.delete('/users/:id', authenticateToken, requireRole(['admin']), adminController.deleteUser);
router.patch('/users/:id/toggle-status', authenticateToken, requireRole(['admin']), adminController.toggleUserStatus);

// Dashboard
router.get('/dashboard', authenticateToken, requireRole(['admin']), adminController.getDashboard);
router.post('/assign-technicians', authenticateToken, requireRole(['admin']), adminController.assignTechniciansToSupervisor);

// Site Management
router.get('/sites', authenticateToken, requireRole(['admin']), adminController.getAllSites);
router.post('/sites', authenticateToken, requireRole(['admin']), adminController.createSite);
router.put('/sites/:id', authenticateToken, requireRole(['admin']), adminController.updateSite);
router.delete('/sites/:id', authenticateToken, requireRole(['admin']), adminController.deleteSite);

// Maintenance Management
router.get('/maintenance', authenticateToken, requireRole(['admin']), adminController.getAllMaintenance);
router.patch('/maintenance/:id/status', authenticateToken, requireRole(['admin']), adminController.updateMaintenanceStatus);
router.delete('/maintenance/:id', authenticateToken, requireRole(['admin']), adminController.deleteMaintenance);

// Cluster Management
router.get('/clusters', authenticateToken, requireRole(['admin']), adminController.getAllClusters);
router.post('/clusters', authenticateToken, requireRole(['admin']), adminController.createCluster);
router.put('/clusters/:id', authenticateToken, requireRole(['admin']), adminController.updateCluster);
router.delete('/clusters/:id', authenticateToken, requireRole(['admin']), adminController.deleteCluster);


// Parts Management
router.get('/parts', authenticateToken, requireRole(['admin']), adminController.getAllParts);
router.post('/parts', authenticateToken, requireRole(['admin']), adminController.createPart);
router.put('/parts/:id', authenticateToken, requireRole(['admin']), adminController.updatePart);
router.delete('/parts/:id', authenticateToken, requireRole(['admin']), adminController.deletePart);

// Part Requests Management
router.get('/part-requests', authenticateToken, requireRole(['admin']), adminController.getAllPartRequests);
router.get('/part-requests/:id', authenticateToken, requireRole(['admin']), adminController.getPartRequestById);
router.patch('/part-requests/:id/status', authenticateToken, requireRole(['admin']), adminController.updatePartRequestStatus);
router.delete('/part-requests/:id', authenticateToken, requireRole(['admin']), adminController.deletePartRequest);

// Reports and Logs
router.get('/reports', authenticateToken, requireRole(['admin']), adminController.getSystemReports);
router.get('/audit-logs', authenticateToken, requireRole(['admin']), adminController.getAuditLogs);



router.post('/clusters/:id/technicians', authenticateToken, requireRole(['admin']), adminController.assignTechnicianToCluster);
router.delete('/clusters/:id/technicians/:technicianId', authenticateToken, requireRole(['admin']), adminController.removeTechnicianFromCluster);

// ── Fuel Request Approval Chain configuration ─────────────────────────────────
// Lets an admin change the six approvers (name/email/role/department) and the
// CEO liters threshold WITHOUT a code deploy. Previously these were hardcoded
// directly in config/fuelRequestApprovalChain.js — see that file's header
// comment for why that was a real operational risk. Falls back to the
// hardcoded defaults in the response until an admin has saved a config once.
const ApprovalChainConfig = require('../models/ApprovalChainConfig');
const { DEFAULT_APPROVERS, refreshApprovalChainConfig } = require('../config/fuelRequestApprovalChain');
const asyncHandler = require('../middlewares/asyncHandler');

router.get('/approval-chain/fuel-request',
  authenticateToken, requireRole(['admin']),
  asyncHandler(async (req, res) => {
    const cfg = await ApprovalChainConfig.getActive('fuel_request');
    res.json({
      success: true,
      data: cfg || {
        chain_name: 'fuel_request',
        steps: DEFAULT_APPROVERS,
        ceo_liters_threshold: 100,
        is_default: true, // signals to the UI: nothing has been saved yet, this is the fallback
      },
    });
  })
);

router.put('/approval-chain/fuel-request',
  authenticateToken, requireRole(['admin']),
  asyncHandler(async (req, res) => {
    const { steps, ceo_liters_threshold } = req.body;
    if (!Array.isArray(steps) || steps.length === 0) {
      return res.status(400).json({ success: false, error: 'steps must be a non-empty array' });
    }
    for (const s of steps) {
      if (!s.name?.trim() || !s.email?.trim() || !s.role?.trim() || !s.department?.trim()) {
        return res.status(400).json({ success: false, error: `Every step needs name, email, role, and department (level ${s.level} is missing one)` });
      }
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const badEmail = steps.find(s => !emailPattern.test(s.email));
    if (badEmail) {
      return res.status(400).json({ success: false, error: `Invalid email address for ${badEmail.name}: "${badEmail.email}"` });
    }

    const cfg = await ApprovalChainConfig.findOneAndUpdate(
      { chain_name: 'fuel_request' },
      {
        $set: {
          steps,
          ceo_liters_threshold: ceo_liters_threshold ?? 100,
          updated_by: req.user.userId,
        },
      },
      { upsert: true, new: true }
    );

    // Apply immediately — no restart, no polling lag. Every fuel request
    // created after this line uses the new approver list.
    await refreshApprovalChainConfig();

    logger.info(`[Admin] Fuel request approval chain updated by ${req.user.email}`);
    res.json({ success: true, data: cfg, message: 'Approval chain updated — takes effect immediately for new requests.' });
  })
);

module.exports = router;
