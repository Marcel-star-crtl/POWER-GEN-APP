'use strict';

const express = require('express');
const router = express.Router();

const SiteBudget = require('../models/SiteBudget');
const DieselCycle = require('../models/DieselCycle');
const SiteConsumptionHistory = require('../models/SiteConsumptionHistory');
const { planAllSites, planSiteBudget } = require('../services/budgetPlanningService');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');
const logger = require('../utils/logger');

const PLANNER_ROLES = ['diesel_manager', 'admin', 'finance', 'head_of_business', 'ceo'];

/**
 * GET /api/diesel/budget-plan/history/:site_id
 *
 * Full historical consumption trend for one site — every month on file,
 * not just the 3-month window the planning algorithm itself uses. For
 * charting a site's actual consumption over time, not for the planning
 * calculation (see services/budgetPlanningService.js for that).
 */
router.get('/history/:site_id',
  authenticateToken,
  requireRole(PLANNER_ROLES),
  asyncHandler(async (req, res) => {
    const { site_id } = req.params;
    const history = await SiteConsumptionHistory.find({ site_id })
      .sort({ cycle_key: 1 })
      .select('cycle_key actual_consumption_l submitted_contractual_l approved_contractual_l')
      .lean();

    res.json({ success: true, data: { site_id, history } });
  })
);

/**
 * GET /api/diesel/budget-plan/fleet-trend
 *
 * Aggregate consumption trend across the whole fleet, one point per
 * month on file — for an overview chart at the top of the Budget
 * Planning page, distinct from any single site's history.
 */
router.get('/fleet-trend',
  authenticateToken,
  requireRole(PLANNER_ROLES),
  asyncHandler(async (req, res) => {
    const trend = await SiteConsumptionHistory.aggregate([
      { $group: {
        _id: '$cycle_key',
        total_consumption_l: { $sum: '$actual_consumption_l' },
        site_count: { $sum: 1 },
      }},
      { $sort: { _id: 1 } },
      { $project: { _id: 0, cycle_key: '$_id', total_consumption_l: 1, site_count: 1 } },
    ]);

    res.json({ success: true, data: { trend } });
  })
);

/**
 * GET /api/diesel/budget-plan/:cycle_key
 *
 * Generates a PREVIEW budget plan for every site with engineering
 * parameters on file — nothing is written to SiteBudget by this call.
 * Uses the target cycle's real day count from DieselCycle if that cycle
 * already exists; otherwise accepts a manual ?days= override so a plan
 * can be previewed before the next cycle is formally created.
 */
router.get('/:cycle_key',
  authenticateToken,
  requireRole(PLANNER_ROLES),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;
    const cycle = await DieselCycle.findOne({ cycle_key }).lean();

    let daysInCycle;
    if (cycle) {
      daysInCycle = cycle.days_in_cycle
        || Math.round((new Date(cycle.end_date) - new Date(cycle.start_date)) / 86400000);
    } else if (req.query.days) {
      daysInCycle = Number(req.query.days);
      if (isNaN(daysInCycle) || daysInCycle <= 0) {
        return res.status(400).json({ success: false, error: 'Invalid ?days= value.' });
      }
    } else {
      return res.status(400).json({
        success: false,
        error: `Cycle "${cycle_key}" doesn't exist yet and no ?days= override was given. Either create the cycle first, or pass ?days=30 to preview a plan before the cycle is formally created.`,
      });
    }

    const plan = await planAllSites(daysInCycle);
    res.json({ success: true, data: { cycle_key, days_in_cycle: daysInCycle, ...plan } });
  })
);

/**
 * GET /api/diesel/budget-plan/:cycle_key/site/:site_id
 *
 * Single-site plan detail — same computation as the bulk endpoint, for
 * drilling into one site's numbers (e.g. reviewing a flagged site)
 * without re-fetching the whole fleet's plan.
 */
router.get('/:cycle_key/site/:site_id',
  authenticateToken,
  requireRole(PLANNER_ROLES),
  asyncHandler(async (req, res) => {
    const { cycle_key, site_id } = req.params;
    const cycle = await DieselCycle.findOne({ cycle_key }).lean();
    const daysInCycle = cycle
      ? (cycle.days_in_cycle || Math.round((new Date(cycle.end_date) - new Date(cycle.start_date)) / 86400000))
      : (Number(req.query.days) || 30);

    const result = await planSiteBudget(site_id, daysInCycle);
    res.json({ success: true, data: result });
  })
);

/**
 * POST /api/diesel/budget-plan/:cycle_key/commit
 *
 * Writes a reviewed plan into SiteBudget for the given cycle. Requires
 * the cycle to already exist (unlike the preview endpoint) — committing
 * budgets for a cycle that doesn't exist yet isn't meaningful.
 *
 * Body: { sites: [{ site_id, budget_liters, ...(any other fields to
 *   override, e.g. a manager adjusted one site's figure after review) }] }
 *
 * Deliberately requires the caller to pass the specific sites/figures to
 * commit (normally: whatever GET /:cycle_key just returned, possibly
 * hand-edited) rather than silently re-running the whole calculation
 * server-side at commit time — what gets written should be exactly what
 * was reviewed, not a figure that could have silently changed between
 * preview and commit (e.g. if consumption history was updated in between).
 */
router.post('/:cycle_key/commit',
  authenticateToken,
  requireRole(['diesel_manager', 'admin']),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;
    const { sites } = req.body;

    if (!Array.isArray(sites) || sites.length === 0) {
      return res.status(400).json({ success: false, error: 'Body must include a non-empty "sites" array.' });
    }

    const cycle = await DieselCycle.findOne({ cycle_key }).lean();
    if (!cycle) {
      return res.status(404).json({ success: false, error: `Cycle "${cycle_key}" doesn't exist — create it before committing a budget plan to it.` });
    }

    let written = 0;
    const errors = [];
    const ops = [];

    for (const s of sites) {
      if (!s.site_id || s.budget_liters == null) {
        errors.push({ site_id: s.site_id || '(missing)', error: 'site_id and budget_liters are required' });
        continue;
      }
      const budget_liters = Number(s.budget_liters);
      if (isNaN(budget_liters) || budget_liters < 0) {
        errors.push({ site_id: s.site_id, error: 'budget_liters must be a non-negative number' });
        continue;
      }

      ops.push({
        updateOne: {
          filter: { site_id: s.site_id, cycle_key },
          update: {
            $set: {
              site_id: s.site_id,
              cycle_key,
              cycle_id: cycle._id,
              site_name: s.site_name,
              cluster: s.cluster,
              region: s.region,
              topology: s.topology,
              dg_kva: s.actual_dg_kva || 0,
              ccph: s.genset_cph || 0,
              days_in_cycle: s.days_in_cycle,
              budgeted_rh: s.budgeted_rh,
              final_grid_availability: s.final_grid_availability,
              budget_liters,
              imported_by: req.user.userId,
              imported_at: new Date(),
              source_file: 'Automated Budget Planning',
            },
          },
          upsert: true,
        },
      });
    }

    if (ops.length > 0) {
      const result = await SiteBudget.bulkWrite(ops, { ordered: false });
      written = result.upsertedCount + result.modifiedCount;
      logger.info(`[BudgetPlanning] Committed ${written} site budget(s) for ${cycle_key} by ${req.user.email || req.user.userId}`);
    }

    res.json({ success: true, data: { written, errors, cycle_key } });
  })
);

module.exports = router;
