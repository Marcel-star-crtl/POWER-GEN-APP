'use strict';

const express = require('express');
const router = express.Router();

const HistoricalMonthlyRecord = require('../models/HistoricalMonthlyRecord');
const AdHocFuelRequest = require('../models/AdHocFuelRequest');
const { MidCycleBudgetRelease, MidCycleReleaseDailyProgress } = require('../models/MidCycleBudgetRelease');
const TomCardAllocation = require('../models/TomCardAllocation');
const BudgetRequestApproval = require('../models/BudgetRequestApproval');
const MonthlyDebitSummary = require('../models/MonthlyDebitSummary');
const HistoricalFieldVisit = require('../models/HistoricalFieldVisit');
const HistoricalFuelPurchase = require('../models/HistoricalFuelPurchase');
const SiteEngineeringParams = require('../models/SiteEngineeringParams');
const HistoricalSiteStockSnapshot = require('../models/HistoricalSiteStockSnapshot');
const MidCycleEstimateSnapshot = require('../models/MidCycleEstimateSnapshot');
const PlannedVsSuppliedDelivery = require('../models/PlannedVsSuppliedDelivery');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');
const { buildHistoricalExcelWorkbook } = require('../services/historicalExcelExport');
// Phase 169 — carriedOverStockBurn/cycleEngineeringFigures/
// consumptionStability/computeGainLoss moved to their own module (see its
// own docblock) so the Excel export can share the exact same math instead
// of risking a second, drifting copy.
const { carriedOverStockBurn, cycleEngineeringFigures, consumptionStability, computeGainLoss } = require('../services/historicalMetrics');

const ROLES = ['diesel_manager', 'admin', 'supervisor', 'finance', 'head_of_business', 'ceo'];

/**
 * GET /api/diesel/historical/mid-cycle-estimate/:month_key
 *
 * The mid-cycle "estimate to close" snapshot — currently only real for
 * March 2026 (19 March reference date). A working document showing each
 * site's running balance: initial budget plus two extra-fuel rounds
 * already given, against what's actually been refueled so far. See
 * models/MidCycleEstimateSnapshot.js for why this is modeled
 * separately from every other historical collection.
 */
/**
 * GET /api/diesel/historical/planned-vs-supplied/:month_key
 *
 * Per-site planned-vs-actual delivery tracking with an explicit gap
 * classification — currently spans late May through June 2026 (see
 * models/PlannedVsSuppliedDelivery.js). Genuinely different from
 * field-visit data: this tracks what was *scheduled*, not just what a
 * visit found.
 */
router.get('/planned-vs-supplied/:month_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { month_key } = req.params;
    const records = await PlannedVsSuppliedDelivery.find({ month_key }).sort({ date_done: 1 }).lean();

    const totals = records.reduce((acc, r) => ({
      planned_l: acc.planned_l + (r.planned_l || 0),
      supplied_l: acc.supplied_l + (r.supplied_l || 0),
    }), { planned_l: 0, supplied_l: 0 });

    const gapTypeCounts = {};
    for (const r of records) {
      const t = r.gap_type || '(none)';
      gapTypeCounts[t] = (gapTypeCounts[t] || 0) + 1;
    }

    res.json({ success: true, data: { month_key, records, totals, gap_type_counts: gapTypeCounts } });
  })
);

router.get('/mid-cycle-estimate/:month_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { month_key } = req.params;
    const sites = await MidCycleEstimateSnapshot.find({ month_key }).sort({ balance_l: 1 }).lean();
    const totals = sites.reduce((acc, s) => ({
      initial_budget_l: acc.initial_budget_l + (s.initial_budget_l || 0),
      first_extra_l: acc.first_extra_l + (s.first_extra_l || 0),
      second_extra_l: acc.second_extra_l + (s.second_extra_l || 0),
      total_refuel_done_l: acc.total_refuel_done_l + (s.total_refuel_done_l || 0),
    }), { initial_budget_l: 0, first_extra_l: 0, second_extra_l: 0, total_refuel_done_l: 0 });

    res.json({ success: true, data: { month_key, sites, totals } });
  })
);

/**
 * GET /api/diesel/historical/full-summary/:month_key
 *
 * One row per site for the given month, joining every relevant
 * historical collection: requested/approved (BudgetRequestApproval —
 * currently only real for 2026-07), consumed/budget/reserve
 * (HistoricalMonthlyRecord), and extra/emergency fuel that month
 * (AdHocFuelRequest, aggregated from its date field since that
 * collection isn't stored by month directly).
 *
 * Extra fuel is genuinely real for every month December 2025 through
 * August 2026 now (Phase 101/102 closed the gap that used to make this
 * true only for late July/early August 2026 — see the changelog and
 * scripts/historical_email_data/README.md), not just the original
 * shortage event.
 *
 * Isolated before merged, per the user's explicit instruction: each
 * site's extra-fuel figure here is NOT just one merged total. A site
 * can appear across more than one request round within the same month
 * (e.g. both March's 1st and 2nd rounds) — each of those is a genuinely
 * separate ask, submitted on a different date, sometimes decided
 * differently. `extra_fuel_detail` carries every one of those
 * individual, isolated requests (round, source file, date, requested,
 * approved, delivered, decision status) exactly as recorded; the
 * `extra_fuel_*` totals alongside it are that same detail merged, never
 * the other way around. A request with `approved_l: null` is honestly
 * "no decision recorded" — NOT the same as an explicit 0L rejection,
 * and the two are kept as separate counts (`extra_fuel_pending_count`
 * vs `extra_fuel_rejected_count`) rather than folded together, since
 * collapsing them was exactly the kind of silent merge the ad-hoc data
 * needs to avoid.
 *
 * Deliberately does NOT include debit/credit here — that figure is
 * fleet-wide, not per-site (see MonthlyDebitSummary), and fabricating
 * a per-site split of a fleet-level number would misrepresent the
 * source data. Returned separately as `fleet_debit_summary` so the
 * frontend can show it as clearly-labeled fleet context alongside the
 * per-site table, not implied to be site-specific.
 *
 * Every cell that has no real source data for this month returns null,
 * not zero or an invented figure — the coverage gaps are real (see
 * scripts/historical_email_data/README.md) and this endpoint reflects
 * them honestly rather than papering over them.
 */
router.get('/full-summary/:month_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { month_key } = req.params;
    const [year, month] = month_key.split('-').map(Number);
    const monthStart = new Date(Date.UTC(year, month - 1, 1));
    const monthEnd = new Date(Date.UTC(year, month, 1));

    const [monthlyRecords, requestApprovals, adhocByMonth, debitSummary] = await Promise.all([
      HistoricalMonthlyRecord.find({ month_key }).lean(),
      BudgetRequestApproval.find({ cycle_key: month_key }).lean(),
      AdHocFuelRequest.aggregate([
        { $match: { planned_date: { $gte: monthStart, $lt: monthEnd } } },
        { $sort: { planned_date: 1 } },
        // Per-record decision status, computed once here so both the
        // isolated detail list and the merged counts below agree with
        // each other by construction rather than being derived twice.
        { $addFields: {
          decision_status: {
            $switch: {
              branches: [
                // $ne against a bare `null` literal is NOT safe for a field
                // that may be entirely absent from the document (as
                // delivered_l genuinely is on every record recovered from
                // the original July/August tracker — it was never a column
                // in that source at all, see AdHocFuelRequest's own model
                // comment). MongoDB's aggregation framework does not treat
                // a missing field as equal to an explicit null for $ne/$eq
                // purposes, so `{ $ne: ['$delivered_l', null] }` evaluated
                // true for those "never had the field" records and wrongly
                // classified them as delivered — confirmed directly from a
                // real screenshot showing "Delivered (confirmed)" next to a
                // blank Delivered (L) figure, not assumed from reading the
                // code alone. $ifNull first normalizes "missing" and
                // "explicitly null" to the same null value before the
                // comparison, so only a record with a REAL delivered figure
                // (including a real 0, which $ifNull correctly leaves
                // alone) takes this branch.
                { case: { $ne: [{ $ifNull: ['$delivered_l', null] }, null] }, then: 'delivered' },
                { case: { $eq: ['$approved_l', 0] }, then: 'rejected' },
                { case: { $gt: ['$approved_l', 0] }, then: 'approved' },
              ],
              default: 'pending',
            },
          },
        }},
        { $group: {
          _id: '$site_id',
          extra_fuel_l: { $sum: '$quantity_requested_l' },
          extra_fuel_requests: { $sum: 1 },
          extra_fuel_approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
          extra_fuel_delivered_l: { $sum: { $ifNull: ['$delivered_l', 0] } },
          extra_fuel_approved_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'approved'] }, 1, 0] } },
          extra_fuel_rejected_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'rejected'] }, 1, 0] } },
          extra_fuel_pending_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'pending'] }, 1, 0] } },
          extra_fuel_delivered_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'delivered'] }, 1, 0] } },
          // The isolated view, preserved alongside the merge above —
          // every individual request that fed into it, untouched.
          extra_fuel_detail: { $push: {
            request_round: '$request_round',
            source_file: '$source_file',
            planned_date: '$planned_date',
            requested_l: '$quantity_requested_l',
            approved_l: '$approved_l',
            delivered_l: '$delivered_l',
            status: '$decision_status',
          }},
        }},
      ]),
      MonthlyDebitSummary.findOne({ cycle_key: month_key }).lean(),
    ]);

    const approvalBySite = new Map(requestApprovals.map(r => [r.site_id, r]));
    const adhocBySite = new Map(adhocByMonth.map(a => [a._id, a]));

    // Union of every site appearing in ANY of the three site-level
    // sources this month — a site with only an ad-hoc request and no
    // monthly record (or vice versa) still shows up, rather than being
    // silently dropped because it's missing from one particular source.
    const allSiteIds = new Set([
      ...monthlyRecords.map(r => r.site_id),
      ...requestApprovals.map(r => r.site_id),
      ...adhocByMonth.map(a => a._id),
    ]);

    const sites = [...allSiteIds].map(site_id => {
      const monthly = monthlyRecords.find(r => r.site_id === site_id);
      const approval = approvalBySite.get(site_id);
      const adhoc = adhocBySite.get(site_id);
      return {
        site_id,
        site_name: monthly?.site_name || approval?.site_name || null,
        cluster: monthly?.cluster || approval?.cluster || null,
        requested_l: approval?.sbc_requested_l ?? null,
        approved_l: approval?.ihs_approved_l ?? monthly?.budget_liters ?? null,
        extra_fuel_l: adhoc?.extra_fuel_l ?? null,
        extra_fuel_requests: adhoc?.extra_fuel_requests ?? null,
        extra_fuel_approved_l: adhoc?.extra_fuel_approved_l ?? null,
        extra_fuel_delivered_l: adhoc?.extra_fuel_delivered_l ?? null,
        extra_fuel_approved_count: adhoc?.extra_fuel_approved_count ?? null,
        extra_fuel_rejected_count: adhoc?.extra_fuel_rejected_count ?? null,
        extra_fuel_pending_count: adhoc?.extra_fuel_pending_count ?? null,
        extra_fuel_delivered_count: adhoc?.extra_fuel_delivered_count ?? null,
        extra_fuel_detail: adhoc?.extra_fuel_detail ?? null,
        consumed_l: monthly?.final_consumption_l ?? null,
        reserve_l: monthly?.reserve_liters ?? null,
        fully_exhausted: monthly?.fully_exhausted ?? null,
      };
    }).sort((a, b) => (a.site_name || a.site_id).localeCompare(b.site_name || b.site_id));

    res.json({
      success: true,
      data: {
        month_key,
        sites,
        fleet_debit_summary: debitSummary ? {
          submitted_consumption_l: debitSummary.submitted_consumption_l,
          approved_consumption_l: debitSummary.approved_consumption_l,
          purchases_l: debitSummary.purchases_l,
          debit_credit_amount_xaf: debitSummary.debit_credit_amount_xaf,
        } : null,
        coverage: {
          has_request_approval: requestApprovals.length > 0,
          has_monthly_reconciliation: monthlyRecords.length > 0,
          has_adhoc_requests: adhocByMonth.length > 0,
          has_debit_summary: !!debitSummary,
        },
      },
    });
  })
);

/**
 * GET /api/diesel/historical/site-stock-snapshots
 *
 * The one-off, site-level stock snapshots found during the full
 * multi-sheet investigation (Phase 70) — HO Stock, BB Site Stock, and
 * Small Tank Usage. Grouped by snapshot_type since these are three
 * genuinely different documents, not one recurring series (see
 * models/HistoricalSiteStockSnapshot.js). Found during audit: this
 * data had a model and import script but no way to actually view it —
 * closed here.
 */
router.get('/site-stock-snapshots',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const all = await HistoricalSiteStockSnapshot.find({}).sort({ snapshot_type: 1, snapshot_date: 1 }).lean();
    const grouped = {};
    for (const s of all) {
      if (!grouped[s.snapshot_type]) grouped[s.snapshot_type] = [];
      grouped[s.snapshot_type].push(s);
    }
    res.json({ success: true, data: { groups: grouped, total: all.length } });
  })
);

/**
 * GET /api/diesel/historical/fuel-purchases/:month_key
 *
 * Individual fuel card purchase transactions for one recovered month —
 * the procurement side of the supply chain (see
 * models/HistoricalFuelPurchase.js), distinct from field-visit
 * deliveries. Includes a by-vendor and by-station breakdown alongside
 * the raw transaction list.
 */
router.get('/fuel-purchases/:month_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { month_key } = req.params;
    const [transactions, byVendor, byStation] = await Promise.all([
      HistoricalFuelPurchase.find({ month_key }).sort({ purchase_date: 1 }).lean(),
      HistoricalFuelPurchase.aggregate([
        { $match: { month_key } },
        { $group: { _id: '$vendor', total_l: { $sum: { $ifNull: ['$quantity_l', 0] } }, total_xaf: { $sum: { $ifNull: ['$amount_xaf', 0] } }, count: { $sum: 1 } } },
        { $sort: { total_l: -1 } },
      ]),
      HistoricalFuelPurchase.aggregate([
        { $match: { month_key } },
        { $group: { _id: '$place', total_l: { $sum: { $ifNull: ['$quantity_l', 0] } }, count: { $sum: 1 } } },
        { $sort: { total_l: -1 } },
        { $limit: 15 },
      ]),
    ]);

    const summary = {
      total_transactions: transactions.length,
      total_l: transactions.reduce((s, t) => s + (t.quantity_l || 0), 0),
      total_xaf: transactions.reduce((s, t) => s + (t.amount_xaf || 0), 0),
    };

    res.json({ success: true, data: { month_key, transactions, by_vendor: byVendor, top_stations: byStation, summary } });
  })
);

/**
 * GET /api/diesel/historical/field-visits/:site_id
 *
 * Every recovered visit for one site, oldest first — the actual
 * delivered-to-site figure per visit, generator readings, and
 * technician-recorded status. The most granular view of any historical
 * data recovered so far (see models/HistoricalFieldVisit.js).
 */
router.get('/field-visits/:site_id',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const visits = await HistoricalFieldVisit.find({ site_id: req.params.site_id })
      .sort({ visit_date: 1 })
      .lean();
    res.json({ success: true, data: { site_id: req.params.site_id, visits } });
  })
);

/**
 * GET /api/diesel/historical/field-visits-summary/:month_key
 *
 * Fleet-wide summary of visit activity for one recovered month — total
 * visits, total delivered, and the sites with the most visits, for a
 * quick overview without pulling every individual record.
 */
router.get('/field-visits-summary/:month_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { month_key } = req.params;
    const [totals, bySite] = await Promise.all([
      HistoricalFieldVisit.aggregate([
        { $match: { month_key } },
        { $group: {
          _id: null,
          total_visits: { $sum: 1 },
          total_delivered_l: { $sum: { $ifNull: ['$fuel_added_l', 0] } },
          visits_with_delivery: { $sum: { $cond: [{ $gt: [{ $ifNull: ['$fuel_added_l', 0] }, 0] }, 1, 0] } },
        }},
      ]),
      HistoricalFieldVisit.aggregate([
        { $match: { month_key } },
        { $group: {
          _id: '$site_id',
          site_name: { $first: '$site_name' },
          cluster: { $first: '$cluster' },
          visit_count: { $sum: 1 },
          total_delivered_l: { $sum: { $ifNull: ['$fuel_added_l', 0] } },
        }},
        { $sort: { visit_count: -1 } },
        { $limit: 20 },
      ]),
    ]);

    res.json({
      success: true,
      data: {
        month_key,
        totals: totals[0] || { total_visits: 0, total_delivered_l: 0, visits_with_delivery: 0 },
        most_visited_sites: bySite,
      },
    });
  })
);

/**
 * GET /api/diesel/historical/debit-summary
 *
 * The fleet-level monthly settlement between Grato and IHS Towers —
 * submitted vs approved consumption, purchases, and the actual
 * debit/credit amount, across every recovered month that has this data
 * (see models/MonthlyDebitSummary.js — July genuinely has none).
 */
router.get('/debit-summary',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const months = await MonthlyDebitSummary.find({}).sort({ cycle_key: 1 }).lean();
    res.json({ success: true, data: { months } });
  })
);

/**
 * GET /api/diesel/historical/request-approval/:cycle_key
 *
 * The site-level "SBC Request" vs. IHS Towers-approved exchange — the
 * actual budget request step, done by email, upstream of everything
 * else recovered (see models/BudgetRequestApproval.js). Sorted by
 * variance so the sites where the biggest negotiation happened surface
 * first.
 */
router.get('/request-approval/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;
    const sites = await BudgetRequestApproval.find({ cycle_key })
      .sort({ variance_l: 1 })
      .lean();

    const withBoth = sites.filter(s => s.sbc_requested_l != null && s.ihs_approved_l != null);
    const summary = {
      total_sites: sites.length,
      sites_with_both_figures: withBoth.length,
      total_requested_l: withBoth.reduce((s, r) => s + r.sbc_requested_l, 0),
      total_approved_l: withBoth.reduce((s, r) => s + r.ihs_approved_l, 0),
      approved_less_count: withBoth.filter(r => r.variance_l < 0).length,
      approved_more_count: withBoth.filter(r => r.variance_l > 0).length,
      sites_with_comments: sites.filter(s => s.comments).length,
    };

    res.json({ success: true, data: { cycle_key, sites, summary } });
  })
);

/**
 * GET /api/diesel/historical/tomcard-allocations
 *
 * Tom Card cluster-level fuel funding — the "budget request" step
 * upstream of the per-site budget already tracked (see
 * models/TomCardAllocation.js). Currently a single recovered instance,
 * not a monthly series — returned as-is, not padded to imply more.
 */
/**
 * GET /api/diesel/historical/tomcard-allocations
 *
 * Cluster-level card funding/budget data — now spans two genuinely
 * different cycles in the same collection (December 2025's "Card
 * Limit" data, Phase 70, and January 2026's "TomCard Refill" funding,
 * Phase 64). Grouped by funded_cycle_key rather than returned as one
 * undifferentiated set — mixing two cycles' totals into one number
 * would be actively misleading, not just imprecise.
 */
router.get('/tomcard-allocations',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const allocations = await TomCardAllocation.find({}).sort({ funded_cycle_key: 1, cluster: 1 }).lean();

    const byCycle = new Map();
    for (const a of allocations) {
      const key = a.funded_cycle_key;
      if (!byCycle.has(key)) {
        byCycle.set(key, { funded_cycle_key: key, allocations: [], totals: { quantity_l: 0, amount_xaf: 0 }, grand_total_xaf: a.grand_total_xaf ?? null });
      }
      const group = byCycle.get(key);
      group.allocations.push(a);
      group.totals.quantity_l += (a.quantity_l || a.budget_l || 0);
      group.totals.amount_xaf += (a.amount_xaf || a.budget_xaf || 0);
    }

    res.json({ success: true, data: { cycles: [...byCycle.values()] } });
  })
);

/**
 * GET /api/diesel/historical/mid-cycle-release/:release_cycle_key
 *
 * Progress on a mid-cycle partial budget release (see
 * models/MidCycleBudgetRelease.js) — per-site delivered-vs-released
 * status plus the cluster-level daily delivery trend from the source
 * file's own Recap sheet.
 */
router.get('/mid-cycle-release/:release_cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { release_cycle_key } = req.params;

    const [sites, dailyProgress] = await Promise.all([
      MidCycleBudgetRelease.find({ release_cycle_key })
        .select('site_id site_name cluster region delivered_l released_budget_l variance_l to_be_added_l tier_50pct_l tier_80pct_l')
        .sort({ variance_l: -1 })
        .lean(),
      MidCycleReleaseDailyProgress.find({ release_cycle_key }).sort({ date: 1 }).lean(),
    ]);

    const summary = {
      total_sites: sites.length,
      total_delivered_l: sites.reduce((s, r) => s + (r.delivered_l || 0), 0),
      total_released_l: sites.reduce((s, r) => s + (r.released_budget_l || 0), 0),
      sites_ahead_of_release: sites.filter(s => (s.variance_l || 0) < 0).length, // delivered more than currently released
      sites_behind_release: sites.filter(s => (s.variance_l || 0) > 0).length,
    };

    // Cluster-level daily trend, pivoted for easy charting.
    const byDate = {};
    for (const r of dailyProgress) {
      const key = r.date.toISOString().slice(0, 10);
      if (!byDate[key]) byDate[key] = { date: key };
      byDate[key][r.cluster] = r.delivered_l;
    }

    res.json({
      success: true,
      data: {
        release_cycle_key,
        sites,
        daily_trend: Object.values(byDate).sort((a, b) => a.date.localeCompare(b.date)),
        clusters: [...new Set(dailyProgress.map(r => r.cluster))],
        summary,
      },
    });
  })
);

/**
 * GET /api/diesel/historical/adhoc-requests
 *
 * Ad-hoc/emergency fuel requests recovered from email archives — outside
 * the normal monthly budget cycle (see models/AdHocFuelRequest.js).
 * Returns a daily timeline (for a trend view of the shortage response)
 * plus a per-site breakdown (which sites needed emergency fuel most).
 */
router.get('/adhoc-requests',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const byDate = await AdHocFuelRequest.aggregate([
      { $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$planned_date' } },
        total_l: { $sum: '$quantity_requested_l' },
        request_count: { $sum: 1 },
      }},
      { $sort: { _id: 1 } },
      { $project: { _id: 0, date: '$_id', total_l: 1, request_count: 1 } },
    ]);

    // Month-by-month detail — not just a monthly total, but the full
    // per-site breakdown within each month, since a single aggregate
    // number per month hides exactly the detail a manager would need to
    // act on (which sites, how many requests, how much each).
    //
    // Isolated before merged, same principle as /full-summary: each
    // site's `requests` array below carries every individual round it
    // was part of that month exactly as submitted (round, source file,
    // date, requested/approved/delivered, decision status) — the
    // site-level total_l/approved_l/delivered_l are that array merged,
    // never the only thing returned. A request with a null approved_l
    // is "no decision recorded," genuinely different from an explicit
    // 0L rejection — kept as separate counts, not folded together.
    //
    // Approved_l/delivered_l are real sums, not fabricated for months
    // that lack them: MongoDB's $sum naturally treats a missing/null
    // field as 0 when aggregating, so a month with no approval data at
    // all shows 0 here rather than an invented figure — the frontend
    // distinguishes "0" from "not tracked this month" by checking
    // has_approval_data. As of Phase 101/102, that now covers every
    // month December 2025 through July 2026, not just March.
    const byMonth = await AdHocFuelRequest.aggregate([
      { $addFields: { month_key: { $dateToString: { format: '%Y-%m', date: '$planned_date' } } } },
      { $sort: { planned_date: 1 } },
      { $addFields: {
        decision_status: {
          $switch: {
            branches: [
              // Same fix as /full-summary's identical switch above: a bare
              // `$ne` against `null` misclassifies a field that's entirely
              // absent (every record from the original July/August
              // tracker, which never had a delivered column) as
              // "delivered" — MongoDB's aggregation framework doesn't
              // treat missing as equal to explicit null here. $ifNull
              // normalizes both to null first, so only a genuine delivered
              // figure (0 included) takes this branch.
              { case: { $ne: [{ $ifNull: ['$delivered_l', null] }, null] }, then: 'delivered' },
              { case: { $eq: ['$approved_l', 0] }, then: 'rejected' },
              { case: { $gt: ['$approved_l', 0] }, then: 'approved' },
            ],
            default: 'pending',
          },
        },
      }},
      { $group: {
        _id: { month_key: '$month_key', site_id: '$site_id' },
        site_name: { $first: '$site_name' },
        cluster: { $first: '$cluster' },
        total_l: { $sum: '$quantity_requested_l' },
        approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
        delivered_l: { $sum: { $ifNull: ['$delivered_l', 0] } },
        has_approval_data: { $max: { $ne: ['$approved_l', null] } },
        request_count: { $sum: 1 },
        pending_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'pending'] }, 1, 0] } },
        rejected_count: { $sum: { $cond: [{ $eq: ['$decision_status', 'rejected'] }, 1, 0] } },
        dates: { $push: { $dateToString: { format: '%Y-%m-%d', date: '$planned_date' } } },
        // The isolated requests themselves, preserved alongside the
        // per-site merge above — untouched, not just a date string.
        requests: { $push: {
          request_round: '$request_round',
          source_file: '$source_file',
          date: { $dateToString: { format: '%Y-%m-%d', date: '$planned_date' } },
          requested_l: '$quantity_requested_l',
          approved_l: '$approved_l',
          delivered_l: '$delivered_l',
          status: '$decision_status',
        }},
      }},
      { $sort: { total_l: -1 } },
      { $group: {
        _id: '$_id.month_key',
        total_l: { $sum: '$total_l' },
        total_approved_l: { $sum: '$approved_l' },
        total_delivered_l: { $sum: '$delivered_l' },
        has_approval_data: { $max: '$has_approval_data' },
        request_count: { $sum: '$request_count' },
        pending_count: { $sum: '$pending_count' },
        rejected_count: { $sum: '$rejected_count' },
        unique_sites: { $sum: 1 },
        sites: { $push: {
          site_id: '$_id.site_id', site_name: '$site_name', cluster: '$cluster',
          total_l: '$total_l', approved_l: '$approved_l', delivered_l: '$delivered_l',
          request_count: '$request_count', dates: '$dates', requests: '$requests',
        }},
      }},
      { $sort: { _id: 1 } },
      { $project: { _id: 0, month_key: '$_id', total_l: 1, total_approved_l: 1, total_delivered_l: 1, has_approval_data: 1, request_count: 1, pending_count: 1, rejected_count: 1, unique_sites: 1, sites: 1 } },
    ]);

    const bySite = await AdHocFuelRequest.aggregate([
      { $group: {
        _id: '$site_id',
        site_name: { $first: '$site_name' },
        cluster: { $first: '$cluster' },
        total_l: { $sum: '$quantity_requested_l' },
        request_count: { $sum: 1 },
        dates: { $push: { $dateToString: { format: '%Y-%m-%d', date: '$planned_date' } } },
      }},
      { $sort: { total_l: -1 } },
      { $limit: 30 },
    ]);

    const totals = await AdHocFuelRequest.aggregate([
      { $group: { _id: null, total_l: { $sum: '$quantity_requested_l' }, total_requests: { $sum: 1 }, unique_sites: { $addToSet: '$site_id' } } },
    ]);

    res.json({
      success: true,
      data: {
        by_date: byDate,
        by_month: byMonth,
        top_sites: bySite,
        summary: {
          total_l: totals[0]?.total_l ?? 0,
          total_requests: totals[0]?.total_requests ?? 0,
          unique_sites: totals[0]?.unique_sites?.length ?? 0,
        },
      },
    });
  })
);

/**
 * GET /api/diesel/historical/summary
 * GET /api/diesel/historical/summary?since=2025-12
 *
 * Fleet-wide picture across every recovered month — total budget vs
 * actual consumption, how many sites exhausted their allocation, and
 * the reserve trend over time. This is the direct answer to "was
 * whatever was requested ever exhausted."
 *
 * Phase 151 — optional `since` query param (a month_key, e.g.
 * "2025-12"), added because this endpoint has two real callers with
 * two genuinely different needs: HistoricalDataPage.tsx uses
 * `months_covered` to populate its own per-month dropdown, where every
 * recovered month (this system does have real April 2025 onward data,
 * from Phase 88) is legitimately useful; History Analysis's Global
 * Summary tab is explicitly framed, same as every other page in this
 * feature, as "December 2025 onward" — its trend charts showing
 * May 2025 as their starting point was a real reported bug, not
 * intentional. Rather than silently change what every caller gets
 * (which would have quietly removed the April–November 2025 months
 * from the Historical Data page's dropdown, never reported as a
 * problem), this is opt-in: omitted, behavior is 100% unchanged,
 * every recovered month included, exactly as before. The Global
 * Summary tab now passes `since=2025-12` explicitly.
 */
router.get('/summary',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { since } = req.query; // e.g. "2025-12" — see docblock above
    const monthMatch = since ? [{ $match: { month_key: { $gte: since } } }] : [];

    const byMonth = await HistoricalMonthlyRecord.aggregate([
      ...monthMatch,
      { $group: {
        _id: '$month_key',
        site_count: { $sum: 1 },
        sites_with_budget: { $sum: { $cond: [{ $ne: ['$budget_liters', null] }, 1, 0] } },
        total_budget_l: { $sum: { $ifNull: ['$budget_liters', 0] } },
        total_consumption_l: { $sum: { $ifNull: ['$final_consumption_l', 0] } },
        total_reserve_l: { $sum: { $ifNull: ['$reserve_liters', 0] } },
        exhausted_count: { $sum: { $cond: [{ $eq: ['$fully_exhausted', true] }, 1, 0] } },
        theft_flagged_count: { $sum: { $cond: [{ $gt: [{ $ifNull: ['$theft_liters', 0] }, 0] }, 1, 0] } },
        avg_rh_variance: { $avg: '$rh_variance' },
      }},
      { $sort: { _id: 1 } },
      { $project: {
        _id: 0, month_key: '$_id', site_count: 1, sites_with_budget: 1,
        total_budget_l: { $round: ['$total_budget_l', 0] },
        total_consumption_l: { $round: ['$total_consumption_l', 0] },
        total_reserve_l: { $round: ['$total_reserve_l', 0] },
        exhausted_count: 1, theft_flagged_count: 1,
        avg_rh_variance: { $round: ['$avg_rh_variance', 1] },
      }},
    ]);

    // ── Carried-over stock burn, fleet-wide, per month — Phase 165.
    // carriedOverStockBurn() needs one site's own visits for one CYCLE,
    // in visit_date order, so this groups by (site_id, month_key)
    // together, not by site_id alone (a site's visits span many
    // months). Then rolled up to a per-month fleet total, same
    // exclude-rather-than-zero rule as everywhere else this figure
    // appears.
    const cobVisits = await HistoricalFieldVisit.find(since ? { month_key: { $gte: since } } : {})
      .select('site_id month_key visit_date fuel_previously_left_l fuel_found_l fuel_added_l fuel_left_l days_since_last_visit')
      .sort({ site_id: 1, month_key: 1, visit_date: 1 })
      .lean();
    const visitsBySiteMonth = new Map(); // "site_id|month_key" -> visits[]
    for (const v of cobVisits) {
      const key = `${v.site_id}|${v.month_key}`;
      if (!visitsBySiteMonth.has(key)) visitsBySiteMonth.set(key, []);
      visitsBySiteMonth.get(key).push(v);
    }
    const cobByMonth = new Map(); // month_key -> { total_l, sites_reporting }
    for (const [key, visits] of visitsBySiteMonth) {
      const month_key = key.split('|')[1];
      const cob = carriedOverStockBurn(visits);
      if (cob.net_change_l == null) continue;
      if (!cobByMonth.has(month_key)) cobByMonth.set(month_key, { total_l: 0, sites_reporting: 0 });
      const agg = cobByMonth.get(month_key);
      agg.total_l += cob.net_change_l;
      agg.sites_reporting += 1;
    }
    for (const m of byMonth) {
      const cob = cobByMonth.get(m.month_key);
      m.carried_over_stock_burn_l = cob ? Math.round(cob.total_l) : null;
      m.carried_over_stock_burn_sites_reporting = cob?.sites_reporting ?? 0;
    }

    // ── Has Stock vs No Stock, fleet-wide, per month — Phase 168.
    // Replaces "Sites Exhausted vs Has Reserve" on the Global Summary
    // chart with a physical reading instead of a budget one: does this
    // site's own LAST visit of the cycle show fuel_left_l > 0 or not?
    // Reuses visitsBySiteMonth (already grouped/sorted) — no new query.
    // A site with no reading this cycle is excluded from both buckets,
    // not assumed either way.
    const stockStatusByMonth = new Map(); // month_key -> { has_stock, no_stock }
    for (const [key, visits] of visitsBySiteMonth) {
      const month_key = key.split('|')[1];
      const last = visits[visits.length - 1];
      const stock_l = last?.fuel_left_l ?? null;
      if (stock_l == null) continue;
      if (!stockStatusByMonth.has(month_key)) stockStatusByMonth.set(month_key, { has_stock: 0, no_stock: 0 });
      const agg = stockStatusByMonth.get(month_key);
      if (stock_l > 0) agg.has_stock += 1; else agg.no_stock += 1;
    }
    for (const m of byMonth) {
      const st = stockStatusByMonth.get(m.month_key);
      m.has_stock_count = st?.has_stock ?? 0;
      m.no_stock_count = st?.no_stock ?? 0;
      m.stock_status_sites_reporting = st ? (st.has_stock + st.no_stock) : 0;
    }

    // ── Gain / Loss, fleet-wide, per month — Phase 167. Reuses
    // visitsBySiteMonth (already grouped by site_id + cycle, ascending
    // by visit_date) so each cycle's "first visit" is correct without a
    // second visits query. Needs each site-month's own validated
    // final_consumption_l too, which the byMonth aggregate above only
    // has as a fleet SUM — so a lightweight per-site-month lookup is
    // fetched separately here.
    const consumptionRows = await HistoricalMonthlyRecord.find(since ? { month_key: { $gte: since } } : {})
      .select('site_id month_key final_consumption_l')
      .lean();
    const consumedBySiteMonth = new Map(consumptionRows.map(r => [`${r.site_id}|${r.month_key}`, r.final_consumption_l ?? null]));
    const gainLossByMonth = new Map(); // month_key -> { total_l, sites_reporting }
    for (const [key, visits] of visitsBySiteMonth) {
      const month_key = key.split('|')[1];
      const delivered_l = visits.reduce((s, v) => s + (v.fuel_added_l || 0), 0);
      const gl = computeGainLoss(visits, delivered_l, consumedBySiteMonth.get(key) ?? null);
      if (gl.gain_loss_l == null) continue;
      if (!gainLossByMonth.has(month_key)) gainLossByMonth.set(month_key, { total_l: 0, sites_reporting: 0 });
      const agg = gainLossByMonth.get(month_key);
      agg.total_l += gl.gain_loss_l;
      agg.sites_reporting += 1;
    }
    for (const m of byMonth) {
      const gl = gainLossByMonth.get(m.month_key);
      m.gain_loss_l = gl ? Math.round(gl.total_l) : null;
      m.gain_loss_sites_reporting = gl?.sites_reporting ?? 0;
    }

    // Sites that show up as exhausted in EVERY month they have budget
    // data for — a much stronger, more actionable signal than any
    // single month's exhaustion on its own. Same `since` filter applied
    // here too, so a site's "chronically exhausted" streak (and its
    // months_with_budget/months_exhausted denominator) reflects the
    // same window as the chart above it, not a silently wider one.
    const perSite = await HistoricalMonthlyRecord.aggregate([
      { $match: { budget_liters: { $ne: null }, ...(since ? { month_key: { $gte: since } } : {}) } },
      { $group: {
        _id: '$site_id',
        site_name: { $first: '$site_name' },
        cluster: { $first: '$cluster' },
        months_with_budget: { $sum: 1 },
        months_exhausted: { $sum: { $cond: [{ $eq: ['$fully_exhausted', true] }, 1, 0] } },
        avg_reserve_l: { $avg: '$reserve_liters' },
      }},
      { $match: { $expr: { $eq: ['$months_with_budget', '$months_exhausted'] } } },
      { $sort: { avg_reserve_l: 1 } },
      { $limit: 20 },
    ]);

    res.json({
      success: true,
      data: {
        by_month: byMonth,
        chronically_exhausted_sites: perSite,
        months_covered: byMonth.map(m => m.month_key),
      },
    });
  })
);

/**
 * GET /api/diesel/historical/reserves/:month_key
 *
 * Site-by-site reserve status for one month — every site with a budget
 * figure, sorted by how much reserve remains (or how far over they
 * went), so the sites most worth looking at surface first.
 */
router.get('/reserves/:month_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { month_key } = req.params;
    const records = await HistoricalMonthlyRecord.find({ month_key })
      .select('site_id site_name cluster region budget_liters final_consumption_l reserve_liters fully_exhausted final_rh cms_rh rh_variance sign_off_status source_file')
      .sort({ reserve_liters: 1 })
      .lean();

    res.json({ success: true, data: { month_key, sites: records } });
  })
);

/**
 * GET /api/diesel/historical/site/:site_id
 *
 * Full chronological history for one site — every recovered month, for
 * trend charting. Phase 165: each month's entry also gets its own
 * `carried_over_stock_burn` (see carriedOverStockBurn() docblock) —
 * this site's own visits, grouped by month_key so each cycle's figure
 * only sees that cycle's own visits, same rule as everywhere else this
 * appears.
 */
router.get('/site/:site_id',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { site_id } = req.params;
    const [history, visits] = await Promise.all([
      HistoricalMonthlyRecord.getSiteHistory(site_id),
      HistoricalFieldVisit.find({ site_id })
        .select('month_key visit_date fuel_previously_left_l fuel_found_l fuel_added_l days_since_last_visit')
        .sort({ month_key: 1, visit_date: 1 })
        .lean(),
    ]);
    const visitsByMonth = new Map();
    for (const v of visits) {
      if (!visitsByMonth.has(v.month_key)) visitsByMonth.set(v.month_key, []);
      visitsByMonth.get(v.month_key).push(v);
    }
    const historyWithBurn = history.map(h => {
      const monthVisits = visitsByMonth.get(h.month_key) || [];
      const delivered_l = monthVisits.reduce((s, v) => s + (v.fuel_added_l || 0), 0);
      return {
        ...h,
        carried_over_stock_burn: carriedOverStockBurn(monthVisits),
        // Phase 167 — see computeGainLoss() docblock. h.final_consumption_l
        // is this same site-month's validated consumption, already on the
        // getSiteHistory() record.
        gain_loss: computeGainLoss(monthVisits, delivered_l, h.final_consumption_l ?? null),
      };
    });
    res.json({ success: true, data: { site_id, history: historyWithBurn } });
  })
);

/**
 * Shared decision-status classifier for an ad-hoc/extra-fuel request,
 * applied here as a plain JS function (these two new endpoints work on
 * already-`.lean()`-fetched arrays, not a live aggregation pipeline) —
 * same three-way logic as the $switch blocks above
 * (full-summary/adhoc-requests), and the same care: `r.delivered_l !=
 * null` is false for BOTH `undefined` (field absent — every record from
 * the original July/August source) and an explicit `null`, so a record
 * that never had a delivered_l column at all is correctly left out of
 * 'delivered' rather than misclassified into it (the Phase 142 bug,
 * re-verified not to recur here since this is a direct JS comparison,
 * not a Mongo `$ne` against a possibly-missing field).
 */
function classifyDecisionStatus(r) {
  if (r.delivered_l != null) return 'delivered';
  if (r.approved_l === 0) return 'rejected';
  if (r.approved_l > 0) return 'approved';
  return 'pending';
}

function cycleDateRange(cycle_key) {
  const [year, month] = cycle_key.split('-').map(Number);
  return {
    monthStart: new Date(Date.UTC(year, month - 1, 1)),
    monthEnd: new Date(Date.UTC(year, month, 1)),
  };
}

// carriedOverStockBurn / cycleEngineeringFigures / consumptionStability / computeGainLoss now live in services/historicalMetrics.js (Phase 169) — see that file's docblock.

/**
 * GET /api/diesel/historical/site-cycle-report/:site_id/:cycle_key
 *
 * "Everything that was ever done for and on that site for that cycle" —
 * one consolidated view, cycle by cycle, joining every relevant
 * historical collection for a single site:
 *
 *  - the regular request/approval exchange (BudgetRequestApproval)
 *  - extra/emergency fuel requests that cycle, isolated before merged
 *    (AdHocFuelRequest) — same principle as /full-summary and
 *    /adhoc-requests: `extra_fuel.requests` is the untouched per-round
 *    detail, `extra_fuel.totals` is that same array merged, never the
 *    only thing returned
 *  - Total Requested / Total Approved = the regular request/approval
 *    figure PLUS the extra-fuel figure — each returned with its two
 *    components broken out (`initial_*` / `extra_fuel_*`) alongside the
 *    combined total, and `*_is_partial: true` whenever only one
 *    component has real data, so a partial sum is never presented as if
 *    it were complete
 *  - the full field-visit log for the cycle (HistoricalFieldVisit),
 *    exactly the columns already shown in the existing all-time "Full
 *    Recovered History" panel (meter reading, RH, fuel found/added/left,
 *    generator status), plus two NEW per-visit derived fields:
 *    `interval_true_cph` and `interval_hours` (see below)
 *  - `delivered_to_site_l` — the sum of `fuel_added_l` across this
 *    cycle's own visits (genuinely different from AdHocFuelRequest's own
 *    rarely-populated `delivered_l` — this is the real, field-recorded
 *    figure, matching Phase 141/142's established distinction between
 *    the two "delivered" concepts)
 *  - Consumed / Reserve liters and Generator KVA / Contractual CPH, each
 *    with a `source` label naming exactly which collection it came from
 *
 * ── Approximate True CPH (new, Phase 143) ───────────────────────────────
 * The Contractual CPH (`genset_cph`) is a planning input, fixed ahead of
 * time. This is the ACTUAL rate the generator burned fuel at, backed out
 * from two consecutive real field visits.
 *
 * The source template turns out to already carry everything needed on a
 * SINGLE visit row, self-contained — no need to look up the
 * chronologically-previous visit at all: `fuel_previously_left_l`
 * ("QTY OF FUEL PREVIOUSLY Left") is recorded directly on the current
 * visit's own row, and is exactly the previous visit's own
 * `fuel_left_l` (verified directly against the real July source file:
 * Apouh's 7/8/2026 row records fuel_previously_left_l = 150, which is
 * exactly 7/7/2026's own recorded fuel_left_l — the two agree exactly
 * across all 6 of Apouh's July visits checked). `run_hours` ("RH") is
 * likewise hours run SINCE the previous visit, not a cumulative total —
 * confirmed against the user's own numbers (37 hours between exactly
 * those two dates). So, per visit v:
 *
 *   consumed_l  = v.fuel_previously_left_l - v.fuel_found_l
 *   true_cph    = consumed_l / v.run_hours
 *
 * Worked example (Apouh, 7/8/2026 visit): fuel_previously_left_l = 150
 * (0 found + 150 added on 7/7), fuel_found_l = 47, run_hours = 37 =>
 * consumed_l = 150 - 47 = 103L, true_cph = 103 / 37 = 2.78 L/hr — matches
 * the user's own worked example exactly. Hand-checked against all 5
 * other Apouh visits that same July: consistently 2.75-2.81 L/hr, a
 * believably stable rate for one generator, not noise.
 *
 * Every visit in the whole recovered history carries its own interval
 * this way (self-contained per row), so this is computed straight off
 * `cycleVisits` — no separate full-history pairing pass needed, and no
 * risk of mismatching visits if two happen on the same date or the sort
 * order has a gap. `crosses_cycle_boundary: true` is set whenever the
 * visit's own `previous_visit_date` falls in a different calendar month
 * than the visit itself, so the frontend can show honestly that the
 * interval didn't happen entirely within this cycle, rather than
 * implying it did. A negative consumed_l (found more fuel than was
 * left) is not hidden — returned with `anomaly: true` rather than
 * silently clamped, since that's real data worth a manager's attention
 * (a theft-adjacent reading, a meter reset, or a recording error), not
 * this endpoint's to interpret away.
 *
 * `avg_true_cph_this_cycle` is the hours-weighted average of every
 * interval whose LATER visit falls in this cycle, compared directly
 * against `engineering.contractual_cph` with a signed variance —
 * answering the user's own framing ("compare it to the CCPH").
 */
router.get('/site-cycle-report/:site_id/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { site_id, cycle_key } = req.params;
    const { monthStart, monthEnd } = cycleDateRange(cycle_key);

    const [monthly, approval, engParams, adhocRaw, allVisits] = await Promise.all([
      HistoricalMonthlyRecord.findOne({ site_id, month_key: cycle_key }).lean(),
      BudgetRequestApproval.findOne({ site_id, cycle_key }).lean(),
      SiteEngineeringParams.findOne({ site_id }).lean(),
      AdHocFuelRequest.find({ site_id, planned_date: { $gte: monthStart, $lt: monthEnd } })
        .sort({ planned_date: 1 }).lean(),
      // ALL visits, not just this cycle's — the True CPH interval
      // ending this cycle's first visit needs the visit before it,
      // which usually belongs to the previous cycle.
      HistoricalFieldVisit.find({ site_id }).sort({ visit_date: 1 }).lean(),
    ]);

    if (!monthly && !approval && !engParams && adhocRaw.length === 0 && allVisits.length === 0) {
      return res.status(404).json({ success: false, error: `No historical data found for site "${site_id}"` });
    }

    const site_name = monthly?.site_name || approval?.site_name || engParams?.site_name
      || allVisits.find(v => v.site_name)?.site_name || null;
    const cluster = monthly?.cluster || approval?.cluster || engParams?.cluster
      || allVisits.find(v => v.cluster)?.cluster || null;
    const region = monthly?.region || approval?.region || engParams?.region || null;
    const topology = monthly?.topology || approval?.topology || engParams?.topology || null;

    // ── Extra fuel — isolated, then merged, exactly per Phase 141's rule ──
    const extraFuelRequests = adhocRaw.map(r => ({
      request_round: r.request_round,
      source_file: r.source_file,
      planned_date: r.planned_date,
      requested_l: r.quantity_requested_l,
      approved_l: r.approved_l ?? null,
      delivered_l: r.delivered_l ?? null,
      status: classifyDecisionStatus(r),
    }));
    const extraFuelTotals = extraFuelRequests.reduce((acc, r) => {
      acc.requested_l += r.requested_l || 0;
      acc.approved_l += r.approved_l || 0;
      acc.delivered_l += r.delivered_l || 0;
      acc[`${r.status}_count`] = (acc[`${r.status}_count`] || 0) + 1;
      return acc;
    }, { requested_l: 0, approved_l: 0, delivered_l: 0, approved_count: 0, rejected_count: 0, pending_count: 0, delivered_count: 0 });

    // ── Total Requested / Total Approved — two components, never silently summed ──
    const initial_requested_l = approval?.sbc_requested_l ?? null;
    const initial_approved_l = approval?.ihs_approved_l ?? monthly?.budget_liters ?? null;
    const extra_fuel_requested_l = extraFuelRequests.length ? extraFuelTotals.requested_l : null;
    const extra_fuel_approved_l = extraFuelRequests.length ? extraFuelTotals.approved_l : null;

    const total_requested = {
      initial_l: initial_requested_l,
      extra_fuel_l: extra_fuel_requested_l,
      total_l: (initial_requested_l == null && extra_fuel_requested_l == null) ? null
        : (initial_requested_l || 0) + (extra_fuel_requested_l || 0),
      is_partial: (initial_requested_l == null) !== (extra_fuel_requested_l == null),
    };
    const total_approved = {
      initial_l: initial_approved_l,
      extra_fuel_l: extra_fuel_approved_l,
      total_l: (initial_approved_l == null && extra_fuel_approved_l == null) ? null
        : (initial_approved_l || 0) + (extra_fuel_approved_l || 0),
      is_partial: (initial_approved_l == null) !== (extra_fuel_approved_l == null),
    };

    // ── Engineering: Generator KVA + Contractual CPH, each with provenance ──
    let generator_kva = null, generator_kva_source = null;
    if (engParams?.actual_dg_kva != null) { generator_kva = engParams.actual_dg_kva; generator_kva_source = 'SiteEngineeringParams.actual_dg_kva'; }
    else if (engParams?.genset_capacity_mapped_kva != null) { generator_kva = engParams.genset_capacity_mapped_kva; generator_kva_source = 'SiteEngineeringParams.genset_capacity_mapped_kva'; }
    else {
      const withKva = [...allVisits].reverse().find(v => v.generator_capacity_kva != null);
      if (withKva) { generator_kva = withKva.generator_capacity_kva; generator_kva_source = `HistoricalFieldVisit (${withKva.visit_date?.toISOString?.().slice(0, 10)})`; }
    }

    let contractual_cph = null, contractual_cph_source = null;
    if (approval?.genset_cph != null) { contractual_cph = approval.genset_cph; contractual_cph_source = `BudgetRequestApproval (${cycle_key} approved budget)`; }
    else if (engParams?.genset_cph != null) { contractual_cph = engParams.genset_cph; contractual_cph_source = 'SiteEngineeringParams.genset_cph (current, not cycle-specific)'; }

    // ── Visit log for this cycle, each with its own self-contained True CPH interval ──
    function prevVisitMonthKey(v) {
      if (!v.previous_visit_date) return null;
      const d = new Date(v.previous_visit_date);
      return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
    }
    const cycleVisits = allVisits
      .filter(v => v.month_key === cycle_key)
      .map(v => {
        const hasInterval = v.fuel_previously_left_l != null && v.fuel_found_l != null && !!v.run_hours;
        const consumed_l = hasInterval ? v.fuel_previously_left_l - v.fuel_found_l : null;
        return {
          visit_date: v.visit_date,
          generator_meter_reading: v.generator_meter_reading,
          run_hours: v.run_hours,
          fuel_found_l: v.fuel_found_l,
          fuel_added_l: v.fuel_added_l,
          fuel_left_l: v.fuel_left_l,
          generator_status: v.generator_status,
          generator_visual_check: v.generator_visual_check,
          interval_consumed_l: consumed_l,
          interval_true_cph: hasInterval ? Math.round((consumed_l / v.run_hours) * 100) / 100 : null,
          interval_anomaly: hasInterval ? consumed_l < 0 : null,
          interval_crosses_cycle_boundary: hasInterval ? (prevVisitMonthKey(v) != null && prevVisitMonthKey(v) !== v.month_key) : null,
        };
      });
    const delivered_to_site_l = cycleVisits.reduce((s, v) => s + (v.fuel_added_l || 0), 0);

    // ── End-of-cycle stock — the last field visit's own tank-dip
    // reading (fuel_left_l), NOT a derived/estimated figure. Distinct
    // from `reserve_l` below: reserve is budget minus consumption, a
    // paper calculation; this is what a technician actually measured
    // on site on their last visit of the cycle. cycleVisits is already
    // sorted ascending by visit_date (inherited from allVisits), so the
    // last entry is the most recent visit this cycle. Null when no
    // visit this cycle recorded a stock reading — not assumed to be 0.
    const lastVisitThisCycle = cycleVisits.length ? cycleVisits[cycleVisits.length - 1] : null;
    const end_of_cycle_stock = {
      stock_l: lastVisitThisCycle?.fuel_left_l ?? null,
      as_of_date: lastVisitThisCycle?.visit_date ?? null,
      is_last_visit_of_cycle: !!lastVisitThisCycle,
      note: !lastVisitThisCycle
        ? 'No field visit recorded this cycle.'
        : (lastVisitThisCycle.fuel_left_l == null
          ? 'Last visit this cycle did not record a fuel_left_l reading.'
          : null),
    };

    // ── Carried-over stock burned — net change in physical stock this
    // cycle (Phase 165, redefined Phase 168). See carriedOverStockBurn()
    // docblock below — computed from this site's own RAW visits this
    // cycle (allVisits, already sorted ascending), not the display-mapped
    // cycleVisits array, since the helper needs fuel_found_l/fuel_left_l
    // directly and is shared verbatim across every route that uses it.
    const carried_over_stock_burn = carriedOverStockBurn(allVisits.filter(v => v.month_key === cycle_key));

    const thisCycleIntervals = cycleVisits.filter(v => v.interval_true_cph != null);
    let avg_true_cph_this_cycle = null;
    if (thisCycleIntervals.length) {
      const totalHours = thisCycleIntervals.reduce((s, v) => s + v.run_hours, 0);
      const totalConsumed = thisCycleIntervals.reduce((s, v) => s + v.interval_consumed_l, 0);
      avg_true_cph_this_cycle = totalHours ? Math.round((totalConsumed / totalHours) * 100) / 100 : null;
    }
    const true_cph_vs_contractual = (avg_true_cph_this_cycle != null && contractual_cph != null)
      ? Math.round((avg_true_cph_this_cycle - contractual_cph) * 100) / 100
      : null;
    // Phase 168 — same stability figure as the bulk sortable listings,
    // reusing thisCycleIntervals (already has interval_true_cph per entry).
    const consumption_stability = consumptionStability(thisCycleIntervals);

    // ── Gain / Loss — Phase 167. Replaces the budget-based Reserve figure
    // on the display side with a purely physical reconciliation, per the
    // user's own formula. See computeGainLoss() docblock above. Uses
    // allVisits (not cycleVisits) filtered to this cycle so the "first
    // visit" is the true chronological first, same contract as
    // carried_over_stock_burn just above. reserve_l/fully_exhausted below
    // are left untouched — they still feed the separate Chronically
    // Exhausted Sites feature in Global Summary.
    const gain_loss = computeGainLoss(
      allVisits.filter(v => v.month_key === cycle_key),
      delivered_to_site_l,
      monthly?.final_consumption_l ?? null
    );

    res.json({
      success: true,
      data: {
        site_id, site_name, cluster, region, topology, cycle_key,
        request_approval: approval ? {
          sbc_requested_l: approval.sbc_requested_l,
          ihs_approved_l: approval.ihs_approved_l,
          variance_l: approval.variance_l,
          comments: approval.comments,
        } : null,
        extra_fuel: { requests: extraFuelRequests, totals: extraFuelTotals },
        total_requested,
        total_approved,
        visits: cycleVisits,
        visits_this_cycle_count: cycleVisits.length,
        delivered_to_site_l,
        consumed_l: monthly?.final_consumption_l ?? null,
        reserve_l: monthly?.reserve_liters ?? null,
        gain_loss,
        end_of_cycle_stock,
        carried_over_stock_burn,
        fully_exhausted: monthly?.fully_exhausted ?? null,
        sign_off_status: monthly?.sign_off_status ?? null,
        engineering: {
          generator_kva, generator_kva_source,
          contractual_cph, contractual_cph_source,
          avg_true_cph_this_cycle,
          true_cph_vs_contractual,
          interval_count_this_cycle: thisCycleIntervals.length,
          run_hours_total_this_cycle: cycleVisits.reduce((s, v) => s + (v.run_hours || 0), 0),
          consumption_stability,
        },
        coverage: {
          has_request_approval: !!approval,
          has_monthly_reconciliation: !!monthly,
          has_engineering_params: !!engParams,
          has_extra_fuel_requests: extraFuelRequests.length > 0,
          has_visits_this_cycle: cycleVisits.length > 0,
          has_true_cph_this_cycle: thisCycleIntervals.length > 0,
          has_end_of_cycle_stock: end_of_cycle_stock.stock_l != null,
          has_carried_over_stock_burn: carried_over_stock_burn.net_change_l != null,
          has_gain_loss: gain_loss.gain_loss_l != null,
        },
      },
    });
  })
);

/**
 * GET /api/diesel/historical/cluster-cycle-report/:cluster/:cycle_key
 *
 * The cluster-level counterpart to the site-cycle report above — "for
 * this cluster, this cycle": every site's request/approval and extra-
 * fuel activity (isolated, then merged into cluster totals), the actual
 * card purchase transactions, and the Tom Card Allocation / Fuel Card
 * Funding Request itself, including its mid-cycle extra-fuel round
 * approvals (Phase 102's `extra_round1/2/3_*` fields) laid out
 * explicitly rather than folded into one number.
 *
 * Purchases carry no site_id or cluster field of their own (see
 * models/HistoricalFuelPurchase.js's own comment) — they're attributed
 * to this cluster here via the card_number(s) on this cluster's own
 * TomCardAllocation rows for this cycle. This is a real but indirect
 * join: a purchase is only attributed when its card_number matches a
 * card this cluster's own funding document names for this exact cycle.
 * `purchases.unattributable_note` says so explicitly rather than
 * implying the purchase list is a complete accounting of the cluster's
 * spend.
 *
 * `monthly` (Phase 149) is the real, recovered budget/consumption/
 * reserve total for this cluster this cycle — a straight sum of this
 * cluster's own HistoricalMonthlyRecord rows, the same source the Site
 * Cycle Analysis tab's Consumed/Reserve columns use. It is genuinely
 * per-cluster, unlike the fleet-wide Debit/Credit XAF settlement (see
 * MonthlyDebitSummary's own comment): the frontend uses `monthly`'s
 * totals, together with the fleet-wide settlement fetched separately,
 * to compute an explicitly-labeled ESTIMATED proportional share of that
 * settlement for this cluster — never presented as a recorded figure.
 */
router.get('/cluster-cycle-report/:cluster/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { cluster, cycle_key } = req.params;
    const { monthStart, monthEnd } = cycleDateRange(cycle_key);

    const [approvals, monthlyRecords, adhocRaw, tomCardRows, midCycleRows, cycleVisitsRaw] = await Promise.all([
      BudgetRequestApproval.find({ cluster, cycle_key }).sort({ site_name: 1 }).lean(),
      HistoricalMonthlyRecord.find({ cluster, month_key: cycle_key }).lean(),
      AdHocFuelRequest.find({ cluster, planned_date: { $gte: monthStart, $lt: monthEnd } })
        .sort({ site_name: 1, planned_date: 1 }).lean(),
      TomCardAllocation.find({ cluster, funded_cycle_key: cycle_key }).lean(),
      MidCycleBudgetRelease.find({ cluster, release_cycle_key: cycle_key }).lean(),
      HistoricalFieldVisit.find({ cluster, month_key: cycle_key }).sort({ visit_date: 1 }).lean(),
    ]);

    if (!approvals.length && !monthlyRecords.length && !adhocRaw.length && !tomCardRows.length) {
      return res.status(404).json({ success: false, error: `No historical data found for cluster "${cluster}" in cycle "${cycle_key}"` });
    }

    // ── Regular request/approval, per site + cluster totals ────────────────
    const requestApproval = {
      sites: approvals.map(a => ({
        site_id: a.site_id, site_name: a.site_name,
        sbc_requested_l: a.sbc_requested_l, ihs_approved_l: a.ihs_approved_l, variance_l: a.variance_l,
      })),
      totals: approvals.reduce((acc, a) => {
        if (a.sbc_requested_l != null) acc.total_requested_l += a.sbc_requested_l;
        if (a.ihs_approved_l != null) acc.total_approved_l += a.ihs_approved_l;
        return acc;
      }, { total_requested_l: 0, total_approved_l: 0 }),
    };

    // ── Extra fuel — isolated per-request, then merged, same rule as everywhere else ──
    const extraFuelRequests = adhocRaw.map(r => ({
      site_id: r.site_id, site_name: r.site_name,
      request_round: r.request_round, source_file: r.source_file, planned_date: r.planned_date,
      requested_l: r.quantity_requested_l, approved_l: r.approved_l ?? null, delivered_l: r.delivered_l ?? null,
      status: classifyDecisionStatus(r),
    }));
    const extraFuelTotals = extraFuelRequests.reduce((acc, r) => {
      acc.requested_l += r.requested_l || 0;
      acc.approved_l += r.approved_l || 0;
      acc.delivered_l += r.delivered_l || 0;
      acc[`${r.status}_count`] = (acc[`${r.status}_count`] || 0) + 1;
      return acc;
    }, { requested_l: 0, approved_l: 0, delivered_l: 0, approved_count: 0, rejected_count: 0, pending_count: 0, delivered_count: 0 });

    // ── Tom Card Allocation, incl. mid-cycle extra rounds itemized ──────────
    const tomCard = tomCardRows.map(t => {
      const base_l = t.quantity_l ?? t.budget_l ?? 0;
      const base_xaf = t.amount_xaf ?? t.budget_xaf ?? 0;
      const extra_rounds_l = (t.extra_round1_approved_l || 0) + (t.extra_round2_approved_l || 0) + (t.extra_round3_approved_l || 0);
      const extra_rounds_xaf = (t.extra_round1_approved_xaf || 0) + (t.extra_round2_approved_xaf || 0) + (t.extra_round3_approved_xaf || 0);
      return {
        card_number: t.card_number, new_card_number: t.new_card_number ?? null, vendor: t.vendor,
        base_l, base_xaf,
        extra_round1_approved_l: t.extra_round1_approved_l ?? null,
        extra_round2_approved_l: t.extra_round2_approved_l ?? null,
        extra_round3_approved_l: t.extra_round3_approved_l ?? null,
        extra_rounds_comment: t.extra_rounds_comment ?? null,
        total_incl_extra_l: base_l + extra_rounds_l,
        total_incl_extra_xaf: base_xaf + extra_rounds_xaf,
        grand_total_xaf: t.grand_total_xaf ?? null,
      };
    });
    const tomCardTotals = tomCard.reduce((acc, t) => {
      acc.base_l += t.base_l; acc.base_xaf += t.base_xaf;
      acc.total_incl_extra_l += t.total_incl_extra_l; acc.total_incl_extra_xaf += t.total_incl_extra_xaf;
      return acc;
    }, { base_l: 0, base_xaf: 0, total_incl_extra_l: 0, total_incl_extra_xaf: 0 });

    // ── Purchases, attributed via card_number -> this cluster's own TomCard cards ──
    const clusterCardNumbers = new Set(
      tomCardRows.flatMap(t => [t.card_number, t.new_card_number].filter(Boolean))
    );
    let purchases = [], purchaseTotals = { total_l: 0, total_xaf: 0, count: 0 };
    if (clusterCardNumbers.size) {
      purchases = await HistoricalFuelPurchase.find({
        month_key: cycle_key,
        card_number: { $in: [...clusterCardNumbers] },
      }).sort({ purchase_date: 1 }).lean();
      purchaseTotals = purchases.reduce((acc, p) => {
        acc.total_l += p.quantity_l || 0;
        acc.total_xaf += p.amount_xaf || 0;
        acc.count += 1;
        return acc;
      }, { total_l: 0, total_xaf: 0, count: 0 });
    }

    // ── Reconciled monthly budget/consumption/reserve, per site + cluster
    // totals — Phase 149. This was already being fetched above (for
    // site_count) but never surfaced as its own totals. It's the same
    // HistoricalMonthlyRecord data the Site Cycle Analysis tab's
    // Consumed/Reserve columns use, just summed here across this
    // cluster's own sites instead of shown per site. Unlike the
    // Debit/Credit settlement below, this genuinely IS a real,
    // recovered, per-cluster figure — it's a straight sum of real
    // per-site rows, not an estimate or allocation of anything. Counts
    // are tracked alongside each total so the frontend can tell "every
    // site in this cluster had this figure" from "only some did."
    const monthly = {
      sites: monthlyRecords.map(m => ({
        site_id: m.site_id, site_name: m.site_name,
        budget_l: m.budget_liters ?? null,
        consumed_l: m.final_consumption_l ?? null,
        reserve_l: m.reserve_liters ?? null,
        fully_exhausted: m.fully_exhausted ?? null,
      })),
      totals: monthlyRecords.reduce((acc, m) => {
        if (m.budget_liters != null) { acc.total_budget_l += m.budget_liters; acc.budget_count += 1; }
        if (m.final_consumption_l != null) { acc.total_consumed_l += m.final_consumption_l; acc.consumed_count += 1; }
        if (m.reserve_liters != null) { acc.total_reserve_l += m.reserve_liters; acc.reserve_count += 1; }
        return acc;
      }, { total_budget_l: 0, total_consumed_l: 0, total_reserve_l: 0, budget_count: 0, consumed_count: 0, reserve_count: 0 }),
      site_count: monthlyRecords.length,
    };

    // ── End-of-cycle stock — one figure per site (its last field visit's
    // own fuel_left_l reading this cycle, not derived), summed across the
    // cluster. cycleVisitsRaw is already sorted ascending by visit_date,
    // so the last entry seen per site_id in that order is its most recent
    // visit — the same "last visit wins" rule the Site Cycle Report uses.
    // A site with no visit this cycle, or whose last visit didn't record
    // fuel_left_l, is excluded from the total and counted separately
    // rather than treated as 0.
    const lastVisitBySite = new Map();
    for (const v of cycleVisitsRaw) lastVisitBySite.set(v.site_id, v); // later entries overwrite earlier ones
    const endOfCycleStockSites = [...lastVisitBySite.values()].map(v => ({
      site_id: v.site_id, site_name: v.site_name,
      stock_l: v.fuel_left_l ?? null,
      as_of_date: v.visit_date,
    }));
    const endOfCycleStockReporting = endOfCycleStockSites.filter(s => s.stock_l != null);
    const end_of_cycle_stock = {
      sites: endOfCycleStockSites,
      total_l: endOfCycleStockReporting.reduce((s, r) => s + r.stock_l, 0),
      sites_reporting: endOfCycleStockReporting.length,
      sites_with_visit_no_reading: endOfCycleStockSites.length - endOfCycleStockReporting.length,
      note: 'Sum of each site\'s own last field visit this cycle (fuel_left_l, an actual tank-dip reading) — not every site in the cluster necessarily had a qualifying visit this cycle, see sites_reporting.',
    };

    // ── Carried-over stock burn, cluster total — Phase 165. See
    // carriedOverStockBurn() docblock. cycleVisitsRaw is already sorted
    // ascending by visit_date fleet-wide; grouping it by site_id here
    // preserves that order within each site's own sub-array (a stable
    // partition of a sorted array), so no extra sort is needed.
    const visitsBySiteForCob = new Map();
    for (const v of cycleVisitsRaw) {
      if (!visitsBySiteForCob.has(v.site_id)) visitsBySiteForCob.set(v.site_id, []);
      visitsBySiteForCob.get(v.site_id).push(v);
    }
    const cobPerSite = [...visitsBySiteForCob.entries()].map(([site_id, visits]) => ({ site_id, ...carriedOverStockBurn(visits) }));
    const cobReportingSites = cobPerSite.filter(s => s.net_change_l != null);
    const carried_over_stock_burn = {
      total_l: cobReportingSites.reduce((s, r) => s + r.net_change_l, 0),
      sites_reporting: cobReportingSites.length,
      site_count: cobPerSite.length,
    };

    // ── Gain / Loss, per site + cluster total — Phase 167. Reuses
    // visitsBySiteForCob (already grouped per site, ascending by
    // visit_date) so "first visit" per site is correct without a second
    // pass over cycleVisitsRaw. consumed_l comes from this same
    // monthlyRecords array already fetched above. Sites with no
    // monthly record or no qualifying first-visit reading are excluded
    // from the cluster total and counted separately, same pattern as
    // end_of_cycle_stock/carried_over_stock_burn above.
    const consumedBySite = new Map(monthlyRecords.map(m => [m.site_id, m.final_consumption_l ?? null]));
    const deliveredBySite = new Map(
      [...visitsBySiteForCob.entries()].map(([site_id, visits]) => [
        site_id, visits.reduce((s, v) => s + (v.fuel_added_l || 0), 0),
      ])
    );
    const gainLossPerSite = [...visitsBySiteForCob.entries()].map(([site_id, visits]) => ({
      site_id,
      site_name: visits[0]?.site_name ?? null,
      ...computeGainLoss(visits, deliveredBySite.get(site_id) ?? 0, consumedBySite.get(site_id) ?? null),
    }));
    const gainLossReportingSites = gainLossPerSite.filter(s => s.gain_loss_l != null);
    const gain_loss = {
      sites: gainLossPerSite,
      total_l: gainLossReportingSites.reduce((s, r) => s + r.gain_loss_l, 0),
      sites_reporting: gainLossReportingSites.length,
      site_count: gainLossPerSite.length,
    };

    // ── Mid-cycle early budget release (real only for 2026-08 so far) ───────
    const midCycleRelease = midCycleRows.length ? {
      sites: midCycleRows.map(m => ({
        site_id: m.site_id, site_name: m.site_name,
        delivered_l: m.delivered_l, released_budget_l: m.released_budget_l, variance_l: m.variance_l,
      })),
      totals: midCycleRows.reduce((acc, m) => {
        acc.total_delivered_l += m.delivered_l || 0;
        acc.total_released_l += m.released_budget_l || 0;
        return acc;
      }, { total_delivered_l: 0, total_released_l: 0 }),
    } : null;

    res.json({
      success: true,
      data: {
        cluster, cycle_key,
        request_approval: requestApproval,
        extra_fuel: { requests: extraFuelRequests, totals: extraFuelTotals },
        tomcard_allocation: { allocations: tomCard, totals: tomCardTotals },
        purchases: {
          transactions: purchases,
          totals: purchaseTotals,
          attributed_via_card_numbers: [...clusterCardNumbers],
          unattributable_note: clusterCardNumbers.size
            ? 'Attributed only to card numbers named on this cluster\'s own Tom Card Allocation for this cycle — a purchase on a card not listed there (or not yet recovered) will not appear here even if it belongs to this cluster.'
            : 'No Tom Card Allocation recovered for this cluster/cycle, so no card numbers were available to attribute purchases against — purchases here are empty by construction, not because none occurred.',
        },
        monthly,
        end_of_cycle_stock,
        carried_over_stock_burn,
        gain_loss,
        mid_cycle_release: midCycleRelease,
        site_count: new Set([
          ...approvals.map(a => a.site_id),
          ...monthlyRecords.map(m => m.site_id),
          ...adhocRaw.map(a => a.site_id),
        ]).size,
        coverage: {
          has_request_approval: approvals.length > 0,
          has_extra_fuel: extraFuelRequests.length > 0,
          has_tomcard_allocation: tomCardRows.length > 0,
          has_purchases: purchases.length > 0,
          has_monthly_record: monthlyRecords.length > 0,
          has_mid_cycle_release: !!midCycleRelease,
          has_end_of_cycle_stock: end_of_cycle_stock.sites_reporting > 0,
          has_carried_over_stock_burn: carried_over_stock_burn.sites_reporting > 0,
          has_gain_loss: gain_loss.sites_reporting > 0,
        },
      },
    });
  })
);

/**
 * GET /api/diesel/historical/site-cycle-summary/:cycle_key
 *
 * Phase 147 — the listing that backs History Analysis's Site Cycle
 * Analysis tab: one row per site for the cycle, with exactly the five
 * figures the user asked to see immediately (no per-site click needed
 * first) — Total Requested, Total Approved, Delivered to Site,
 * Consumed, Reserve. Each site's row also carries a link straight into
 * `/historical/site-cycle-report/:site_id/:cycle_key` for the full
 * detail (visits, extra-fuel isolated detail, engineering, True CPH).
 *
 * Built the same way as `/full-summary/:month_key` (union of every site
 * seen across the four contributing sources, isolate-before-merge on
 * extra fuel, honest nulls) but restructured to match
 * `site-cycle-report`'s own Total Requested/Approved shape
 * (`{ initial_l, extra_fuel_l, total_l, is_partial }`) so the same
 * number reads identically whether seen here or after clicking through
 * to the full report — and with `delivered_to_site_l` added, which
 * `/full-summary` does not carry (that endpoint predates Phase 143's
 * distinction between AdHocFuelRequest's own rarely-populated
 * `delivered_l` and the real field-recorded `fuel_added_l` this figure
 * uses).
 *
 * Deliberately ONE query per contributing collection, not one query per
 * site — a per-site loop calling the equivalent of the single-site
 * report endpoint would be 200+ requests worth of work done as 200+
 * separate queries; this does it as four.
 */
router.get('/site-cycle-summary/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;
    const { monthStart, monthEnd } = cycleDateRange(cycle_key);

    const [monthlyRecords, approvals, adhocByS, deliveredByS, visitsRaw, engParamsRows] = await Promise.all([
      HistoricalMonthlyRecord.find({ month_key: cycle_key }).lean(),
      BudgetRequestApproval.find({ cycle_key }).lean(),
      AdHocFuelRequest.aggregate([
        { $match: { planned_date: { $gte: monthStart, $lt: monthEnd } } },
        { $group: {
          _id: '$site_id',
          requested_l: { $sum: '$quantity_requested_l' },
          approved_l: { $sum: { $ifNull: ['$approved_l', 0] } },
          any_approval_data: { $max: { $ne: [{ $ifNull: ['$approved_l', null] }, null] } },
        }},
      ]),
      HistoricalFieldVisit.aggregate([
        { $match: { month_key: cycle_key } },
        { $group: { _id: '$site_id', delivered_to_site_l: { $sum: { $ifNull: ['$fuel_added_l', 0] } }, visit_count: { $sum: 1 } } },
      ]),
      // Raw (not aggregated) — carriedOverStockBurn/cycleEngineeringFigures
      // need each site's own visits in visit_date order, which a $group
      // can't give directly.
      HistoricalFieldVisit.find({ month_key: cycle_key }).sort({ site_id: 1, visit_date: 1 }).lean(),
      // Phase 168 — contractual CPH fallback source, same priority order
      // as the single-site report (approval.genset_cph wins if present).
      SiteEngineeringParams.find({}).select('site_id genset_cph').lean(),
    ]);

    const approvalBySite = new Map(approvals.map(r => [r.site_id, r]));
    const adhocBySite = new Map(adhocByS.map(a => [a._id, a]));
    const deliveredBySite = new Map(deliveredByS.map(d => [d._id, d]));
    const engParamsBySite = new Map(engParamsRows.map(e => [e.site_id, e]));
    const visitsBySite = new Map();
    for (const v of visitsRaw) {
      if (!visitsBySite.has(v.site_id)) visitsBySite.set(v.site_id, []);
      visitsBySite.get(v.site_id).push(v); // already sorted ascending by visit_date within each site_id group
    }

    const allSiteIds = new Set([
      ...monthlyRecords.map(r => r.site_id),
      ...approvals.map(r => r.site_id),
      ...adhocByS.map(a => a._id),
      ...deliveredByS.map(d => d._id),
    ]);

    const sites = [...allSiteIds].map(site_id => {
      const monthly = monthlyRecords.find(r => r.site_id === site_id);
      const approval = approvalBySite.get(site_id);
      const adhoc = adhocBySite.get(site_id);
      const delivered = deliveredBySite.get(site_id);
      const engParams = engParamsBySite.get(site_id);
      const visits = visitsBySite.get(site_id) || [];
      const cob = carriedOverStockBurn(visits);
      const eng = cycleEngineeringFigures(visits);
      const contractual_cph = approval?.genset_cph ?? engParams?.genset_cph ?? null;

      const initial_requested_l = approval?.sbc_requested_l ?? null;
      const initial_approved_l = approval?.ihs_approved_l ?? monthly?.budget_liters ?? null;
      // Only treat extra-fuel as "has data" when a request genuinely
      // exists this cycle — an absent adhoc entry means no extra-fuel
      // activity, not a 0 to add into the total.
      const extra_fuel_requested_l = adhoc ? adhoc.requested_l : null;
      const extra_fuel_approved_l = adhoc ? adhoc.approved_l : null;

      return {
        site_id,
        site_name: monthly?.site_name || approval?.site_name || adhoc?.site_name || null,
        cluster: monthly?.cluster || approval?.cluster || adhoc?.cluster || null,
        total_requested: {
          initial_l: initial_requested_l,
          extra_fuel_l: extra_fuel_requested_l,
          total_l: (initial_requested_l == null && extra_fuel_requested_l == null) ? null : (initial_requested_l || 0) + (extra_fuel_requested_l || 0),
          is_partial: (initial_requested_l == null) !== (extra_fuel_requested_l == null),
        },
        total_approved: {
          initial_l: initial_approved_l,
          extra_fuel_l: extra_fuel_approved_l,
          total_l: (initial_approved_l == null && extra_fuel_approved_l == null) ? null : (initial_approved_l || 0) + (extra_fuel_approved_l || 0),
          is_partial: (initial_approved_l == null) !== (extra_fuel_approved_l == null),
        },
        delivered_to_site_l: delivered?.delivered_to_site_l ?? null,
        visits_this_cycle_count: delivered?.visit_count ?? 0,
        consumed_l: monthly?.final_consumption_l ?? null,
        reserve_l: monthly?.reserve_liters ?? null,
        fully_exhausted: monthly?.fully_exhausted ?? null,
        carried_over_stock_burn: cob,
        gain_loss: computeGainLoss(visits, delivered?.delivered_to_site_l ?? 0, monthly?.final_consumption_l ?? null),
        // ── Phase 168 — sortable columns for the Site Cycle Summary table:
        // run hours, True CPH vs contractual, and a stability/anomaly
        // figure, all computed per site from the same raw visits already
        // fetched above (no extra queries).
        run_hours_total_this_cycle: eng.run_hours_total,
        avg_true_cph_this_cycle: eng.avg_true_cph,
        contractual_cph,
        true_cph_vs_contractual: (eng.avg_true_cph != null && contractual_cph != null)
          ? Math.round((eng.avg_true_cph - contractual_cph) * 100) / 100
          : null,
        consumption_stability: consumptionStability(eng.intervals),
        has_stock: cob.last_visit_stock_l != null ? cob.last_visit_stock_l > 0 : null,
      };
    }).sort((a, b) => (a.site_name || a.site_id).localeCompare(b.site_name || b.site_id));

    // ── Fleet-wide total for this cycle — Phase 165. Sites with no
    // qualifying reading are excluded, not treated as 0 (same rule as
    // the per-site figure itself).
    const cobReporting = sites.filter(s => s.carried_over_stock_burn.net_change_l != null);
    const fleet_carried_over_stock_burn = {
      total_l: cobReporting.reduce((s, r) => s + r.carried_over_stock_burn.net_change_l, 0),
      sites_reporting: cobReporting.length,
      site_count: sites.length,
    };

    // ── Fleet-wide Gain/Loss total for this cycle — Phase 167. Same
    // exclude-not-zero rule as above.
    const gainLossReporting = sites.filter(s => s.gain_loss.gain_loss_l != null);
    const fleet_gain_loss = {
      total_l: gainLossReporting.reduce((s, r) => s + r.gain_loss.gain_loss_l, 0),
      sites_reporting: gainLossReporting.length,
      site_count: sites.length,
    };

    // ── Fleet-wide Has Stock / No Stock counts — Phase 168, same
    // last-visit-of-cycle stock_l each site's own row already carries.
    const stockReporting = sites.filter(s => s.has_stock != null);
    const fleet_stock_status = {
      has_stock_count: stockReporting.filter(s => s.has_stock === true).length,
      no_stock_count: stockReporting.filter(s => s.has_stock === false).length,
      sites_reporting: stockReporting.length,
      site_count: sites.length,
    };

    res.json({ success: true, data: { cycle_key, sites, totals: { carried_over_stock_burn: fleet_carried_over_stock_burn, gain_loss: fleet_gain_loss, stock_status: fleet_stock_status } } });
  })
);

/**
 * GET /api/diesel/historical/cluster-cycle-summary/:cycle_key
 *
 * The cluster-level counterpart, listing every cluster for the cycle
 * with Requested/Approved (regular), Extra Fuel Requested/Approved,
 * Purchases, and Card Funding incl. Extra Rounds — each cluster's row
 * links into `/historical/cluster-cycle-report/:cluster/:cycle_key` for
 * the full detail. Same "one query per collection, not per cluster"
 * discipline as the site summary above.
 */
router.get('/cluster-cycle-summary/:cycle_key',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;
    const { monthStart, monthEnd } = cycleDateRange(cycle_key);

    const [approvals, adhocByC, tomCardRows, monthlyRecords, visitsRaw] = await Promise.all([
      BudgetRequestApproval.find({ cycle_key }).lean(),
      AdHocFuelRequest.aggregate([
        { $match: { planned_date: { $gte: monthStart, $lt: monthEnd } } },
        { $group: { _id: '$cluster', requested_l: { $sum: '$quantity_requested_l' }, approved_l: { $sum: { $ifNull: ['$approved_l', 0] } } } },
      ]),
      TomCardAllocation.find({ funded_cycle_key: cycle_key }).lean(),
      // Phase 168 — final_consumption_l needed per site for the
      // cluster-level Consumed/Gain-Loss rollups below.
      HistoricalMonthlyRecord.find({ month_key: cycle_key }).select('site_id cluster final_consumption_l').lean(),
      // Raw, per-site, visit_date order — see carriedOverStockBurn()
      // docblock. Grouped first by site_id (to compute each site's own
      // figure), then rolled up by cluster below. fuel_left_l/run_hours
      // added (Phase 168) for has_stock and the CPH/run-hours rollups.
      HistoricalFieldVisit.find({ month_key: cycle_key }).select('site_id cluster visit_date fuel_previously_left_l fuel_found_l fuel_added_l fuel_left_l run_hours days_since_last_visit').sort({ site_id: 1, visit_date: 1 }).lean(),
    ]);

    const visitsBySite = new Map();
    for (const v of visitsRaw) {
      if (!visitsBySite.has(v.site_id)) visitsBySite.set(v.site_id, []);
      visitsBySite.get(v.site_id).push(v);
    }
    // One cluster per site_id — a site's visits all carry the same
    // cluster, so the first visit seen for a site_id names it.
    const clusterBySiteId = new Map(visitsRaw.map(v => [v.site_id, v.cluster]).filter(([, c]) => c));
    const consumedBySiteId = new Map(monthlyRecords.map(m => [m.site_id, m.final_consumption_l ?? null]));

    // ── Per-site rollups, then summed to cluster level — Phase 168.
    // Carried-over stock burn (net change), Gain/Loss, run hours, True
    // CPH, and Has Stock all reuse the same visitsBySite grouping.
    const cobByCluster = new Map();       // cluster -> { total_l, sites_reporting }
    const gainLossByCluster = new Map();  // cluster -> { total_l, sites_reporting }
    const runHoursByCluster = new Map();  // cluster -> total_hours
    const cphByCluster = new Map();       // cluster -> { total_consumed_l, total_hours } (weighted avg True CPH)
    const stockByCluster = new Map();     // cluster -> { has_stock, no_stock }
    for (const [site_id, visits] of visitsBySite) {
      const cluster = clusterBySiteId.get(site_id);
      if (!cluster) continue;
      const cob = carriedOverStockBurn(visits);
      if (cob.net_change_l != null) {
        if (!cobByCluster.has(cluster)) cobByCluster.set(cluster, { total_l: 0, sites_reporting: 0 });
        const agg = cobByCluster.get(cluster);
        agg.total_l += cob.net_change_l;
        agg.sites_reporting += 1;
      }
      if (cob.last_visit_stock_l != null) {
        if (!stockByCluster.has(cluster)) stockByCluster.set(cluster, { has_stock: 0, no_stock: 0 });
        const agg = stockByCluster.get(cluster);
        if (cob.last_visit_stock_l > 0) agg.has_stock += 1; else agg.no_stock += 1;
      }
      const delivered_l = visits.reduce((s, v) => s + (v.fuel_added_l || 0), 0);
      const gl = computeGainLoss(visits, delivered_l, consumedBySiteId.get(site_id) ?? null);
      if (gl.gain_loss_l != null) {
        if (!gainLossByCluster.has(cluster)) gainLossByCluster.set(cluster, { total_l: 0, sites_reporting: 0 });
        const agg = gainLossByCluster.get(cluster);
        agg.total_l += gl.gain_loss_l;
        agg.sites_reporting += 1;
      }
      const eng = cycleEngineeringFigures(visits);
      runHoursByCluster.set(cluster, (runHoursByCluster.get(cluster) || 0) + eng.run_hours_total);
      if (eng.intervals.length) {
        if (!cphByCluster.has(cluster)) cphByCluster.set(cluster, { total_consumed_l: 0, total_hours: 0 });
        const agg = cphByCluster.get(cluster);
        agg.total_consumed_l += eng.intervals.reduce((s, v) => s + v.interval_consumed_l, 0);
        agg.total_hours += eng.intervals.reduce((s, v) => s + v.run_hours, 0);
      }
    }

    // card_number -> cluster, from this cycle's own Tom Card Allocation —
    // the same real-but-indirect join used by the single-cluster report.
    const cardToCluster = new Map();
    for (const t of tomCardRows) {
      if (t.card_number) cardToCluster.set(t.card_number, t.cluster);
      if (t.new_card_number) cardToCluster.set(t.new_card_number, t.cluster);
    }
    const purchases = cardToCluster.size
      ? await HistoricalFuelPurchase.find({ month_key: cycle_key, card_number: { $in: [...cardToCluster.keys()] } }).lean()
      : [];
    const purchasesByCluster = new Map();
    for (const p of purchases) {
      const cluster = cardToCluster.get(p.card_number);
      if (!cluster) continue;
      if (!purchasesByCluster.has(cluster)) purchasesByCluster.set(cluster, { total_l: 0, total_xaf: 0 });
      const agg = purchasesByCluster.get(cluster);
      agg.total_l += p.quantity_l || 0;
      agg.total_xaf += p.amount_xaf || 0;
    }

    const tomCardByCluster = new Map();
    for (const t of tomCardRows) {
      if (!tomCardByCluster.has(t.cluster)) tomCardByCluster.set(t.cluster, { total_incl_extra_l: 0, total_incl_extra_xaf: 0 });
      const agg = tomCardByCluster.get(t.cluster);
      const base_l = t.quantity_l ?? t.budget_l ?? 0;
      const base_xaf = t.amount_xaf ?? t.budget_xaf ?? 0;
      const extra_l = (t.extra_round1_approved_l || 0) + (t.extra_round2_approved_l || 0) + (t.extra_round3_approved_l || 0);
      const extra_xaf = (t.extra_round1_approved_xaf || 0) + (t.extra_round2_approved_xaf || 0) + (t.extra_round3_approved_xaf || 0);
      agg.total_incl_extra_l += base_l + extra_l;
      agg.total_incl_extra_xaf += base_xaf + extra_xaf;
    }

    const approvalTotalsByCluster = new Map();
    for (const a of approvals) {
      if (!a.cluster) continue;
      if (!approvalTotalsByCluster.has(a.cluster)) approvalTotalsByCluster.set(a.cluster, { requested_l: 0, approved_l: 0 });
      const agg = approvalTotalsByCluster.get(a.cluster);
      if (a.sbc_requested_l != null) agg.requested_l += a.sbc_requested_l;
      if (a.ihs_approved_l != null) agg.approved_l += a.ihs_approved_l;
    }

    const adhocByCluster = new Map(adhocByC.filter(a => a._id).map(a => [a._id, a]));

    // Consumed, per cluster — straight sum of each site's own
    // final_consumption_l, same real recovered figure the Cluster Cycle
    // Report's "Consumed (actual)" tile already uses (Phase 168).
    const consumedByCluster = new Map();
    for (const m of monthlyRecords) {
      if (!m.cluster || m.final_consumption_l == null) continue;
      if (!consumedByCluster.has(m.cluster)) consumedByCluster.set(m.cluster, { total_l: 0, sites_reporting: 0 });
      const agg = consumedByCluster.get(m.cluster);
      agg.total_l += m.final_consumption_l;
      agg.sites_reporting += 1;
    }

    const allClusters = new Set([
      ...approvals.map(a => a.cluster).filter(Boolean),
      ...adhocByC.map(a => a._id).filter(Boolean),
      ...tomCardRows.map(t => t.cluster).filter(Boolean),
      ...monthlyRecords.map(m => m.cluster).filter(Boolean),
      ...clusterBySiteId.values(),
    ]);

    const clusters = [...allClusters].map(cluster => {
      const reqApproval = approvalTotalsByCluster.get(cluster);
      const adhoc = adhocByCluster.get(cluster);
      const tomCard = tomCardByCluster.get(cluster);
      const purch = purchasesByCluster.get(cluster);
      const cob = cobByCluster.get(cluster);
      const consumed = consumedByCluster.get(cluster);
      const gainLoss = gainLossByCluster.get(cluster);
      const cph = cphByCluster.get(cluster);
      const stock = stockByCluster.get(cluster);
      const avg_true_cph = cph && cph.total_hours ? Math.round((cph.total_consumed_l / cph.total_hours) * 100) / 100 : null;
      return {
        cluster,
        requested_l: reqApproval?.requested_l ?? null,
        approved_l: reqApproval?.approved_l ?? null,
        extra_fuel_requested_l: adhoc?.requested_l ?? null,
        extra_fuel_approved_l: adhoc?.approved_l ?? null,
        purchases_l: purch?.total_l ?? null,
        purchases_xaf: purch?.total_xaf ?? null,
        tomcard_total_incl_extra_l: tomCard?.total_incl_extra_l ?? null,
        tomcard_total_incl_extra_xaf: tomCard?.total_incl_extra_xaf ?? null,
        carried_over_stock_burn_l: cob?.total_l ?? null,
        carried_over_stock_burn_sites_reporting: cob?.sites_reporting ?? 0,
        // Phase 168 — Compare Clusters columns.
        consumed_l: consumed?.total_l ?? null,
        consumed_sites_reporting: consumed?.sites_reporting ?? 0,
        gain_loss_l: gainLoss?.total_l ?? null,
        gain_loss_sites_reporting: gainLoss?.sites_reporting ?? 0,
        run_hours_total: runHoursByCluster.get(cluster) ?? 0,
        avg_true_cph_this_cycle: avg_true_cph,
        has_stock_count: stock?.has_stock ?? 0,
        no_stock_count: stock?.no_stock ?? 0,
      };
    }).sort((a, b) => a.cluster.localeCompare(b.cluster));

    res.json({ success: true, data: { cycle_key, clusters } });
  })
);

/**
 * GET /api/diesel/historical/export/excel
 *
 * Phase 152 — "Now I need these reports in an excel file with charts and
 * graphs." One workbook, live-queried at request time, covering all four
 * report types on the History Analysis / Historical Data pages: Global
 * Summary, Site Cycle Analysis, Cluster Cycle Analysis, and the Complete
 * Monthly Summary — each its own sheet, each with at least one embedded
 * chart. See services/historicalExcelExport.js for the full design
 * rationale (why charts are images, why cluster attribution is scoped to
 * the 8 real clusters, why this batches queries instead of looping the
 * existing single-cycle endpoints).
 *
 * Can take a while to build (many months × many sites/clusters, several
 * rendered chart images) — no artificial timeout is set here; the
 * frontend's own request for this endpoint specifically raises its
 * timeout well above the default.
 */
router.get('/export/excel',
  authenticateToken,
  requireRole(ROLES),
  asyncHandler(async (req, res) => {
    const buffer = await buildHistoricalExcelWorkbook();
    const filename = `PowerGen_Historical_Report_${new Date().toISOString().slice(0, 10)}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(Buffer.from(buffer));
  })
);

module.exports = router;
