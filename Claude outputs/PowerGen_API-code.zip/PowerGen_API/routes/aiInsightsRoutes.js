'use strict';

const express = require('express');
const router = express.Router();

const { generateBriefing } = require('../services/aiFleetInsightsService');
const { authenticateToken, requireRole } = require('../middlewares/authMiddleware');
const asyncHandler = require('../middlewares/asyncHandler');

const INSIGHTS_ROLES = ['diesel_manager', 'admin', 'supervisor', 'finance', 'head_of_business', 'ceo'];

/**
 * GET /api/diesel/ai-insights/briefing/:cycle_key
 *
 * The cross-cutting Fleet Intelligence Briefing — synthesizes real data
 * from alerts, reconciliation, budget planning, and pending approvals
 * into one prioritized narrative. Cached for an hour per cycle (see
 * services/aiFleetInsightsService.js) since generating one is genuinely
 * expensive (a full budget-plan run plus a Gemini call).
 *
 * Works even without a Gemini API key configured — evidence is always
 * returned; narrative is null and ai_enabled: false if the key isn't
 * set, so the underlying data is still useful on its own.
 */
router.get('/briefing/:cycle_key',
  authenticateToken,
  requireRole(INSIGHTS_ROLES),
  asyncHandler(async (req, res) => {
    const { cycle_key } = req.params;
    const forceRefresh = req.query.refresh === 'true';
    const result = await generateBriefing(cycle_key, { forceRefresh });
    res.json({ success: true, data: result });
  })
);

module.exports = router;
