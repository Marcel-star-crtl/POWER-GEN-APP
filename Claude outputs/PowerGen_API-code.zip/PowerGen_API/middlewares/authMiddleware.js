// middlewares/authMiddleware.js
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Cluster = require('../models/Cluster');
const Tower = require('../models/Tower');
const logger = require('../utils/logger');

// Middleware to authenticate JWT tokens
const authenticateToken = async (req, res, next) => {
  console.log('\n========== AUTH MIDDLEWARE START ==========');
  console.log('Path:', req.path);
  console.log('Method:', req.method);
  
  try {
    // Step 1: Check for Authorization header
    const authHeader = req.headers.authorization;
    console.log('Auth Header:', authHeader ? 'Present' : 'Missing');
    
    if (!authHeader) {
      console.log('ERROR: No authorization header');
      return res.status(401).json({
        success: false,
        error: 'Access token required',
        debug: 'No authorization header found'
      });
    }

    // Step 2: Extract token
    const token = authHeader.split(' ')[1];
    console.log('Token extracted:', token ? `Yes (${token.substring(0, 20)}...)` : 'No');
    
    if (!token) {
      console.log('ERROR: Token missing from header');
      return res.status(401).json({
        success: false,
        error: 'Access token required',
        debug: 'Authorization header format should be: Bearer <token>'
      });
    }

    // Step 3: Verify token
    console.log('Verifying token with JWT_SECRET...');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log('Token decoded successfully:', {
      userId: decoded.userId,
      userType: decoded.userType,
      email: decoded.email
    });

    // Step 4: Fetch user from database
    console.log('Fetching user from database...');
    const user = await User.findById(decoded.userId).select('-password -refreshToken');
    
    if (!user) {
      console.log('ERROR: User not found in database for ID:', decoded.userId);
      return res.status(401).json({
        success: false,
        error: 'Invalid token - user not found',
        debug: `User ID ${decoded.userId} does not exist`
      });
    }

    console.log('User found:', {
      id: user._id,
      username: user.username,
      email: user.email,
      role: user.role,
      isActive: user.isActive
    });

    // Step 5: Check if user is active
    if (!user.isActive) {
      console.log('ERROR: User account is not active');
      return res.status(403).json({
        success: false,
        error: 'Account is not active',
        debug: `User ${user.email} is deactivated`
      });
    }

    // Step 6: Set req.user with BOTH _id and userId for compatibility
    req.user = {
      _id: user._id,              // ← For Mongoose compatibility
      userId: user._id,            // ← For backward compatibility
      username: user.username,
      email: user.email,
      role: user.role,
      userType: user.role,
      fullName: user.fullName,
      phone: user.phone,
      department: user.department,
      position: user.position,
      supervisorId: user.supervisor // ← Added for Supervisor Access to tickets
    };

    console.log('req.user set successfully:', {
      _id: req.user._id,
      userId: req.user.userId,
      username: req.user.username,
      email: req.user.email,
      role: req.user.role,
      userType: req.user.userType,
      fullName: req.user.fullName
    });
    console.log('========== AUTH MIDDLEWARE SUCCESS ==========\n');

    // Step 7: Update last activity (async, don't wait)
    // Safely handle if method doesn't exist
    if (typeof user.updateLastActivity === 'function') {
      user.updateLastActivity().catch(err => {
        logger.error('Error updating user activity:', err);
      });
    } else {
      // Fallback: Update last_login directly
      User.findByIdAndUpdate(
        user._id, 
        { last_login: new Date() },
        { validateBeforeSave: false }
      ).catch(err => {
        logger.error('Error updating last activity:', err);
      });
    }

    next();
  } catch (error) {
    console.log('========== AUTH MIDDLEWARE ERROR ==========');
    console.log('Error type:', error.name);
    console.log('Error message:', error.message);
    console.log('Error stack:', error.stack);
    console.log('===========================================\n');

    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        error: 'Invalid token'
      });
    } else if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        error: 'Token expired',
        debug: `Token expired at ${error.expiredAt}`
      });
    }

    logger.error('Authentication error:', error);
    return res.status(500).json({
      success: false,
      error: 'Authentication server error'
    });
  }
};

const requireRole = (roles) => {
  return (req, res, next) => {
    console.log('\n========== ROLE CHECK MIDDLEWARE ==========');
    console.log('Required roles:', roles);
    console.log('req.user exists:', !!req.user);
    
    if (!req.user) {
      console.log('ERROR: req.user is undefined');
      console.log('=========================================\n');
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
        debug: 'req.user is undefined - authentication middleware may not have run'
      });
    }

    console.log('User role:', req.user.role);
    const userRole = req.user.role;
    const allowedRoles = Array.isArray(roles) ? [...roles] : [roles];
    // Treat AC as a technician-equivalent role for access control
    if (allowedRoles.includes('technician') && !allowedRoles.includes('ac')) {
      allowedRoles.push('ac');
    }

    if (!allowedRoles.includes(userRole)) {
      console.log('ERROR: Role not allowed');
      console.log('=========================================\n');
      
      logger.warn('Unauthorized role access attempt', {
        userId: req.user.userId,
        userRole: userRole,
        requiredRoles: allowedRoles,
        path: req.path
      });

      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions',
        debug: `User role '${userRole}' not in allowed roles: ${allowedRoles.join(', ')}`
      });
    }

    console.log('Role check passed');
    console.log('=========================================\n');
    next();
  };
};

// New middleware aliases to match the new naming convention
const protect = authenticateToken;
const authorize = (...roles) => requireRole(roles);

/**
 * Get user's accessible cluster IDs based on role
 */
async function getUserAccessibleClusters(userId, userRole) {
  try {
    if (userRole === 'admin' || userRole === 'analyst') {
      // Admin and analyst can see all clusters
      const clusters = await Cluster.find({}).select('_id');
      return clusters.map(c => c._id.toString());
    }

    if (userRole === 'supervisor') {
      // Supervisor can see their supervised clusters
      const clusters = await Cluster.find({ supervisor: userId }).select('_id');
      return clusters.map(c => c._id.toString());
    }

    if (userRole === 'technician' || userRole === 'ac') {
      // Technician can see their assigned clusters
      const user = await User.findById(userId).select('assigned_cluster');
      if (user && user.assigned_cluster) {
        return [user.assigned_cluster.toString()];
      }
      return [];
    }

    return [];
  } catch (error) {
    logger.error('Error getting user accessible clusters:', error);
    return [];
  }
}

/**
 * Get user's accessible tower IDs based on role
 */
async function getUserAccessibleTowers(userId, userRole) {
  try {
    if (userRole === 'admin' || userRole === 'analyst') {
      // Admin and analyst can see all towers
      const towers = await Tower.find({}).select('_id');
      return towers.map(t => t._id);
    }

    if (userRole === 'supervisor') {
      // Supervisor can see towers in their supervised clusters
      const clusters = await Cluster.find({ supervisor: userId }).select('_id');
      const clusterIds = clusters.map(c => c._id);
      const towers = await Tower.find({ cluster_id: { $in: clusterIds } }).select('_id');
      return towers.map(t => t._id);
    }

    if (userRole === 'technician' || userRole === 'ac') {
      // Technician can see their assigned towers
      const user = await User.findById(userId).select('assignedTowers');
      return user.assignedTowers || [];
    }

    return [];
  } catch (error) {
    logger.error('Error getting user accessible towers:', error);
    return [];
  }
}

/**
 * Middleware to filter clusters based on user access
 */
async function filterClusterAccess(req, res, next) {
  try {
    const user = req.user;
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    // Get accessible cluster IDs
    const accessibleClusterIds = await getUserAccessibleClusters(user.userId, user.userType);
    
    // Add to request for use in route handlers
    req.accessibleClusters = accessibleClusterIds;
    req.userAccess = {
      canAccessAllClusters: user.userType === 'admin' || user.userType === 'analyst'
    };

    next();
  } catch (error) {
    logger.error('Error in filterClusterAccess middleware:', error);
    res.status(500).json({
      success: false,
      message: 'Authorization error'
    });
  }
}

/**
 * Middleware to filter towers based on user access
 */
async function filterTowerAccess(req, res, next) {
  try {
    const user = req.user;
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    // Get accessible tower IDs
    const accessibleTowerIds = await getUserAccessibleTowers(user.userId, user.userType);
    
    // Add to request for use in route handlers
    req.accessibleTowers = accessibleTowerIds;
    req.userAccess = {
      canAccessAllTowers: user.userType === 'admin' || user.userType === 'analyst'
    };

    next();
  } catch (error) {
    logger.error('Error in filterTowerAccess middleware:', error);
    res.status(500).json({
      success: false,
      message: 'Authorization error'
    });
  }
}

/**
 * Middleware to check if user can access a specific cluster
 */
async function canAccessCluster(req, res, next) {
  try {
    const user = req.user;
    const clusterId = req.params.clusterId || req.params.id;

    if (!clusterId) {
      return res.status(400).json({
        success: false,
        message: 'Cluster ID required'
      });
    }

    // Admin and analyst can access all
    if (user.userType === 'admin' || user.userType === 'analyst') {
      return next();
    }

    const accessibleClusterIds = await getUserAccessibleClusters(user.userId, user.userType);
    
    if (!accessibleClusterIds.includes(clusterId)) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this cluster'
      });
    }

    next();
  } catch (error) {
    logger.error('Error in canAccessCluster middleware:', error);
    res.status(500).json({
      success: false,
      message: 'Authorization error'
    });
  }
}

/**
 * Middleware to check if user can access a specific tower
 */
async function canAccessTower(req, res, next) {
  try {
    const user = req.user;
    const towerId = req.params.towerId || req.params.id;

    if (!towerId) {
      return res.status(400).json({
        success: false,
        message: 'Tower ID required'
      });
    }

    // Admin and analyst can access all
    if (user.userType === 'admin' || user.userType === 'analyst') {
      return next();
    }

    const accessibleTowerIds = await getUserAccessibleTowers(user.userId, user.userType);
    
    const hasAccess = accessibleTowerIds.some(id => id.toString() === towerId);
    
    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this tower'
      });
    }

    next();
  } catch (error) {
    logger.error('Error in canAccessTower middleware:', error);
    res.status(500).json({
      success: false,
      message: 'Authorization error'
    });
  }
}

/**
 * Get user's dashboard data based on role
 */
async function getUserDashboardData(userId, userType) {
  try {
    const data = {
      role: userType,
      accessLevel: null,
      stats: {},
      assignments: {}
    };

    if (userType === 'admin') {
      // Admin sees everything
      data.accessLevel = 'full';
      data.stats = {
        totalClusters: await Cluster.countDocuments({}),
        totalTowers: await Tower.countDocuments({}),
        totalTechnicians: await User.countDocuments({ role: { $in: ['technician', 'ac'] } }),
        totalSupervisors: await User.countDocuments({ role: 'supervisor' })
      };
    } else if (userType === 'supervisor') {
      // Supervisor sees their clusters and towers
      data.accessLevel = 'supervisor';
      const clusters = await Cluster.find({ supervisor: userId });
      const clusterIds = clusters.map(c => c._id);
      const towers = await Tower.find({ cluster_id: { $in: clusterIds } });
      
      data.stats = {
        myClusters: clusters.length,
        myTowers: towers.length,
        myTechnicians: clusters.reduce((sum, c) => sum + (c.assigned_technicians?.length || 0), 0)
      };
      data.assignments = {
        clusters: clusters.map(c => ({ id: c._id, name: c.name })),
        clusterIds: clusterIds
      };
    } else if (userType === 'technician' || userType === 'ac') {
      // Technician sees their assigned cluster and sites
      data.accessLevel = 'technician';
      const user = await User.findById(userId)
        .populate('assigned_cluster', 'name')
        .select('assigned_cluster');
      
      const Site = require('../models/Site');
      const assignedSites = await Site.countDocuments({
        Technician_Name: user.fullName
      });
      
      data.stats = {
        myCluster: user.assigned_cluster ? 1 : 0,
        mySites: assignedSites,
        currentTasks: 0 // Will be populated from Maintenance
      };
      data.assignments = {
        cluster: user.assigned_cluster || null,
        clusterId: user.assigned_cluster?._id || null
      };
    } else if (userType === 'analyst') {
      // Analyst sees everything (read-only)
      data.accessLevel = 'read_all';
      const Generator = require('../models/Generator');
      data.stats = {
        totalClusters: await Cluster.countDocuments({}),
        totalTowers: await Tower.countDocuments({}),
        totalGenerators: await Generator.countDocuments({})
      };
    }

    return data;
  } catch (error) {
    logger.error('Error getting user dashboard data:', error);
    throw error;
  }
}

module.exports = {
  authenticateToken,
  requireRole,
  protect,              
  authorize,            
  getUserAccessibleClusters,
  getUserAccessibleTowers,
  filterClusterAccess,
  filterTowerAccess,
  canAccessCluster,
  canAccessTower,
  getUserDashboardData
};