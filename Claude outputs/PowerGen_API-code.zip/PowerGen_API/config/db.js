const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI;
        await mongoose.connect(mongoUri, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            // Explicit pool size — was previously relying on the silent
            // default (100). Made explicit both for visibility and as a
            // deliberate safety margin: batched-concurrent operations
            // (e.g. reconciliation processing 15 sites at once, each
            // doing several queries) should have real headroom rather
            // than a number nobody consciously chose.
            maxPoolSize: 150,
            // Fail fast and with a clear error if the server genuinely
            // can't be reached, rather than hanging for the driver's
            // default (30s) — matches the client-side timeout instead of
            // silently doubling up with it.
            serverSelectionTimeoutMS: 10000,
        });

        console.log('MongoDB connected');
    } catch (err) {
        console.error(err.message);
        process.exit(1);
    }
};

module.exports = connectDB;





