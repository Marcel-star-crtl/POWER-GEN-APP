/**
 * BudgetPlanningPage.tsx
 *
 * Automated per-site budget planning, before a cycle starts. Generates a
 * preview using the organization's own verified engineering formula
 * (services/budgetPlanningService.js), cross-validated against real
 * recent consumption trend, with clear flags where the two disagree.
 * Nothing is written anywhere until the manager reviews and explicitly
 * commits — this page never silently changes real budget data.
 */
import React, { useMemo, useState } from 'react';
import { useCycles } from '../../hooks/useDiesel';
import { budgetPlanningApi } from '../../api/dieselApi';
import { PageHeader, Spinner, ErrorBox, EmptyState, Btn, CycleSelector } from '../../components/diesel/DieselComponents';
import { neutral, ink, urgency } from '../../styles/dieselTokens';

type PlanSite = {
  site_id: string;
  site_name?: string;
  cluster?: string;
  region?: string;
  topology?: string;
  plannable: boolean;
  reason?: string;
  days_in_cycle?: number;
  genset_cph?: number;
  final_grid_availability?: number;
  budgeted_rh?: number;
  engineering_estimate_l?: number;
  trend_l?: number | null;
  variance_pct?: number | null;
  months_of_history?: number;
  budget_liters: number;
  budget_xaf?: number;
  confidence?: 'high' | 'medium' | 'low';
  flag?: string | null;
};

const CONFIDENCE_COLOR: Record<string, string> = {
  high: urgency.ok.fg,
  medium: urgency.medium.fg,
  low: urgency.high.fg,
};

function fmtNum(n?: number | null, decimals = 0) {
  if (n == null) return '—';
  return n.toLocaleString(undefined, { maximumFractionDigits: decimals, minimumFractionDigits: decimals });
}

export default function BudgetPlanningPage() {
  const { cycles, selectedKey, setSelectedKey } = useCycles();
  const [daysOverride, setDaysOverride] = useState('30');
  const [plan, setPlan] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [edited, setEdited] = useState<Record<string, number>>({});
  const [committing, setCommitting] = useState(false);
  const [commitResult, setCommitResult] = useState<any>(null);
  const [confidenceFilter, setConfidenceFilter] = useState<string>('');
  const [flaggedOnly, setFlaggedOnly] = useState(false);

  // Does the target cycle already exist? If not, the ?days= override is
  // required and shown; if it does, the real cycle length is used and
  // the override is hidden, since it wouldn't have any effect.
  const cycleExists = cycles.some((c: any) => c.cycle_key === selectedKey);

  async function generatePlan() {
    if (!selectedKey) { setError('Select or enter a cycle first.'); return; }
    setLoading(true);
    setError(null);
    setCommitResult(null);
    setEdited({});
    try {
      const days = cycleExists ? undefined : (Number(daysOverride) || 30);
      const res = await budgetPlanningApi.preview(selectedKey, days);
      setPlan((res as any)?.data || res);
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to generate plan');
    } finally {
      setLoading(false);
    }
  }

  const sites: PlanSite[] = plan?.sites || [];
  const unplannable: PlanSite[] = plan?.unplannable_sites || [];

  const filtered = useMemo(() => {
    return sites.filter(s => {
      if (confidenceFilter && s.confidence !== confidenceFilter) return false;
      if (flaggedOnly && !s.flag) return false;
      return true;
    });
  }, [sites, confidenceFilter, flaggedOnly]);

  function effectiveLiters(s: PlanSite): number {
    return edited[s.site_id] ?? s.budget_liters;
  }

  const totalEffective = useMemo(
    () => sites.reduce((sum, s) => sum + effectiveLiters(s), 0),
    [sites, edited]
  );

  async function handleCommit() {
    if (!cycleExists) {
      setError('The target cycle must exist before committing — create it first, then generate and commit the plan.');
      return;
    }
    if (!window.confirm(`Commit budgets for ${sites.length} site(s) to cycle ${selectedKey}? This writes real SiteBudget records.`)) return;

    setCommitting(true);
    setError(null);
    try {
      const payload = sites.map(s => ({ ...s, budget_liters: effectiveLiters(s) }));
      const res = await budgetPlanningApi.commit(selectedKey, payload);
      setCommitResult((res as any)?.data || res);
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Commit failed');
    } finally {
      setCommitting(false);
    }
  }

  return (
    <div style={{ padding: '24px 32px', maxWidth: 1300, margin: '0 auto' }}>
      <PageHeader
        title="🧮 Automated Budget Planning"
        subtitle="Projects your verified engineering formula forward, cross-checked against each site's real recent consumption. Nothing is written until you review and commit."
      />

      {/* ── Cycle selection / generation ── */}
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap', marginBottom: 20, border: `1px solid ${neutral[200]}`, borderRadius: 12, padding: 16 }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: neutral[500], marginBottom: 4, textTransform: 'uppercase' }}>Target Cycle</div>
          <CycleSelector cycles={cycles} value={selectedKey} onChange={setSelectedKey} />
        </div>
        {!cycleExists && selectedKey && (
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: neutral[500], marginBottom: 4, textTransform: 'uppercase' }}>Days in Cycle (not yet created)</div>
            <input
              type="number" min={1} value={daysOverride} onChange={e => setDaysOverride(e.target.value)}
              style={{ border: `1px solid ${neutral[200]}`, borderRadius: 8, padding: '7px 12px', fontSize: 13, width: 100 }}
            />
          </div>
        )}
        <Btn variant="primary" onClick={generatePlan} loading={loading}>
          {plan ? 'Regenerate Plan' : 'Generate Plan'}
        </Btn>
        {!cycleExists && selectedKey && (
          <div style={{ fontSize: 12, color: neutral[500], maxWidth: 320 }}>
            Cycle "{selectedKey}" doesn't exist yet — you can preview a plan now, but committing requires the cycle to be created first.
          </div>
        )}
      </div>

      {error && <ErrorBox message={error} />}

      {commitResult && (
        <div style={{
          border: `1px solid ${urgency.ok.fg}`, background: urgency.ok.bg, borderRadius: 10,
          padding: '12px 16px', marginBottom: 20, fontSize: 13, color: '#166534',
        }}>
          ✓ Committed {commitResult.written} site budget(s) to {commitResult.cycle_key}.
          {commitResult.errors?.length > 0 && ` ${commitResult.errors.length} error(s) — see console.`}
        </div>
      )}

      {loading && <Spinner />}

      {!loading && plan && (
        <>
          {/* ── Summary ── */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12, marginBottom: 20 }}>
            {[
              { label: 'Plannable Sites', value: plan.summary.plannable },
              { label: 'No Engineering Data', value: plan.summary.unplannable },
              { label: 'High Confidence', value: plan.summary.high_confidence, color: CONFIDENCE_COLOR.high },
              { label: 'Medium Confidence', value: plan.summary.medium_confidence, color: CONFIDENCE_COLOR.medium },
              { label: 'Low Confidence', value: plan.summary.low_confidence, color: CONFIDENCE_COLOR.low },
              { label: 'Flagged for Review', value: plan.summary.flagged_for_review, color: urgency.high.fg },
            ].map(box => (
              <div key={box.label} style={{ border: `1px solid ${neutral[200]}`, borderRadius: 10, padding: 12 }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: neutral[400], textTransform: 'uppercase', marginBottom: 4 }}>{box.label}</div>
                <div style={{ fontSize: 22, fontWeight: 700, color: box.color || ink }}>{box.value}</div>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <select value={confidenceFilter} onChange={e => setConfidenceFilter(e.target.value)}
                aria-label="Filter by confidence"
                style={{ border: `1px solid ${neutral[200]}`, borderRadius: 8, padding: '6px 10px', fontSize: 13 }}>
                <option value="">All Confidence Levels</option>
                <option value="high">High Confidence</option>
                <option value="medium">Medium Confidence</option>
                <option value="low">Low Confidence</option>
              </select>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                <input type="checkbox" checked={flaggedOnly} onChange={e => setFlaggedOnly(e.target.checked)} />
                Flagged only
              </label>
            </div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>
              Total: {fmtNum(totalEffective)} L
              {Object.keys(edited).length > 0 && <span style={{ color: neutral[500], fontWeight: 400 }}> (edited)</span>}
            </div>
          </div>

          {/* ── Site table ── */}
          <div style={{ border: `1px solid ${neutral[200]}`, borderRadius: 12, overflow: 'auto', maxHeight: 560, marginBottom: 16 }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead style={{ position: 'sticky', top: 0, background: neutral[50], zIndex: 1 }}>
                <tr>
                  {['Site', 'Cluster', 'CPH', 'Grid Avail.', 'Engineering Est. (L)', 'Recent Trend (L)', 'Variance', 'Confidence', 'Budget (L)'].map(h => (
                    <th key={h} style={{ textAlign: 'left', padding: '8px 10px', borderBottom: `1px solid ${neutral[200]}`, color: neutral[500], fontWeight: 700, whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(s => (
                  <tr key={s.site_id} style={{ borderBottom: `1px solid ${neutral[100]}`, background: s.flag ? '#fffbeb' : undefined }}>
                    <td style={{ padding: '7px 10px' }}>
                      <div style={{ fontWeight: 600 }}>{s.site_name || s.site_id}</div>
                      <div style={{ color: neutral[400], fontSize: 10 }}>{s.site_id}</div>
                    </td>
                    <td style={{ padding: '7px 10px' }}>{s.cluster || '—'}</td>
                    <td style={{ padding: '7px 10px' }}>{fmtNum(s.genset_cph, 2)}</td>
                    <td style={{ padding: '7px 10px' }}>{s.final_grid_availability != null ? `${(s.final_grid_availability * 100).toFixed(1)}%` : '—'}</td>
                    <td style={{ padding: '7px 10px' }}>{fmtNum(s.engineering_estimate_l)}</td>
                    <td style={{ padding: '7px 10px' }}>
                      {s.trend_l != null ? fmtNum(s.trend_l) : <span style={{ color: neutral[400] }}>no history</span>}
                    </td>
                    <td style={{ padding: '7px 10px' }}>
                      {s.variance_pct != null ? (
                        <span style={{ color: Math.abs(s.variance_pct) > 40 ? urgency.critical.fg : Math.abs(s.variance_pct) > 15 ? urgency.high.fg : urgency.ok.fg, fontWeight: 700 }}>
                          {s.variance_pct > 0 ? '+' : ''}{s.variance_pct}%
                        </span>
                      ) : '—'}
                    </td>
                    <td style={{ padding: '7px 10px' }}>
                      <span style={{ color: CONFIDENCE_COLOR[s.confidence || ''] || neutral[500], fontWeight: 700, textTransform: 'capitalize' }}>
                        {s.confidence || '—'}
                      </span>
                      {s.flag && <div title={s.flag} style={{ fontSize: 10, color: '#92400e', marginTop: 2, maxWidth: 220 }}>{s.flag}</div>}
                    </td>
                    <td style={{ padding: '7px 10px' }}>
                      <input
                        type="number" min={0}
                        value={effectiveLiters(s)}
                        onChange={e => setEdited(prev => ({ ...prev, [s.site_id]: Number(e.target.value) }))}
                        aria-label={`Budget liters for ${s.site_id}`}
                        style={{
                          width: 90, border: `1px solid ${edited[s.site_id] != null ? '#2563eb' : neutral[200]}`,
                          borderRadius: 6, padding: '4px 8px', fontSize: 12, fontWeight: 700,
                        }}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {unplannable.length > 0 && (
            <div style={{ border: `1px solid ${neutral[200]}`, borderRadius: 12, padding: 14, marginBottom: 20, fontSize: 12 }}>
              <div style={{ fontWeight: 700, marginBottom: 6 }}>{unplannable.length} site(s) skipped — no engineering data on file</div>
              <div style={{ color: neutral[500] }}>
                {unplannable.slice(0, 15).map(s => s.site_id).join(', ')}{unplannable.length > 15 ? ` … and ${unplannable.length - 15} more` : ''}
              </div>
            </div>
          )}

          <Btn variant="primary" onClick={handleCommit} loading={committing} disabled={sites.length === 0}>
            ✓ Commit Plan to {selectedKey}
          </Btn>
        </>
      )}

      {!loading && !plan && (
        <EmptyState icon="🧮" title="No plan generated yet" desc="Select a cycle and click Generate Plan to see automated per-site budget recommendations." />
      )}
    </div>
  );
}
