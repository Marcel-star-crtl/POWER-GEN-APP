# Historical Email Data — Source Files

## Verifying everything actually landed in the database

`node scripts/verifyHistoricalDataImports.js` checks the real, live
document count in every historical-recovery collection against what
each import script actually reported the last time it ran
successfully — directly against MongoDB, no frontend or API involved.
Exits with a non-zero status if anything is off, so it can be used as
a genuine pass/fail check, not just something to read. Run this any
time after a batch of `--confirm` runs, especially after a connection
error or a retry, to know for certain everything landed rather than
checking the UI page by page.

Real files recovered from email archives (Phases 57–61), used to
reconstruct historical diesel budget/consumption/emergency-request data
that predates this system. Every file here is a verified, real
attachment — not a synthetic sample.

## Actively used by an import script

| File | Used by | Role |
|---|---|---|
| `Dec2025_Validation.xlsx` | `importHistoricalEmailData.js` | December 2025 monthly reconciliation |
| `Jan2026_Validation.xlsx` | `importHistoricalEmailData.js` | January 2026 monthly reconciliation |
| `Feb2026_Validation.xlsx` | `importHistoricalEmailData.js` | February 2026 monthly reconciliation |
| `Apr2026_Validation.xlsx` | `importHistoricalEmailData.js` | April 2026 monthly reconciliation |
| `May2026_Validation.xlsx` | `importHistoricalEmailData.js` | May 2026 monthly reconciliation |
| `Jul2026_Validation.xlsx` | `importHistoricalEmailData.js` | July 2026 monthly reconciliation |
| `Aug2026_Validation.xlsx` | `importHistoricalEmailData.js` | August 2026 monthly reconciliation (Phase 172 — see the dedicated August section below for the methodology change, cross-validation, and still-outstanding sign-off). `headerRowIndex: 2` (one row lower than every other month), `final_dg_cph`/`rh_variance`/all four `fuel_qty_*` fields genuinely null (`OPTIONAL_FIELDS`) — deliberately dropped under the new load-based methodology, not a parsing gap. No budget source wired for this month (`BUDGET_MONTH_LABELS` has no `2026-08` entry, same fallback path already used for December 2025) — `budget_liters`/`reserve_liters`/`fully_exhausted` are null, same as every other month without a dedicated budget column. |
| `MultiMonth_Budget_JanJul.xlsx` | `importHistoricalEmailData.js` | Budget (requested) figures, January–July 2026 — the primary budget source for every recovered month (see below for why) |
| `AdHoc_SpecialRefueling_Latest.xlsx` | `importAdHocFuelRequests.js` | Emergency/ad-hoc fuel requests, 26 July – 5 August 2026 |
| `MidCycleRelease_Aug2026_Latest.xlsx` | `importMidCycleBudgetRelease.js` | August 2026's mid-cycle partial budget release, tiered 50%/80% — now the 24-August snapshot (Phase 170; the earlier 05-August version this filename pointed to is kept as `MidCycleRelease_Aug2026_V1_ARCHIVE.xlsx`, unused). 164 sites, 191 cluster-day Recap records, 111,988L delivered against 96,341L released as of 24-August. |
| `MidCycleRelease_Aug2026_V1_ARCHIVE.xlsx` | *(none — superseded)* | The original 05-August mid-cycle release snapshot, kept for reference only after `MidCycleRelease_Aug2026_Latest.xlsx` was updated to the far-more-complete 24-August version (Phase 170) |
| `TomCard_Allocation_Dec2025.pdf` | `importTomCardAllocation.js` | Cluster-level fuel card funding request for January 2026's cycle — a real PDF, not a spreadsheet |
| `CardLimit_Jul2026.xlsx` | `importCardLimitData.js` | July 2026's cluster card budget/limit — found via a deeper search after the user confirmed this data existed under different naming (source: "Book23.xlsx", from the same "GRATO July Diesel Budget" thread as the multi-month budget rollup). Cross-checked against the already-imported BudgetRequestApproval data: its 116,342L budget figure matches that file's "total approved" figure for July exactly. |
| `JunJul2026_Purchases_1.xlsx`, `JunJul2026_Purchases_2.xlsx` | `importHistoricalFuelPurchases.js` | Standalone "GRATO PURCHASE" thread files (source: "Book8.xlsx", "Book15.xlsx") — found the same way. Together span 26 June through 3 August 2026 continuously, closing June's purchases gap entirely (no Validation file exists for June at all) and extending July's purchases coverage beyond what July's own Validation file has (which has no Purchases sheet). Each row's own date determines its month, since a single file spans a month boundary. |
| `CardLimit_Aug2026.xlsx` | `importCardLimitData.js` | August 2026's cluster card budget/limit — uploaded directly by the user (source: "Book3.xlsx"). Total budget (108,832L) cross-checked against a figure the live dashboard had already shown months earlier for August's cycle — matches almost exactly, independent confirmation from a source outside this recovery effort entirely. Introduced a real bug fix: its "New Card Number" header has an internal `\r\n` that plain `.trim()` doesn't remove (only strips edges) — `findCol` across this script now normalizes all internal whitespace, not just leading/trailing. |
| `EstimatedBudget_Aug2026.xlsx` | `importBudgetRequestApproval.js` | August 2026's estimated budget — uploaded directly by the user. Structurally different from July's request/approval file: no "SBC Request" column exists at all, only a single estimated/approved figure per site. `sbc_requested_l` is genuinely `null` for every August record — not a parsing gap, the source document simply doesn't have a request side to report. Total (126,775L) matches the source file's own embedded summary total exactly. |
| `EstimatedBudget_Sep2026.xlsx` | `importBudgetRequestApproval.js` | September 2026's estimated budget (Phase 170 — source: "GRATO Estimated Budget September 2026.xlsx", the "September Diesel Budget" email thread, received 2026-08-18, before the September cycle opened). Same shape as August's file — `sbc_requested_l` genuinely null, only an estimated/approved figure per site. 164 sites, 120,821L total. The source sheet also carries a separate "September-26 DIESEL BUDGET - New CPH" column, deliberately not used — `budgetColumn` matches the exact "-26 DIESEL BUDGET (L)" pattern August's file used, not the New-CPH variant. |

## March 2026 — the full reconciliation file found (Phase 83)

A seventh email batch (127 genuinely new emails) surfaced something
repeatedly concluded to be genuinely absent in every earlier phase: a
real monthly reconciliation file for March, with the same sheet family
as every other confirmed month (Main, Analysis, Validation, Debit,
Purchases breakdown), plus its own real sign-off PDF (dated 25 March
2026, verified by reading it directly).

| Sheet | What it added | Script |
|---|---|---|
| Validation | Real consumption/reconciliation, 164 sites — replaces the earlier budget-only placeholder from Phase 76 | `importHistoricalEmailData.js` |
| Main | 890 field visits, 641 with real fuel delivered | `importHistoricalFieldVisits.js` |
| Analysis | 105 sites flagged "CMS Team to investigate" | `enrichHistoricalRecordsWithAnalysis.js` |
| Debit | Submitted 101,742L / Approved 99,499L, -12.1M XAF | `importMonthlyDebitSummary.js` |
| Purchases breakdown (Update) | 138 real transactions, 115,240L — matches the Debit sheet's own "Purchases (L)" figure exactly | `importHistoricalFuelPurchases.js` |

**A real correction, caught and fixed properly, not silently
overwritten**: discovering this file surfaced that the multi-month
rollup's own "Total March-26 Budget given to the SBCs (L)" column had
been present the whole time (`BUDGET_MONTH_LABELS` already mapped it) —
but was never actually used, because March had no `importHistoricalEmailData.js`
entry until now. The earlier standalone March budget import (Phase 76)
had been treating the "Requested Quantity" figure from a *different*
file as if it were the approved budget. Cross-checked the two site by
site before assuming either was right: only 27 of 164 sites agreed —
consistent with these being genuinely different concepts (a request vs.
what was actually given), the same relationship already found for
February and April. March moved into `pairSbcRequestWithExistingApproval.js`
alongside them — its real request/approval pair (117,107L requested vs.
112,498L approved) is now in `BudgetRequestApproval`, and
`HistoricalMonthlyRecord.budget_liters` for March is now correctly
sourced from the rollup, consistent with every other month.

## June's Card Limit and May's Request/Approval — found the same batch (Phase 83)

| File | Script | What it is |
|---|---|---|
| `CardLimit_Jun2026.xlsx` (source: "Book12.xlsx") | `importCardLimitData.js` | June's cluster card budget. A more complete, later version of the same data found in an earlier "GRATO June-26 Budget.xlsx" (verified by comparing the two directly — the earlier file is a genuine subset of this one). Also carries real "exceeding purchases" detail with human-written explanatory comments per cluster. Total (61,410L) matches the already-verified, corrected June approved figure from Phase 81 exactly — strong independent confirmation from a completely different document. **Note**: this file's own "New limit" column header literally reads "26/04/2026," a copy-paste leftover from an earlier month's template — verified directly, not assumed; the column's position and values are still genuinely June's, `newLimitDate` is left `null` since the header text itself can't be trusted for that one field. |
| `SbcBudget_May2026.xlsx` | `pairSbcRequestWithExistingApproval.js` (now covers Feb/Mar/Apr/May) | May's requested budget, paired with May's already-imported approved figure from the rollup (135,485L requested vs. 95,295L approved) — the same request/approval relationship already established for the other months. |

## 2025 — an entire previously-untouched year (Phase 88, in progress)

An eighth email batch surfaced real, sign-off-attested Validation files
for April through November 2025 — an entire year predating this
recovery effort's earlier earliest month (December 2025). No March 2025
file exists; a "Kick off meeting Grato Sagemcom" email dated March 2025
suggests the relationship itself started then, consistent with April
being the first month with real reconciliation data.

**A real refactor, not a workaround**: the 2025 templates use several
different column names for the same concepts across different months —
checked all 8 months' headers directly rather than assumed consistency
with the 2026 format. June 2025 uses "IHS ID" instead of "I.H.S SITE
ID"; May through August 2025 use "QTY OF FUEL PREVIOUSLY Left" / "Fuel
Qty Added (L)" instead of the shorter 2026-era names; April 2025 uses
entirely different names ("PREVIOUS DIESEL LEVEL Found" / "ACTUAL
DIESEL LEVEL Found") for the same two fields. `importHistoricalEmailData.js`'s
column mapping was rebuilt to support multiple candidate names per
field, tried in order, rather than one fixed name — verified this
didn't change anything for the already-confirmed 2026 months before
trusting it for the new ones (identical 1,312-record output for those
8 months, unchanged). April and September 2025 have no standalone "SBC"
column at all — every other month's own SBC column has held "GRATO" for
every row throughout this entire project, so a documented fallback is
used only where genuinely no column exists, not as an override.

| Month | Sites | Sign-off | Notes |
|---|---|---|---|
| Apr 2025 | 246 | ✅ 25/04/2025, verified | No SBC column — fallback applied |
| May 2025 | 247 | ✅ 25/05/2025, verified | |
| Jun 2025 | 245 | ✅ verified | Uses "IHS ID" for site ID |
| Jul 2025 | 248 | ✅ verified | |
| Aug 2025 | 249 | ✅ verified | Only a V3.0 file found, no Vf |
| Sep 2025 | 182 | ✅ verified | No SBC column — fallback applied; large site-count drop begins here |
| Oct 2025 | 173 | ✅ verified | |
| Nov 2025 | 173 | ✅ verified | |

**The large site-count drop between August (249) and September (182)
is real, not a parsing error** — consistent with a previously-known
pending cluster deactivation (Kribi 1/2, Yassa) this project has
referenced since early phases; September's own file even has a sheet
named "Kribi and yassa stock handover."

**Status: Complete for the four largest sheets (Phase 90).** Validation,
Main (field visits), Analysis, and Debit are imported for all 8 months.
Purchases is imported for 7 of 8 (November genuinely has no Purchases
sheet at all). Real structural differences were found and handled
along the way, not smoothed over: June uses "IHS ID" throughout,
July's Analysis sheet has a literal trailing space in its name, April
2025's Debit sheet has its header at a different row than every other
month, and April/May use a singular "Purchase" sheet name with several
different column names for the same concepts (a real gap in the
existing sheet-lookup fallback, since it could only ever match plural
variants).

**Not yet explored for 2025**: Card Limit / funding documents, ad-hoc
emergency requests, and various smaller one-off sheets specific to
individual months (e.g. April's "Fuel Theft" and "Overloaded" sheets,
May's "Renau IHS Sup conso") — seen during the original survey, not
investigated.

## July 2026 — a more complete revision found, closing another documented gap (Phase 87)

The V1.0 file this system had been using for July had no Debit or
Analysis sheet, and no sign-off document was ever found for it — all
three were previously documented as genuine, confirmed gaps. A newer
V2.0 revision, found in this batch, has all three.

**Verified as a safe replacement before switching anything**: compared
all 164 sites' "Final Cons" figures between the old V1.0 and new V2.0
Validation sheets — exact match on every one. This is the same
underlying data, completed with sheets that hadn't been sent yet when
V1.0 first went out, not a conflicting revision.

| Sheet | What it added | Script |
|---|---|---|
| Sign-off PDF | Real attestation, dated 25 July 2026 — read directly, same format as every other confirmed month | `importHistoricalEmailData.js` (`signOff: 'signed_off'`, was `'draft'`) |
| Debit | Submitted 110,519L / Approved 93,945L, -37.6M XAF — the largest single-month debit found anywhere in this recovery effort | `importMonthlyDebitSummary.js` |
| Analysis | 73 sites flagged "CMS Team to investigate" | `enrichHistoricalRecordsWithAnalysis.js` |
| Purchases breakdown (Update) | 161 transactions, 142,623L | `importHistoricalFuelPurchases.js` |

**A real overlap found and resolved, not silently double-counted**:
July's new embedded Purchases sheet covers 26 June–25 July — the exact
same window already covered by the standalone "Book8"
(`JunJul2026_Purchases_1.xlsx`) and "Book15"
(`JunJul2026_Purchases_2.xlsx`) files imported in Phase 73. Compared the
two sources directly before deciding what to do: 161 vs. 160
transactions, 142,623L vs. 142,473L — a ~0.1% difference, genuinely the
same underlying transactions, not two different datasets. Importing
both would have double-counted roughly 142,000L. The embedded sheet
(part of the official signed-off file) is now authoritative for July;
July-dated rows are excluded from both standalone files to avoid the
duplication — June's and August's non-overlapping portions of those
same files are unaffected.

The old V1.0 file is kept as `Jul2026_Validation_V1_ARCHIVE.xlsx` for
provenance, not deleted.

## March 2026 — found after the user provided a third email batch (Phase 76)

Earlier phases confirmed no monthly *reconciliation* file exists for
March (Phase 63/73, verified by actual email send date, not just
subject keyword). That finding still stands — but a third batch of
emails, genuinely new (verified by content hash, not previously seen),
surfaced a different kind of March data entirely: a budget planning
file and a real shortage-response event with its own multi-round
tracking.

| File | Script | What it is |
|---|---|---|
| `GRATO_SBC_DIESEL_BUDGET_March_2026.xlsx` | `importMarch2026Budget.js` | Uploaded directly by the user. 165 sites, "Requested Quantity (L)" and "Budget (XAF)" — March's budget, but no consumption data of any kind exists alongside it, so `HistoricalMonthlyRecord`'s consumption/reserve fields are deliberately left null for every March record. |
| `MarExtra2_17Mar2026.xlsx`, `MarExtra3_23Mar2026.xlsx`, `MarExtra4_24Mar2026.xlsx` | `importMarch2026ExtraFuelRequests.js` | Three of four numbered rounds in March's own shortage-response event (subjects: "GRATO 2nd/3rd/4rd Extra Fuel Request"). Richer than the original July/August ad-hoc data — includes an approval figure ("SS approval") and actual delivered quantity ("Extra Given") per site, where the source has them. The "1st" round (referenced by context inside these files and the estimate-to-close snapshot below) was never found as a standalone attachment in any recovered email — not fabricated or reconstructed here. |
| `MarEstimateToClose_19Mar2026.xlsx` | `importMarch2026EstimateToClose.js` | A genuinely different document type — a working "where do we stand" snapshot from 19 March, combining initial budget, both extra rounds already given, and actual refueling done into one running balance per site (77 sites). Not a formal reconciliation; a mid-cycle status check. Modeled separately (`MidCycleEstimateSnapshot`) since it doesn't fit any existing collection's shape. |

**Still not found**: standalone attachments for the "SBC DIESEL BUDGET
MARCH 2026: CARD LIMIT UPDATE" email thread — the thread exists, but
every email seen for it is a reply with no attachment; the original
message carrying the actual file wasn't in what was provided. (April's
equivalent thread WAS resolved — see below.)

## April 2026 — found in a fourth email batch (Phase 78)

A fourth batch (92 genuinely new emails) surfaced April's own version
of the same kind of shortage-response event already found for March,
plus April's Card Limit data — found under a "MAY 2026" email subject,
but the file's own content clearly says April; trusted over the
subject line.

| File | Script | What it is |
|---|---|---|
| `CardLimit_Apr2026.xlsx` (source: "Book11.xlsx", "Limit" sheet) | `importCardLimitData.js` | April's cluster card budget. Genuinely different structure from every other Card Limit source — header at row 3, not row 0, with 6 leading blank columns. Total (95,295L) is consistent with the range of every other month's Card Limit total. |
| `AprExtra1_13Apr2026.xlsx`, `AprExtra2_14Apr2026.xlsx`, `AprExtra3_22Apr2026.xlsx` | `importMarch2026ExtraFuelRequests.js` (now covers both months) | April's own three-round shortage-response event. Multiple revisions of each round existed in the archive (different hashes, not duplicates) — the latest version of each was identified by tracing every attachment back to its exact source email and date, not by filename guessing. |

**A real source-file date bug found and fixed, not silently trusted**:
April's 2nd round file has a "Date" column that's a fixed, identical
serial value (45396 = 14 April **2024**) for every single one of its 70
rows — not a per-row real date, verified directly against the raw
cells. A month-consistency check added to the parser caught this
automatically (comparing each row's actual date against the file's
configured cycle month). Rather than trust a demonstrably wrong year or
guess a per-row date that was never actually entered, this specific
file falls back to its own known email-send date (14 April 2026) — the
closest real, verifiable reference point available. Every other
quantity in the file was unaffected; only the date field had this
issue.

## June 2026 — budget found, other June data still open

| File | Script | What it is |
|---|---|---|
| `EstimatedBudget_Jun2026.xlsx` | `importBudgetRequestApproval.js` (generalized from an August-only script to a config-driven one) | June's estimated budget, same shape as August's. Uses May's actual run-hours as its basis ("RH MAY -26" column) rather than its own cycle's — verified this is the file's own real column name, not a labeling assumption. |

**"Daily Refueling Report of June-2026 Cycle.xlsx" — checked and
correctly NOT imported.** Its region/team list (Maroua, Bamenda, Buea,
Bertoua, Batouri, Mokolo, Limbe, Tibati, Mbanga, Mamfe, Abong Mbang —
spanning South West, Adamawa, Far North, East, West, North West) does
not match GRATO's known operational area (Littoral: Bonaberi, Edea,
Pouma, Kotto, Ndogbong). Very likely another SBC's report that ended up
in the same mailbox — excluded deliberately, not an oversight.

| File | Script | What it is |
|---|---|---|
| `JuneFuelPlan_PlannedVsSupplied.xlsx` (source: "20260526_GRATO_FUEL PLAN JUNE-26.xlsx", "ALL DATA" sheet) | `importPlannedVsSuppliedDeliveries.js` | Per-site planned-vs-actual delivery with an explicit gap classification. Genuinely spans 26 May through 29 June 2026 in one sheet, not just June despite the filename. 114 real records (245 raw rows total — the other 131 have no completion date, meaning they were still-planned deliveries not yet done at export time, correctly excluded). **A genuine, unreconciled discrepancy found and documented, not resolved by guessing**: this workbook's per-day tabs do not cleanly reduce to "ALL DATA" filtered by date (checked directly — 26 May's day-tab has 83 real rows, "ALL DATA" filtered to the same date has only 47). "ALL DATA" was used as the source since it's the one sheet covering the full date range in one place, but the day-tabs may hold additional records not reflected in this import. |

**Found but not yet investigated further**: June's own 4th extra-fuel-
request round (a genuinely different column structure than March/
April's — not yet parsed). Also found but not yet checked: files
referencing April/May consumption comparisons, site risk flags, and
"Manutention" (handling) fees for June and July — a cost category not
previously seen anywhere in this recovery effort.
| `BudgetRequestApproval_Jul2026.xlsx` | `importBudgetRequestApproval.js` | Site-level "SBC Request" vs. IHS Towers-approved budget for July 2026 — the actual request/approval exchange, done by email directly with IHS Towers, not through this system. Cross-checked against the multi-month rollup's own July column before use: 95.1% exact match across all 164 common sites. **Provenance note**: unlike every other file in this folder, this one was uploaded directly by the user, not recovered from either email batch — its exact source email in the user's mailbox hasn't been traced. |

Plus, from the deeper multi-sheet investigation (Phases 67–70) —
detailed below: `importMonthlyDebitSummary.js`,
`importHistoricalFieldVisits.js`, `importHistoricalFuelPurchases.js`,
`enrichHistoricalRecordsWithAnalysis.js`, `importCardLimitData.js`,
`importHistoricalSiteStockSnapshots.js`, and the Service Desk merge
inside `importMidCycleBudgetRelease.js`.

## The monthly validation files have more sheets than were ever used — the full investigation, sheet by sheet

Every `[Month]_Validation.xlsx` file was only ever read from its
"Validation" sheet until Phases 67–70 went back through **every single
sheet in every file**, at the user's explicit request that no data be
treated as too small to check. Final disposition of every sheet found:

**Imported, real data:**
- **Debit** (fleet-level monthly settlement) — `importMonthlyDebitSummary.js`.
- **Main** (individual field-visit records, ~5,600 across all six
  months) — `importHistoricalFieldVisits.js`. Checked every column's
  real fill rate first: dates, meters, run-hours, and fuel-added are
  genuinely well-populated (71–100%), but "Theft (L)," "Gap CPH
  Variation," "Qty Consumed (L)," and both comment columns were checked
  across all six months and found **100% empty everywhere** — theft
  detection was part of the template but never actually used during
  this period. Not included as fields; permanently-null columns add
  clutter, not information.
- **Purchases** / "Purchases breakdown" (826 transactions across 5
  months, including one Storage Tank Usage record folded in) —
  `importHistoricalFuelPurchases.js`.
- **Analysis** (enrichment, not a fresh import) —
  `enrichHistoricalRecordsWithAnalysis.js`. A 52-column superset of
  Validation; checked every "100%-filled" comment column's actual value
  distribution before including anything, since several turned out to
  be placeholder noise (e.g. "Site Comment" is the literal number `0`
  for 155 of 164 December sites). Three genuinely meaningful fields
  added to existing `HistoricalMonthlyRecord` documents: whether a site
  needs CMS investigation, which generator-capacity source is trusted,
  and real site lifecycle notes where they exist.
- **HO Stock** (Dec, 9 sites), **BB Site Stock** (Apr, 25 sites),
  **Stock Usage** (May, 5 "Small Tank" sites) — one-off, site-level
  stock snapshots, structurally different documents unified under one
  model — `importHistoricalSiteStockSnapshots.js`.
- **Card Limit** (in `Jan2026_Budget.xlsx`, December's cluster-level
  card budget/limit tracking) — `importCardLimitData.js`. Genuinely
  different row alignment than every other file (header at row 0, not
  row 1) and a real duplicate column header in the source, both
  verified directly before writing the parser.
- **Service desk Recap** (in the mid-cycle release file) — merged into
  the existing `importMidCycleBudgetRelease.js`, not a separate import.
  **A real, unresolved discrepancy found**: this sheet and the main
  "Recap" sheet report *different delivery figures* for the same
  cluster on the same day (e.g. Bonaberi 1, 26 July: 1,370L in Recap vs.
  1,433L here) — both numbers are kept, side by side, not reconciled to
  one, since there's no way to determine from the data alone which
  team's tracking is correct.

**Investigated, genuinely not importable — engineering reference material, not records:**
- **Conversion Table**, **Reference**, **Table**, **Final CPH Table**
  (May only) — checked their full contents directly. All four are
  static engineering lookup tables (generator-capacity-to-CPH
  conversion factors, topology-to-fueling-formula mappings) that the
  spreadsheet's own formulas pull from — not site-specific or
  time-specific operational records. `Final CPH Table` in particular
  has a startling ~151,885-row dimension; opened it and confirmed it's
  a mathematically-generated table covering every possible generator
  capacity/load combination, not real data.

**Investigated, real data found, deliberately not imported — genuine unresolved discrepancies:**
- **Matrix Cons (Approved)** (May) — initially deprioritized in Phase
  67 over a `#REF!` error; checked again properly this time rather than
  leave that assumption unverified, and found the error is isolated to
  one broken summary cell — the 164 actual site rows are clean. But
  cross-checking its "Approved May-26 Cons" figure against the
  already-imported Validation sheet's "Final Cons" for the same sites
  revealed **real, unexplained differences** (e.g. site IHS_EDA_019:
  2,409.68L here vs. 1,665L in Validation). This looks like a
  forward-looking June-planning document that carries its own May
  baseline, not necessarily the same authoritative figure used in May's
  actual sign-off. Documented as a genuine data inconsistency between
  two internal tracking documents, not silently imported as agreeing
  additional data.
- **Diesel Validation (Canceled)** (May) — has substantial real data,
  but uses an entirely different validation methodology (grid/ENEO
  KWH-based cross-checking of expected diesel consumption, rather than
  the fuel-level-based method used everywhere else) and is explicitly
  labeled "Canceled" in its own sheet name. Read in full: appears to be
  an alternative approach that was tried for May and then abandoned in
  favor of the standard method. Valuable as investigative context — it
  shows a real methodology that was tested and rejected — but not
  imported as reliable data.

## Sign-off evidence — read directly, not inferred from spreadsheet filenames

`importHistoricalEmailData.js` sets `sign_off_verified: true` only for a
month where one of these was actually opened and read. A spreadsheet's
own filename (e.g. "Vf" for "final") was found to be an unreliable
signal on its own — see the May correction below.

| File | Month | What it shows |
|---|---|---|
| `SignOff_Dec2025.pdf` | Dec 2025 | Formal attestation document, signature lines for Diesel Manager / Operations Manager |
| `SignOff_Jan2026.pdf` | Jan 2026 | Same format, dated late January |
| `SignOff_Feb2026.pdf` | Feb 2026 | Same format — found despite the spreadsheet itself being labeled "V3.0" (not "Vf"), correcting an earlier assumption that "V3.0" meant draft |
| `SignOff_Apr2026.pdf` | Apr 2026 | Same format, same correction as February |
| `May2026_DisputeEvidence.png` | May 2026 | **Not** an attestation — a screenshot from a later (20 July) thread showing multiple sites with unresolved SBC comments and "NOK" (rejected) engineering feedback, despite the spreadsheet's own "Vf" filename. This is why May is marked `pending_site_disputes`, not `signed_off`, and why `sign_off_verified` is `false` for May even though evidence exists — the evidence shown is of a dispute, not a completed sign-off. |
| (none found) | Jul 2026 | No sign-off document of any kind found in either email batch — consistent with the spreadsheet's own "V1.0" (first draft) label |

## Present, but only partially referenced — the rest kept deliberately

| File | Status |
|---|---|
| `Jan2026_Budget.xlsx` | Its **"Card Limit" sheet is actively used** (`importCardLimitData.js`, December's cluster card budgets). Its **"Budget" sheet** — the original, standalone January 2026 budget file (Phase 57) — is no longer the *active* budget source (superseded once `MultiMonth_Budget_JanJul.xlsx` was recovered and found more complete, Phase 59), but is kept for provenance: it's what the multi-month file's January column was cross-checked against, which is how the "36% of sites differ, always higher, never lower" pattern was discovered. If this file is ever deleted, that finding can no longer be independently re-verified against its original source. |

## August 2026 — Validation imported; sign-off still outstanding (Phase 171 investigated, Phase 172 wired up and imported)

`Aug2026_Validation.xlsx` and `Aug2026_ValidationSignOff_UNSIGNED.pdf`
(source filenames: "GRATO Validation TEMPLATE  August 2026 V3.0.xlsx"
and "GRATO Validation Sign Off August 2026 V3.pdf" — previously staged
as `Aug2026_Validation_V3_PENDING_CORRECTION.xlsx` /
`SignOff_Aug2026_V3_UNSIGNED_PENDING.pdf` while the structural gap below
was unexplained) are now wired into `importHistoricalEmailData.js`'s
`MONTHS` array and dry-run verified: 164 site rows, no missing-column
errors.

Phase 171 found the `Validation` sheet structurally different from
every prior month and — correctly, per the project's standing "don't
guess" rule — held off rather than force a mapping:

1. Its real header row sits one row lower than every prior month's (an
   extra summary row above it — confirmed directly with the same
   `XLSX.utils.sheet_to_json` call the import script uses).
2. It uses `NEW IHS ID` instead of `I.H.S SITE ID` for the site key.
3. `Final Cons` and all four `QTY OF FUEL PREVIOUSLY/FOUND/ADDED/LEFT`
   columns are entirely absent.

**Phase 172 resolved why**, via `messagesources_86` — the original
email thread this file came from (Charles Gnouve/IHS Towers to
Dominique Assako and Minka Kevin/GRATO, 15 September 2026, "RE: GRATO
validation file August 2026"), recovered as its own archive and read in
full. IHS management (Dominique Assako) explicitly directed a
methodology change effective August/September/October: *"There is
nothing like gen CPH... consumption now depends on load, topology, grid
availability, and generator capacity."* That's a deliberate change, not
a broken file — so the missing columns above are handled as genuinely
optional for this month (`OPTIONAL_FIELDS` in the import script), not
forced or defaulted.

The replacement columns were cross-validated against two independent
sources before trusting them, the same standard used throughout this
project:
- `Approved August-26 Cons` (used for `final_consumption_l`) sums to
  exactly **99,800L** across all 164 rows — matching both the same
  file's own `Debit` sheet total and the sign-off PDF's printed
  "Approved Consumption (L)" figure.
- `SBC Submited Cons` (used for `sbc_consumption_l`) sums to exactly
  **110,280L** — matching "Submited Consumption" in both other sources
  the same way.
- All 164 `Validation` rows already carry `SBC === 'GRATO'` directly —
  no `Analysis DB` / multi-SBC filter is needed after all; that earlier
  concern is resolved.

**Sign-off remains genuinely outstanding.** The PDF was read directly —
not inferred from its "V3" filename — both as extracted text and as a
rendered page image (text extraction alone can't distinguish "blank" from
"signature image present"; the rendered page confirms it's truly blank,
no signature graphics). All five attestation lines (Officer Energy
Analysis, Manager Diesel, SM Grid & Diesel, Grato Diesel Manager, Grato
Operations Manager) are unsigned, and the most recent message in the
`messagesources_86` thread is IHS asking GRATO to *"kindly sign the
attached document and return it to us"* — as of that email, GRATO had
not yet done so. Imported with `sign_off_status: 'draft'` (closest fit
in the fixed schema enum) and `signOffPdf: null` /
`sign_off_verified: false`, the same honest-uncertainty treatment used
for May 2026's disputed sign-off — the consumption data is IHS's own
declared, cross-validated final figures, but the attestation itself is
not yet real. Re-check once (or if) a genuinely countersigned PDF
arrives; at that point `signOff` should move to `'signed_off'` and
`signOffPdf` should point at the real file.

## Not yet recovered (see the running checklist in `DIESEL_SYSTEM_CHANGELOG.md`)

- January's own request/approval-style budget file specifically (a
  "LEC Diesel Budget" file was found under a January search, but
  confirmed to belong entirely to a different vendor, "LEC CAM," not
  GRATO — see below)
- June and March's full monthly reconciliation (Debit, Analysis,
  per-visit data) — March's budget and April's shortage event are now
  covered; the reconciliation-style data for either month is not

Found during Phase 62's audit: this file was created because the
`Jan2026_Budget.xlsx` situation above had never been documented anywhere
— a new contributor (or a future audit) would have had no way to know
whether it was safe to delete without re-reading every changelog phase
from Phase 57 onward.

## January 2026 — a file found, checked, and correctly excluded (Phase 81)

A file titled "LEC Diesel Budget -JANUARY 2026.xlsx" surfaced while
searching for January's own budget data. Checked every row's SBC value
before assuming this was GRATO's January budget — 100% of its rows
belong to "LEC CAM," a completely different fuel-management vendor with
a different site set entirely (Akwa, Bepanda, Kribi 1/2, Yassa — none
of which appear anywhere else in this recovery effort). Not imported.

## December 2025 – August 2026 — a real correction and real additions (Phase 81)

Found via a large fifth email batch (478 genuinely new emails). This
phase both corrected a real, existing mistake and added new coverage.

| Month | What changed | Script |
|---|---|---|
| **June** | **Real correction, not an addition.** The earlier single-figure June import (`EstimatedBudget_Jun2026.xlsx`, now removed) was mislabeled — its figure matched the real "Submitted" (requested) column in a better source for 158 of 164 sites, and the true approved figure for zero. The real approved total is 61,410L against 132,762L requested — less than half approved, a genuinely significant finding. `RequestApproval_Jun2026.xlsx` replaces it as June's source. | `importBudgetRequestApproval.js` |
| **March** | Found the original "SBC DIESEL BUDGET MARCH 2026: CARD LIMIT UPDATE" email with its actual attachment (`Grato Mar-26 Budget.xlsx`) — the thread that was previously only found as a reply with no file. | `importCardLimitData.js` |
| **December, March** | Site-level budget request files. December's file has 184 sites — 20 more than the standard 164, confirmed by comparing site ID sets directly before trusting the larger count (all 164 original IDs are a genuine subset). | `importSbcBudgetFiles.js` |
| **February, April** | New request-side files found for both — checked against their already-imported approved figures first, and found genuinely different numbers (April: 107,996L requested vs. 137,746L already-approved; February: 127,274L vs. 134,081L). A real request/approval pair, not the same figure twice — the existing approved data was left untouched and paired with the new requested figure instead. | `pairSbcRequestWithExistingApproval.js` (new — writes to `BudgetRequestApproval` only, never touches `HistoricalMonthlyRecord`) |

## June 2026 — the biggest single find of this recovery effort (Phase 82)

A sixth email batch surfaced June's own full "Validation TEMPLATE" file
(three revisions found, V3.0 confirmed latest by email date) with its
real sign-off PDF — closing what had been the largest remaining monthly
gap. Same sheet family as every other month: Main, Analysis, Purchases
breakdown, Debit, Validation.

| Sheet | What it added | Script |
|---|---|---|
| Validation | Real consumption/reconciliation, 164 sites | `importHistoricalEmailData.js` |
| Main | 1,047 field visits, 808 with real fuel delivered | `importHistoricalFieldVisits.js` |
| Analysis | 115 sites flagged "CMS Team to investigate" | `enrichHistoricalRecordsWithAnalysis.js` |
| Debit | Submitted 126,183L / Approved 113,121L, -29.3M XAF | `importMonthlyDebitSummary.js` |
| Purchases breakdown (Update) | 212 real transactions, 26 May–25 June — checked its date range first, confirmed genuinely earlier than the already-imported standalone files' 26 June start, not a duplicate | `importHistoricalFuelPurchases.js` |

**June's `budget_liters` was deliberately left null** — four different
sources claim to be "June's budget" (61,410L from the verified
request/approval pair; 132,762L, the mislabeled figure already
corrected in Phase 81; 147,014L from the multi-month rollup; 113,121L,
which is actually post-cycle approved *consumption*, not the pre-cycle
budget). Rather than guess which one belongs in this field — and risk
repeating the exact mistake already caught once — none of them was
used. The two genuinely verified figures (request/approval and
Debit-sheet approved consumption) are both stored correctly in their
own proper places.

**Two real bugs caught and fixed while wiring this in**: June's Debit
sheet has its header at row 3, not row 1 like every other month
(verified directly, not assumed); its "Management Fees" column is
capitalized differently than every other month's "Management fees"
(would have silently returned null without a case-insensitive match);
and its embedded Purchases sheet uses "Card num**/**" with a trailing
slash, not "Card num" like the standalone files.

## Phase 88 — March's shortage-event gap fully closed

A seventh email batch (349 genuinely new emails) closed the one
remaining gap in March's shortage-response event.

| Find | What it is | Script |
|---|---|---|
| **March's "1st" round** (`MarExtra1_13Mar2026.xlsx`) | Genuinely missing since Phase 76 (through Phases 76, 81, and 86). Two versions existed in this batch; traced both to their exact source email and used the later, fully-approved one (61 sites, 100% filled). All four March rounds and all three April rounds are now complete. | `importMarch2026ExtraFuelRequests.js` |
| **February's Card Limit** (`CardLimit_Feb2026.xlsx`) | Confirmed correct — genuinely different row alignment than every other Card Limit source (header row 2, a third distinct variant). Whether this was first found in Phase 85's own work or this phase wasn't fully resolved; the current state was verified correct either way. | `importCardLimitData.js` |

**A false lead, checked and correctly rejected**: a file titled "GRATO
June-26 Budget.xlsx," under a "Card limit Update" subject, turned out
on inspection to be an earlier, less complete draft of the June
request/approval file already imported (missing the "Submitted" and
"Variance" columns entirely) — not a genuine Card Limit source. Not
imported.

**A real numbering mistake, caught and corrected, not left standing**:
this phase initially wrote a changelog entry claiming several things
(June's Card Limit, May's request/approval) as new discoveries, before
checking the changelog's actual current state and finding Phases 85-87
already existed and had genuinely already done that work — March's
entire monthly reconciliation (Phase 86) and July's Debit/Analysis/
sign-off (Phase 87), among other things. The incorrect entry was
removed, not silently kept alongside the real one.

**Also checked and correctly excluded as out of scope**: an August
2025 Validation file and an October 2025 Card Limit thread both
surfaced in this batch — both predate this project's tracked period
(December 2025 onward) and were not investigated further.

## Phase 101 — Five more months of shortage-response data, and a genuinely different second template

Fourteen more email batches (673 emails, 297 unique attachments) were
provided specifically to check for more extra-fuel-request data. A
large amount of it was 2025-dated (April, June, September, October,
November 2025) and correctly excluded as out of scope, same as Phase
88's precedent — but a substantial amount of genuinely new,
in-scope (Dec 2025 – Aug 2026) data was found.

| Month | Rounds found | Total requested | Script |
|---|---|---|---|
| December 2025 | 2 (16th, 22nd) | 26,502 L | `importMarch2026ExtraFuelRequests.js` |
| January 2026 | 1 (15th/19th) | 20,538 L | same |
| February 2026 | 3 (10th, 17th, 20th) | 82,713 L | same |
| June 2026 | 4th round | 6,532 L | same (Family 2, see below) |
| July 2026 | 1st round | 11,571 L | same (Family 2, see below) |

**Picked each round's best version by real fill rate, not by
timestamp.** Several rounds had 3-4 revisions sitting in the archive.
Checked every one directly rather than assume the chronologically
latest carries the most complete approval data — for February 10th's
round specifically, an *earlier* copy (10:13am) had more approvals
filled in (29 sites) than a *later* one from the same morning (11:13am,
21 sites). Used the more complete one.

**February's three rounds show 0 approvals in every single copy
checked** — a real, consistent finding across every revision, not a
fluke of which file was picked.

**A genuinely different second template family**, found for June's 4th
round and July's 1st round: real per-row dates (unlike the
December–February files below, which have none), a different site-ID
column ("NEW IHS ID" rather than "IHS ID" — verified against real data
that "SITE ID" in this template is a different, physical T-number code,
not the site_id scheme used everywhere else), and an approval column
that mixes real numbers with status text ("Approved", "Not approved").
"Not approved" was treated as a real 0 — an explicit decision was
made. The bare string "Approved" with no number was left null rather
than assumed to mean "the full requested amount" — that would be
inferring a figure the source never actually stated.

**A genuinely different first-family variant**, found for December,
January, and February: no per-row "Date" column exists in this
template at all (only "Last visit Date," a different field) — resolved
using each file's own known email-send date for every row, the same
principle already used for April's date-bug fix. Also: the real
approval figure lives in a column called "Qty to approve," not "SS
approval" (present in this variant but genuinely empty in every file
checked, not just assumed to be unused).

**Checked and correctly left alone**: June's 3rd round (an email
thread exists with that exact subject, but every copy found in this
batch has only inline images as attachments, not the actual file — the
same "thread exists, file doesn't" situation as several earlier gaps in
this project). A large family of "Daily Refueling Report" files for
June, a "Manutention" (handling fees) cost category for June/July, and
several June budget/limit files were also found in this batch but not
yet investigated — noted for a future phase, not silently dropped.

**Total `AdHocFuelRequest` collection after this phase: 1,266** — 284
from the original July/August shortage data (a separate script,
untouched), plus 982 now managed by
`importMarch2026ExtraFuelRequests.js` across 15 rounds spanning six
different months.

## Phase 102 — June's Card Limit tracker, extended mid-cycle with three extra-fuel rounds

User uploaded `June_Limits.xlsx` directly, asking specifically about
June's 3rd extra-fuel round (flagged as missing at the end of Phase
101). It turned out to be a later, richer snapshot of the exact same
running Card Limit tracker already in the system as
`CardLimit_Jun2026.xlsx` — verified the base numbers (budget per
cluster, recharge %, actual card limit) are identical between the two
files before treating them as the same document at different points in
time, not just assumed compatible from the filename.

**What the newer snapshot adds**: cluster-level approved amounts for
June's 1st, 2nd, and 3rd extra-fuel rounds, plus the card limit after
each round settled. This doesn't give site-level detail for round 3
(the actual per-site spreadsheet for that round is still missing — see
Phase 101), but it does give real cluster totals: Edea approved 8,500L
for round 3, Kotto 7,500L, the other five clusters show no round-3
approval in this source.

**A real regression caught before shipping, not after**: the new
snapshot's main sheet is missing Pouma 2/TRADEX entirely — it's
tracked on a separate "Tradex" sheet with a much sparser structure (no
budget or card-limit fields, only a single combined extra-fuel total
for the whole cycle, not split by round). Switching to the new file
naively would have silently dropped a cluster that the *original* file
did cover. Fixed by merging: Pouma 2's base budget/limit data now
comes from the original file (confirmed unchanged), with the new
file's Tradex-sheet total layered on as its extra-fuel figure.

**`TomCardAllocation` extended** with nine new fields (three per round:
approved liters, approved XAF, settled new limit) plus a comment field
— genuinely absent from every other month's Card Limit source checked
so far, left null everywhere else rather than assumed to generalize.

**Frontend**: the Tom Card Allocation section now shows a conditional
breakdown table for the extra-fuel rounds, but only for cycles that
actually have this data (currently just June) — not empty columns on
every other cycle's table.

**A real editing mistake caught and fixed within this same phase, not
carried into the delivered code**: an early version of the frontend
change accidentally deleted the closing tag for the section's outer
container div while adding the new table. Traced with a manual
stack-based trace of every div open/close in the section (not just
visual inspection) before concluding where the actual mismatch was, and
verified the fix against the real TypeScript compiler — zero errors —
not just a visual read-through.

**Total `TomCardAllocation` collection after this phase: still 57** —
June's cluster count stays at 7 either way (the merge fix restores what
the file swap would have otherwise dropped), so this phase changes
what the June records *contain*, not how many exist.

