// app/(technician)/maintenance-flow/checkout-site.tsx
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { patchMaintenanceWorkflowStatus } from "../../../services/offlineMaintenanceWorkflow";
import { Colors } from "../../../constants/Colors";
import { FontAwesome5 } from "@expo/vector-icons";

export default function MaintenanceCheckoutSiteScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{
    workflowId: string;
    maintenanceId: string;
    siteId: string;
    siteName: string;
  }>();

  const [loading, setLoading] = useState(false);

  const handleCheckout = async () => {
    const maintenanceId = params.workflowId || params.maintenanceId;
    if (!maintenanceId) {
      Alert.alert("Error", "Maintenance task ID missing.");
      return;
    }

    try {
      setLoading(true);

      // Always succeeds locally, online or offline -- updates the local
      // workflow cache immediately and queues the server PATCH against the
      // real endpoint (workflowId === maintenanceId, always a valid,
      // pre-existing server ID -- no client-id resolution needed here).
      await patchMaintenanceWorkflowStatus(maintenanceId, "checked_out", {
        checkedOutAt: new Date().toISOString(),
      });

      console.log(
        "[MaintenanceCheckout] Patched checked_out, maintenanceId:",
        maintenanceId
      );

      Alert.alert(
        "Checked Out",
        "You have successfully checked out of the site.",
        [
          {
            text: "OK",
            onPress: () => router.replace("/(technician)/dashboard"),
          },
        ]
      );
    } catch (err: any) {
      // patchMaintenanceWorkflowStatus itself doesn't throw for
      // connectivity reasons -- this only fires for a genuine unexpected
      // error, so it's safe to surface here.
      console.error("[MaintenanceCheckout] error:", err?.message);
      Alert.alert("Error", "Failed to save checkout.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.back}>
          <FontAwesome5 name="arrow-left" size={20} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Check Out</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.body}>
        <View style={styles.iconWrap}>
          <FontAwesome5 name="sign-out-alt" size={48} color={Colors.primary} />
        </View>

        <Text style={styles.siteName}>{params.siteName}</Text>
        <Text style={styles.siteCode}>{params.siteId}</Text>

        <View style={styles.infoCard}>
          <FontAwesome5 name="info-circle" size={16} color="#92400E" />
          <Text style={styles.infoText}>
            Checking out will mark your site visit as complete. Make sure you
            have submitted all equipment checks before checking out.
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.btn, loading && { opacity: 0.6 }]}
          onPress={handleCheckout}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.btnText}>Confirm Check Out</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.cancelBtn} onPress={() => router.back()}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, backgroundColor: "#F3F4F6" },
  header: {
    backgroundColor: Colors.primary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  headerTitle: { color: "#fff", fontSize: 18, fontWeight: "600" },
  back: { padding: 4 },
  body: { padding: 20, gap: 16, alignItems: "center" },
  iconWrap: { marginTop: 20, marginBottom: 8 },
  siteName: { fontSize: 22, fontWeight: "700", color: "#111827" },
  siteCode: { fontSize: 14, color: "#6B7280" },
  infoCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    backgroundColor: "#FEF3C7",
    borderRadius: 10,
    padding: 14,
    borderWidth: 1,
    borderColor: "#FDE68A",
    width: "100%",
  },
  infoText: { flex: 1, fontSize: 13, color: "#92400E", lineHeight: 20 },
  btn: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
    width: "100%",
    marginTop: 8,
  },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  cancelBtn: { paddingVertical: 12 },
  cancelText: { color: "#6B7280", fontSize: 15 },
});







